#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# SOW Portal — Cloudera CML Startup Script
# Deploy location: /home/cdsw/poc/sowa/
# Run as: Application Script in CML Project
# ─────────────────────────────────────────────────────────────────────────────
set -e

# ── Paths ────────────────────────────────────────────────────────────────────
PROJECT_ROOT="/home/cdsw/poc/sowa"
BACKEND_DIR="$PROJECT_ROOT/backend"

# CML injects CDSW_APP_PORT. Fall back to 8000 for local testing.
PORT="${CDSW_APP_PORT:-8000}"

echo "========================================================"
echo "  SOW Portal — CML Application Startup"
echo "  Project root : $PROJECT_ROOT"
echo "  Backend dir  : $BACKEND_DIR"
echo "  Port         : $PORT"
echo "========================================================"

# ── 1. Verify directory structure ────────────────────────────────────────────
echo ""
echo "[1/5] Checking project structure..."

if [ ! -f "$BACKEND_DIR/main.py" ]; then
    echo "ERROR: $BACKEND_DIR/main.py not found."
    echo "       Ensure the project is deployed at $PROJECT_ROOT"
    exit 1
fi

if [ ! -d "$PROJECT_ROOT/bos-portal" ]; then
    echo "ERROR: $PROJECT_ROOT/bos-portal/ not found."
    echo "       Copy bos-portal/ from local machine to $PROJECT_ROOT/"
    exit 1
fi

if [ ! -d "$BACKEND_DIR/admin-console" ]; then
    echo "ERROR: $BACKEND_DIR/admin-console/ not found."
    echo "       Copy admin-console/ from local machine to $BACKEND_DIR/"
    exit 1
fi

echo "      Structure OK"

# ── 2. Install Python dependencies ───────────────────────────────────────────
echo ""
echo "[2/5] Installing Python packages..."
cd "$BACKEND_DIR"

pip install -q --user -r requirements-cml.txt

echo "      Dependencies installed"

# ── 3. Configure paths ───────────────────────────────────────────────────────
echo ""
echo "[3/5] Configuring storage paths..."

SOW_DIR="${SOW_SESSIONS_DIR:-$PROJECT_ROOT/sow_sessions}"
mkdir -p "$SOW_DIR"
export SOW_SESSIONS_DIR="$SOW_DIR"
echo "      Session uploads : $SOW_DIR"

# ── 4. Configure database ────────────────────────────────────────────────────
echo ""
echo "[4/5] Configuring database..."

if [ -z "$DATABASE_URL" ]; then
    export DATABASE_URL="sqlite:///$PROJECT_ROOT/sow.db"
    echo "      Using SQLite    : $PROJECT_ROOT/sow.db"
else
    echo "      Using           : $DATABASE_URL"
fi

# ── 5. Start application ─────────────────────────────────────────────────────
echo ""
echo "[5/5] Starting uvicorn..."
echo ""
echo "  ┌────────────────────────────────────────────────────┐"
echo "  │  BOS Portal    → <CML App URL>/                    │"
echo "  │  Admin Console → <CML App URL>/admin/              │"
echo "  │  API Docs      → <CML App URL>/docs                │"
echo "  └────────────────────────────────────────────────────┘"
echo ""

cd "$BACKEND_DIR"

# PATH extension so pip --user installed binaries are found
export PATH="$HOME/.local/bin:$PATH"

exec uvicorn main:app \
    --host 0.0.0.0 \
    --port "$PORT" \
    --workers 1 \
    --loop asyncio \
    --log-level info
