/* ============================================
   BANK OF SINGAPORE — SOURCE OF WEALTH PORTAL
   Application Logic (5-Step Workflow)
   ============================================ */

const API_BASE = 'http://localhost:8000';

// ── DATA ─────────────────────────────────────────────────────────────────────

const USERS = {
  demo: { password: 'gdo2024', name: 'Demo', role: 'Private Client', initials: 'D' }
};

const SALARIED_DOCS = [
  { id: 'income_tax', title: 'Income Tax Returns / NOA', subtitle: 'Last 2 years', required: true, description: 'Provide your most recent Notice of Assessment (NOA) or income tax returns for the last two consecutive years to demonstrate your declared income.', examples: ['Notice of Assessment (NOA)', 'Income Tax Return (ITR)', 'e-Filing Acknowledgement'] },
  { id: 'payslips', title: 'Recent Payslips', subtitle: 'Last 3 months', required: true, description: 'Provide your three most recent monthly payslips from your current employer, showing your name, employer name, salary details and CPF contributions.', examples: ['Monthly payslip (Jan–Mar)', 'CPF contribution statement', 'Electronic payslip PDF'] },
  { id: 'employment_letter', title: 'Employment Letter', subtitle: 'Confirming salary & position', required: true, description: 'An official letter from your employer on company letterhead confirming your designation, employment start date, and gross monthly salary.', examples: ['Offer letter with salary', 'Employment confirmation letter', 'HR letter on letterhead'] },
  { id: 'bank_statements', title: 'Bank Statements', subtitle: 'Last 6 months', required: true, description: 'Recent 6-month bank statements showing regular salary credits from your employer. All accounts receiving salary must be included.', examples: ['DBS/POSB statement', 'OCBC statement', 'UOB statement', 'Overseas bank statement'] },
  { id: 'cpf_statement', title: 'CPF Contribution History', subtitle: 'Last 12 months', required: false, description: 'CPF contribution history for the last 12 months confirming employer and employee contributions consistent with declared salary.', examples: ['CPF statement via my.cpf.gov.sg', 'CPF annual history printout'] },
  { id: 'bonus_letter', title: 'Bonus / Variable Pay Documentation', subtitle: 'If applicable', required: false, description: 'Where sources of wealth include bonuses or variable compensation, provide supporting documentation confirming the amount and source.', examples: ['Bonus confirmation letter', 'RSU/ESOP vesting statement', 'Commission statement'] },
  { id: 'identification', title: 'Identity Document', subtitle: 'Passport or NRIC', required: true, description: 'A clear copy of your valid passport (biographical page) or NRIC (both sides). Document must be valid and not expired.', examples: ['Passport (bio page)', 'Singapore NRIC (front & back)', 'Employment Pass'] }
];

const BUSINESS_OWNER_DOCS = [
  { id: 'biz_reg', title: 'Business Registration / Incorporation Certificate', subtitle: 'Company registration documents', required: true, description: 'Official certificate of incorporation or business registration showing company name, registration number, date of incorporation, and registered address.', examples: ['ACRA BizFile printout', 'Certificate of Incorporation', 'Business Registration Certificate'] },
  { id: 'ownership_structure', title: 'Ownership / Shareholding Structure', subtitle: 'Shareholding chart or register', required: true, description: 'Document showing the complete ownership structure of the business, including all shareholders with name and percentage held. For complex structures, provide group-level chart.', examples: ['Shareholder register', 'ACRA shareholders listing', 'Group structure chart'] },
  { id: 'biz_financials', title: 'Audited Financial Statements', subtitle: 'Last 2 years', required: true, description: 'Signed audited or unaudited financial statements (balance sheet, P&L) for the last two financial years showing business revenue, profit and net assets.', examples: ['Audited accounts FY2022–2023', 'Unaudited management accounts', 'Financial summary letter from auditor'] },
  { id: 'bank_statements_biz', title: 'Business Bank Statements', subtitle: 'Last 6 months — company account', required: true, description: 'Six months of the company\'s primary operating bank account statements showing business transactions and cashflow.', examples: ['DBS business account statement', 'Corporate current account statement'] },
  { id: 'personal_bank_statements', title: 'Personal Bank Statements', subtitle: 'Last 6 months', required: true, description: 'Personal bank statements for the last six months showing directors\' fees, dividends, or salary received from the business entity.', examples: ['Personal DBS/OCBC statement', 'Foreign personal account statement'] },
  { id: 'dividend_record', title: 'Dividend Records', subtitle: 'If income via dividends', required: false, description: 'Board resolutions or dividend vouchers confirming dividend declared and paid to you from the company, with amounts and dates.', examples: ['Board resolution on dividends', 'Dividend vouchers', 'CDP dividend statement'] },
  { id: 'director_fee', title: 'Director Fee Evidence', subtitle: 'Director\'s remuneration proof', required: false, description: 'Documents confirming director\'s fees paid, such as board resolutions, service agreements, or IR8A forms.', examples: ['Director fee resolution', 'Service contract', 'IR8A from company'] },
  { id: 'tax_returns_biz', title: 'Corporate Tax Returns / NOA', subtitle: 'Last 2 years', required: true, description: 'Company income tax filings or Notice of Assessment (NOA) for the last two years, confirming taxable income declared by the business.', examples: ['Form C / C-S filing', 'Corporate NOA from IRAS', 'Tax clearance certificate'] },
  { id: 'biz_contracts', title: 'Material Business Contracts', subtitle: 'Key revenue contracts', required: false, description: 'Where business income derives from specific contracts or clients, provide redacted copies of key contracts demonstrating recurring revenue.', examples: ['Service agreements', 'Supply contracts', 'Retainer contracts'] },
  { id: 'asset_documents', title: 'Asset Ownership Documents', subtitle: 'Property, investments, etc.', required: false, description: 'Documents evidencing significant personal or business assets that form part of your wealth, such as property title deeds, investment portfolio statements, or vehicle valuations.', examples: ['Property title deed', 'Investment portfolio statement', 'Asset valuation report'] },
  { id: 'ubo_declaration', title: 'UBO Declaration Form', subtitle: 'Ultimate Beneficial Owner declaration', required: true, description: 'Completed and signed UBO declaration form identifying all ultimate beneficial owners holding 25% or more of the company, as required under MAS guidelines.', examples: ['Signed SOW UBO form', 'ACRA register of registrable controllers'] },
  { id: 'identification_biz', title: 'Identity Document', subtitle: 'Passport or NRIC', required: true, description: 'Valid passport (biographical page) or NRIC (both sides) of the business owner / director. Document must be current and unexpired.', examples: ['Passport (bio page)', 'Singapore NRIC (front & back)', 'Employment Pass'] }
];

const CATEGORY_ICONS = {
  'Personal Information': '\uD83D\uDC64',
  'Employment Income': '\uD83D\uDCBC',
  'Tax Assessment': '\uD83D\uDCCA',
  'Business Income': '\uD83C\uDFE2',
  'Property': '\uD83C\uDFE0',
  'Investments': '\uD83D\uDCC8',
  'Bank Statements': '\uD83C\uDFE6',
  'Shareholding': '\uD83C\uDFE2',
  'Dividends': '\uD83D\uDCB0',
  'Identity': '\uD83D\uDC64',
  'Other': '\uD83D\uDCCB',
  'Other Financial': '\uD83D\uDCCB'
};

// ── STATE ─────────────────────────────────────────────────────────────────────

const state = {
  currentUser: null,
  currentStep: 1,
  selectedProfile: null,
  uploadedFiles: {},
  submissionRef: null,
  // New SOW pipeline state
  sessionId: null,
  extractionId: null,
  extractionResult: null,    // { categories: [...], totalFields: N }
  verifiedFields: [],        // user-edited copy of extracted fields
  sowText: '',
  generationId: null,
  generationSections: [],
  isExtracting: false,
  isGenerating: false,
  totalWords: 0
};

// ── ROUTER ────────────────────────────────────────────────────────────────────

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById(pageId);
  if (page) page.classList.add('active');
}

// ── AUTH ──────────────────────────────────────────────────────────────────────

function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const errEl = document.getElementById('login-error');

  const user = USERS[username.toLowerCase()];
  if (!user || user.password !== password) {
    errEl.classList.add('visible');
    errEl.querySelector('span').textContent = 'Invalid credentials. Please check your Client ID and password.';
    document.getElementById('password').value = '';
    return;
  }
  errEl.classList.remove('visible');
  state.currentUser = { username, ...user };
  state.currentStep = 1;
  state.selectedProfile = null;
  state.uploadedFiles = {};
  state.sessionId = null;
  state.extractionId = null;
  state.extractionResult = null;
  state.verifiedFields = [];
  state.sowText = '';
  state.generationId = null;
  showPortal();
}

function handleSignOut() {
  state.currentUser = null;
  state.selectedProfile = null;
  state.uploadedFiles = {};
  state.currentStep = 1;
  state.sessionId = null;
  state.extractionId = null;
  state.extractionResult = null;
  state.verifiedFields = [];
  state.sowText = '';
  state.generationId = null;
  showPage('page-login');
  document.getElementById('login-form').reset();
}

// ── PORTAL LAYOUT ─────────────────────────────────────────────────────────────

function showPortal() {
  showPage('page-portal');
  document.getElementById('header-user-name').textContent = state.currentUser.name;
  document.getElementById('header-user-role').textContent = state.currentUser.role;
  document.getElementById('header-user-initials').textContent = state.currentUser.initials;
  navigateToStep(1);
}

function updateStepNav(step) {
  document.querySelectorAll('.step-item').forEach((el, i) => {
    el.classList.remove('active', 'completed');
    const n = i + 1;
    if (n < step) el.classList.add('completed');
    else if (n === step) el.classList.add('active');
    const numEl = el.querySelector('.step-num');
    if (n < step) {
      numEl.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" width="10" height="10"><polyline points="2,8 6,12 14,4"/></svg>';
    } else {
      numEl.textContent = n;
    }
  });
}

function navigateToStep(step) {
  state.currentStep = step;
  updateStepNav(step);
  document.querySelectorAll('.portal-page').forEach(p => p.classList.remove('active'));

  const footerBar = document.getElementById('portal-footer-bar');
  footerBar.style.display = 'flex';

  if (step === 1) {
    document.getElementById('portal-step1').classList.add('active');
    renderStep1();
  } else if (step === 2) {
    document.getElementById('portal-step2').classList.add('active');
    renderStep2();
  } else if (step === 3) {
    document.getElementById('portal-step3').classList.add('active');
    renderStep3();
  } else if (step === 4) {
    document.getElementById('portal-step4').classList.add('active');
    renderStep4();
  } else if (step === 5) {
    document.getElementById('portal-step5').classList.add('active');
    renderStep5();
  }

  updateFooterBar(step);
}

function updateFooterBar(step) {
  const backBtn = document.getElementById('footer-back-btn');
  const continueBtn = document.getElementById('footer-continue-btn');
  const footerInfo = document.getElementById('footer-step-info');
  const footerBar = document.getElementById('portal-footer-bar');

  backBtn.style.visibility = step === 1 ? 'hidden' : 'visible';

  if (step === 5) {
    // Final step — different footer
    footerBar.style.display = 'flex';
    backBtn.style.visibility = 'visible';
    continueBtn.style.display = 'none';
    footerInfo.textContent = '';
    backBtn.onclick = function() {
      // Start new assessment
      state.currentStep = 1;
      state.selectedProfile = null;
      state.uploadedFiles = {};
      state.sessionId = null;
      state.extractionId = null;
      state.extractionResult = null;
      state.verifiedFields = [];
      state.sowText = '';
      state.generationId = null;
      navigateToStep(1);
    };
    // Replace back text
    backBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg> Start New Assessment';
    return;
  }

  continueBtn.style.display = 'inline-flex';
  backBtn.onclick = handleBack;
  backBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg> Back';

  if (step === 1) {
    continueBtn.innerHTML = 'Continue to Document Upload <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    continueBtn.disabled = false;
    continueBtn.classList.remove('disabled');
  } else if (step === 2) {
    continueBtn.innerHTML = 'Submit Documents for Analysis <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    const hasFiles = Object.keys(state.uploadedFiles).length > 0;
    continueBtn.disabled = !hasFiles;
    continueBtn.classList.toggle('disabled', !hasFiles);
  } else if (step === 3) {
    continueBtn.innerHTML = 'Confirm & Generate SOW <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    const hasFields = state.extractionResult && state.extractionResult.totalFields > 0;
    continueBtn.disabled = !hasFields || state.isExtracting;
    continueBtn.classList.toggle('disabled', !hasFields || state.isExtracting);
  } else if (step === 4) {
    continueBtn.innerHTML = 'View Summary & Download <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';
    backBtn.style.visibility = 'hidden';
    continueBtn.disabled = state.isGenerating || !state.generationId;
    continueBtn.classList.toggle('disabled', state.isGenerating || !state.generationId);
  }

  footerInfo.textContent = `Step ${step} of 5`;
}

// ── STEP 1 ────────────────────────────────────────────────────────────────────

function renderStep1() {
  const cards = document.querySelectorAll('.profile-card');
  cards.forEach(c => {
    c.classList.toggle('selected', c.dataset.profile === state.selectedProfile);
  });
}

function handleProfileSelect(profile) {
  state.selectedProfile = profile;
  renderStep1();
}

// ── STEP 2 ────────────────────────────────────────────────────────────────────

function renderStep2() {
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const container = document.getElementById('doc-list-container');
  container.innerHTML = '';

  docs.forEach((doc) => {
    const isUploaded = !!state.uploadedFiles[doc.id];
    const item = document.createElement('div');
    item.className = `doc-item${isUploaded ? ' uploaded' : ''}`;
    item.id = `doc-item-${doc.id}`;

    const badgeClass = isUploaded ? 'uploaded-badge' : (doc.required ? 'required-badge' : 'optional-badge');
    const badgeText = isUploaded ? 'Uploaded' : (doc.required ? 'Required' : 'Optional');

    item.innerHTML = `
      <button class="doc-item-header" onclick="toggleDocItem('${doc.id}')" aria-expanded="false" aria-controls="doc-body-${doc.id}">
        <div class="doc-item-header-top">
          <div class="doc-status-icon ${isUploaded ? 'uploaded' : 'empty'}">
            ${isUploaded ? '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="2,8 6,12 14,4"/></svg>' : ''}
          </div>
          <div class="doc-item-required">
            <span class="${badgeClass}">${badgeText}</span>
            <svg class="doc-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
        </div>
        <div class="doc-item-info">
          <div class="doc-item-title">${doc.title}</div>
          <div class="doc-item-subtitle">${doc.subtitle}</div>
        </div>
      </button>
      <div class="doc-item-body" id="doc-body-${doc.id}">
        <p class="doc-description">${doc.description}</p>
        <div class="doc-examples">
          <div class="doc-examples-title">Accepted Documents</div>
          <div class="doc-examples-list">
            ${doc.examples.map(ex => `<span class="doc-example-tag">${ex}</span>`).join('')}
          </div>
        </div>
        <div class="doc-upload-area" onclick="triggerFileInput('${doc.id}')">
          <input type="file" id="file-input-${doc.id}" accept=".pdf,.jpg,.jpeg,.png" onchange="handleFileUpload('${doc.id}', this)" onclick="event.stopPropagation()"/>
          <div class="doc-upload-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="36" height="36"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          </div>
          <div class="doc-upload-text">Drag & drop or <span class="doc-upload-link">browse file</span></div>
          <div class="doc-upload-subtext">PDF, JPG or PNG — max 50MB</div>
        </div>
        <div class="doc-file-preview ${isUploaded ? 'visible' : ''}" id="preview-${doc.id}">
          <div class="doc-file-name" id="filename-${doc.id}">${isUploaded ? state.uploadedFiles[doc.id].name : ''}</div>
          <button class="doc-file-remove" onclick="removeFile('${doc.id}')" title="Remove file">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </div>
    `;
    container.appendChild(item);
  });

  updateSidebar();
  updateUploadWarning();
}

function toggleDocItem(docId) {
  const item = document.getElementById(`doc-item-${docId}`);
  const header = item.querySelector('.doc-item-header');
  const isExpanded = item.classList.toggle('expanded');
  header.setAttribute('aria-expanded', isExpanded);
}

function triggerFileInput(docId) {
  document.getElementById(`file-input-${docId}`).click();
}

function handleFileUpload(docId, input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  state.uploadedFiles[docId] = file;

  const item = document.getElementById(`doc-item-${docId}`);
  item.classList.add('uploaded');
  const statusIcon = item.querySelector('.doc-status-icon');
  statusIcon.className = 'doc-status-icon uploaded';
  statusIcon.innerHTML = '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="2,8 6,12 14,4"/></svg>';

  // Update badge to "Uploaded"
  const badge = item.querySelector('.required-badge, .optional-badge');
  if (badge) {
    badge.className = 'uploaded-badge';
    badge.textContent = 'Uploaded';
  }

  document.getElementById(`filename-${docId}`).textContent = file.name;
  document.getElementById(`preview-${docId}`).classList.add('visible');

  showToast('\u2713 ' + file.name + ' uploaded');
  updateSidebar();
  updateUploadWarning();
  updateFooterBar(2);
}

function removeFile(docId) {
  delete state.uploadedFiles[docId];
  const item = document.getElementById(`doc-item-${docId}`);
  item.classList.remove('uploaded');
  const statusIcon = item.querySelector('.doc-status-icon');
  statusIcon.className = 'doc-status-icon empty';
  statusIcon.innerHTML = '';

  // Restore original badge
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const doc = docs.find(d => d.id === docId);
  const badge = item.querySelector('.uploaded-badge');
  if (badge && doc) {
    badge.className = doc.required ? 'required-badge' : 'optional-badge';
    badge.textContent = doc.required ? 'Required' : 'Optional';
  }

  document.getElementById(`preview-${docId}`).classList.remove('visible');
  document.getElementById(`file-input-${docId}`).value = '';
  updateSidebar();
  updateUploadWarning();
  updateFooterBar(2);
}

function updateSidebar() {
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const total = docs.length;
  const done = Object.keys(state.uploadedFiles).filter(id => docs.find(d => d.id === id)).length;

  document.getElementById('progress-done').textContent = done;
  document.getElementById('progress-total').textContent = total;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  document.getElementById('progress-fill').style.width = pct + '%';

  // Total file size
  let totalSize = 0;
  Object.keys(state.uploadedFiles).forEach(id => {
    if (docs.find(d => d.id === id)) {
      totalSize += state.uploadedFiles[id].size || 0;
    }
  });
  const sizeEl = document.getElementById('sidebar-total-size');
  if (sizeEl) {
    if (totalSize > 0) {
      const sizeMB = (totalSize / (1024 * 1024)).toFixed(1);
      sizeEl.textContent = `Total: ${sizeMB} MB`;
    } else {
      sizeEl.textContent = '';
    }
  }

  const listEl = document.getElementById('sidebar-doc-list');
  listEl.innerHTML = docs.map(doc => {
    const isDone = !!state.uploadedFiles[doc.id];
    return `<li class="sidebar-doc-item">
      <div class="sidebar-doc-status ${isDone ? 'done' : 'pending'}">
        ${isDone ? '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="2,8 6,12 14,4"/></svg>' : ''}
      </div>
      <span style="${isDone ? 'text-decoration:line-through;color:var(--color-text-muted)' : ''}">${doc.title}</span>
    </li>`;
  }).join('');
}

function updateUploadWarning() {
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const missingRequired = docs.filter(d => d.required && !state.uploadedFiles[d.id]);
  const hasAnyFile = Object.keys(state.uploadedFiles).length > 0;
  const banner = document.getElementById('upload-warning-banner');
  if (banner) {
    banner.style.display = (hasAnyFile && missingRequired.length > 0) ? 'flex' : 'none';
  }
}

// ── STEP 2: UPLOAD & SUBMIT TO BACKEND ────────────────────────────────────────

async function handleUploadSubmit() {
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const uploadedDocs = docs.filter(d => state.uploadedFiles[d.id]);

  if (uploadedDocs.length === 0) {
    showToast('\u26A0 Please upload at least one document to continue.');
    return;
  }

  const overlay = document.getElementById('loading-overlay');
  const loadingText = overlay.querySelector('.loading-text');
  loadingText.textContent = 'Uploading your documents securely\u2026';
  overlay.classList.add('visible');

  try {
    const formData = new FormData();
    formData.append('profile_type', state.selectedProfile);
    // Send per-file category metadata so backend can apply category-specific extraction
    const fileMeta = uploadedDocs.map(doc => ({
      filename: state.uploadedFiles[doc.id].name,
      category_id: doc.id,
      category_title: doc.title,
      profile: state.selectedProfile,
    }));
    formData.append('file_metadata', JSON.stringify(fileMeta));
    for (const doc of uploadedDocs) {
      formData.append('files', state.uploadedFiles[doc.id]);
    }

    const response = await fetch(`${API_BASE}/api/v1/upload`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Upload failed');
    }

    const data = await response.json();
    state.sessionId = data.session_id;

    overlay.classList.remove('visible');
    navigateToStep(3);
  } catch (error) {
    console.error('Upload error:', error);
    overlay.classList.remove('visible');
    showToast('\u26A0 Upload failed. Please try again.');
  }
}

// ── STEP 3: EXTRACTION ────────────────────────────────────────────────────────

function renderStep3() {
  if (!state.sessionId) {
    // If no session yet, show processing state and start extraction
    document.getElementById('extraction-processing').style.display = 'flex';
    document.getElementById('extraction-completed').style.display = 'none';
    startExtraction();
  } else if (state.extractionResult) {
    // Already extracted, show results
    document.getElementById('extraction-processing').style.display = 'none';
    document.getElementById('extraction-completed').style.display = 'grid';
    renderExtractionResults();
  } else {
    // Have session but no results — start extraction
    document.getElementById('extraction-processing').style.display = 'flex';
    document.getElementById('extraction-completed').style.display = 'none';
    startExtraction();
  }
}

// AbortController for cancelling in-flight extraction
let extractionAbortController = null;

async function startExtraction() {
  if (!state.sessionId) return;
  state.isExtracting = true;
  updateFooterBar(3);

  const progressText = document.getElementById('extraction-processing-detail');
  const progressFill = document.getElementById('extraction-progress-fill');
  const cancelBtn = document.getElementById('btn-cancel-extraction');

  if (progressText) progressText.textContent = 'Preparing to process...';
  if (progressFill) progressFill.style.width = '0%';
  if (cancelBtn) cancelBtn.style.display = 'inline-flex';

  // Create abort controller for this extraction
  extractionAbortController = new AbortController();

  // Safety timeout: if SSE hangs for >10min without completing, abort
  const _sseTimeout = setTimeout(() => {
    if (state.isExtracting && extractionAbortController) {
      console.warn('SSE extraction timed out after 10min — aborting');
      extractionAbortController.abort();
    }
  }, 600000);

  try {
    const response = await fetch(`${API_BASE}/api/v1/extract`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: state.sessionId }),
      signal: extractionAbortController.signal
    });

    if (!response.ok) throw new Error('Extraction failed');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let categories = [];
    let totalFields = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        try {
          const event = JSON.parse(line.substring(6));

          if (event.type === 'status') {
            updateStatusPanel(event);
            appendToProcessingLog(event);
          } else if (event.type === 'progress') {
            // Legacy progress events — update page counter
            if (event.total > 0) {
              updatePageCounter(event.page, event.total);
            }
          } else if (event.type === 'category_complete') {
            categories.push(event.category);
          } else if (event.type === 'complete') {
            state.extractionId = event.extraction_id;
            totalFields = event.total_fields;
          } else if (event.type === 'info') {
            appendToProcessingLog({message: event.message, service: '', status_type: 'warning'});
          } else if (event.type === 'error') {
            showToast('\u26A0 ' + (event.message || 'Extraction error'));
          }
        } catch (e) {
          // Skip malformed SSE
        }
      }
    }

    clearTimeout(_sseTimeout);
    // Fetch full extraction results from backend
    state.extractionResult = await fetchExtractionDetails();

    state.isExtracting = false;
    extractionAbortController = null;
    if (cancelBtn) cancelBtn.style.display = 'none';
    document.getElementById('extraction-processing').style.display = 'none';
    document.getElementById('extraction-completed').style.display = 'grid';
    renderExtractionResults();
    updateFooterBar(3);
  } catch (error) {
    if (error.name === 'AbortError') {
      // User cancelled — handled in cancelExtraction()
      return;
    }
    console.error('Extraction error:', error);
    state.isExtracting = false;
    extractionAbortController = null;
    // Always hide the processing panel — never leave it visible on error
    const procPanel = document.getElementById('extraction-processing');
    const compPanel = document.getElementById('extraction-completed');
    if (procPanel) procPanel.style.display = 'none';
    if (compPanel) compPanel.style.display = 'grid';
    // Show error in the categories area
    const catContainer = document.getElementById('extraction-categories');
    if (catContainer) {
      catContainer.innerHTML = `<div style="padding:32px;text-align:center;color:var(--color-red);">
        <p style="font-size:15px;font-weight:600;margin-bottom:8px;">Extraction failed</p>
        <p style="font-size:13px;color:var(--text-muted);">${error.message || 'An unexpected error occurred. Please re-upload your documents.'}</p>
      </div>`;
    }
    showToast('\u26A0 Extraction failed. Please try again.');
    updateFooterBar(3);
  }
}

function cancelExtraction() {
  // Abort the in-flight SSE fetch
  if (extractionAbortController) {
    extractionAbortController.abort();
    extractionAbortController = null;
  }

  // Tell backend to clean up session files
  if (state.sessionId) {
    fetch(`${API_BASE}/api/v1/session/${state.sessionId}`, { method: 'DELETE' }).catch(() => {});
  }

  state.isExtracting = false;
  state.sessionId = null;
  state.extractionId = null;
  state.extractionResult = null;
  state.verifiedFields = [];

  showToast('Extraction stopped. You can re-upload your documents.');
  navigateToStep(2);
}

// ── STATUS PANEL HELPERS ───────────────────────────────────────────────────────

const _SERVICE_DOT_CLASS = {
  'OCR': 'ocr', 'VLM': 'vlm', 'LLM': 'llm',
  'Embeddings': 'embeddings', 'Reranker': 'reranker',
  'Native': 'native', 'System': 'native',
};

let _processingLogEntries = [];

function updateStatusPanel(event) {
  // Main message
  const titleEl = document.getElementById('extraction-processing-title');
  const detailEl = document.getElementById('extraction-processing-detail');
  if (titleEl && event.message) {
    titleEl.style.opacity = '0';
    setTimeout(() => { titleEl.textContent = event.message; titleEl.style.opacity = '1'; titleEl.style.transition = 'opacity 0.25s'; }, 150);
  }
  if (detailEl && event.detail !== undefined) {
    detailEl.textContent = event.detail || '';
  }

  // Progress bar + percentage
  const progressFill = document.getElementById('extraction-progress-fill');
  const progressPct  = document.getElementById('extraction-progress-pct');
  if (event.progress !== undefined && event.progress >= 0) {
    const pct = Math.min(100, Math.max(0, event.progress));
    if (progressFill) progressFill.style.width = pct + '%';
    if (progressPct)  progressPct.textContent = pct + '%';
  }

  // Service badge
  const badge     = document.getElementById('extraction-service-badge');
  const dot       = document.getElementById('service-dot');
  const svcName   = document.getElementById('service-name');
  const svcModel  = document.getElementById('service-model');
  if (badge && event.service && event.service !== 'System' && event.service !== '') {
    badge.style.display = 'inline-flex';
    if (dot) {
      dot.className = 'service-dot ' + (_SERVICE_DOT_CLASS[event.service] || 'native');
    }
    if (svcName) svcName.textContent = event.service;
    if (svcModel) svcModel.textContent = event.model || '';
  } else if (badge && (!event.service || event.service === 'System')) {
    badge.style.display = 'none';
  }

  // Page counter
  if (event.page_current && event.page_total) {
    updatePageCounter(event.page_current, event.page_total);
  }

  // Status type colouring
  if (titleEl) {
    titleEl.style.color = event.status_type === 'error' ? 'var(--color-red)'
                        : event.status_type === 'warning' ? 'var(--color-gold)'
                        : event.status_type === 'success' ? 'var(--color-green)'
                        : '';
  }
}

function updatePageCounter(current, total) {
  const counter = document.getElementById('extraction-page-counter');
  const label   = document.getElementById('extraction-page-label');
  const dots    = document.getElementById('extraction-page-dots');
  if (!counter) return;
  counter.style.display = 'flex';
  if (label) label.textContent = `Processing page ${current} of ${total}`;
  if (dots) {
    dots.innerHTML = '';
    const maxDots = Math.min(total, 20);
    for (let i = 1; i <= maxDots; i++) {
      const d = document.createElement('div');
      d.className = 'page-dot' + (i < current ? ' done' : i === current ? ' active' : '');
      dots.appendChild(d);
    }
    if (total > maxDots) {
      const more = document.createElement('span');
      more.style.cssText = 'font-size:10px;color:var(--text-muted);margin-left:3px;';
      more.textContent = `+${total - maxDots}`;
      dots.appendChild(more);
    }
  }
}

function appendToProcessingLog(event) {
  const logEl = document.getElementById('extraction-log');
  if (!logEl) return;
  const time = new Date().toLocaleTimeString('en-GB', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  const entry = document.createElement('div');
  const statusClass = event.status_type === 'error' ? ' log-error'
                    : event.status_type === 'warning' ? ' log-warn' : '';
  entry.className = 'log-entry' + statusClass;
  entry.innerHTML = `<span class="log-time">${time}</span><span class="log-msg">${escapeHtml(event.message || '')}</span><span class="log-svc">${escapeHtml(event.service || '')}</span>`;
  logEl.appendChild(entry);
  // Keep last 10
  while (logEl.children.length > 10) logEl.removeChild(logEl.firstChild);
  logEl.scrollTop = logEl.scrollHeight;
  // Track for badge
  _processingLogEntries.push(event);
}

function toggleProcessingLog() {
  const logEl    = document.getElementById('extraction-log');
  const toggleEl = document.getElementById('extraction-log-toggle');
  if (!logEl) return;
  const isHidden = logEl.style.display === 'none';
  logEl.style.display = isHidden ? 'block' : 'none';
  if (toggleEl) {
    toggleEl.querySelector('svg').style.transform = isHidden ? 'rotate(180deg)' : '';
  }
}

async function fetchExtractionDetails() {
  // Fetch the full extraction result from the backend GET endpoint
  try {
    // Retry up to 5 times with 3s delay — pipeline may still be completing
    let resp;
    for (let attempt = 0; attempt < 5; attempt++) {
      resp = await fetch(`${API_BASE}/api/v1/extract/${state.sessionId}/result`);
      if (resp.ok) break;
      if (attempt < 4) await new Promise(r => setTimeout(r, 3000));
    }
    if (!resp.ok) throw new Error('Failed to fetch extraction results');

    const data = await resp.json();
    state.extractionId = data.extraction_id;

    const categories = data.categories;
    const totalFields = data.total_fields;

    // Initialize verified fields as a copy of extracted fields
    state.verifiedFields = [];
    categories.forEach(cat => {
      cat.fields.forEach(f => {
        state.verifiedFields.push({
          id: f.id,
          key: f.key,
          value: f.value,
          category: cat.category_name,
          originalValue: f.value
        });
      });
    });

    return { categories, totalFields };
  } catch (e) {
    console.error('Failed to fetch extraction details:', e);
    showToast('\u26A0 Could not load extraction results.');
    return { categories: [], totalFields: 0 };
  }
}

function _uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

function renderExtractionResults() {
  if (!state.extractionResult) return;
  const { categories, totalFields } = state.extractionResult;

  // Stats sidebar
  const docsCount = Object.keys(state.uploadedFiles).length;
  const highConf = categories.reduce((s, c) => s + c.fields.filter(f => f.confidence >= 0.9).length, 0);
  const needsReview = totalFields - highConf;

  document.getElementById('stat-total-fields').textContent = totalFields;
  document.getElementById('stat-docs-analysed').textContent = docsCount;
  document.getElementById('stat-high-conf').textContent = highConf;
  document.getElementById('stat-needs-review').textContent = needsReview;

  const confPct = totalFields > 0 ? Math.round((highConf / totalFields) * 100) : 0;
  document.getElementById('extraction-confidence-fill').style.width = confPct + '%';

  // Documents processed list
  const docListEl = document.getElementById('extraction-doc-list');
  const docs = state.selectedProfile === 'salaried' ? SALARIED_DOCS : BUSINESS_OWNER_DOCS;
  const uploadedDocs = docs.filter(d => state.uploadedFiles[d.id]);
  docListEl.innerHTML = uploadedDocs.map(doc => {
    const file = state.uploadedFiles[doc.id];
    const fieldCount = categories.reduce((s, c) => {
      return s + c.fields.filter(f => f.source_file === doc.title || f.source_file === file.name).length;
    }, 0);
    return `<div class="extraction-doc-chip">
      <span class="extraction-doc-chip-name" title="${escapeHtml(file.name)}">${escapeHtml(doc.title)}</span>
      <span class="extraction-doc-chip-fields">${fieldCount || '\u2014'} fields</span>
    </div>`;
  }).join('');

  // Category accordions
  const container = document.getElementById('extraction-categories');
  container.innerHTML = '';

  categories.forEach((cat, catIdx) => {
    const icon = CATEGORY_ICONS[cat.category_name] || '\uD83D\uDCCB';
    const accordion = document.createElement('div');
    accordion.className = 'category-accordion' + (catIdx === 0 ? ' expanded' : '');
    accordion.innerHTML = `
      <button class="category-accordion-header" onclick="toggleCategory(this)">
        <div class="category-icon">${icon}</div>
        <div class="category-name">${cat.category_name}</div>
        <div class="category-field-count">${cat.fields.length} fields</div>
        <svg class="category-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
      </button>
      <div class="category-accordion-body">
        <div class="field-table">
          ${cat.fields.map(f => renderFieldRow(f, cat.category_name)).join('')}
        </div>
      </div>
    `;
    container.appendChild(accordion);
  });
}

function renderFieldRow(field, categoryName) {
  const confClass = field.confidence >= 0.9 ? 'confidence-high' : (field.confidence >= 0.75 ? 'confidence-medium' : 'confidence-low');
  return `
    <div class="field-row ${confClass}">
      <div class="field-label">
        ${field.key}
        <span class="field-warning-icon" title="Please verify this value">\u26A0</span>
      </div>
      <div class="field-value-wrap" id="wrap-${field.id}">
        <input class="field-value-input" type="text" value="${escapeHtml(field.value)}" data-field-id="${field.id}" data-original="${escapeHtml(field.value)}" data-category="${categoryName}" onchange="handleFieldEdit(this)" onfocus="this.select()" />
        <div class="field-modified-dot"></div>
      </div>
      <div class="field-source" title="${field.source_file}">${truncate(field.source_file, 18)}</div>
      <div class="field-page">p.${field.source_page}</div>
    </div>
  `;
}

function toggleCategory(btn) {
  const accordion = btn.parentElement;
  accordion.classList.toggle('expanded');
}

function handleFieldEdit(input) {
  const fieldId = input.dataset.fieldId;
  const original = input.dataset.original;
  const newValue = input.value;
  const wrap = document.getElementById('wrap-' + fieldId);

  if (newValue !== original) {
    wrap.classList.add('modified');
  } else {
    wrap.classList.remove('modified');
  }

  // Update verified fields
  const vf = state.verifiedFields.find(f => f.id === fieldId);
  if (vf) {
    vf.value = newValue;
  }
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function truncate(str, len) {
  return str.length > len ? str.substring(0, len - 2) + '\u2026' : str;
}

// ── STEP 4: GENERATE SOW ──────────────────────────────────────────────────────

const SOW_SECTION_NAMES = [
  'Executive Summary',
  'Personal & Identity Details',
  'Source of Employment Income',
  'Tax Compliance',
  'Business & Corporate Interests',
  'Investment Portfolio Overview',
  'Property Holdings',
  'Banking & Financial Position',
  'Overall Wealth Assessment',
  'Supporting Documentation',
  'Compliance Notes',
];

function renderStep4() {
  // Reset generation UI
  const textEl = document.getElementById('generate-text');
  textEl.innerHTML = '';
  document.getElementById('generate-cursor').style.display = 'inline';
  document.getElementById('generate-complete-banner').style.display = 'none';
  document.getElementById('generate-word-count').textContent = '0 words generated';
  document.getElementById('generate-vertical-fill').style.height = '0%';

  // Build section progress pills
  const progressEl = document.getElementById('generate-section-progress');
  state.generationSections = SOW_SECTION_NAMES.map(name => ({ name, status: 'pending' }));
  renderSectionPills();

  // Start generation
  startGeneration();
}

function renderSectionPills() {
  const progressEl = document.getElementById('generate-section-progress');
  progressEl.innerHTML = state.generationSections.map(s => {
    let icon = '\u25CB';
    if (s.status === 'completed') icon = '\u2713';
    else if (s.status === 'active') icon = '\u25CF';
    return `<div class="section-pill ${s.status}">
      <span class="section-pill-icon">${icon}</span>
      ${s.name}
    </div>`;
  }).join('');
}

async function startGeneration() {
  // Disable download buttons during streaming
  const pdfBtn  = document.getElementById('download-pdf-btn');
  const docxBtn = document.getElementById('download-docx-btn');
  if (pdfBtn)  { pdfBtn.disabled  = true; pdfBtn.style.opacity  = '0.4'; }
  if (docxBtn) { docxBtn.disabled = true; docxBtn.style.opacity = '0.4'; }

  // Start elapsed timer for status bar
  const _genStart = Date.now();
  let _genTokens = 0;
  const _genTimer = setInterval(() => {
    const elapsed = Math.round((Date.now() - _genStart) / 1000);
    const elapsedEl = document.getElementById('gen-status-elapsed');
    if (elapsedEl) elapsedEl.textContent = elapsed + 's';
  }, 1000);

  // Show model in status bar
  const genModelEl = document.getElementById('gen-status-model');
  if (genModelEl) genModelEl.textContent = 'Generating...';

  state.isGenerating = true;
  state.sowText = '';
  state.totalWords = 0;
  updateFooterBar(4);

  // Collect verified fields for the request
  const fieldsPayload = state.verifiedFields.map(f => ({
    id: f.id,
    key: f.key,
    value: f.value,
    category: f.category
  }));

  try {
    const response = await fetch(`${API_BASE}/api/v1/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: state.sessionId,
        extraction_id: state.extractionId || 'mock-extraction',
        verified_fields: fieldsPayload
      })
    });

    if (!response.ok) throw new Error('Generation failed');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    const textEl = document.getElementById('generate-text');
    let wordCount = 0;
    let completedSections = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        try {
          const event = JSON.parse(line.substring(6));

          if (event.type === 'section_start') {
            // Update pill status
            const idx = state.generationSections.findIndex(s => s.name === event.section);
            if (idx >= 0) {
              state.generationSections[idx].status = 'active';
              renderSectionPills();
            }
            // Add section header to text
            const h = document.createElement('h2');
            h.textContent = event.section;
            textEl.appendChild(h);
            const secEl = document.getElementById('gen-status-section');
            if (secEl) secEl.textContent = event.section || '';
          } else if (event.type === 'token') {
            // Filter structural markers from display
            let displayText = event.text;
            const structMarkers = [/\[SECTION:[^\]]+\]/g, /\[\/SECTION\]/g,
                                   /\[NARRATIVE\]/g, /\[\/NARRATIVE\]/g,
                                   /\[TABLE\]/g, /\[\/TABLE\]/g,
                                   /^CAPTION:.*$/gm, /^ALIGN:.*$/gm,
                                   /^HEADERS:.*$/gm, /^ROW:.*$/gm,
                                   /^TOTAL:.*$/gm];
            for (const rx of structMarkers) displayText = displayText.replace(rx, '');
            if (displayText.trim()) {
              const span = document.createElement('span');
              span.textContent = displayText;
              textEl.appendChild(span);
            }
            state.sowText += event.text;
            _genTokens++;
            const tokEl = document.getElementById('gen-status-tokens');
            if (tokEl) tokEl.textContent = _genTokens + ' tokens';
            wordCount += event.text.split(/\s+/).filter(w => w.length > 0).length;
            document.getElementById('generate-word-count').textContent = wordCount + ' words generated';

            // Auto-scroll
            const container = document.getElementById('generate-text-container');
            container.scrollTop = container.scrollHeight;
          } else if (event.type === 'section_complete') {
            completedSections++;
            const idx = state.generationSections.findIndex(s => s.name === event.section);
            if (idx >= 0) {
              state.generationSections[idx].status = 'completed';
              renderSectionPills();
            }
            // Update vertical progress
            const pct = Math.round((completedSections / SOW_SECTION_NAMES.length) * 100);
            document.getElementById('generate-vertical-fill').style.height = pct + '%';

            // Add paragraph break
            textEl.appendChild(document.createElement('br'));
            textEl.appendChild(document.createElement('br'));

            // Append to sowText
            state.sowText += '\n\n';
          } else if (event.type === 'complete') {
            state.generationId = event.generation_id;
            state.totalWords = event.total_words || wordCount;
          }
        } catch (e) {
          // Skip
        }
      }
    }

    // Generation complete
    clearInterval(_genTimer);
    if (pdfBtn)  { pdfBtn.disabled  = false; pdfBtn.style.opacity  = '1'; }
    if (docxBtn) { docxBtn.disabled = false; docxBtn.style.opacity = '1'; }
    const genModelEl2 = document.getElementById('gen-status-model');
    if (genModelEl2) genModelEl2.textContent = 'Complete';
    state.isGenerating = false;
    document.getElementById('generate-cursor').style.display = 'none';
    document.getElementById('generate-complete-banner').style.display = 'flex';
    document.getElementById('generate-vertical-fill').style.height = '100%';

    // Mark all sections complete
    state.generationSections.forEach(s => s.status = 'completed');
    renderSectionPills();

    updateFooterBar(4);
  } catch (error) {
    console.error('Generation error:', error);
    state.isGenerating = false;
    document.getElementById('generate-cursor').style.display = 'none';
    showToast('\u26A0 Report generation failed. Please try again.');
    updateFooterBar(4);
  }
}

// ── STEP 5: SUMMARY & EXPORT ──────────────────────────────────────────────────

function renderStep5() {
  const refId = state.sessionId ? state.sessionId.substring(0, 8).toUpperCase() : 'N/A';
  const genDate = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const genTime = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  const profileLabel = state.selectedProfile === 'salaried' ? 'Salaried Professional' : 'Business Owner';
  const docsCount = Object.keys(state.uploadedFiles).length;
  const fieldCount = state.verifiedFields.length;
  const wordCount = state.totalWords || state.sowText.split(/\s+/).filter(w => w.length > 0).length;

  // SOW Document header
  document.getElementById('sow-client-name').textContent = state.currentUser.name;
  document.getElementById('sow-gen-date').textContent = genDate;
  document.getElementById('sow-ref-id').textContent = 'SOW-' + refId;

  // SOW Document body — render the generated text as formatted HTML
  const bodyEl = document.getElementById('sow-doc-body');
  bodyEl.innerHTML = formatSowHtml(state.sowText);

  // Footer note
  document.getElementById('sow-doc-footer-note').textContent =
    `Generated by Source of Wealth Portal \u00B7 ${genDate} ${genTime} \u00B7 Reference: SOW-${refId}`;

  // Sidebar details
  document.getElementById('detail-ref-id').textContent = 'SOW-' + refId;
  document.getElementById('detail-gen-date').textContent = genDate + ' ' + genTime;
  document.getElementById('detail-profile-type').textContent = profileLabel;
  document.getElementById('detail-doc-count').textContent = docsCount;
  document.getElementById('detail-field-count').textContent = fieldCount;
  document.getElementById('detail-word-count').textContent = wordCount;
}

function formatSowHtml(text) {
  if (!text) return '<p>No report content available.</p>';

  // Try to parse the new [SECTION]/[NARRATIVE]/[TABLE] structured format
  if (text.includes('[SECTION:') || text.includes('[NARRATIVE]')) {
    return _parseStructuredSow(text);
  }

  // Legacy ## markdown format
  const lines = text.split('\n');
  let html = '';
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    if (trimmed.startsWith('## '))       html += `<h2>${escapeHtml(trimmed.substring(3))}</h2>`;
    else if (trimmed.startsWith('### ')) html += `<h3>${escapeHtml(trimmed.substring(4))}</h3>`;
    else                                 html += `<p>${escapeHtml(trimmed)}</p>`;
  }
  return html || '<p>No report content available.</p>';
}

function _parseStructuredSow(text) {
  let html = '';
  // Split on [SECTION: ...] markers
  const sectionRe = /\[SECTION:\s*(.+?)\]/g;
  const parts = text.split(sectionRe);
  // parts[0] = preamble, then alternating: title, body, title, body...
  let i = 1;
  while (i < parts.length - 1) {
    const title = parts[i].trim();
    const body  = parts[i + 1]
      .replace(/\[\/SECTION\]/g, '')
      .replace(/\[\/NARRATIVE\]/g, '')
      .replace(/\[NARRATIVE\]/g, '');
    i += 2;

    html += `<h2>${escapeHtml(title)}</h2>`;

    // Extract TABLE blocks
    const tableRe = /\[TABLE\]([\s\S]*?)\[\/TABLE\]/g;
    const tables = [];
    let tableMatch;
    let bodyWithoutTables = body;
    while ((tableMatch = tableRe.exec(body)) !== null) {
      tables.push(tableMatch[1]);
      bodyWithoutTables = bodyWithoutTables.replace(tableMatch[0], `__TABLE_${tables.length - 1}__`);
    }

    // Render body segments and table placeholders
    const segments = bodyWithoutTables.split(/(__TABLE_\d+__)/);
    for (const seg of segments) {
      const tableIdx = seg.match(/^__TABLE_(\d+)__$/);
      if (tableIdx) {
        html += _renderSowTable(tables[parseInt(tableIdx[1])]);
      } else {
        // Prose
        for (const line of seg.split('\n')) {
          const t = line.trim();
          if (t && !t.startsWith('CAPTION:') && !t.startsWith('ALIGN:') &&
              !t.startsWith('HEADERS:') && !t.startsWith('ROW:') && !t.startsWith('TOTAL:')) {
            html += `<p>${escapeHtml(t)}</p>`;
          }
        }
      }
    }
  }
  return html || '<p>No report content available.</p>';
}

function _renderSowTable(tableContent) {
  let caption = '', headers = [], rows = [], totals = [];
  for (const line of tableContent.split('\n')) {
    const t = line.trim();
    if (t.startsWith('CAPTION:')) caption = t.substring(8).trim();
    else if (t.startsWith('HEADERS:')) headers = t.substring(8).split('|').map(h => h.trim());
    else if (t.startsWith('ROW:'))    rows.push(t.substring(4).split('|').map(c => c.trim()));
    else if (t.startsWith('TOTAL:')) totals.push(t.substring(6).split('|').map(c => c.trim()));
  }
  if (!headers.length && !rows.length) return '';
  let html = '';
  if (caption) html += `<p class="sow-table-caption"><em>${escapeHtml(caption)}</em></p>`;
  html += '<table class="sow-data-table"><thead><tr>';
  for (const h of headers) html += `<th>${escapeHtml(h)}</th>`;
  html += '</tr></thead><tbody>';
  rows.forEach((row, i) => {
    html += `<tr class="${i % 2 === 1 ? 'row-even' : ''}">`;
    row.forEach(c => { html += `<td>${escapeHtml(c)}</td>`; });
    html += '</tr>';
  });
  for (const row of totals) {
    html += '<tr class="row-total">';
    row.forEach(c => { html += `<td><strong>${escapeHtml(c)}</strong></td>`; });
    html += '</tr>';
  }
  html += '</tbody></table>';
  return html;
}

// ── EXPORT ────────────────────────────────────────────────────────────────────

async function handleExport(format) {
  if (!state.sessionId || !state.generationId) {
    showToast('\u26A0 No report available to export.');
    return;
  }

  showToast('Preparing your ' + format.toUpperCase() + ' download\u2026');

  try {
    const response = await fetch(`${API_BASE}/api/v1/export/${format}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: state.sessionId,
        generation_id: state.generationId,
        client_name: state.currentUser ? state.currentUser.name : 'Client',
        profile_type: state.selectedProfile === 'salaried' ? 'Salaried Professional' : 'Business Owner',
        doc_count: Object.keys(state.uploadedFiles).length,
        field_count: state.verifiedFields.length,
        word_count: state.totalWords || 0
      })
    });

    if (!response.ok) throw new Error('Export failed');

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SOW_Report_${state.sessionId.substring(0, 8)}.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('\u2713 ' + format.toUpperCase() + ' downloaded successfully');
  } catch (error) {
    console.error('Export error:', error);
    showToast('\u26A0 Export failed. Please try again.');
  }
}

function handleShareWithRM() {
  const email = document.getElementById('rm-email-input').value.trim();
  if (!email || !email.includes('@')) {
    showToast('\u26A0 Please enter a valid email address.');
    return;
  }
  // Frontend-only stub — show success
  showToast('\u2713 Report sent to ' + email);
  document.getElementById('rm-email-input').value = '';
}

// ── NAVIGATION HANDLERS ───────────────────────────────────────────────────────

function handleContinue() {
  if (state.currentStep === 1) {
    if (!state.selectedProfile) {
      showToast('\u26A0 Please select a client profile to continue.');
      return;
    }
    navigateToStep(2);
  } else if (state.currentStep === 2) {
    // Flexible upload — only need 1 file
    const hasAnyFile = Object.keys(state.uploadedFiles).length > 0;
    if (!hasAnyFile) {
      showToast('\u26A0 Please upload at least one document to continue.');
      return;
    }
    handleUploadSubmit();
  } else if (state.currentStep === 3) {
    if (state.isExtracting) {
      showToast('\u26A0 Please wait for extraction to complete.');
      return;
    }
    navigateToStep(4);
  } else if (state.currentStep === 4) {
    if (state.isGenerating) {
      showToast('\u26A0 Please wait for generation to complete.');
      return;
    }
    navigateToStep(5);
  }
}

function handleBack() {
  if (state.currentStep === 3) {
    navigateToStep(2);
  } else if (state.currentStep > 1 && state.currentStep !== 4) {
    // Can't go back from step 4 (generation)
    navigateToStep(state.currentStep - 1);
  }
}

// ── TOAST ─────────────────────────────────────────────────────────────────────

function showToast(msg) {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => { toast.remove(); }, 3500);
}

// ── INIT ──────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  showPage('page-login');

  // Login form
  document.getElementById('login-form').addEventListener('submit', handleLogin);
  document.getElementById('signout-btn').addEventListener('click', handleSignOut);
  document.getElementById('success-signout-btn').addEventListener('click', handleSignOut);

  // Profile cards
  document.querySelectorAll('.profile-card').forEach(card => {
    card.addEventListener('click', () => handleProfileSelect(card.dataset.profile));
  });

  // Nav buttons
  document.getElementById('footer-continue-btn').addEventListener('click', handleContinue);
  document.getElementById('footer-back-btn').addEventListener('click', handleBack);

  // Download buttons (Step 5)
  const pdfBtn = document.getElementById('download-pdf-btn');
  if (pdfBtn) pdfBtn.addEventListener('click', () => handleExport('pdf'));

  const docxBtn = document.getElementById('download-docx-btn');
  if (docxBtn) docxBtn.addEventListener('click', () => handleExport('docx'));

  const sendRmBtn = document.getElementById('send-rm-btn');
  if (sendRmBtn) sendRmBtn.addEventListener('click', handleShareWithRM);
});
