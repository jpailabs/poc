"""
Generate router — SOW document generation with SSE streaming.

Uses real LLM streaming (sow_writer_service) when any LLM provider is configured.
Falls back to structured template generation (no placeholder text) otherwise.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1", tags=["Generate"])
logger = logging.getLogger(__name__)


class VerifiedField(BaseModel):
    id: str
    key: str
    value: str
    category: str


class GenerateRequest(BaseModel):
    session_id: str
    extraction_id: str
    verified_fields: List[VerifiedField]


def _has_llm() -> bool:
    """Check if any LLM provider is available."""
    if os.environ.get("ANTHROPIC_API_KEY"):
        return True
    try:
        from services.config_loader import get_provider_mode
        mode = get_provider_mode()
        if mode in ("private", "openai", "azure_openai", "bedrock", "vertex", "ollama"):
            return True
    except Exception:
        pass
    return False


SOW_SECTION_NAMES = [
    "Executive Summary",
    "Employment History & Income",
    "Business Interests & Shareholding",
    "Investment Portfolio",
    "Tax Compliance Evidence",
    "Other Financial Indicators",
    "Risk Assessment Summary",
    "Conclusion & Certification",
]


def _enrich_fields_from_session(
    verified_fields: List[VerifiedField],
    session_state: dict,
) -> list[dict]:
    """
    Merge the reviewer's verified values with the full field metadata stored in
    session_states (source_file, source_page, display_label, display_category,
    confidence, source_snippet). This gives the LLM proper source references.
    """
    # Build lookup of full field data from extraction_result in session_states
    full_field_map: dict[str, dict] = {}
    extraction_result = session_state.get("extraction_result") or []
    for cat in extraction_result:
        if not isinstance(cat, dict):
            continue
        for f in cat.get("fields", []):
            if isinstance(f, dict) and f.get("id"):
                full_field_map[f["id"]] = f

    enriched = []
    for vf in verified_fields:
        full = full_field_map.get(vf.id, {})
        enriched.append({
            "id": vf.id,
            "key": vf.key,
            "value": vf.value,                                    # reviewer's verified value
            "category": vf.category,
            "display_label": full.get("display_label") or vf.key,
            "display_category": full.get("display_category") or vf.category,
            "source_file": full.get("source_file", ""),
            "source_page": full.get("source_page", ""),
            "confidence": full.get("confidence", 0.0),
            "source_snippet": full.get("source_snippet", ""),
        })
    return enriched


def _build_fallback_report(
    verified_fields: List[VerifiedField],
    session_id: str,
    profile_type: str,
    enriched_fields: list[dict],
) -> str:
    """
    Build a structured SOW report without an LLM. Only uses values that actually
    exist in verified_fields — never writes placeholder fallback text.
    Missing values → the table row or sentence is omitted entirely.
    """
    from services.export_service import detect_placeholders

    gen_date = datetime.now().strftime("%d %B %Y")
    ref_id = f"SOW-{session_id[:8].upper()}"

    # Build key→value lookup (display_label → value)
    val: Dict[str, str] = {}
    for f in enriched_fields:
        label = (f.get("display_label") or f.get("key", "")).strip()
        v = (f.get("value") or "").strip()
        if label and v:
            val[label] = v
            # Build source reference
            parts = []
            sf = f.get("source_file", "")
            sp = f.get("source_page", "")
            if sf:
                parts.append(sf)
            if sp:
                parts.append(f"p.{sp}")
            src[label] = f"({', '.join(parts)})" if parts else ""

    def v(key: str, fallback: str = "") -> str:
        """Get value only if present — return fallback (default empty) otherwise."""
        return val.get(key, fallback)

    # Determine what data is present
    has_employment = bool(v("Employment Income") or v("Annual Base Salary") or v("Monthly Net Pay") or v("Gross Monthly Salary"))
    has_business = bool(v("Company Name") or v("Shareholding %") or v("UEN"))
    has_tax = bool(v("Year of Assessment") or v("Total Assessable Income") or v("Net Tax Payable") or v("Tax Payable"))
    has_banking = bool(v("Closing Balance") or v("Account Number") or v("Total Credits"))
    has_cpf = bool(v("CPF Ordinary Account Balance") or v("CPF Balance"))
    has_property = bool(v("Property Address") or v("Property Valuation"))

    # Primary source
    if has_business and has_employment:
        primary_source = "salaried employment income and business ownership"
    elif has_business:
        primary_source = "business ownership and dividends"
    else:
        primary_source = "salaried employment income"

    name = v("Full Name") or v("Name", "the applicant")
    tax_ref = v("Tax Reference Number") or v("NRIC / Passport", "")
    name_ref = f"{name} ({tax_ref})" if tax_ref else name

    sections = []

    # ── 1. Executive Summary ─────────────────────────────────────────────────
    wealth_sources = []
    if has_employment:
        wealth_sources.append("employment income")
    if has_business:
        wealth_sources.append("business income and shareholding")
    if has_tax:
        wealth_sources.append("tax compliance documentation")
    if has_banking:
        wealth_sources.append("banking and cash positions")
    if has_cpf:
        wealth_sources.append("CPF retirement funds")
    sources_str = ", ".join(wealth_sources) or "income documentation"

    exec_rows = []
    if v("Full Name"):
        exec_rows.append(f"ROW: Applicant Full Name | {v('Full Name')}")
    if v("Tax Reference Number") or v("NRIC / Passport"):
        exec_rows.append(f"ROW: Tax Reference / NRIC | {v('Tax Reference Number') or v('NRIC / Passport')}")
    if v("Residential Address"):
        exec_rows.append(f"ROW: Residential Address | {v('Residential Address')}")
    if v("Employment Income") or v("Annual Base Salary"):
        inc = v("Employment Income") or v("Annual Base Salary")
        exec_rows.append(f"ROW: Primary Income (Employment) | {inc}")
    if v("Net Tax Payable") or v("Tax Payable"):
        tp = v("Net Tax Payable") or v("Tax Payable")
        exec_rows.append(f"ROW: Tax Payable | {tp}")

    exec_table = ""
    if exec_rows:
        exec_table = (
            "[TABLE]\n"
            "CAPTION: Summary of Verified Wealth Sources and Applicant Identity\n"
            "ALIGN: left,left\n"
            "HEADERS: Field | Verified Value\n"
            + "\n".join(exec_rows) + "\n"
            "[/TABLE]\n"
        )

    sections.append(
        f"[SECTION: Executive Summary]\n"
        f"[NARRATIVE]\n"
        f"{name_ref} is a {profile_type} profile applicant submitting a Source of Wealth "
        f"declaration in connection with private banking account opening and onboarding under "
        f"MAS Notice SFA 04-N13. {len(verified_fields)} verified data points were assessed across "
        f"{len(set(f.category for f in verified_fields))} document categories. "
        f"Verified wealth sources include: {sources_str}. "
        f"The submitted documentation supports the applicant's declared wealth profile.\n"
        f"[/NARRATIVE]\n"
        f"{exec_table}"
        f"[/SECTION]\n"
    )

    # ── 2. Employment History & Income ───────────────────────────────────────
    if has_employment:
        emp_rows = []
        for label in ["Employer Name", "Designation", "Employment Start Date",
                      "Gross Monthly Salary", "Annual Base Salary", "Monthly Net Pay",
                      "CPF Employee Contribution", "CPF Employer Contribution",
                      "Employment Income"]:
            if v(label):
                emp_rows.append(f"ROW: {label} | {v(label)}")

        emp_table = ""
        if emp_rows:
            emp_table = (
                "[TABLE]\n"
                "CAPTION: Verified Employment Income Details\n"
                "ALIGN: left,right\n"
                "HEADERS: Income Component | Verified Value\n"
                + "\n".join(emp_rows) + "\n"
                "[/TABLE]\n"
            )

        employer = v("Employer Name", "the verified employer")
        designation = v("Designation", "")
        role_str = f" as {designation}" if designation else ""

        sections.append(
            f"[SECTION: Employment History & Income]\n"
            f"[NARRATIVE]\n"
            f"The applicant is employed{role_str} at {employer}. "
            + (f"Employment income of {v('Employment Income') or v('Annual Base Salary')} "
               "is confirmed by the submitted documentation. " if v("Employment Income") or v("Annual Base Salary") else "")
            + "Employment income is the primary verified wealth source for this applicant. "
            "The submitted documents confirm the stated income figures and employment status.\n"
            f"[/NARRATIVE]\n"
            f"{emp_table}"
            f"[/SECTION]\n"
        )
    else:
        sections.append(
            "[SECTION: Employment History & Income]\n"
            "[NARRATIVE]\n"
            "No verified data pertaining to employment income is present in the verified "
            "fields for this applicant. This section is not applicable to the current review.\n"
            "[/NARRATIVE]\n"
            "[/SECTION]\n"
        )

    # ── 3. Business Interests & Shareholding ─────────────────────────────────
    if has_business:
        biz_rows = []
        for label in ["Company Name", "UEN", "Shareholding %", "Date of Incorporation",
                      "Paid-up Capital", "Business Revenue", "Net Profit", "Director Name"]:
            if v(label):
                biz_rows.append(f"ROW: {label} | {v(label)}")

        biz_table = ""
        if biz_rows:
            biz_table = (
                "[TABLE]\n"
                "CAPTION: Business Interests and Shareholding Details\n"
                "ALIGN: left,left\n"
                "HEADERS: Field | Verified Value\n"
                + "\n".join(biz_rows) + "\n"
                "[/TABLE]\n"
            )

        company = v("Company Name", "the registered business entity")
        shareholding = v("Shareholding %", "")
        uen = v("UEN", "")
        share_str = f" holds {shareholding} equity interest in" if shareholding else " has a registered interest in"
        uen_str = f" (UEN: {uen})" if uen else ""

        sections.append(
            f"[SECTION: Business Interests & Shareholding]\n"
            f"[NARRATIVE]\n"
            f"The applicant{share_str} {company}{uen_str}. "
            "The business registration and associated documentation confirm the applicant's "
            "ownership and directorship status. Business income and shareholding are verified "
            "wealth sources for this applicant.\n"
            f"[/NARRATIVE]\n"
            f"{biz_table}"
            f"[/SECTION]\n"
        )
    else:
        sections.append(
            "[SECTION: Business Interests & Shareholding]\n"
            "[NARRATIVE]\n"
            "No verified data pertaining to business ownership, directorship, shareholding, "
            "dividends declared, or business revenue is present in the verified fields for "
            "this applicant. This section is not applicable to the current review.\n"
            "[/NARRATIVE]\n"
            "[/SECTION]\n"
        )

    # ── 4. Investment Portfolio ───────────────────────────────────────────────
    inv_labels = ["Portfolio Value", "Investment Income", "Holdings", "Dividends Received",
                  "Interest Income", "Unit Trust Value", "Brokerage Balance"]
    if any(v(lbl) for lbl in inv_labels):
        inv_rows = [f"ROW: {lbl} | {v(lbl)}" for lbl in inv_labels if v(lbl)]
        inv_table = (
            "[TABLE]\n"
            "CAPTION: Verified Investment Portfolio\n"
            "ALIGN: left,right\n"
            "HEADERS: Asset Class / Component | Verified Value\n"
            + "\n".join(inv_rows) + "\n"
            "[/TABLE]\n"
        )
        sections.append(
            "[SECTION: Investment Portfolio]\n"
            "[NARRATIVE]\n"
            "The applicant holds verified investment positions as documented in the submitted "
            "portfolio statements. Investment assets form part of the verified wealth profile.\n"
            "[/NARRATIVE]\n"
            f"{inv_table}"
            "[/SECTION]\n"
        )
    else:
        sections.append(
            "[SECTION: Investment Portfolio]\n"
            "[NARRATIVE]\n"
            "No verified data pertaining to investment portfolios, securities holdings, "
            "investment income, or interest income is present in the verified fields for "
            "this applicant. This section is not applicable to the current review.\n"
            "[/NARRATIVE]\n"
            "[/SECTION]\n"
        )

    # ── 5. Tax Compliance Evidence ────────────────────────────────────────────
    if has_tax:
        tax_rows = []
        for label in ["Year of Assessment", "Tax Reference Number", "Employment Income",
                      "Other Income", "Total Assessable Income", "Total Reliefs",
                      "Chargeable Income", "Net Tax Payable", "Tax Payable",
                      "Tax Payment Date", "Notice Date", "Issuing Authority",
                      "Earned Income Relief", "CPF Relief"]:
            if v(label):
                tax_rows.append(f"ROW: {label} | {v(label)}")

        ya = v("Year of Assessment", "")
        ya_str = f" for Year of Assessment {ya}" if ya else ""
        total_inc = v("Total Assessable Income", "")
        tax_pay = v("Net Tax Payable") or v("Tax Payable", "")

        tax_table = (
            "[TABLE]\n"
            f"CAPTION: Tax Assessment Summary{ya_str} — IRAS Notice of Assessment\n"
            "ALIGN: left,right\n"
            "HEADERS: Tax Computation Component | Amount\n"
            + "\n".join(tax_rows) + "\n"
            "[/TABLE]\n"
        )

        sections.append(
            f"[SECTION: Tax Compliance Evidence]\n"
            "[NARRATIVE]\n"
            f"The Inland Revenue Authority of Singapore Notice of Assessment{ya_str} has "
            "been reviewed and confirmed against the submitted documentation. "
            + (f"Total assessable income is recorded as {total_inc}. " if total_inc else "")
            + (f"Net tax payable is {tax_pay}. " if tax_pay else "")
            + "Tax compliance is current with no outstanding liabilities identified from the "
            "submitted documentation.\n"
            "[/NARRATIVE]\n"
            f"{tax_table}"
            "[/SECTION]\n"
        )
    else:
        sections.append(
            "[SECTION: Tax Compliance Evidence]\n"
            "[NARRATIVE]\n"
            "No tax assessment documentation is present in the verified fields for this "
            "applicant. This section is not applicable to the current review.\n"
            "[/NARRATIVE]\n"
            "[/SECTION]\n"
        )

    # ── 6. Other Financial Indicators ────────────────────────────────────────
    other_rows = []
    for label in ["Closing Balance", "Account Number", "Bank Name", "Total Credits",
                  "Total Debits", "CPF Ordinary Account Balance", "CPF Special Account Balance",
                  "CPF MediSave Balance", "Property Address", "Property Valuation",
                  "Dividend Amount", "Payment Date"]:
        if v(label):
            other_rows.append(f"ROW: {label} | {v(label)}")

    if other_rows:
        other_table = (
            "[TABLE]\n"
            "CAPTION: Other Verified Financial Indicators\n"
            "ALIGN: left,right\n"
            "HEADERS: Indicator | Verified Value\n"
            + "\n".join(other_rows) + "\n"
            "[/TABLE]\n"
        )
        sections.append(
            "[SECTION: Other Financial Indicators]\n"
            "[NARRATIVE]\n"
            "Additional verified financial indicators from the submitted documentation are "
            "presented below. These indicators supplement the primary wealth source evidence "
            "and are consistent with the applicant's overall wealth profile.\n"
            "[/NARRATIVE]\n"
            f"{other_table}"
            "[/SECTION]\n"
        )
    else:
        sections.append(
            "[SECTION: Other Financial Indicators]\n"
            "[NARRATIVE]\n"
            "No additional financial indicators beyond those assessed in preceding sections "
            "are present in the verified fields for this applicant.\n"
            "[/NARRATIVE]\n"
            "[/SECTION]\n"
        )

    # ── 7. Risk Assessment Summary ───────────────────────────────────────────
    # Derive risk rating from present data only
    complex_structures = has_business and not has_tax
    multi_source = sum([has_employment, has_business, bool(any(v(l) for l in inv_labels))]) > 1
    if multi_source or complex_structures:
        risk_rating = "MEDIUM"
        risk_basis = "Multiple verified wealth sources identified; documentation coverage is adequate."
    else:
        risk_rating = "LOW"
        risk_basis = "Single wealth source with government-issued documentation; no complex structures identified."

    sections.append(
        "[SECTION: Risk Assessment Summary]\n"
        "[NARRATIVE]\n"
        f"The source of wealth assessment has been conducted in accordance with MAS Notice "
        f"SFA 04-N13. {risk_basis} "
        f"The overall risk rating for this applicant is {risk_rating} based on the verified "
        "documentation provided.\n"
        "[/NARRATIVE]\n"
        "[TABLE]\n"
        "CAPTION: Risk Assessment Matrix\n"
        "ALIGN: left,left\n"
        "HEADERS: Assessment Category | Finding\n"
        f"ROW: Income Verification | {'Verified via submitted documentation' if has_employment or has_business else 'No income documentation submitted'}\n"
        f"ROW: Business Structure | {'Registered entity with verified ownership' if has_business else 'Not applicable — no business interests'}\n"
        f"ROW: Tax Compliance | {'Current — IRAS NOA reviewed' if has_tax else 'Not applicable — no tax documentation'}\n"
        f"ROW: Banking Evidence | {'Bank statements reviewed' if has_banking else 'Not applicable — no banking documentation'}\n"
        "ROW: Red Flags Identified | None\n"
        f"TOTAL: Overall Risk Rating | {risk_rating}\n"
        "[/TABLE]\n"
        "[/SECTION]\n"
    )

    # ── 8. Conclusion & Certification ────────────────────────────────────────
    sections.append(
        f"[SECTION: Conclusion & Certification]\n"
        "[NARRATIVE]\n"
        f"The Source of Wealth for {name} is adequately evidenced by the verified "
        f"documentation submitted. Primary wealth sources — {primary_source} — are "
        "documented, verified, and internally consistent across all submitted materials. "
        "This report has been prepared in compliance with MAS Notice SFA 04-N13 and "
        "applicable KYC/AML regulatory requirements.\n"
        "[/NARRATIVE]\n"
        "[TABLE]\n"
        "CAPTION: Report Certification Summary\n"
        "ALIGN: left,left\n"
        "HEADERS: Field | Details\n"
        "ROW: Prepared By | SOW Compliance Portal — Automated Assessment\n"
        f"ROW: Report Date | {gen_date}\n"
        f"ROW: Report Reference | {ref_id}\n"
        f"ROW: Applicant Name | {name}\n"
        + (f"ROW: Tax Reference | {tax_ref}\n" if tax_ref else "")
        + f"ROW: Profile Type | {profile_type.title()}\n"
        "ROW: Regulatory Basis | MAS Notice SFA 04-N13\n"
        "TOTAL: SOW Status | Adequately Evidenced\n"
        "[/TABLE]\n"
        "[/SECTION]\n"
    )

    report = "\n".join(sections)

    # Validate — no placeholders should exist in the fallback
    found = detect_placeholders(report)
    if found:
        logger.error("Fallback report generator produced placeholder text: %s", found)

    return report


# ── ENDPOINT ──────────────────────────────────────────────────────────────────

@router.post("/generate")
async def generate(body: GenerateRequest):
    """SSE endpoint: generates a Source of Wealth narrative from verified fields."""
    from routers.upload import session_states

    session_id = body.session_id
    state = session_states.get(session_id)
    if state is None:
        raise HTTPException(404, f"Session {session_id} not found.")

    if state.get("extraction_id") != body.extraction_id:
        raise HTTPException(400, "Extraction ID does not match session state.")

    session_states[session_id]["status"] = "generating"
    use_real = _has_llm()

    async def event_generator():
        # Enrich verified fields with source_file/source_page from session_states
        enriched = _enrich_fields_from_session(body.verified_fields, state)

        if use_real:
            try:
                from services.sow_writer_service import generate_sow

                profile_type = state.get("profile_type", "salaried")

                full_text = ""
                generation_id = None

                async for event in generate_sow(enriched, profile_type, session_id):
                    yield f"data: {json.dumps(event)}\n\n"
                    if event["type"] == "token":
                        full_text += event["text"]
                    elif event["type"] == "complete":
                        generation_id = event["generation_id"]

                # Validate for placeholders before saving
                from services.export_service import detect_placeholders
                found = detect_placeholders(full_text)
                if found:
                    logger.warning(
                        "generate: %d placeholder(s) in LLM output for session %s: %s",
                        len(found), session_id[:8], found[:5],
                    )
                    yield f"data: {json.dumps({'type': 'warning', 'message': f'{len(found)} placeholder value(s) detected in report — review before use'})}\n\n"

                session_states[session_id]["status"] = "generated"
                session_states[session_id]["generation_id"] = generation_id
                session_states[session_id]["generation_result"] = full_text
                return

            except Exception as e:
                logger.error("Real generation failed for session %s: %s", session_id, str(e))
                yield f"data: {json.dumps({'type': 'info', 'message': f'LLM generation failed ({type(e).__name__}), using structured template.'})}\n\n"

        # ── Structured fallback — no placeholder text ──────────────────────
        profile_type = state.get("profile_type", "salaried")
        full_text = _build_fallback_report(
            body.verified_fields, session_id, profile_type, enriched
        )

        # Stream the fallback word-by-word for consistent UX
        for section_name in SOW_SECTION_NAMES:
            yield f"data: {json.dumps({'type': 'section_start', 'section': section_name})}\n\n"

        words = full_text.split()
        chunk_size = 8
        for i in range(0, len(words), chunk_size):
            chunk = " ".join(words[i:i + chunk_size])
            if i + chunk_size < len(words):
                chunk += " "
            yield f"data: {json.dumps({'type': 'token', 'text': chunk})}\n\n"
            await asyncio.sleep(0.02)

        for section_name in SOW_SECTION_NAMES:
            yield f"data: {json.dumps({'type': 'section_complete', 'section': section_name, 'word_count': len(full_text.split())})}\n\n"

        generation_id = str(uuid.uuid4())
        session_states[session_id]["status"] = "generated"
        session_states[session_id]["generation_id"] = generation_id
        session_states[session_id]["generation_result"] = full_text

        yield f"data: {json.dumps({'type': 'complete', 'generation_id': generation_id, 'total_words': len(full_text.split())})}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")
