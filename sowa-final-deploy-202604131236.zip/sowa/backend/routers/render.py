"""
Render router — mock-mode data serving from the render/ folder.

When APP_MODE = "mock" this router provides:
  GET /api/v1/render/mode          — returns current APP_MODE
  GET /api/v1/render/fields        — scans render/ for .json files, flattens all
                                     values into field groups per source file
  GET /api/v1/render/pdfs          — returns list of .pdf filenames in render/
  GET /api/v1/render/pdf/{name}    — serves a PDF from render/ for inline preview
  GET /api/v1/render/stream_sow    — SSE stream of *_final_writeup.md content
"""
from __future__ import annotations

import json
import os
import asyncio
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, StreamingResponse

from services.config_loader import get_app_mode

router = APIRouter(prefix="/api/v1/render", tags=["Render"])

# Path to the render/ folder at SOWA project root (two levels up from backend/)
RENDER_DIR = Path(__file__).resolve().parent.parent.parent / "render"


def _ensure_render_dir() -> Path:
    RENDER_DIR.mkdir(parents=True, exist_ok=True)
    return RENDER_DIR


import re as _re


def _leaf_label(key: str) -> str:
    """Convert a snake_case or path key to a professional display label.
    Uses only the last segment — never shows the full JSON path."""
    # Strip array indices and take the last dot-segment
    key = _re.sub(r'\[\d+\]', '', key)
    parts = [p for p in key.replace('[', '.').replace(']', '').split('.') if p]
    leaf = parts[-1] if parts else key
    # Convert snake_case to Title Case
    return leaf.replace('_', ' ').title()


def _smart_group_json(obj: Any, filename: str) -> list[dict]:
    """
    Intelligently group a JSON object into categories for display.
    - Top-level dict with string-keyed sub-dicts → one category per sub-key (e.g. one per company)
    - Top-level dict with array of objects → one category per array item, named by year/name/id
    - Otherwise → flat list
    """
    import uuid as _uuid
    base_category = _category_for_filename(filename)
    categories = []

    def _make_field(key: str, value: Any, group_hint: str = "") -> dict:
        label = _leaf_label(key)
        return {
            "id": str(_uuid.uuid4()),
            "key": key,
            "display_label": label,
            "value": str(value) if value is not None else "",
            "confidence": 0.95,
            "source_file": filename,
            "source_page": 1,
            "display_category": base_category,
        }

    def _flatten_leaf(obj: Any, prefix: str = "") -> list[dict]:
        """Flatten to leaf fields, using only leaf key for display_label."""
        results = []
        if isinstance(obj, dict):
            for k, v in obj.items():
                full_key = f"{prefix}.{k}" if prefix else k
                if isinstance(v, (dict, list)):
                    results.extend(_flatten_leaf(v, full_key))
                else:
                    results.append(_make_field(full_key, v))
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                full_key = f"{prefix}[{i}]"
                if isinstance(item, (dict, list)):
                    results.extend(_flatten_leaf(item, full_key))
                else:
                    results.append(_make_field(full_key, item))
        else:
            results.append(_make_field(prefix, obj))
        return results

    if not isinstance(obj, dict):
        fields = _flatten_leaf(obj)
        if fields:
            categories.append({
                "category_name": base_category,
                "fields": fields,
                "source_file": filename,
            })
        return categories

    # Check if there is a single top-level key wrapping the real data
    top_keys = list(obj.keys())
    if len(top_keys) == 1:
        # One top key wrapping sub-objects — e.g. {"companies": {"A": {...}, "B": {...}}}
        wrapper_key = top_keys[0]
        inner = obj[wrapper_key]
        if isinstance(inner, dict) and all(isinstance(inner[k], dict) for k in inner):
            for group_name, group_data in inner.items():
                fields = _flatten_leaf(group_data)
                if fields:
                    # Professional category name: "Employment Income — Company Name"
                    cat_name = f"{base_category} — {group_name}"
                    categories.append({
                        "category_name": cat_name,
                        "fields": fields,
                        "source_file": filename,
                    })
            return categories
        elif isinstance(inner, list):
            # Array of objects — e.g. {"noa_data": [{year:2021,...}, ...]}
            for i, item in enumerate(inner):
                if isinstance(item, dict):
                    # Try to find a meaningful name (year, name, date, id)
                    name_val = (
                        item.get("year") or item.get("name") or
                        item.get("date") or item.get("id") or str(i + 1)
                    )
                    cat_name = f"{base_category} ({name_val})"
                    fields = _flatten_leaf(item)
                    if fields:
                        categories.append({
                            "category_name": cat_name,
                            "fields": fields,
                            "source_file": filename,
                        })
            return categories

    # Default: flat list grouped by the top-level keys
    for k, v in obj.items():
        sub_label = k.replace('_', ' ').title()
        cat_name = f"{base_category} — {sub_label}"
        if isinstance(v, (dict, list)):
            fields = _flatten_leaf(v, k)
        else:
            fields = [_make_field(k, v)]
        if fields:
            categories.append({
                "category_name": cat_name,
                "fields": fields,
                "source_file": filename,
            })

    return categories


def _flatten_json(obj: Any, prefix: str = "") -> list[dict]:
    """Legacy flat flatten — kept for backward compat. Use _smart_group_json instead."""
    import uuid as _uuid
    results = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            full_key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, (dict, list)):
                results.extend(_flatten_json(v, full_key))
            else:
                results.append({
                    "key": full_key,
                    "display_label": _leaf_label(full_key),
                    "value": str(v) if v is not None else "",
                    "confidence": 0.95,
                    "source_file": "",
                    "source_page": 1,
                    "display_category": "Other Wealth Sources",
                })
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            full_key = f"{prefix}[{i}]"
            if isinstance(item, (dict, list)):
                results.extend(_flatten_json(item, full_key))
            else:
                results.append({
                    "key": full_key,
                    "display_label": _leaf_label(full_key),
                    "value": str(item) if item is not None else "",
                    "confidence": 0.95,
                    "source_file": "",
                    "source_page": 1,
                    "display_category": "Other Wealth Sources",
                })
    else:
        results.append({
            "key": prefix or "value",
            "display_label": _leaf_label(prefix) or "Value",
            "value": str(obj) if obj is not None else "",
            "confidence": 0.95,
            "source_file": "",
            "source_page": 1,
            "display_category": "Other Wealth Sources",
        })
    return results


def _md_to_html(md: str) -> str:
    """
    Convert markdown to clean HTML on the backend.
    Handles: headers, bold, italic, tables, horizontal rules, paragraphs.
    This runs in Python so browser JS caching cannot affect it.
    """
    import html as _html

    def inline(text: str) -> str:
        text = _html.escape(text)
        text = _re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', text)
        text = _re.sub(r'\*\*(.+?)\*\*',     r'<strong>\1</strong>', text)
        text = _re.sub(r'\*(.+?)\*',          r'<em>\1</em>', text)
        text = _re.sub(r'`(.+?)`',            r'<code>\1</code>', text)
        return text

    def parse_md_table(lines: list[str]) -> str:
        if len(lines) < 2:
            return ''.join(f'<p>{inline(l)}</p>' for l in lines)
        parse_row = lambda l: [c.strip() for c in l.strip().strip('|').split('|')]
        headers   = parse_row(lines[0])
        data_rows = [parse_row(l) for l in lines[2:]
                     if l.strip() and not _re.match(r'^\|?[\s\-:]+\|', l.strip())]
        out = '<table class="sow-data-table"><thead><tr>'
        for h in headers:
            out += f'<th>{inline(h)}</th>'
        out += '</tr></thead><tbody>'
        for i, row in enumerate(data_rows):
            cls = ' class="row-even"' if i % 2 == 1 else ''
            out += f'<tr{cls}>'
            for cell in row:
                out += f'<td>{inline(cell)}</td>'
            out += '</tr>'
        out += '</tbody></table>'
        return out

    result = []
    lines  = md.split('\n')
    i      = 0
    sep_re = _re.compile(r'^\|?[\s\-:]+\|')

    while i < len(lines):
        raw  = lines[i]
        line = raw.strip()

        # Table block
        if line.startswith('|') and not sep_re.match(line):
            tbl = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                tbl.append(lines[i])
                i += 1
            result.append(parse_md_table(tbl))
            continue

        # Horizontal rule
        if _re.match(r'^[-*_]{3,}$', line):
            result.append('<hr style="border:none;border-top:1px solid #D4C9A8;margin:20px 0;">')
            i += 1; continue

        # ATX headings
        hm = _re.match(r'^(#{1,4})\s+(.*)', line)
        if hm:
            lvl  = len(hm.group(1))
            text = inline(hm.group(2))
            sizes = {1: '20px', 2: '17px', 3: '15px', 4: '13px'}
            result.append(
                f'<h{lvl} style="font-size:{sizes[lvl]};font-weight:700;'
                f'color:#1A1A1A;margin:{28 if lvl==1 else 22 if lvl==2 else 18}px 0 8px;'
                f'padding-left:12px;border-left:3px solid #9A7B3F;">'
                f'{text}</h{lvl}>'
            )
            i += 1; continue

        # Empty line
        if line == '':
            result.append('<div style="height:6px;"></div>')
            i += 1; continue

        # Paragraph
        result.append(f'<p style="margin:0 0 10px;line-height:1.75;">{inline(raw)}</p>')
        i += 1

    return ''.join(result)


def _category_for_filename(filename: str) -> str:
    """Guess display category from filename for better grouping."""
    name = filename.lower()
    if "noa" in name or "tax" in name:
        return "Tax & Assessment"
    if "emp" in name or "salary" in name or "payslip" in name:
        return "Employment Income"
    if "bank" in name or "statement" in name:
        return "Banking & Cash"
    if "cpf" in name:
        return "CPF & Retirement"
    if "share" in name or "dividend" in name or "equity" in name:
        return "Dividends & Shareholdings"
    if "invest" in name or "portfolio" in name:
        return "Investment Portfolio"
    if "property" in name or "real_estate" in name:
        return "Property & Real Estate"
    if "biz" in name or "corp" in name or "company" in name:
        return "Business & Corporate Income"
    return "Other Wealth Sources"


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/mode")
async def get_mode():
    """Return current APP_MODE so the frontend can gate its behaviour."""
    return {"app_mode": get_app_mode()}


@router.get("/fields")
async def get_render_fields():
    """
    Scan render/ for all .json files, flatten their contents, and return
    them as extraction categories grouped by source filename.
    """
    render_dir = _ensure_render_dir()
    json_files = sorted(render_dir.glob("*.json"))

    if not json_files:
        return {"categories": [], "total_fields": 0}

    categories = []

    for json_path in json_files:
        try:
            with open(json_path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue  # skip malformed files silently

        # Use smart grouper — one category per company/year, clean leaf labels
        file_cats = _smart_group_json(data, json_path.name)
        for cat in file_cats:
            cat["icon_key"] = cat["category_name"].lower() \
                .replace(" ", "_").replace("&", "and").replace("—", "").replace("(", "").replace(")", "")
        categories.extend(file_cats)

    total_fields = sum(len(c["fields"]) for c in categories)
    return {"categories": categories, "total_fields": total_fields}


@router.get("/pdfs")
async def list_render_pdfs():
    """Return a list of .pdf filenames available in the render/ folder."""
    render_dir = _ensure_render_dir()
    pdfs = [p.name for p in sorted(render_dir.glob("*.pdf"))]
    return {"pdfs": pdfs}


@router.get("/pdf/{filename}")
async def serve_render_pdf(filename: str):
    """Serve a PDF from the render/ folder for inline browser preview."""
    import urllib.parse
    safe_name = os.path.basename(urllib.parse.unquote(filename))
    file_path = RENDER_DIR / safe_name

    if not file_path.is_file() or not safe_name.lower().endswith(".pdf"):
        raise HTTPException(404, f"PDF '{safe_name}' not found in render/.")

    return FileResponse(
        str(file_path),
        media_type="application/pdf",
        headers={"Content-Disposition": "inline"},
    )


@router.get("/stream_sow")
async def stream_sow_writeup(session_id: str = ""):
    """
    SSE stream of the *_final_writeup.md file content.
    Streams HTML chunks and stores the raw markdown server-side so the
    export endpoint can read it without needing the frontend to send it back.
    The raw_markdown is NOT sent in the SSE stream (avoids large payload
    JSON-parse failures through CML network proxies).
    """
    render_dir = _ensure_render_dir()
    writeup_files = sorted(render_dir.glob("*_final_writeup.md"))

    if not writeup_files:
        raise HTTPException(
            404,
            "No *_final_writeup.md file found in render/. "
            "Place a file ending in '_final_writeup.md' in the render/ folder."
        )

    writeup_path = writeup_files[0]

    async def event_generator():
        try:
            with open(writeup_path, encoding="utf-8") as f:
                md_content = f.read()

            # Convert markdown → HTML on the backend
            html_content = _md_to_html(md_content)

            import uuid as _uuid
            gen_id = str(_uuid.uuid4())

            # Store raw markdown in session_states NOW (server-side, before streaming).
            # This means the export endpoint can always find it regardless of
            # whether the frontend successfully receives the complete event.
            if session_id:
                try:
                    from routers.upload import session_states
                    if session_id not in session_states:
                        session_states[session_id] = {}
                    session_states[session_id]["generation_id"]     = gen_id
                    session_states[session_id]["generation_result"] = md_content
                    session_states[session_id]["status"]            = "generated"
                except Exception:
                    pass  # non-fatal — inline sow_text fallback still works

            # Stream HTML in chunks
            CHUNK = 40
            for i in range(0, len(html_content), CHUNK):
                chunk = html_content[i:i + CHUNK]
                yield f"data: {json.dumps({'type': 'html_token', 'text': chunk})}\n\n"
                await asyncio.sleep(0.08)

            # Final complete event — small payload only (no raw_markdown)
            yield f"data: {json.dumps({'type': 'complete', 'generation_id': gen_id, 'total_words': len(md_content.split())})}\n\n"

        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.post("/save_result")
async def save_mock_result(body: dict):
    """
    Store mock generation result in session_states so the existing
    export endpoint can find it and generate PDF/DOCX.
    Called by the frontend after startGenerationMock() completes.
    """
    from routers.upload import session_states

    session_id      = body.get("session_id", "")
    generation_id   = body.get("generation_id", "mock-gen")
    generation_text = body.get("generation_result", "")
    profile_type    = body.get("profile_type", "salaried")

    if not session_id:
        from fastapi import HTTPException
        raise HTTPException(400, "session_id is required")

    if session_id not in session_states:
        session_states[session_id] = {
            "status": "generated",
            "profile_type": profile_type,
            "files": [],
            "files_count": 0,
            "extraction_id": "mock-extraction",
            "doc_categories": {},
        }

    session_states[session_id]["generation_id"]     = generation_id
    session_states[session_id]["generation_result"] = generation_text
    session_states[session_id]["status"]            = "generated"

    return {"ok": True, "session_id": session_id, "generation_id": generation_id}
