# Source of Wealth (SOW) Documentation Portal
# Complete Setup & Run Instructions

---

## Prerequisites

| Tool       | Version  | Purpose                          |
|------------|----------|----------------------------------|
| Python     | 3.10+    | Backend API                      |
| PostgreSQL | 16+      | Database                         |
| Docker     | 24+      | (Optional) Full-stack container  |
| pip        | 23+      | Python package manager           |

---

## Project Structure

```
sowa/
├── backend/                     # FastAPI backend
│   ├── main.py                  # Primary API entry point
│   ├── app.py                   # Standalone in-memory demo API
│   ├── database.py              # SQLAlchemy ORM + PostgreSQL
│   ├── schemas.py               # Pydantic models + document registry
│   ├── seed.py                  # Sample data seeder
│   ├── requirements.txt         # Python dependencies (15 packages)
│   ├── Dockerfile               # Backend container image
│   ├── config/
│   │   └── config.yaml          # Master config: provider mode, auth, all LLM providers
│   ├── providers/               # AI provider abstraction layer
│   │   ├── base.py              # Abstract interfaces (LLM, Vision, Embedding, Reranker, OCR)
│   │   ├── anthropic_provider.py
│   │   ├── openai_compatible_provider.py
│   │   ├── token_manager.py     # Bearer token cache for internal endpoints
│   │   └── provider_factory.py  # ProviderRegistry + init_providers()
│   ├── auth/                    # SSO/AD authentication
│   │   ├── user_store.py        # SQLite user allowlist
│   │   ├── sso_handler.py       # LDAP/Azure AD/OAuth2/demo
│   │   └── session_manager.py   # Session tokens (8-hour TTL)
│   ├── prompts/
│   │   ├── ocr_prompt.py
│   │   ├── extraction_prompt.py
│   │   └── sow_prompt.py
│   ├── services/
│   │   ├── config_loader.py     # YAML config reader (config.yaml)
│   │   ├── ocr_service.py       # PyMuPDF + Vision OCR
│   │   ├── extraction_service.py
│   │   ├── sow_writer_service.py
│   │   └── export_service.py
│   ├── routers/
│   │   ├── upload.py            # POST /api/v1/upload
│   │   ├── extract.py           # POST /api/v1/extract (SSE)
│   │   ├── generate.py          # POST /api/v1/generate (SSE)
│   │   ├── export.py            # POST /api/v1/export/{pdf|docx}
│   │   ├── admin.py             # POST /api/admin/* (user management)
│   │   └── auth_router.py       # POST /auth/* (login/logout)
│   ├── prompts_store/           # Prompt file storage (editable via Admin UI)
│   │   ├── prompts_registry.json
│   │   ├── *.txt                # Prompt files
│   │   └── history/             # Auto-version backups
│   └── audit_log.jsonl          # Admin audit trail (created on first change)
├── bos-portal/                  # Frontend (vanilla HTML/CSS/JS)
│   ├── index.html               # 5-step wizard portal
│   ├── app.js                   # Application logic + SSE streaming
│   ├── styles.css               # Full design system
│   └── logo.svg                 # Custom SOW shield logo
├── admin-console/               # Admin web UI
│   └── index.html               # User management console
├── postman/                     # API testing
│   ├── SOW_Portal_API.postman_collection.json
│   ├── openapi.json
│   └── POSTMAN_GUIDE.md
├── docker-compose.yml
├── .env.example
├── ARCHITECTURE.md
├── PROVIDER_SWITCH_README.md
└── RUN_INSTRUCTIONS.md
```

---

## Option A: Run with Docker (Recommended)

This is the simplest way. Docker handles PostgreSQL, backend, and frontend automatically.

### Step 1: Set environment variables (optional)

```bash
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY if you want real LLM features
# The app works without it using mock data
```

### Step 2: Start all services

```bash
docker compose up --build -d
```

### Step 3: Verify

```bash
docker compose ps
```

You should see 3 containers running:
- `findoc_postgres` — PostgreSQL 16 on port **5432**
- `findoc_backend` — FastAPI on port **8000**
- `findoc_frontend` — Static file server on port **3000**

### Step 4: Open the portal

- **Frontend Portal**: http://localhost:3000
- **Backend API Docs**: http://localhost:8000/docs
- **Login credentials**: `demo` / `gdo2024`
- **Admin Console**: http://localhost:8000/admin/ (login: `admin` / your `ADMIN_PASSWORD`)
- **File Sync (Admin)**: http://localhost:8000/admin/ → File Sync tab (edit config.yaml / .env live)
- **Prompt Editor (Admin)**: http://localhost:8000/admin/ → Prompt Management tab

### Stop

```bash
docker compose down
```

### Reset database

```bash
docker compose down -v   # -v removes the postgres volume
docker compose up --build -d
```

---

## Option B: Run Locally (without Docker)

### Step 1: Install PostgreSQL

**macOS (Homebrew):**
```bash
brew install postgresql@16
brew services start postgresql@16
createdb findoc_db
psql findoc_db -c "CREATE USER findoc WITH PASSWORD 'findoc_secret';"
psql findoc_db -c "GRANT ALL PRIVILEGES ON DATABASE findoc_db TO findoc;"
psql findoc_db -c "GRANT ALL ON SCHEMA public TO findoc;"
```

**Ubuntu/Debian:**
```bash
sudo apt install postgresql-16
sudo -u postgres createdb findoc_db
sudo -u postgres psql -c "CREATE USER findoc WITH PASSWORD 'findoc_secret';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE findoc_db TO findoc;"
```

### Step 2: Install Python dependencies

```bash
cd backend
python3 -m venv venv
source venv/bin/activate      # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

#### Python Libraries Installed:

| Library          | Version | Purpose                                       |
|------------------|---------|-----------------------------------------------|
| fastapi          | latest  | Web framework for the REST API                |
| uvicorn          | latest  | ASGI server to run FastAPI                    |
| sqlalchemy       | 2.0+    | ORM for PostgreSQL database access            |
| psycopg2-binary  | latest  | PostgreSQL driver for Python                  |
| pydantic         | 2.0+    | Data validation and serialization             |
| python-multipart | latest  | Multipart form data parsing (file uploads)    |
| PyMuPDF          | latest  | PDF page rendering for OCR (fitz library)     |
| anthropic        | latest  | Anthropic Claude API SDK for LLM calls        |
| pyyaml           | latest  | YAML config file parser                       |
| reportlab        | latest  | PDF generation with custom styling            |
| python-docx      | latest  | Microsoft Word DOCX file generation           |
| aiofiles         | latest  | Async file I/O operations                     |
| httpx            | latest  | Async HTTP client for provider API calls      |
| ldap3            | latest  | LDAP/Active Directory authentication          |
| msal             | latest  | Microsoft Azure AD authentication (MSAL)      |
| watchdog         | latest  | File system monitoring for config/prompt sync |
| websockets       | latest  | WebSocket support for real-time admin sync    |
| python-dotenv    | latest  | .env file parsing                             |

### Step 3: Set environment variables

```bash
export DATABASE_URL="postgresql://findoc:findoc_secret@localhost:5432/findoc_db"
export ANTHROPIC_API_KEY="sk-ant-your-key-here"   # Optional — app works with mock data
export ADMIN_PASSWORD="admin2024"           # Admin console password
```

### Step 4: Start the backend

```bash
cd backend
uvicorn main:app --reload --port 8000
```

The backend will:
- Create database tables automatically
- Seed sample data on first run
- Start the cleanup background task for session files
- Serve API at http://localhost:8000
- Serve API docs at http://localhost:8000/docs

### Step 5: Start the frontend (separate terminal)

```bash
cd bos-portal
python3 -m http.server 3000
```

Frontend available at http://localhost:3000

### Step 6: Open the portal

- **URL**: http://localhost:3000
- **Login**: `demo` / `gdo2024`

---

## Option C: Run Standalone Demo (No Database)

For a quick demo without PostgreSQL:

```bash
cd backend
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

This uses `app.py` (in-memory storage). The new SOW pipeline (Steps 3-5) requires `main.py` with PostgreSQL.

---

## 5-Step Workflow Guide

1. **Select Profile** — Choose Salaried Professional or Business Owner
2. **Upload Documents** — Upload 1+ documents (PDF/JPG/PNG, max 50MB each). Missing required docs show a soft warning but don't block you.
3. **Review Extraction** — System analyses documents via OCR and extracts financial data. Review and inline-edit any values. Confidence indicators show green/amber/red.
4. **Generate SOW** — Watch the Source of Wealth report generate in real-time with SSE streaming. Section progress pills show completion status.
5. **Summary & Export** — View the formatted report. Download as PDF or DOCX. Share with your Relationship Manager via email.

---

## API Endpoints

### Existing (preserved)

| Method | Path                              | Description                    |
|--------|-----------------------------------|--------------------------------|
| POST   | `/sessions/extract`               | Mock extraction + DB persist   |
| GET    | `/sessions`                       | List all sessions              |
| GET    | `/sessions/{id}`                  | Get session records            |
| GET    | `/sessions/{id}/history`          | Edit history                   |
| GET    | `/records/{id}`                   | Get single record              |
| PUT    | `/records/{id}`                   | Update record                  |
| DELETE | `/records/{id}`                   | Delete record                  |
| POST   | `/records/{id}/summarize`         | Mock LLM summary               |
| GET    | `/schema`                         | JSON Schema for all models     |

### New SOW Pipeline

| Method | Path                              | Description                    |
|--------|-----------------------------------|--------------------------------|
| POST   | `/api/v1/upload`                  | Upload files + create session  |
| GET    | `/api/v1/session/{id}/status`     | Pipeline state for reconnect   |
| POST   | `/api/v1/extract`                 | OCR + extraction (SSE stream)  |
| POST   | `/api/v1/generate`                | SOW generation (SSE stream)    |
| POST   | `/api/v1/export/{pdf\|docx}`      | Download report as PDF/DOCX    |

### Admin API

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/admin/login` | Admin login → X-Admin-Token |
| `GET` | `/api/admin/users` | List approved users |
| `POST` | `/api/admin/users` | Add user to allowlist |
| `DELETE` | `/api/admin/users/{username}` | Remove user |
| `GET` | `/api/admin/audit` | Admin audit log |
| `GET` | `/api/admin/health` | System health + provider status |

### Portal Auth

| Method | Path | Description |
|---|---|---|
| `POST` | `/auth/login` | SSO login → X-Session-Token |
| `POST` | `/auth/logout` | Invalidate session |
| `GET` | `/auth/me` | Current user info |

---

## Configuration

All settings are in `backend/config/config.yaml`. The key top-level switch:

```yaml
PROVIDER_MODE: "anthropic"   # anthropic | internal_vllm | openai | azure_openai | ollama | bedrock | vertex

AUTH:
  provider: "demo"           # demo | ldap | azure_ad | oauth2
  admin_username: "admin"
  admin_password_hash: ""    # SHA-256 hex (or use ADMIN_PASSWORD env var)

model:
  name: "claude-sonnet-4-20250514"
  temperature: 0.2
  max_tokens: 4096
  ocr_dpi: 200
```

See `PROVIDER_SWITCH_README.md` for full provider and auth configuration.

---

## Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `DATABASE_URL` | No | `postgresql://findoc:findoc_secret@localhost:5432/findoc_db` | PostgreSQL connection string |
| `ANTHROPIC_API_KEY` | No | (none) | Anthropic Claude API key. App works with mock data without it |
| `ADMIN_PASSWORD` | No | (none) | Admin console password. Required unless using admin_password_hash in config.yaml |

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `Connection refused` on port 5432 | PostgreSQL not running. Start it: `brew services start postgresql@16` or `docker compose up postgres -d` |
| `relation "document_sessions" does not exist` | Tables auto-create on startup. Restart the backend. |
| Container name conflict | Run `docker rm -f findoc_postgres findoc_backend findoc_frontend` then retry |
| `ANTHROPIC_API_KEY` not set | App works with mock data. Set the key for real OCR/LLM features. |
| Port 8000/3000 already in use | Kill existing process: `lsof -ti:8000 \| xargs kill` |
| Frontend can't reach backend | Ensure backend runs on port 8000. Check CORS (enabled for all origins). |
| Admin console shows blank/error | Session expired or wrong password | Clear browser sessionStorage, re-login at http://localhost:8000/admin/ |
| `Admin password not configured` error | ADMIN_PASSWORD not set | Add `ADMIN_PASSWORD=yourpassword` to `.env` and restart |
| Prompts not loading | `prompts_store/` missing | Backend auto-creates on first startup |
| Config changes lost on restart | Docker volume not mounted | Ensure `./backend:/app` volume in docker-compose.yml |
| WebSocket not connecting | Firewall or proxy | Try direct http://localhost:8000/admin/ access |

---

## Backup

A backup of the full codebase is at:
```
/Users/software/codebase/sowa-backup-20260331_210834.tar.gz
```

Restore with:
```bash
cd /Users/software/codebase
tar xzf sowa-backup-20260331_210834.tar.gz
```
