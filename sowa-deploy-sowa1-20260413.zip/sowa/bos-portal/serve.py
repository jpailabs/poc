"""No-cache static file server for the SOW portal frontend."""
import http.server
import os

class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def log_message(self, fmt, *args):
        pass  # suppress access logs to keep output clean

os.chdir("/app")
print("SOW Portal frontend serving on http://0.0.0.0:3000 (no-cache)")
http.server.HTTPServer(("", 3000), NoCacheHandler).serve_forever()
