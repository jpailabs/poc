#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# SOW Portal — One-time setup for /home/cdsw/poc/sowa1/
# Run this ONCE after uploading the ZIP.
# After this, use start_cml_sowa1.sh or the CML Application to run.
# ─────────────────────────────────────────────────────────────────────────────
set -e

PROJECT_ROOT="/home/cdsw/poc/sowa1"
BACKEND_DIR="$PROJECT_ROOT/backend"
VENV_DIR="$PROJECT_ROOT/venv"

echo "╔══════════════════════════════════════════════════════╗"
echo "║  SOW Portal — Setup for /home/cdsw/poc/sowa1        ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── 1. Verify files ────────────────────────────────────────────────────────
echo "[1/5] Checking files..."

[ -f "$BACKEND_DIR/main.py" ]          || { echo "ERROR: $BACKEND_DIR/main.py not found"; exit 1; }
[ -f "$PROJECT_ROOT/bos-portal/index.html" ] || { echo "ERROR: bos-portal not found"; exit 1; }
echo "      ✓ Source files present"

# ── 2. Fix admin-console placement ────────────────────────────────────────
echo "[2/5] Fixing admin-console placement..."

if [ -f "$PROJECT_ROOT/admin-console/index.html" ]; then
    cp -r "$PROJECT_ROOT/admin-console" "$BACKEND_DIR/admin-console"
    echo "      ✓ admin-console copied to backend/"
elif [ -f "$BACKEND_DIR/admin-console/index.html" ]; then
    echo "      ✓ admin-console already in correct location"
else
    echo "      ⚠ WARNING: admin-console/index.html not found — admin UI will not load"
fi

# ── 3. Use clean config ────────────────────────────────────────────────────
echo "[3/5] Setting up config..."

if [ -f "$BACKEND_DIR/config/config.yaml.cml" ]; then
    cp "$BACKEND_DIR/config/config.yaml.cml" "$BACKEND_DIR/config/config.yaml"
    echo "      ✓ Clean config deployed (no API keys)"
else
    echo "      ✓ Using existing config.yaml"
fi

# Update upload_dir in config to sowa1 path
python3 -c "
import re
f = '$BACKEND_DIR/config/config.yaml'
try:
    content = open(f).read()
    content = re.sub(r'upload_dir:.*', 'upload_dir: /home/cdsw/poc/sowa1/sow_sessions', content)
    open(f, 'w').write(content)
    print('      ✓ upload_dir updated to sowa1 path')
except: pass
"

# ── 4. Create virtual environment and install packages ────────────────────
echo "[4/5] Setting up Python environment..."

if [ -d "$VENV_DIR" ]; then
    echo "      ✓ Virtual environment already exists — skipping"
else
    echo "      Creating virtual environment..."
    python3 -m venv "$VENV_DIR"
    echo "      ✓ Virtual environment created"
fi

source "$VENV_DIR/bin/activate"

export PIP_USER=false
echo "      Installing packages..."
pip install -q --upgrade pip
if pip install -q -r "$BACKEND_DIR/requirements-cml.txt"; then
    echo "      ✓ Packages installed"
else
    echo "      Retrying without SSO packages..."
    grep -v "^ldap3\|^msal" "$BACKEND_DIR/requirements-cml.txt" > /tmp/req_nosso.txt
    pip install -q -r /tmp/req_nosso.txt
    echo "      ✓ Packages installed (without SSO)"
fi

# ── 5. Create required directories ────────────────────────────────────────
echo "[5/5] Creating directories..."

mkdir -p "$PROJECT_ROOT/sow_sessions"
touch "$PROJECT_ROOT/sow.db" 2>/dev/null || true
chmod +x "$PROJECT_ROOT/start_cml_sowa1.sh" 2>/dev/null || true
echo "      ✓ Directories ready"

# ── Done ──────────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ SETUP COMPLETE                                            ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "  NEXT STEPS:"
echo ""
echo "  A) Set environment variables in CML UI:"
echo "     Project → Settings → Environment Variables"
echo ""
echo "     DATABASE_URL    = sqlite:////home/cdsw/poc/sowa1/sow.db"
echo "     SOW_SESSIONS_DIR = /home/cdsw/poc/sowa1/sow_sessions"
echo "     ADMIN_PASSWORD  = <your password>"
echo ""
echo "  B) Create CML Application:"
echo "     Name   : SOW Portal (sowa1)"
echo "     Script : bash /home/cdsw/poc/sowa1/start_cml_sowa1.sh"
echo "     CPU    : 2 vCPU  |  Memory : 4 GB"
echo ""
echo "  C) After it starts — configure providers:"
echo "     Open <app-url>/admin/ → Configuration → set LLM/OCR/VLM endpoints"
echo ""
