# SOW Portal — Postman API Testing Guide

Complete guide for testing the Source of Wealth Portal API using Postman.

---

## Table of Contents

1. [Setup](#1-setup)
2. [Importing the Collection](#2-importing-the-collection)
3. [Importing the OpenAPI Spec](#3-importing-the-openapi-spec)
4. [Collection Variables](#4-collection-variables)
5. [End-to-End Pipeline Flow](#5-end-to-end-pipeline-flow)
6. [Request-by-Request Reference](#6-request-by-request-reference)
7. [Testing Legacy Endpoints](#7-testing-legacy-endpoints)
8. [SSE Stream Testing](#8-sse-stream-testing)
9. [Automated Test Scripts](#9-automated-test-scripts)
10. [Common Test Scenarios](#10-common-test-scenarios)

---

## 1. Setup

### Prerequisites

- **Postman** (desktop app or web) — https://www.postman.com/downloads/
- **SOW Portal backend running** on `http://localhost:8000`

Start the backend:
```bash
# Docker (recommended)
docker compose up -d

# Or standalone
cd backend && uvicorn main:app --reload --port 8000
```

Verify it's running:
```
GET http://localhost:8000/schema
```
Should return JSON with `registered_types` array.

---

## 2. Importing the Collection

### Method A: Import the Postman Collection (recommended)

1. Open Postman
2. Click **Import** (top-left)
3. Drag or browse to: `postman/SOW_Portal_API.postman_collection.json`
4. Click **Import**
5. The collection "SOW Portal API" appears in your sidebar with 4 folders and 17 requests

### Method B: Import from OpenAPI Spec

1. Open Postman
2. Click **Import**
3. Drag or browse to: `postman/openapi.json`
4. Postman auto-generates requests from the OpenAPI 3.1 spec
5. Note: this creates raw requests without the test scripts and variable chaining

**Recommendation:** Use Method A for the full experience with auto-populated variables.

---

## 3. Importing the OpenAPI Spec

The file `postman/openapi.json` is the raw OpenAPI 3.1 specification exported directly from the running FastAPI backend (`/openapi.json`). It contains:

- All endpoint paths, methods, and parameters
- Request/response schemas (Pydantic models)
- Validation error schemas

**Use cases:**
- Import into Postman for auto-generated request stubs
- Import into Swagger UI, Insomnia, or any OpenAPI-compatible tool
- Generate client SDKs using openapi-generator

---

## 4. Collection Variables

The collection uses these variables (auto-populated by test scripts as you run requests):

| Variable | Default | Set By | Used In |
|---|---|---|---|
| `base_url` | `http://localhost:8000` | Manual | All requests |
| `session_id` | (empty) | Upload Documents | Extract, Generate, Export, Status, Cancel |
| `extraction_id` | (empty) | Get Extraction Result | Generate SOW |
| `generation_id` | (empty) | Generate SOW | Export PDF, Export DOCX |
| `legacy_session_id` | (empty) | Create Session (Extract) | Legacy session endpoints |
| `record_id` | `1` | Create Session (Extract) | Legacy record endpoints |

### Changing the Base URL

If your backend runs on a different host/port:

1. Click the collection name "SOW Portal API"
2. Go to **Variables** tab
3. Change `base_url` current value (e.g., `http://192.168.1.100:8000`)
4. Click **Save**

---

## 5. End-to-End Pipeline Flow

Run these requests **in order** to test the complete SOW workflow. Variables are auto-chained via test scripts.

```
Step 1: Upload Documents          → saves {{session_id}}
Step 2: Extract — SSE Stream      → starts OCR + extraction
Step 3: Get Extraction Result     → saves {{extraction_id}}, returns categories + fields
Step 4: Get Session Status        → verify status = "extracted"
Step 5: Generate SOW — SSE Stream → generates report, saves {{generation_id}}
Step 6: Export as PDF             → downloads PDF binary
Step 7: Export as DOCX            → downloads DOCX binary
Step 8: Cancel Session            → cleanup (optional)
```

### Quick Run (Collection Runner)

1. Click the **"SOW Pipeline — Full Flow"** folder
2. Click **Run** (top-right)
3. **Important:** For Step 1, you must attach a file — click the "Upload Documents" request, go to Body, and select a PDF/image file for the `files` field
4. Click **Run SOW Pipeline — Full Flow**
5. Watch all 8 requests execute in sequence

---

## 6. Request-by-Request Reference

### 6.1 Upload Documents

```
POST {{base_url}}/api/v1/upload
Content-Type: multipart/form-data
```

**Body (form-data):**

| Key | Type | Value | Required |
|---|---|---|---|
| `files` | File | Select a PDF, JPG, or PNG file | Yes |
| `profile_type` | Text | `salaried` or `business` | Yes |

**Example Response:**
```json
{
    "session_id": "88182cea-a592-495c-a5aa-db7bcd3c7103",
    "uploaded_files": [
        {
            "file_id": "f6e26a1e-9cec-490d-a93a-06369aa75007",
            "filename": "noa_2023.pdf",
            "pages": 3,
            "size_kb": 245.5,
            "category_hint": "noa"
        }
    ]
}
```

**Test script auto-saves:** `session_id` → collection variable

**Notes:**
- You can upload multiple files by adding more `files` rows in form-data
- `category_hint` is auto-detected from filename (noa, payslip, bank, business, etc.)
- Files are stored at `/tmp/sow_sessions/{session_id}/`

---

### 6.2 Extract — SSE Stream

```
POST {{base_url}}/api/v1/extract
Content-Type: application/json
```

**Body (JSON):**
```json
{
    "session_id": "{{session_id}}"
}
```

**Response (Server-Sent Events stream):**
```
data: {"type": "progress", "page": 1, "total": 3, "filename": "noa_2023.pdf"}

data: {"type": "progress", "page": 2, "total": 3, "filename": "noa_2023.pdf"}

data: {"type": "progress", "page": 3, "total": 3, "filename": "noa_2023.pdf"}

data: {"type": "category_complete", "category": "Personal Information", "field_count": 4}

data: {"type": "category_complete", "category": "Employment Income", "field_count": 6}

data: {"type": "category_complete", "category": "Tax Assessment", "field_count": 3}

data: {"type": "complete", "extraction_id": "ac8ea511-...", "total_fields": 13, "categories": ["Personal Information", "Employment Income", "Tax Assessment"]}
```

**Notes:**
- This is an SSE endpoint — Postman shows the raw `data:` lines
- Each `progress` event represents one PDF page being OCR'd
- With `ANTHROPIC_API_KEY` set: real Claude Vision OCR (slower, real data)
- Without API key: smart mock extraction (fast, simulated data)
- The `extraction_id` in the `complete` event is needed for the generate step

---

### 6.3 Get Extraction Result

```
GET {{base_url}}/api/v1/extract/{{session_id}}/result
```

**Example Response:**
```json
{
    "extraction_id": "ac8ea511-e7eb-4716-b21f-28ffe76bc5a7",
    "session_id": "88182cea-a592-495c-a5aa-db7bcd3c7103",
    "total_fields": 13,
    "categories": [
        {
            "category_name": "Personal Information",
            "icon_key": "user",
            "fields": [
                {
                    "id": "dfe2ef8a-8755-47fd-bee9-c51a15b227f1",
                    "key": "Full Name",
                    "value": "John Tan Wei Ming",
                    "confidence": 0.97,
                    "source_file": "noa_2023.pdf",
                    "source_page": 1
                },
                {
                    "id": "d23199f1-e0f6-4347-acae-f4cb6307de02",
                    "key": "NRIC / Passport",
                    "value": "S****567A",
                    "confidence": 0.95,
                    "source_file": "noa_2023.pdf",
                    "source_page": 1
                }
            ]
        },
        {
            "category_name": "Employment Income",
            "icon_key": "briefcase",
            "fields": [
                {
                    "id": "a1b2c3d4-...",
                    "key": "Annual Base Salary",
                    "value": "SGD 420,000.00",
                    "confidence": 0.97,
                    "source_file": "noa_2023.pdf",
                    "source_page": 1
                }
            ]
        }
    ]
}
```

**Test script auto-saves:** `extraction_id` → collection variable

**Notes:**
- Call this AFTER the extract SSE stream completes
- Each field has a unique UUID `id`, confidence score (0-1), and source traceability
- Confidence: ≥0.9 = high (green), 0.75-0.89 = medium (amber), <0.75 = low (red)

---

### 6.4 Get Session Status

```
GET {{base_url}}/api/v1/session/{{session_id}}/status
```

**Example Response:**
```json
{
    "session_id": "88182cea-a592-495c-a5aa-db7bcd3c7103",
    "status": "extracted",
    "files_count": 1,
    "extraction_id": "ac8ea511-e7eb-4716-b21f-28ffe76bc5a7",
    "generation_id": null
}
```

**Status values:** `uploaded` → `extracting` → `extracted` → `generating` → `generated`

---

### 6.5 Generate SOW — SSE Stream

```
POST {{base_url}}/api/v1/generate
Content-Type: application/json
```

**Body (JSON):**
```json
{
    "session_id": "{{session_id}}",
    "extraction_id": "{{extraction_id}}",
    "verified_fields": [
        {
            "id": "1",
            "key": "Full Name",
            "value": "John Tan Wei Ming",
            "category": "Personal Information"
        },
        {
            "id": "2",
            "key": "Employer Name",
            "value": "TechCorp Pte Ltd",
            "category": "Employment Income"
        },
        {
            "id": "3",
            "key": "Annual Base Salary",
            "value": "SGD 420,000",
            "category": "Employment Income"
        },
        {
            "id": "4",
            "key": "Assessment Year",
            "value": "2023",
            "category": "Tax Assessment"
        },
        {
            "id": "5",
            "key": "Tax Payable",
            "value": "SGD 42,350",
            "category": "Tax Assessment"
        }
    ]
}
```

**Response (SSE stream):**
```
data: {"type": "section_start", "section": "Executive Summary"}

data: {"type": "token", "text": "This Source of Wealth "}

data: {"type": "token", "text": "report has been prepared "}

data: {"type": "token", "text": "for John Tan Wei Ming "}

data: {"type": "section_complete", "section": "Executive Summary", "word_count": 145}

data: {"type": "section_start", "section": "Employment History & Income"}

data: {"type": "token", "text": "The client is currently "}

...

data: {"type": "complete", "generation_id": "a965cf13-...", "total_words": 1250}
```

**Notes:**
- `verified_fields` are the user-reviewed fields from Step 3 (can be edited values)
- The `extraction_id` must match the one from the extract step
- With API key: real Claude streaming (rich, varied content)
- Without API key: template-based 8-section SOW with field substitution
- The `generation_id` in the final `complete` event is needed for export

---

### 6.6 Export as PDF

```
POST {{base_url}}/api/v1/export/pdf
Content-Type: application/json
```

**Body (JSON):**
```json
{
    "session_id": "{{session_id}}",
    "generation_id": "{{generation_id}}",
    "client_name": "John Tan Wei Ming",
    "profile_type": "Salaried Professional",
    "doc_count": 3,
    "field_count": 12,
    "word_count": 1250
}
```

**Response:** Binary PDF file

**In Postman:**
1. Send the request
2. Click **"Save Response"** → **"Save to a file"**
3. Save as `SOW_Report.pdf`
4. Open the PDF — you'll see the full branded report with:
   - "Source *of* Wealth" header
   - "SOURCE OF WEALTH REPORT" title
   - "PRIVATE & CONFIDENTIAL" marking
   - Client metadata table
   - Gold divider and section borders
   - CONFIDENTIAL watermark
   - Page numbers and reference ID

---

### 6.7 Export as DOCX

```
POST {{base_url}}/api/v1/export/docx
Content-Type: application/json
```

**Body:** Same as PDF export above.

**Response:** Binary DOCX file

**In Postman:** Save response to file as `SOW_Report.docx`

---

### 6.8 Cancel Session

```
DELETE {{base_url}}/api/v1/session/{{session_id}}
```

**Example Response:**
```json
{
    "detail": "Session 88182cea-a592-495c-a5aa-db7bcd3c7103 cancelled and cleaned up."
}
```

**Notes:**
- Removes session from in-memory state
- Deletes uploaded files from `/tmp/sow_sessions/{session_id}/`
- Use this to clean up after testing or to simulate the "Stop & Re-upload" feature

---

## 7. Testing Legacy Endpoints

These endpoints interact with the PostgreSQL database (seeded with sample data on startup).

### 7.1 Create Session (Extract)

```
POST {{base_url}}/sessions/extract
Content-Type: multipart/form-data
```

| Key | Type | Value |
|---|---|---|
| `doc_types` | Text | `noa` (or `noa,payslip,summary`) |
| `session_id` | Text | (optional — omit to create new) |
| `file` | File | (optional PDF) |

**Example Response:**
```json
[
    {
        "id": 1,
        "session_id": "550e8400-...",
        "subsession_id": "6ba7b810-...",
        "doc_type": "noa",
        "status": "extracted",
        "extracted_data": {
            "noa_data": [
                {"year": 2023, "employment_income": 85000.0, "tax_payable": 5200.0, "currency": "SGD"}
            ]
        },
        "verified_data": null,
        "diff_summary": null,
        "created_at": "2026-04-01T14:30:00Z",
        "updated_at": "2026-04-01T14:30:00Z"
    }
]
```

### 7.2 List All Sessions

```
GET {{base_url}}/sessions
```

Returns summary of all sessions in the database (seeded with 3 demo sessions).

### 7.3 Update Record

```
PUT {{base_url}}/records/1
Content-Type: application/json
```

```json
{
    "verified_data": {
        "noa_data": [
            {
                "year": 2023,
                "employment_income": 90000.0,
                "tax_payable": 5800.0,
                "currency": "SGD"
            }
        ]
    },
    "status": "verified"
}
```

**Response:** New record with `subsession_id` (append-only history).

### 7.4 Get Schema

```
GET {{base_url}}/schema
```

Returns JSON Schema for all 20+ registered document types, useful for understanding data structures.

---

## 8. SSE Stream Testing

Postman handles SSE responses as plain text. For better SSE testing:

### Option A: Postman (basic)

SSE responses show as raw text in the response body:
```
data: {"type": "progress", "page": 1, "total": 3, "filename": "noa.pdf"}

data: {"type": "complete", "extraction_id": "..."}
```

You can read the JSON from each `data:` line.

### Option B: curl (better for SSE)

```bash
# Extract with live streaming output
curl -N -X POST http://localhost:8000/api/v1/extract \
  -H "Content-Type: application/json" \
  -d '{"session_id": "YOUR_SESSION_ID"}'

# Generate with live streaming output
curl -N -X POST http://localhost:8000/api/v1/generate \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "YOUR_SESSION_ID",
    "extraction_id": "YOUR_EXTRACTION_ID",
    "verified_fields": [
      {"id":"1","key":"Full Name","value":"John Tan","category":"Personal"}
    ]
  }'
```

The `-N` flag disables buffering so you see events in real-time.

### Option C: Browser DevTools

Open http://localhost:3000, login, upload a file, and watch the Network tab:
- Filter by "EventStream" type
- Click the extract/generate request
- Switch to "EventStream" tab to see parsed events

---

## 9. Automated Test Scripts

The collection includes JavaScript test scripts that auto-populate variables.

### Upload Documents — Test Script

```javascript
var jsonData = pm.response.json();
if (jsonData.session_id) {
    pm.collectionVariables.set("session_id", jsonData.session_id);
    console.log("Saved session_id: " + jsonData.session_id);
}
pm.test("Upload successful", function () {
    pm.response.to.have.status(200);
    pm.expect(jsonData).to.have.property("session_id");
    pm.expect(jsonData.uploaded_files).to.be.an("array").that.is.not.empty;
});
```

### Get Extraction Result — Test Script

```javascript
var jsonData = pm.response.json();
if (jsonData.extraction_id) {
    pm.collectionVariables.set("extraction_id", jsonData.extraction_id);
    console.log("Saved extraction_id: " + jsonData.extraction_id);
}
pm.test("Extraction result has categories", function () {
    pm.response.to.have.status(200);
    pm.expect(jsonData.categories).to.be.an("array").that.is.not.empty;
    pm.expect(jsonData.total_fields).to.be.above(0);
});
```

### Writing Your Own Tests

Add tests to any request via the **Tests** tab:

```javascript
// Check status code
pm.test("Status is 200", function () {
    pm.response.to.have.status(200);
});

// Check response time
pm.test("Response under 5 seconds", function () {
    pm.expect(pm.response.responseTime).to.be.below(5000);
});

// Validate JSON structure
pm.test("Has required fields", function () {
    var json = pm.response.json();
    pm.expect(json).to.have.property("session_id");
});

// Save variable for next request
var data = pm.response.json();
pm.collectionVariables.set("my_variable", data.some_field);
```

---

## 10. Common Test Scenarios

### Scenario A: Happy Path — Salaried Professional

```
1. Upload Documents     → profile_type: "salaried", file: payslip.pdf
2. Extract              → wait for "complete" event
3. Get Extraction Result → verify employment + tax categories
4. Generate SOW         → pass all verified_fields
5. Export PDF           → save and verify 3-4 page report
6. Export DOCX          → save and verify formatted document
```

### Scenario B: Happy Path — Business Owner

```
1. Upload Documents     → profile_type: "business", files: biz_reg.pdf, financials.pdf
2. Extract              → verify shareholding + dividend categories appear
3. Generate SOW         → include business-specific fields
4. Export               → verify all 8 SOW sections
```

### Scenario C: Cancel Mid-Extraction

```
1. Upload Documents     → large PDF
2. Extract              → note the streaming starts
3. Cancel Session       → DELETE /api/v1/session/{id}
4. Get Session Status   → should return 404
```

### Scenario D: Error Handling — No Files

```
1. Upload Documents     → omit the files field
   Expected: 422 Validation Error
```

### Scenario E: Error Handling — Invalid Session

```
1. Extract with fake session_id: "00000000-0000-0000-0000-000000000000"
   Expected: 404 Session not found
```

### Scenario F: Error Handling — Wrong Extraction ID

```
1. Upload + Extract (get real session_id + extraction_id)
2. Generate with wrong extraction_id: "fake-id"
   Expected: 400 Extraction ID does not match
```

### Scenario G: Export Without Generation

```
1. Upload + Extract (skip generate)
2. Export PDF with session_id but fake generation_id
   Expected: 400 Generation ID does not match
```

### Scenario H: Legacy CRUD Flow

```
1. POST /sessions/extract    → doc_types: "noa,payslip"
2. GET /sessions             → verify new session appears
3. GET /sessions/{id}        → verify 2 records (noa + payslip)
4. PUT /records/{id}         → update with verified_data
5. GET /sessions/{id}/history → verify 2 subsessions (original + update)
6. POST /records/{id}/summarize → get LLM summary
7. DELETE /records/{id}      → cleanup
```

---

## 11. Admin & Auth API Testing

### 11.1 Admin Login

```http
POST {{base_url}}/api/admin/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin2024"
}
```

Response:
```json
{"token": "abc123...", "expires_in": 28800}
```

Save the token — use it as `X-Admin-Token` header in all subsequent admin requests.

### 11.2 Add User to Allowlist

```http
POST {{base_url}}/api/admin/users
Content-Type: application/json
X-Admin-Token: <admin-token>

{
  "username": "alice@company.com",
  "display_name": "Alice Wong",
  "email": "alice@company.com"
}
```

Response: `201 Created`
```json
{"message": "User 'alice@company.com' added successfully", "user": {...}}
```

### 11.3 List Approved Users

```http
GET {{base_url}}/api/admin/users
X-Admin-Token: <admin-token>
```

### 11.4 Remove User

```http
DELETE {{base_url}}/api/admin/users/alice@company.com
X-Admin-Token: <admin-token>
```

### 11.5 System Health Check

```http
GET {{base_url}}/api/admin/health
X-Admin-Token: <admin-token>
```

Response:
```json
{
  "status": "ok",
  "provider_mode": "anthropic",
  "providers": {"llm": true, "vision": true, "embedding": false, "reranker": false, "ocr": false},
  "active_users": 3,
  "timestamp": "2026-04-03T10:00:00"
}
```

### 11.6 Portal User Login (SSO)

```http
POST {{base_url}}/auth/login
Content-Type: application/json

{
  "username": "demo",
  "password": "gdo2024"
}
```

Response:
```json
{
  "token": "e2c3fd78...",
  "username": "demo",
  "display_name": "Demo User",
  "email": "demo@sow-portal.local",
  "role": "user"
}
```

Use the returned `token` as `X-Session-Token` header in portal API calls.

### 11.7 Get Current User Session

```http
GET {{base_url}}/auth/me
X-Session-Token: <session-token>
```

### 11.8 Logout

```http
POST {{base_url}}/auth/logout
X-Session-Token: <session-token>
```

### Scenario I: Admin User Management Flow

```
1. POST /api/admin/login         → get admin token
2. GET  /api/admin/users         → list current users (empty initially)
3. POST /api/admin/users         → add alice@company.com
4. POST /api/admin/users         → add bob@company.com
5. GET  /api/admin/users         → verify 2 active users
6. GET  /api/admin/audit         → see ADD_USER events in log
7. POST /auth/login (alice)      → alice can now login (if LDAP configured)
8. DELETE /api/admin/users/alice → remove alice
9. GET  /api/admin/audit         → see REMOVE_USER event
```

---

## 12. Config & Prompt Management API Testing

### 12.1 Get Full Config (YAML)

```http
GET {{base_url}}/admin/api/config/yaml
X-Admin-Token: <admin-token>
```

Response: complete config.yaml as JSON object with all sections.

### 12.2 Get Config Section

```http
GET {{base_url}}/admin/api/config/yaml/LLM
X-Admin-Token: <admin-token>
```

Response:
```json
{
  "LLM": {
    "base_url": "https://llm-coordinator.example.com",
    "model_name": "Qwen3-Next-80B-A3B-Instruct-FP8",
    "api_key": ""
  }
}
```

### 12.3 Update Config Section

```http
PUT {{base_url}}/admin/api/config/yaml/LLM
X-Admin-Token: <admin-token>
Content-Type: application/json

{
  "values": {
    "model_name": "Qwen3-Next-80B-A3B-Instruct-FP8",
    "base_url": "https://llm-coordinator.example.com"
  }
}
```

Response:
```json
{
  "ok": true,
  "section": "LLM",
  "diff": {
    "model_name": {"old": "gpt-4", "new": "Qwen3-Next-80B-A3B-Instruct-FP8"}
  },
  "changed_keys": 1
}
```

### 12.4 Switch Provider Mode

```http
PUT {{base_url}}/admin/api/config/provider_mode
X-Admin-Token: <admin-token>
Content-Type: application/json

{"mode": "internal_vllm"}
```

### 12.5 Get .env Variables

```http
GET {{base_url}}/admin/api/config/env
X-Admin-Token: <admin-token>
```

Note: Sensitive keys (API keys, passwords) are masked as `••••••`. Use `/env/raw` for unmasked values.

### 12.6 Update .env Variables

```http
PUT {{base_url}}/admin/api/config/env
X-Admin-Token: <admin-token>
Content-Type: application/json

{
  "values": {
    "ANTHROPIC_API_KEY": "sk-ant-new-key",
    "ADMIN_PASSWORD": "newpassword"
  }
}
```

### 12.7 Export config.yaml as File

```http
GET {{base_url}}/admin/api/config/export/yaml
X-Admin-Token: <admin-token>
```

In Postman: Send → Save Response → Save to file → `config.yaml`

### 12.8 Force Hot Reload

```http
POST {{base_url}}/admin/api/config/reload
X-Admin-Token: <admin-token>
```

Triggers re-read of config.yaml and .env from disk + re-initialises all AI providers.

---

### 12.9 List All Prompts

```http
GET {{base_url}}/admin/api/prompts
X-Admin-Token: <admin-token>
```

Response:
```json
{
  "prompts": [
    {"key": "ocr_extraction", "description": "OCR system prompt", "version": 2, "last_modified": "..."},
    {"key": "field_extraction", "description": "...", "version": 1, "variables": ["categories_list"], ...}
  ],
  "count": 4
}
```

### 12.10 Get Prompt Content

```http
GET {{base_url}}/admin/api/prompts/ocr_extraction
X-Admin-Token: <admin-token>
```

### 12.11 Save Prompt

```http
PUT {{base_url}}/admin/api/prompts/ocr_extraction
X-Admin-Token: <admin-token>
Content-Type: application/json

{
  "content": "You are an OCR specialist. Extract ALL text faithfully from the document image."
}
```

Response:
```json
{"ok": true, "key": "ocr_extraction", "version": 3, "diff_lines": 1}
```

### 12.12 Test Prompt Interpolation

```http
POST {{base_url}}/admin/api/prompts/field_extraction/test
X-Admin-Token: <admin-token>
Content-Type: application/json

{
  "variables": {
    "categories_list": "EMPLOYMENT_INCOME, TAX_DOCUMENTS, SHAREHOLDING"
  }
}
```

Response:
```json
{
  "key": "field_extraction",
  "rendered": "... Extract from categories: EMPLOYMENT_INCOME, TAX_DOCUMENTS, SHAREHOLDING ...",
  "variables_used": ["categories_list"]
}
```

### 12.13 Version History

```http
GET {{base_url}}/admin/api/prompts/ocr_extraction/versions
X-Admin-Token: <admin-token>
```

### 12.14 Restore a Version

```http
POST {{base_url}}/admin/api/prompts/ocr_extraction/restore/1
X-Admin-Token: <admin-token>
```

---

### 12.15 Read Audit Log

```http
GET {{base_url}}/admin/api/sync/audit?limit=50&action=config_update
X-Admin-Token: <admin-token>
```

Supported filters: `action`, `section`, `changed_by`, `limit`, `offset`.

Response:
```json
{
  "entries": [
    {
      "timestamp": "2026-04-04T10:00:00+00:00",
      "changed_by": "admin",
      "action": "config_update",
      "section": "LLM",
      "key": "model_name",
      "old_value": "gpt-4",
      "new_value": "Qwen3-Next-80B-A3B-Instruct-FP8",
      "details": null
    }
  ],
  "total": 25,
  "limit": 50,
  "offset": 0
}
```

### Scenario J: Full Config Change Flow

```
1. GET  /admin/api/config/yaml/LLM          → note current model_name
2. PUT  /admin/api/config/yaml/LLM          → update model_name
3. GET  /admin/api/config/yaml/LLM          → verify change persisted
4. GET  /admin/api/sync/audit?section=LLM   → see audit entry
5. POST /admin/api/config/reload            → force full reload
6. GET  /admin/api/health                   → verify provider re-initialized
```

### Scenario K: Prompt Edit + Version Restore

```
1. GET  /admin/api/prompts/ocr_extraction        → get current content
2. PUT  /admin/api/prompts/ocr_extraction        → save new content
3. GET  /admin/api/prompts/ocr_extraction/versions → see v1 in history
4. POST /admin/api/prompts/ocr_extraction/test   → test (no variables needed)
5. POST /admin/api/prompts/ocr_extraction/restore/1 → restore original
6. GET  /admin/api/prompts/ocr_extraction        → confirm restored
```

---

## Files Reference

| File | Size | Description |
|---|---|---|
| `postman/SOW_Portal_API.postman_collection.json` | ~18KB | Postman Collection v2.1 — 4 folders, 17 requests, test scripts |
| `postman/openapi.json` | ~41KB | OpenAPI 3.1 spec — auto-generated from FastAPI |
| `postman/POSTMAN_GUIDE.md` | — | This guide including Admin & Auth API testing |
| `ADMIN_CONSOLE.md` | — | Dedicated Admin Console technical reference |
