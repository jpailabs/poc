#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# SOW Portal — CML Application Startup Script
# This script is used by the CML Application to start the web server.
# It uses the virtual environment created by deploy.sh — no pip install here.
#
# Prerequisites: bash /home/cdsw/poc/sowa/deploy.sh must have been run first.
# ─────────────────────────────────────────────────────────────────────────────
set -e

PROJECT_ROOT="/home/cdsw/poc/sowa"
VENV_DIR="$PROJECT_ROOT/venv"
BACKEND_DIR="$PROJECT_ROOT/backend"
PORT="${CDSW_APP_PORT:-8000}"

echo "========================================================"
echo "  SOW Portal — Starting"
echo "  Port    : $PORT"
echo "  Venv    : $VENV_DIR"
echo "========================================================"

# ── Activate virtual environment ─────────────────────────────────────────────
if [ ! -f "$VENV_DIR/bin/activate" ]; then
    echo ""
    echo "ERROR: Virtual environment not found at $VENV_DIR"
    echo "       Run the deployment script first:"
    echo "       bash $PROJECT_ROOT/deploy.sh"
    exit 1
fi

source "$VENV_DIR/bin/activate"
echo "  Venv    : activated ($(python --version))"

# ── Configure paths ───────────────────────────────────────────────────────────
export DATABASE_URL="${DATABASE_URL:-sqlite:////home/cdsw/poc/sowa/sow.db}"
export SOW_SESSIONS_DIR="${SOW_SESSIONS_DIR:-$PROJECT_ROOT/sow_sessions}"
mkdir -p "$SOW_SESSIONS_DIR"

echo "  DB      : $DATABASE_URL"
echo "  Uploads : $SOW_SESSIONS_DIR"
echo ""
echo "  BOS Portal    → <CML App URL>/"
echo "  Admin Console → <CML App URL>/admin/"
echo "  API Docs      → <CML App URL>/docs"
echo ""

# ── Start application ─────────────────────────────────────────────────────────
cd "$BACKEND_DIR"
exec uvicorn main:app \
    --host 0.0.0.0 \
    --port "$PORT" \
    --workers 1 \
    --loop asyncio \
    --log-level info
