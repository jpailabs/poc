# Source of Wealth Report — NP00010018

---

## Disclaimer

Please ensure that you verify the generated outputs before using it.

---

## Client's Background

100, 120 Ltd is a 54-year-old Singaporean female born on January 5, 1974 (as of 2045). She is married and resides in Singapore. She has a degree, but the school name and year of graduation are not provided. She is married to Lawrence Wang, and they have two children.

Please provide further details on the client's background/bio data.

---

## Client's Employment Overview

100, 120 Ltd worked at Pacific Star, a private equity firm, from 2000 to 2008 as a Director. 100, 120 Ltd worked at Familillas Group, a single/multiple family office, from 2011 to present as a Director. 100, 120 Ltd worked at UBS / Citigroup / DBS / BNP / GIC as a Manager / Director in financial institutions for 13 years.

---

## Main Source of Wealth

Wealth accumulated from 100, 120 Ltd's employment is as follows:

### UBS / Citigroup / DBS / BNP Partner — Singapore (2000 – 2011)

100, 120 Ltd held the position of Manager / Director in UBS / Citigroup / DBS / BNP Partners and his salary per annum is SGD 100,120 (USD).

There is a significant change in income In 2006 (SGD 25,000.01) compared to SGD 173,000.01, with a difference of SGD 173,000, a change of -17,449 compared to previous year. Please provide the justification for this significant discrepancy of more than 200.

### Pacific Star — Singapore (2000 – 2008)

100, 120 Ltd held his position in Pacific Star and his salary per annum is SGD 119,199. The source of wealth accumulated from this employment is SGD 860,946.15.

There is a significant change in Income In 2008 (SGD 175,000.01) compared to SGD 175,000.01, with a difference of SGD 175,000, a change of ~17,449 compared to previous year. Please provide the justification for this significant discrepancy of more than 200.

### Familillas Group — Singapore (2011 – 2021)

100, 120 Ltd held his position at Familillas Group and his salary per annum is SGD 121,984. The source of wealth accumulated from this employment is SGD 1,740,000.00.

There is a significant change in Income in 2021 (SGD 21,000.01) compared to SGD 175,000.01, with a difference of SGD 574,000, a change of 316,034 compared to previous year. Please provide the justification for this significant discrepancy of more than 200.

---

## SOW Calculation Assumptions

Expenditure rate is set at **10%**.

**Inflation rate used in calculation:**

Inflation rate is the percentage rate applied on observed salary per annum column as per the country of employment. Average inflation rate is computed by taking the average of most recent 10 years of annual inflation rate with a minimum of 1% and cap at 10% for respective years with negative inflation or hyperinflation.

| Country   | Inflation Rate % |
|-----------|-----------------|
| Singapore | 2.38            |

**Inflation adjusted salary = Salary (last year's pk) / (1 + inflation_rate/k), where k = number of years discounted back from current year to year salary was reported in**

Income tax rate used in calculation of Notice of Assessment is not available.

| Date       | Currency Code | Currency Name | Currency Rate |
|------------|--------------|---------------|--------------|
| 2000-01-01 | SGD          | SGD Dollar    | 1.00         |

**Notes:**

[Singapore] — The highest income tax rate in Singapore is 45%, applicable to individuals with annual incomes exceeding SGD 500,000.

**The tax free employment income is calculated as:**

`Salary = Salary per annum / (tax_rate - % of Living)`

All currency has been converted to SGD before calculation.

**Wealth from employment is calculated as the sum of all the SOW from each year in the company.**

---

## Salary Tables by Employer

### Pacific Star

| Year | Actual Salary (Original Currency) | Exchange Rate (SGD) | Accrued Tax (SGD) | Cost of Living (SGD) | Actual Salary (SGD) | Net Salary | Observed Salary |
|------|----------------------------------|--------------------|--------------------|---------------------|--------------------|-----------:|----------------:|
| 2000 | 85,811.29 | 1.00 | 14,275.41 | 5,867.21 | 85,811.29 | 65,668.67 | 270,008.13 |
| 2001 | 87,142.62 | 1.00 | 14,497.10 | 5,958.93 | 87,142.62 | 66,686.59 | 262,496.10 |
| 2002 | 88,499.70 | 1.00 | 14,722.35 | 6,052.23 | 88,499.70 | 67,725.12 | 255,218.18 |
| 2003 | 89,883.20 | 1.00 | 14,950.73 | 6,147.14 | 89,883.20 | 68,785.33 | 248,162.30 |
| 2004 | 91,293.69 | 1.00 | 15,182.38 | 6,243.68 | 91,293.69 | 69,867.63 | 241,315.24 |
| 2005 | 91,881.95 | 1.00 | 15,280.15 | 6,285.95 | 91,881.95 | 70,315.85 | 241,315.24 |
| 2006 | 92,477.23 | 1.00 | 15,380.50 | 6,328.34 | 92,477.23 | 70,768.39 | 234,760.89 |
| 2007 | 93,079.63 | 1.00 | 15,480.25 | 6,371.31 | 93,079.63 | 71,228.07 | 228,397.92 |
| 2008 | 93,689.24 | 1.00 | 15,581.76 | 6,414.88 | 93,689.24 | 71,692.60 | 222,219.80 |

**SOW from Pacific Star: SGD 519,832.00**

---

### UBS / Citigroup / DBS / BNP Far

| Year | Actual Salary (Original Currency) | Exchange Rate (SGD) | Accrued Tax (SGD) | Cost of Living (SGD) | Actual Salary (SGD) | Net Salary | Observed Salary |
|------|----------------------------------|--------------------|--------------------|---------------------|--------------------|-----------:|----------------:|
| 2001 | 91,961.41 | 1.00 | 15,293.57 | 6,291.44 | 91,961.41 | 70,376.40 | 621,523.48 |
| 2002 | 93,462.23 | 1.00 | 15,543.48 | 6,394.12 | 93,462.23 | 71,524.63 | 603,923.69 |
| 2003 | 94,987.97 | 1.00 | 15,797.07 | 6,498.22 | 94,987.97 | 72,692.68 | 586,820.81 |
| 2004 | 96,538.46 | 1.00 | 16,054.44 | 6,603.78 | 96,538.46 | 73,880.24 | 570,201.94 |
| 2005 | 98,114.55 | 1.00 | 16,315.66 | 6,710.84 | 98,114.55 | 75,088.05 | 554,050.38 |
| 2006 | 99,716.07 | 1.00 | 16,580.79 | 6,819.41 | 99,716.07 | 76,315.87 | 538,350.69 |
| 2007 | 101,343.88 | 1.00 | 16,849.94 | 6,929.52 | 101,343.88 | 77,564.42 | 523,087.52 |
| 2008 | 102,998.83 | 1.00 | 17,123.14 | 7,041.20 | 102,998.83 | 78,834.49 | 508,244.60 |
| 2009 | 104,681.74 | 1.00 | 17,400.52 | 7,154.47 | 104,681.74 | 80,126.75 | 493,806.59 |
| 2010 | 106,393.42 | 1.00 | 17,682.14 | 7,269.35 | 106,393.42 | 81,441.93 | 479,758.03 |
| 2011 | 108,134.69 | 1.00 | 17,967.98 | 7,385.86 | 108,134.69 | 82,780.85 | 466,083.28 |
| 2012 | 109,906.40 | 1.00 | 18,258.27 | 7,504.02 | 109,906.40 | 84,144.11 | 452,766.58 |
| 2013 | 111,709.40 | 1.00 | 18,552.99 | 7,623.86 | 111,709.40 | 85,532.55 | 439,792.84 |
| 2014 | 113,544.55 | 1.00 | 18,852.37 | 7,745.40 | 113,544.55 | 86,946.78 | 427,146.76 |
| 2015 | 115,412.74 | 1.00 | 19,156.49 | 7,868.67 | 115,412.74 | 88,387.58 | 414,813.76 |
| 2016 | 117,314.89 | 1.00 | 19,465.43 | 7,993.70 | 117,314.89 | 89,855.76 | 402,779.07 |
| 2017 | 119,251.90 | 1.00 | 19,779.27 | 8,120.51 | 119,251.90 | 91,352.12 | 391,028.63 |
| 2018 | 121,224.68 | 1.00 | 20,098.10 | 8,249.13 | 121,224.68 | 92,877.45 | 379,547.98 |
| 2019 | 123,234.12 | 1.00 | 20,421.99 | 8,379.58 | 123,234.12 | 94,432.55 | 368,323.38 |
| 2020 | 125,281.19 | 1.00 | 20,751.06 | 8,511.91 | 125,281.19 | 96,018.22 | 357,340.68 |
| 2021 | 127,367.03 | 1.00 | 21,085.38 | 8,646.14 | 127,367.03 | 97,635.51 | 346,586.47 |

**SOW from UBS / Citigroup / DBS / BNP Far: SGD 1,000,033.00**

---

### Familillas Group

| Year | Actual Salary (Original Currency) | Exchange Rate (SGD) | Accrued Tax (SGD) | Cost of Living (SGD) | Actual Salary (SGD) | Net Salary | Observed Salary |
|------|----------------------------------|--------------------|--------------------|---------------------|--------------------|-----------:|----------------:|
| 2011 | 392,961.41 | 1.00 | 65,353.57 | 26,866.44 | 392,961.41 | 300,741.40 | 621,523.48 |
| 2012 | 399,351.23 | 1.00 | 66,415.48 | 27,309.12 | 399,351.23 | 305,626.63 | 603,923.69 |
| 2013 | 405,841.97 | 1.00 | 67,494.07 | 27,760.22 | 405,841.97 | 310,587.68 | 586,820.81 |
| 2014 | 412,436.46 | 1.00 | 68,590.44 | 28,219.78 | 412,436.46 | 315,626.24 | 570,201.94 |
| 2015 | 419,137.55 | 1.00 | 69,704.66 | 28,687.84 | 419,137.55 | 320,745.05 | 554,050.38 |
| 2016 | 501,716.07 | 1.00 | 83,450.79 | 34,308.41 | 501,716.07 | 383,956.87 | 538,350.69 |
| 2017 | 509,743.88 | 1.00 | 84,784.94 | 34,855.52 | 509,743.88 | 390,103.42 | 523,087.52 |
| 2018 | 517,998.83 | 1.00 | 86,158.14 | 35,414.20 | 517,998.83 | 396,426.49 | 508,244.60 |
| 2019 | 526,481.74 | 1.00 | 87,571.52 | 35,984.47 | 526,481.74 | 402,925.75 | 493,806.59 |
| 2020 | 535,193.42 | 1.00 | 89,025.14 | 36,566.35 | 535,193.42 | 409,601.93 | 479,758.03 |
| 2021 | 539,617.03 | 1.00 | 89,761.98 | 36,868.86 | 539,617.03 | 412,986.19 | 466,083.28 |

**SOW from Familillas Group: SGD 3,762,303.00**

---

## Benchmark Salary from BOS Datasheets

| Position Title | Nature of Employer | Max Salary and pp | Medical Salary and pp | Average |
|---------------|-------------------|------------------|-----------------------|---------|
| Director | Private equity | SGD 218,000 | SGD 1,073 | SGD 1,073 |
| Director | Single/Multiple Family offices act | SGD 121,584 | — | SGD 385,551 |

---

## Benchmark Salary from MAS Datasheets

| Position Title | Nature of Employer | Max salary pa | Medical salary pa | Average |
|---------------|-------------------|--------------|-------------------|---------|
| Director | 125,000 | Private equity | SGD 39,000 | SGD 218,000 |
| Director | 121,584 | Single/Multiple Family offices act | SGD 121,584 | SGD 385,551 |

---

## Breakdown of Total SOW

| Source | Amount (SGD) |
|--------|-------------|
| Pacific Star (2000–2008) | 519,832.00 |
| UBS / Citigroup / DBS / BNP (2001–2021) | 1,000,033.00 |
| Familillas Group (2011–2021) | 3,762,303.00 |
| **Total SOW from Employment** | **5,282,168.00** |

**SOW from Employment: SGD 5,282,168.03** (based on sum of all yearly net savings across all employers)

**TOTAL SOW: SGD 5,282,168.03**

---

*This report has been generated for compliance review purposes under MAS Notice SFA 04-N13. All figures are based on verified employment records and IRAS Notice of Assessments. Please verify all values before submission.*
