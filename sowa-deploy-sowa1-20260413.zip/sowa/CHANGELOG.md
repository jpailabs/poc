# SOW Portal — Full Change Log

All changes made to the codebase across this development session, documented for rollback reference.
Each section describes what changed, why, and what the original code was doing.

---

## Table of Contents

1. [Critical Bug Fix — Async Event Loop Blocking](#1-critical-bug-fix--async-event-loop-blocking)
2. [Vector Store — Non-Blocking Embeddings & Batched Reranking](#2-vector-store--non-blocking-embeddings--batched-reranking)
3. [Private Pipeline — Sync SDK Calls Wrapped in Executor](#3-private-pipeline--sync-sdk-calls-wrapped-in-executor)
4. [Native Pipeline — Sync SDK Call Fixed](#4-native-pipeline--sync-sdk-call-fixed)
5. [Document Ingestion — Sync SDK Calls Fixed](#5-document-ingestion--sync-sdk-calls-fixed)
6. [Service Registry — OpenAI Client Timeout Fix & Async LLM](#6-service-registry--openai-client-timeout-fix--async-llm)
7. [Extraction Service — Full Rewrite & Parser Hardening](#7-extraction-service--full-rewrite--parser-hardening)
8. [Admin Config — Service Registry Auto-Reload](#8-admin-config--service-registry-auto-reload)
9. [Pipeline Router — Provider Routing Fix](#9-pipeline-router--provider-routing-fix)
10. [OpenAI-Compatible Provider — Error Logging & URL Fix](#10-openai-compatible-provider--error-logging--url-fix)
11. [Anthropic Provider — Thread-Pool Executor Wrapper](#11-anthropic-provider--thread-pool-executor-wrapper)
12. [Pipeline Status — Event System Fix](#12-pipeline-status--event-system-fix)
13. [Field Extraction Counts — total_fields Bug](#13-field-extraction-counts--total_fields-bug)
14. [Category Display Names — Pipeline Result Fix](#14-category-display-names--pipeline-result-fix)
15. [Frontend — SSE Timeout & Retry Logic](#15-frontend--sse-timeout--retry-logic)
16. [SOW Generation — Provider Routing Fix](#16-sow-generation--provider-routing-fix)
17. [SOW Generation — Structured Text Token Emission Fix](#17-sow-generation--structured-text-token-emission-fix)
18. [SOW Prompt — Complete Rewrite to Compliance Standard](#18-sow-prompt--complete-rewrite-to-compliance-standard)
19. [SOW Export — Structured Text Parser & PDF Renderer](#19-sow-export--structured-text-parser--pdf-renderer)
20. [Generate Router — Placeholder Fix & Field Enrichment](#20-generate-router--placeholder-fix--field-enrichment)
21. [Export Service — Placeholder Detector](#21-export-service--placeholder-detector)
22. [Database — SQLite Compatibility for CML](#22-database--sqlite-compatibility-for-cml)
23. [File Paths — Configurable Upload Directory for CML](#23-file-paths--configurable-upload-directory-for-cml)
24. [CML Deployment — Startup Script & Requirements](#24-cml-deployment--startup-script--requirements)

---

## 1. Critical Bug Fix — Async Event Loop Blocking

### File: `backend/providers/anthropic_provider.py`

**Problem:** `anthropic.Anthropic().messages.create()` is a synchronous blocking call. When called directly inside an `async def` function, it freezes the entire asyncio event loop. SSE events stop flowing, the browser shows the last status message forever, and the app appears stuck.

**Root Cause:** The Anthropic SDK is synchronous. Running it in an async context blocks the single-threaded event loop. All other coroutines (including SSE streaming) are blocked until the API call completes.

**Original code pattern:**
```python
async def complete(self, ...):
    resp = client.messages.create(...)   # BLOCKS the event loop
    return resp.content[0].text
```

**Fix applied:** All synchronous SDK calls wrapped in `asyncio.get_running_loop().run_in_executor(None, _sync_call)` with a 120-second hard timeout.

```python
async def complete(self, ...):
    def _sync_call():
        return client.messages.create(...)
    loop = asyncio.get_running_loop()
    return await asyncio.wait_for(
        loop.run_in_executor(None, _sync_call),
        timeout=LLM_TIMEOUT_SECONDS,
    )
```

**Applies to:** `complete()`, `stream()`, `vision_complete()` methods in `AnthropicLLMProvider` and `AnthropicVisionProvider`.

**To revert:** Remove the `_sync_call` closure and `run_in_executor` wrapper, call the SDK directly. The app will work for simple tests but freeze under load or with SSE streaming.

---

## 2. Vector Store — Non-Blocking Embeddings & Batched Reranking

### File: `backend/services/vector_store.py`

**Problem:** `openai_client.embeddings.create()` (sync OpenAI SDK) was called directly in async functions, blocking the event loop. Reranking was called once per query (8 times) instead of once for all candidates — potential 240-second hang.

**Root Cause:** Same async/sync mismatch as above. Additionally, the reranker was invoked N times in a loop instead of once with all candidates batched.

**Changes:**
1. All `embeddings.create()` calls moved inside `_sync_embed()` closures and run via `run_in_executor`
2. New `_embed_query()` helper — also non-blocking
3. New `rerank_batch()` method — single HTTP request for all candidates
4. Old `rerank()` now delegates to `rerank_batch()`
5. `asyncio.get_event_loop()` replaced with `asyncio.get_running_loop()` throughout

**Constants added:**
```python
EMBED_TIMEOUT = 30    # seconds per embedding call
RERANK_TIMEOUT = 20   # seconds for batch rerank
```

**To revert:** Call `client.embeddings.create()` directly without executor. Remove `rerank_batch()`, restore per-query reranking loop.

---

## 3. Private Pipeline — Sync SDK Calls Wrapped in Executor

### File: `backend/services/private_pipeline.py`

**Problem:** Four places in the private pipeline called `client.chat.completions.create()` (sync OpenAI SDK) directly inside async functions, blocking the event loop during OCR, VLM, LLM vision, and Stage 4 structuring calls.

**Affected methods:**
- `_call_ocr()` — OCR service call
- `_call_vlm_enhance()` — VLM enhancement call
- `_call_llm_vision()` — LLM vision fallback
- `_stage4_structure()` — Content structuring LLM call

**Fix pattern applied to all four:**
```python
# Before:
resp = client.chat.completions.create(model=model, messages=[...], max_tokens=4096)

# After:
def _sync_call():
    return client.chat.completions.create(timeout=60, model=model, messages=[...], max_tokens=4096)
loop = asyncio.get_running_loop()
resp = await loop.run_in_executor(None, _sync_call)
```

**Additional change:** Mock fallback on pipeline exception removed. When `_run_pipeline()` throws, the error is now yielded as a `{"type": "error"}` event instead of restarting the mock pipeline (which caused the "Document received. Analysing structure..." restart loop).

**To revert:** Call `client.chat.completions.create()` directly. The restart loop will also return if you restore the mock fallback in the `except` block of `run()`.

---

## 4. Native Pipeline — Sync SDK Call Fixed

### File: `backend/services/native_pipeline.py`

**Problem:** `_extract_page_with_llm()` called `llm.chat.completions.create()` directly, blocking the event loop during each page's foundation model extraction.

**Fix:** Same `run_in_executor` pattern applied. Also uses `asyncio.get_running_loop()` (not deprecated `get_event_loop()`).

**Additional change:** `extract_fields()` now receives `emitter` parameter so intermediate status events can be emitted during extraction. Category display names use `CATEGORY_TO_DISPLAY` mapping instead of `.replace("_"," ").title()`.

**To revert:** Call sync SDK directly. Remove emitter parameter from `_extract_fields()`.

---

## 5. Document Ingestion — Sync SDK Calls Fixed

### File: `backend/services/document_ingestion.py`

**Problem:** Three functions calling sync OpenAI SDK within async functions:
- `_extract_via_ocr()` — OCR call with retry loop
- `_extract_via_vlm()` — VLM call with retry loop
- `_extract_via_llm_vision()` — LLM vision fallback

**Fix:** All wrapped in `_sync_*_call()` closures and run via `run_in_executor`.

**To revert:** Call SDK methods directly inside the retry loops.

---

## 6. Service Registry — OpenAI Client Timeout Fix & Async LLM

### File: `backend/services/service_registry.py`

**Problems fixed:**

**A) Thread pool exhaustion:** The `openai.OpenAI` client was built with default `max_retries=2` and `timeout=600s`. A single unreachable endpoint would hang a thread for 30 minutes. With multiple LLM calls per pipeline, the thread pool filled up, blocking all subsequent operations.

**Original:**
```python
http_client = httpx.Client(timeout=timeout)  # 120s per attempt × 3 retries = 360s hang
return openai.OpenAI(base_url=..., api_key=..., http_client=http_client)
```

**Fix:** Short connect timeout + zero retries:
```python
http_timeout = httpx.Timeout(
    connect=10.0,          # fail fast if host unreachable
    read=min(timeout, 60), # capped at 60s for inference
    write=10.0,
    pool=5.0,
)
return openai.OpenAI(..., http_client=http_client, max_retries=0)
```

**B) Stale config after admin updates:** When admin updated LLM config (model, API key, provider mode), the cached `ServiceRegistry` singleton was never reloaded. The stale config persisted until server restart, causing 400 errors on subsequent extraction/generation calls.

**Fix:** `reload_service_registry()` is now called from `admin_config.py` after every `PUT /yaml/{section}` and `PUT /provider_mode` request.

**C) New `get_async_llm()` method:** Returns an `OpenAICompatibleLLMProvider` (async httpx, no threads) for the private LLM, falling back to `provider_factory.get_registry().llm` for native modes. Used by extraction and SOW generation to avoid sync SDK thread issues entirely.

**To revert:**
- Remove `httpx.Timeout` and `max_retries=0` from `_build_openai_client()`
- Remove `reload_service_registry()` calls from admin_config.py
- Remove `get_async_llm()` method

---

## 7. Extraction Service — Full Rewrite & Parser Hardening

### File: `backend/services/extraction_service.py`

**Multiple changes:**

**A) LLM call now uses async provider:**
`_call_llm_for_extraction()` was using the sync openai.OpenAI client via `run_in_executor`. Now uses `registry.get_async_llm().complete()` directly — fully async, no threads, no timeout workarounds.

**B) Classification skipped when category hint available:**
If the frontend provides a category hint (e.g. `income_tax`), the `classify_document_type()` LLM call is skipped — saves one full LLM round-trip (30–120s on private providers).

**C) Intermediate status events emitted:**
`extract_fields()` now accepts an optional `emitter` parameter. Status events are emitted before the primary LLM call ("Extracting fields from documents...") and before each secondary pass ("Running detailed extraction for IRAS_NOA...") so the UI shows progress instead of staying frozen on "Reranking...".

**D) Secondary extraction uses full system prompt:**
Previously, secondary passes used a minimal system prompt ("You are a financial compliance analyst...") that didn't include the field schema. The LLM returned inconsistent field formats. Now uses `get_extraction_system_prompt()` (full schema) matching the primary pass.

**E) `_parse_universal_response()` hardened:**
Original silently returned `[]` on any exception. New version:
- Strips `<think>...</think>` blocks from thinking models (qwen3, deepseek-r1)
- Strips markdown code fences
- Finds first JSON object/array in text (handles preamble)
- Supports both `{"fields": [...]}` and top-level list `[...]`
- Supports mixed key names: `field_name`/`key`, `raw_value`/`value`
- Logs the full raw response and error before returning empty
- `confidence` field accepts both float and string ("high"/"medium")

**F) `total_fields` added to return dict:**
```python
# Added to return statement:
"total_fields": sum(len(v) for v in categories.values()),
```
Without this, both pipelines read `extraction_result.get("total_fields", 0)` → always 0 → `needs_review = 0 - high_conf = negative`.

**To revert:**
- Restore `hasattr(client, 'chat')` branch with `run_in_executor` in `_call_llm_for_extraction()`
- Remove emitter parameter from `extract_fields()`
- Remove `<think>` stripping from `_parse_universal_response()`
- Remove `total_fields` from return dict

---

## 8. Admin Config — Service Registry Auto-Reload

### File: `backend/routers/admin_config.py`

**Problem:** Saving config in admin UI wrote to disk but the in-memory `ServiceRegistry` singleton was never invalidated. All pipeline calls continued using stale credentials/model names until server restart.

**Fix:** Added `reload_service_registry()` call to both config-saving endpoints:

```python
# Added to PUT /yaml/{section}:
from services.service_registry import reload_service_registry
reload_service_registry()

# Added to PUT /provider_mode:
reload_service_registry()
```

**To revert:** Remove the two `reload_service_registry()` calls and their imports.

---

## 9. Pipeline Router — Provider Routing Fix

### File: `backend/services/pipeline_router.py`

No code changes. Documents the routing logic:
- `provider_mode = "private"` or `"internal_vllm"` → `PrivatePipeline` (9-stage specialist)
- Any other mode → `NativePipeline` (5-stage foundation model)

---

## 10. OpenAI-Compatible Provider — Error Logging & URL Fix

### File: `backend/providers/openai_compatible_provider.py`

**A) URL normalization fix:**
`_normalize_base_url()` strips trailing `/v1` before storing. Prevents double `/v1/v1/chat/completions` when users configure a base URL that already includes `/v1` (e.g. OpenRouter: `https://openrouter.ai/api/v1`).

**B) Error response body logged:**
When any non-2xx response is received, the full response body is now logged at ERROR level before raising:
```python
if not resp.is_success:
    logger.error("LLM API error %d for model=%s body=%s",
                 resp.status_code, model, resp.text[:1000])
```
Previously, the error message was "400 Bad Request" with no body — impossible to diagnose why the request failed.

**To revert:** Remove the `if not resp.is_success:` logging block. Remove `_normalize_base_url()` (or keep it — it's non-breaking).

---

## 11. Anthropic Provider — Thread-Pool Executor Wrapper

*(See item 1 above — full details there.)*

Summary: All three methods (`complete`, `stream`, `vision_complete`) now run sync SDK in `run_in_executor`. `asyncio.get_event_loop()` replaced with `asyncio.get_running_loop()`.

---

## 12. Pipeline Status — Event System Fix

### File: `backend/services/pipeline_status.py`

**Problem:** `emit()` used `asyncio.get_event_loop().create_task(...)` which is deprecated in Python 3.10+ and can fail when called from certain async contexts.

**Fix:** Changed to `asyncio.get_running_loop().create_task(...)`.

```python
# Before:
asyncio.get_event_loop().create_task(_store_event(...))

# After:
asyncio.get_running_loop().create_task(_store_event(...))
```

**To revert:** Change back to `get_event_loop()`.

---

## 13. Field Extraction Counts — total_fields Bug

### Files: `backend/services/private_pipeline.py`, `backend/services/native_pipeline.py`

**Problem:** Both pipelines read `extraction_result.get("total_fields", 0)`. Since `extract_fields()` never included `total_fields` in its return dict, this always returned 0. Downstream calculation:
```python
needs_review = total - high_conf  # = 0 - 17 = -17
```
The UI showed "0 fields extracted, 17 high confidence, -17 require review."

**Fix in both pipeline files:**
```python
# Before:
total = extraction_result.get("total_fields", 0)

# After:
categories = extraction_result.get("categories", {})
total = sum(len(v) for v in categories.values())
```

**Also fixed:** `needs_review = max(0, total - high_conf)` — prevents negative display even if calculation is off.

**To revert:** Change back to `.get("total_fields", 0)`.

---

## 14. Category Display Names — Pipeline Result Fix

### Files: `backend/services/private_pipeline.py`, `backend/services/native_pipeline.py`

**Problem:** Category keys like `"TAX_DOCUMENTS"` were converted to display names using `.replace("_"," ").title()` → `"Tax Documents"` instead of the correct `"Tax & Assessment"`. Frontend category matching and rendering broke.

**Fix:** Now uses `CATEGORY_TO_DISPLAY` mapping imported from `prompts/extraction_prompt.py`:
```python
from prompts.extraction_prompt import CATEGORY_TO_DISPLAY
display_name = CATEGORY_TO_DISPLAY.get(cat_key, cat_key.replace("_", " ").title())
```

**To revert:** Remove the import and change back to `.replace("_", " ").title()`.

---

## 15. Frontend — SSE Timeout & Retry Logic

### File: `bos-portal/app.js`

**A) SSE safety timeout extended:** 90 seconds → 600 seconds (10 minutes). The 90s timeout was shorter than a single LLM call on private mode providers (qwen3 takes 2–4 minutes per call). The frontend was aborting the connection mid-pipeline, then calling `fetchExtractionDetails()` before the pipeline completed → 400 error → empty review section.

```javascript
// Before:
}, 90000);

// After:
}, 600000);  // 10 minutes
```

**B) `fetchExtractionDetails()` now retries:** If the backend returns non-200 (pipeline still running), retries up to 5 times with 3-second delay before giving up.

```javascript
// Before: single fetch, throws on non-ok
const resp = await fetch(`${API_BASE}/api/v1/extract/${state.sessionId}/result`);
if (!resp.ok) throw new Error('Failed to fetch extraction results');

// After: retry loop
for (let attempt = 0; attempt < 5; attempt++) {
    resp = await fetch(`${API_BASE}/api/v1/extract/${state.sessionId}/result`);
    if (resp.ok) break;
    if (attempt < 4) await new Promise(r => setTimeout(r, 3000));
}
```

**To revert:** Change `600000` back to `90000`. Remove the retry loop, restore single fetch.

---

## 16. SOW Generation — Provider Routing Fix

### File: `backend/services/sow_writer_service.py`

**Problem:** `generate_sow()` used `providers.provider_factory.get_registry().get_llm()`. For private mode, `get_registry()` throws `RuntimeError("Provider registry not initialized")` because provider_factory is only initialized for native provider modes. Private mode SOW generation silently fell back to the template fallback.

**Fix:** New `_get_llm_and_model()` function:
- Private mode → `service_registry.get_service_registry().get_async_llm()` (OpenAI-compatible httpx, no streaming)
- Native modes → `provider_factory.get_registry().get_llm()` (native streaming)

Returns `(llm, model, supports_streaming)` tuple so the streaming/non-streaming path is selected correctly.

**To revert:** Remove `_get_llm_and_model()`. Restore direct `get_registry().get_llm().stream(...)` call.

---

## 17. SOW Generation — Structured Text Token Emission Fix

### File: `backend/services/sow_writer_service.py`

**Problem:** For private mode (non-streaming), structural delimiter lines like `[SECTION: Title]`, `[TABLE]`, `[/TABLE]`, `[/SECTION]` were emitted as `section_start`/`section_complete` events — NOT as `token` events. Only prose words were emitted as tokens.

`generate.py` accumulates `full_text` from `token` events only. So `session_states[session_id]["generation_result"]` was a blob of prose words with no structure — no `[SECTION:]` delimiters, no `[TABLE]` blocks. The export parser found no sections → "No report content available."

**Fix:** All lines (including structural delimiters) are now emitted as `token` events in 5-line batches:
```python
# Structural delimiter:
yield {"type": "token", "text": line + "\n"}  # preserves in full_text

# Prose lines:
line_buf += line + "\n"
if line_buf.count("\n") >= 5:
    yield {"type": "token", "text": line_buf}
    line_buf = ""
```

**To revert:** Restore the original word-by-word emission that lost structural delimiters.

---

## 18. SOW Prompt — Complete Rewrite to Compliance Standard

### File: `backend/prompts/sow_prompt.py`

**Problem:** Previous prompt was too permissive. Generated reports contained:
- Placeholder text ("the verified net amount", "the declared annual amount", "significant" as shareholding %)
- Speculative language ("this suggests", "consistent with", "indicating financial capacity")
- Inconsistent structure across runs
- Annotated source references after every value cluttering the prose

**Fix:** Complete rewrite with:

1. **Explicit prohibited phrases list:** "it appears", "suggests", "indicates", "consistent with", "would seem", "it is noted", "reflecting", "demonstrating"
2. **Placeholder prohibition with exact examples:** "the verified amount", "the declared value", "the relevant year", "the assessed income", "significant" as shareholding
3. **Risk rating rules** derived only from present fields (LOW/MEDIUM/HIGH with explicit criteria)
4. **Fixed 8-section structure** with specific content requirements per section
5. **Absent data wording** standardized: "No verified data pertaining to [topic] has been submitted for this applicant; this section is not applicable to the current review."
6. **Source references removed** from user prompt — fields passed as clean `Label: Value` pairs, no file annotations
7. **Token budget raised** to 8,000 minimum to prevent mid-report truncation
8. **Temperature raised** to 0.3 for more natural prose flow

**To revert:** Restore previous `_DEFAULT_SOW_SYSTEM_PROMPT` and `get_sow_user_prompt()` with JSON dump and source file annotations.

---

## 19. SOW Export — Structured Text Parser & PDF Renderer

### File: `backend/services/export_service.py`

**Problem:** The original `_parse_sow_lines()` function only handled `## heading` markdown headers. The LLM output uses `[SECTION:]`/`[TABLE]` structured text. All section headings appeared as raw body text, all tables appeared as raw text with pipe characters visible, no actual ReportLab Table objects were created.

**Note:** The primary export renderer is in `routers/export.py` (which already had a working `_parse_sow_document()` parser). `export_service.py` is a secondary export path.

**Fix:** Complete rewrite of `export_service.py`:

1. `_parse_structured_sow()` — Parses `[SECTION]`/`[NARRATIVE]`/`[TABLE]` blocks into structured dicts
2. `_build_pdf_table()` — Creates actual `reportlab.platypus.Table` objects with:
   - Dark navy header row
   - Alternating row colors
   - Column alignment per `ALIGN:` spec
   - Total/summary row styling
3. `_blocks_to_flowables()` — Converts parsed blocks to ReportLab flowables with section headings and page breaks
4. New PDF header: dark navy bar with gold "PRIVATE & CONFIDENTIAL" text
5. `detect_placeholders()` — Regex-based scanner for 10 placeholder patterns, called before rendering

**To revert:** Restore original `_parse_sow_lines()` with `## heading` parsing and no table support.

---

## 20. Generate Router — Placeholder Fix & Field Enrichment

### File: `backend/routers/generate.py`

**Problem:** The mock template fallback (`_build_mock_sections()`) used placeholder default values:
```python
"{net_pay}": lookup.get("Monthly Net Pay", "the verified net amount"),   # PLACEHOLDER
"{annual_salary}": lookup.get("Annual Base Salary", "the declared annual amount"),  # PLACEHOLDER
"{assessment_year}": lookup.get("Assessment Year", "the relevant year"),  # PLACEHOLDER
```
When field keys didn't match, these default strings appeared verbatim in the generated report.

**Fixes:**

**A) `_build_fallback_report()` replaces `_build_mock_sections()`:**
- Only writes a sentence/row when the actual verified value exists
- No placeholder defaults anywhere
- Missing data → section states "not applicable" in one sentence
- Two-column tables only (no "Source Document" column)

**B) `_enrich_fields_from_session()` new function:**
Merges reviewer's verified field values with full metadata from `session_states["extraction_result"]` (source_file, source_page, display_label, display_category, confidence). Passes enriched fields to LLM so it has complete context.

**C) `_has_llm()` replaces `_has_api_key()`:**
Checks both `ANTHROPIC_API_KEY` and `provider_mode` config. Private/openai/azure/ollama users now get real LLM generation instead of always falling back to template.

**D) Placeholder detection post-generation:**
After LLM generation, `detect_placeholders()` scans the output. Placeholder count logged as warning and emitted to frontend.

**To revert:** Restore `_build_mock_sections()`, `_has_api_key()`. Remove `_enrich_fields_from_session()`.

---

## 21. Export Service — Placeholder Detector

### File: `backend/services/export_service.py`

**New function `detect_placeholders(text)`:**
Scans generated SOW text for 10 patterns that indicate substitution language instead of real values:

```python
_PLACEHOLDER_PATTERNS = [
    r"\bthe verified (?:net |annual |...)?(?:amount|value|income|...)\b",
    r"\bthe declared (?:annual |monthly |...)?(?:amount|value|...)\b",
    r"\bthe relevant (?:year|period|date|...)\b",
    r"\bthe assessed (?:income|tax|amount|value)\b",
    # ... 6 more patterns
]
```

Called before every PDF/DOCX render. Logs warnings when found. Does not block rendering (logs only).

**To revert:** Remove `detect_placeholders()` function and its call sites.

---

## 22. Database — SQLite Compatibility for CML

### File: `backend/database.py`

**Problem:** Original used PostgreSQL-specific SQLAlchemy types:
- `JSONB` from `sqlalchemy.dialects.postgresql` — PostgreSQL only
- `UUID(as_uuid=True)` from `sqlalchemy.dialects.postgresql` — PostgreSQL only

These types raise `ImportError` or `TypeError` on SQLite.

Also, `init_pipeline_jobs_table()` used `SERIAL PRIMARY KEY` syntax — PostgreSQL only.

**Fix:**
- `JSONB` → `JSON` (from `sqlalchemy`, cross-database)
- `UUID(as_uuid=True)` → `String(36)` (stores UUID as text string)
- `sqlite:///` detected via `_IS_SQLITE` flag
- SQLite engine uses `connect_args={"check_same_thread": False}` (required for FastAPI)
- `init_pipeline_jobs_table()` uses `INTEGER PRIMARY KEY AUTOINCREMENT` for SQLite, `SERIAL PRIMARY KEY` for PostgreSQL

**Default database:** SQLite file at `backend/sow.db` (same directory as `main.py`), created automatically on first startup.

**To revert:** Restore `from sqlalchemy.dialects.postgresql import UUID, JSONB`, remove `_IS_SQLITE` branching. Will break without a PostgreSQL server.

---

## 23. File Paths — Configurable Upload Directory for CML

### Files: `backend/utils/paths.py` (new), `backend/routers/upload.py`, `backend/routers/extract.py`

**Problem:** All file uploads were stored in `/tmp/sow_sessions/`. On CML (and many Linux servers), `/tmp` is:
- Not persistent across application restarts
- Shared across users (security concern)
- Sometimes has strict quotas

**New file `backend/utils/paths.py`:**
```python
def get_sessions_root() -> str:
    default = os.path.join(os.path.expanduser("~"), "sow_sessions")
    return os.environ.get("SOW_SESSIONS_DIR", default)

def get_session_dir(session_id: str) -> str:
    d = os.path.join(get_sessions_root(), session_id)
    os.makedirs(d, exist_ok=True)
    return d
```

**Changed in `upload.py` and `extract.py`:**
```python
# Before:
session_dir = f"/tmp/sow_sessions/{session_id}"

# After:
from utils.paths import get_sessions_root, get_session_dir
session_dir = get_session_dir(session_id)
```

**To revert:** Remove `utils/paths.py`. Replace `get_session_dir(session_id)` back to `f"/tmp/sow_sessions/{session_id}"`.

---

## 24. CML Deployment — Startup Script & Requirements

### New files:

**`start_cml.sh`:**
- Reads `CDSW_APP_PORT` (CML injects this) with fallback to 8000
- Installs `requirements-cml.txt` via pip
- Creates `~/sow_sessions` directory
- Sets `DATABASE_URL=sqlite:///...` if not already set
- Starts uvicorn with `--workers 1 --loop asyncio`

**`backend/requirements-cml.txt`:**
- No `psycopg2-binary` (not needed with SQLite)
- All packages use pre-compiled wheels available on PyPI Linux x86_64
- `ldap3` and `msal` marked as removable if SSO not needed

**`.env.cml`:**
Template environment variables file for CML deployment documenting all required and optional variables.

---

## Rollback Reference

### To rollback to pre-session state (full rollback):

1. **database.py** — Restore PostgreSQL imports (`JSONB`, `UUID`), remove `_IS_SQLITE` branching
2. **vector_store.py** — Remove `run_in_executor`, restore direct `embeddings.create()` calls
3. **private_pipeline.py** — Remove `run_in_executor` wrappers, restore direct SDK calls; restore mock fallback in `run()` exception handler
4. **native_pipeline.py** — Remove `run_in_executor` wrapper
5. **document_ingestion.py** — Remove `run_in_executor` wrappers
6. **service_registry.py** — Remove `httpx.Timeout`, remove `max_retries=0`, remove `get_async_llm()`
7. **admin_config.py** — Remove `reload_service_registry()` calls
8. **extraction_service.py** — Restore sync SDK in `_call_llm_for_extraction()`, restore simple exception handling in parser
9. **sow_writer_service.py** — Restore `provider_factory.get_registry().get_llm().stream()` direct call
10. **sow_prompt.py** — Restore previous system prompt (permissive tone, source annotations)
11. **export_service.py** — Restore `_parse_sow_lines()` markdown-only parser
12. **generate.py** — Restore `_build_mock_sections()` with placeholder defaults, `_has_api_key()` check
13. **routers/upload.py**, **routers/extract.py** — Replace `get_session_dir()` back to `/tmp/sow_sessions/{session_id}`
14. **bos-portal/app.js** — Change SSE timeout back to `90000`, remove retry loop in `fetchExtractionDetails()`
15. **Delete** `backend/utils/paths.py`, `backend/requirements-cml.txt`, `start_cml.sh`, `.env.cml`

### To rollback individual features only — see each numbered section above for the specific lines to change.

---

## Environment Variables Reference

| Variable | Purpose | Default |
|----------|---------|---------|
| `DATABASE_URL` | Database connection string | `sqlite:///backend/sow.db` |
| `SOW_SESSIONS_DIR` | Upload file storage directory | `~/sow_sessions` |
| `ANTHROPIC_API_KEY` | Anthropic Claude API key | — |
| `ADMIN_PASSWORD` | Admin console password | — |
| `CDSW_APP_PORT` | Port (injected by CML) | `8000` |

Provider-mode-specific variables (set via Admin Console or `config.yaml`):
- Private mode LLM: `base_url`, `api_key`, `model_name`
- Vectorisation: `base_url`, `api_key`, `model_name`
- Reranker: `endpoint`, `api_key`, `model_name`
- OCR: `base_url`, `api_key`, `model_name`, `auth_url`
- VLM: `base_url`, `api_key`, `model_name`
