#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# SOW Portal — CML Application Startup Script
# Deploy path: /home/cdsw/poc/sowa1/
# ─────────────────────────────────────────────────────────────────────────────
set -e

PROJECT_ROOT="/home/cdsw/poc/sowa1"
VENV_DIR="$PROJECT_ROOT/venv"
BACKEND_DIR="$PROJECT_ROOT/backend"
PORT="${CDSW_APP_PORT:-8000}"

echo "================================================"
echo "  SOW Portal — Starting"
echo "  Path    : $PROJECT_ROOT"
echo "  Port    : $PORT"
echo "================================================"

# Activate virtual environment
if [ ! -f "$VENV_DIR/bin/activate" ]; then
    echo "ERROR: Virtual environment not found at $VENV_DIR"
    echo "       Run: bash $PROJECT_ROOT/setup_sowa1.sh"
    exit 1
fi

source "$VENV_DIR/bin/activate"
echo "  Python  : $(python --version)"

export DATABASE_URL="${DATABASE_URL:-sqlite:////home/cdsw/poc/sowa1/sow.db}"
export SOW_SESSIONS_DIR="${SOW_SESSIONS_DIR:-$PROJECT_ROOT/sow_sessions}"
mkdir -p "$SOW_SESSIONS_DIR"

echo "  DB      : $DATABASE_URL"
echo "  Uploads : $SOW_SESSIONS_DIR"
echo ""
echo "  BOS Portal    → <CML App URL>/"
echo "  Admin Console → <CML App URL>/admin/"
echo "  API Docs      → <CML App URL>/docs"
echo ""

cd "$BACKEND_DIR"
exec uvicorn main:app \
    --host 0.0.0.0 \
    --port "$PORT" \
    --workers 1 \
    --loop asyncio \
    --log-level info
