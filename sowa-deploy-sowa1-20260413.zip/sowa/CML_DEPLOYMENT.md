# SOW Portal — Cloudera CML Deployment Guide

**Deploy path on CML:** `/home/cdsw/poc/sowa/`
**Deployment type:** CML Application (single persistent web service)
**Requires:** Python 3.9+ (3.10 recommended), pip install access
**Database:** SQLite — no PostgreSQL server needed

---

## What Gets Deployed

One CML Application serves all three interfaces on a single port:

| Interface | URL |
|-----------|-----|
| BOS Portal (client document uploads) | `https://<your-app>.cml.company.com/` |
| Admin Console (config & prompts) | `https://<your-app>.cml.company.com/admin/` |
| REST API & Swagger Docs | `https://<your-app>.cml.company.com/docs` |

---

## Step 1 — Understand the Folder Structure

Your local project is at `/Users/software/codebase/sowa/`. Here is exactly what exists and where each piece must go on CML.

### Local structure → CML target mapping

```
LOCAL MACHINE                              CML TARGET
──────────────────────────────────────     ──────────────────────────────────────────
sowa/
├── backend/                           →   /home/cdsw/poc/sowa/backend/
│   ├── main.py                        →   /home/cdsw/poc/sowa/backend/main.py
│   ├── database.py                    →   /home/cdsw/poc/sowa/backend/database.py
│   ├── schemas.py                     →   /home/cdsw/poc/sowa/backend/schemas.py
│   ├── seed.py                        →   /home/cdsw/poc/sowa/backend/seed.py
│   ├── requirements-cml.txt           →   /home/cdsw/poc/sowa/backend/requirements-cml.txt
│   ├── auth/                          →   /home/cdsw/poc/sowa/backend/auth/
│   ├── config/config.yaml             →   /home/cdsw/poc/sowa/backend/config/config.yaml
│   │   (edit before copying — see Step 2)
│   ├── config/model_config.yaml       →   /home/cdsw/poc/sowa/backend/config/model_config.yaml
│   ├── prompts/                       →   /home/cdsw/poc/sowa/backend/prompts/
│   ├── prompts_store/                 →   /home/cdsw/poc/sowa/backend/prompts_store/
│   ├── providers/                     →   /home/cdsw/poc/sowa/backend/providers/
│   ├── routers/                       →   /home/cdsw/poc/sowa/backend/routers/
│   ├── services/                      →   /home/cdsw/poc/sowa/backend/services/
│   └── utils/                         →   /home/cdsw/poc/sowa/backend/utils/
│
├── bos-portal/                        →   /home/cdsw/poc/sowa/bos-portal/
│   ├── app.js
│   ├── index.html
│   ├── logo.png
│   ├── logo.svg
│   └── styles.css
│
├── admin-console/                     →   /home/cdsw/poc/sowa/backend/admin-console/
│   └── index.html                         ⚠ Goes INSIDE backend/, not at root
│
└── start_cml.sh                       →   /home/cdsw/poc/sowa/start_cml.sh
```

### ⚠ Critical placement rules

**Rule 1 — `bos-portal` is a sibling of `backend/`**
`main.py` resolves it as `Path(__file__).parent.parent / "bos-portal"` which means:
`/home/cdsw/poc/sowa/backend/../bos-portal` = `/home/cdsw/poc/sowa/bos-portal/`
✅ Correct: `/home/cdsw/poc/sowa/bos-portal/index.html`
❌ Wrong:   `/home/cdsw/poc/sowa/backend/bos-portal/index.html`

**Rule 2 — `admin-console` goes inside `backend/`**
`main.py` resolves it as `Path(__file__).parent / "admin-console"` which means:
`/home/cdsw/poc/sowa/backend/admin-console/`
✅ Correct: `/home/cdsw/poc/sowa/backend/admin-console/index.html`
❌ Wrong:   `/home/cdsw/poc/sowa/admin-console/index.html`

### What to EXCLUDE — do not copy these

```
backend/venv/               ← reinstalled fresh on CML
backend/sow.db              ← fresh database created on first startup
backend/audit_log.jsonl     ← fresh on CML
backend/.env                ← API keys — use CML Environment Variables instead
.env                        ← same
backend/**/__pycache__/     ← Python bytecode, auto-regenerated
**/*.pyc                    ← compiled Python files
.DS_Store                   ← macOS metadata
.claude/                    ← Claude Code settings
```

---

## Step 2 — Prepare config.yaml Before Copying

Your local `backend/config/config.yaml` contains API keys. **Do not copy it as-is.**

A clean version without API keys was already generated at:
`backend/config/config.yaml.cml`

**Use this file as your `config.yaml` on CML:**

```bash
# On your local machine, before creating the ZIP:
cp backend/config/config.yaml.cml backend/config/config.yaml.upload
# Rename it to config.yaml when placing on CML
```

Or edit `config.yaml` manually — clear every `api_key` field and update `upload_dir`:

```yaml
# Clear all api_key fields in every section:
ANTHROPIC:
  api_key: ''          # cleared

private:
  llm:
    api_key: ''        # cleared
  ocr:
    api_key: ''        # cleared
  vlm:
    api_key: ''        # cleared
  vectorisation:
    api_key: ''        # cleared
  reranker:
    api_key: ''        # cleared

# Update upload directory to CML persistent path:
session:
  upload_dir: /home/cdsw/poc/sowa/sow_sessions   # ← changed from /tmp/sow_sessions
```

---

## Step 3 — Transfer Files to CML

Choose the method that works in your environment.

---

### Method A — ZIP Upload via CML File Browser

**On your local machine**, create a ZIP excluding unwanted files:

```bash
cd /Users/software/codebase

zip -r sowa-cml.zip sowa/ \
  --exclude "sowa/backend/venv/*" \
  --exclude "sowa/backend/sow.db" \
  --exclude "sowa/backend/audit_log.jsonl" \
  --exclude "sowa/backend/.env" \
  --exclude "sowa/.env" \
  --exclude "sowa/**/__pycache__/*" \
  --exclude "sowa/**/*.pyc" \
  --exclude "sowa/.DS_Store" \
  --exclude "sowa/.claude/*" \
  --exclude "sowa/backend/venv"

# Verify ZIP size is reasonable (should be under 5MB without venv)
ls -lh sowa-cml.zip
```

**Upload to CML:**
1. Log into your CML workspace
2. Open your project (or create one named `poc`)
3. Click **Files** in the left sidebar
4. Navigate to the `poc/` folder (create it if it doesn't exist)
5. Click **Upload** → select `sowa-cml.zip`
6. Open a **CML Terminal** session and run:

```bash
cd /home/cdsw/poc
unzip sowa-cml.zip
# The ZIP already contains the sowa/ folder
ls /home/cdsw/poc/sowa/
# Expected: backend  bos-portal  admin-console  start_cml.sh  ...
```

**Fix the admin-console placement** (must be inside `backend/`):

```bash
# Copy admin-console into backend/ (where main.py expects it)
cp -r /home/cdsw/poc/sowa/admin-console \
      /home/cdsw/poc/sowa/backend/admin-console

# Verify
ls /home/cdsw/poc/sowa/backend/admin-console/
# Expected output: index.html
```

---

### Method B — SCP from Local Machine to CML

If your CML cluster allows SSH access:

```bash
# From your LOCAL machine terminal:

# Create the target directory structure on CML
ssh cml-user@cml-gateway-host "mkdir -p /home/cdsw/poc/sowa"

# Copy backend (excluding venv and cache)
rsync -av --exclude='venv/' --exclude='__pycache__/' \
  --exclude='*.pyc' --exclude='*.db' --exclude='.env' \
  /Users/software/codebase/sowa/backend/ \
  cml-user@cml-gateway-host:/home/cdsw/poc/sowa/backend/

# Copy bos-portal
rsync -av \
  /Users/software/codebase/sowa/bos-portal/ \
  cml-user@cml-gateway-host:/home/cdsw/poc/sowa/bos-portal/

# Copy admin-console INTO backend/ (critical placement)
rsync -av \
  /Users/software/codebase/sowa/admin-console/ \
  cml-user@cml-gateway-host:/home/cdsw/poc/sowa/backend/admin-console/

# Copy startup script
scp /Users/software/codebase/sowa/start_cml.sh \
    cml-user@cml-gateway-host:/home/cdsw/poc/sowa/start_cml.sh
```

---

### Method C — Git Clone (Cleanest, Recommended)

If your organisation has an internal Git server:

```bash
# On your LOCAL machine — push to internal Git
cd /Users/software/codebase/sowa
git init
git add -A
git commit -m "SOW Portal initial deployment"
git remote add origin https://your-git.company.com/sow-portal.git
git push -u origin main
```

```bash
# In a CML Terminal session:
cd /home/cdsw/poc
git clone https://your-git.company.com/sow-portal.git sowa

# Fix admin-console placement
cp -r /home/cdsw/poc/sowa/admin-console \
      /home/cdsw/poc/sowa/backend/admin-console

# Use clean config without API keys
cp /home/cdsw/poc/sowa/backend/config/config.yaml.cml \
   /home/cdsw/poc/sowa/backend/config/config.yaml
```

---

## Step 4 — Verify the Structure in CML Terminal

Open a **CML Terminal** session (Project → Overview → Open Terminal) and run these checks:

```bash
echo "=== Checking project structure ==="

# 1. Project root
ls /home/cdsw/poc/sowa/
# Must show: backend  bos-portal  start_cml.sh

# 2. Backend entry point
ls /home/cdsw/poc/sowa/backend/main.py
# Must show: /home/cdsw/poc/sowa/backend/main.py

# 3. BOS Portal (sibling of backend)
ls /home/cdsw/poc/sowa/bos-portal/index.html
# Must show: /home/cdsw/poc/sowa/bos-portal/index.html

# 4. Admin console (inside backend)
ls /home/cdsw/poc/sowa/backend/admin-console/index.html
# Must show: /home/cdsw/poc/sowa/backend/admin-console/index.html

# 5. Requirements file
ls /home/cdsw/poc/sowa/backend/requirements-cml.txt
# Must show: /home/cdsw/poc/sowa/backend/requirements-cml.txt

# 6. Startup script is executable
ls -la /home/cdsw/poc/sowa/start_cml.sh
# Must show: -rwxr-xr-x (executable)

# If not executable, fix it:
chmod +x /home/cdsw/poc/sowa/start_cml.sh
```

**Expected pass — all 6 checks show the correct files.** If any fail, fix the placement before proceeding.

---

## Step 5 — Install Dependencies

In the same **CML Terminal** session:

```bash
cd /home/cdsw/poc/sowa/backend

# Install all packages to user directory (no sudo/root needed)
pip install --user -r requirements-cml.txt

# Add user bin to PATH so uvicorn is found
export PATH="$HOME/.local/bin:$PATH"

# Verify the key packages installed correctly
python3 -c "
import fastapi, uvicorn, sqlalchemy, httpx, yaml, reportlab
print('Core packages: OK')
"

python3 -c "import fitz; print('PyMuPDF (PDF processing): OK')"
python3 -c "import anthropic; print('Anthropic SDK: OK')"
python3 -c "import openai; print('OpenAI SDK: OK')"
```

---

### If a package fails to install

| Package | Error | Fix |
|---------|-------|-----|
| `pymupdf` | `glibc version too old` | `pip install --user pdfplumber` (text extraction only, no image rendering) |
| `ldap3` | Any error | Remove line from `requirements-cml.txt` — only needed for LDAP SSO |
| `msal` | Any error | Remove line from `requirements-cml.txt` — only needed for Azure AD SSO |
| `reportlab` | `FreeType` error | `pip install --user reportlab==3.6.13` (older stable version) |
| Any package | `Connection timed out` | Your CML may use an internal PyPI mirror — ask your admin for `--index-url` |

**If using an internal PyPI mirror:**
```bash
pip install --user -r requirements-cml.txt \
  --index-url https://your-pypi-mirror.company.com/simple/ \
  --trusted-host your-pypi-mirror.company.com
```

---

## Step 6 — Test Run in CML Terminal

Before creating the CML Application, do a manual test run to catch any errors:

```bash
cd /home/cdsw/poc/sowa/backend

# Set environment variables for the test
export DATABASE_URL="sqlite:////home/cdsw/poc/sowa/sow.db"
export SOW_SESSIONS_DIR="/home/cdsw/poc/sowa/sow_sessions"
export ADMIN_PASSWORD="test_password_123"
export PATH="$HOME/.local/bin:$PATH"

# Create session upload directory
mkdir -p /home/cdsw/poc/sowa/sow_sessions

# Start the application (choose any free port for testing)
uvicorn main:app --host 0.0.0.0 --port 8080 --log-level info
```

**Expected output — all three lines must appear:**
```
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8080 (Press CTRL+C to quit)
```

**Also watch for these startup messages (appear before uvicorn line):**
```
DB already has N records. Skipping seed.   ← database created, tables created
# or on first run:
Seeded N sample records.
```

Press **Ctrl+C** to stop the test. If it started cleanly, proceed to Step 7.

---

### Common startup errors and fixes

**Error: `ModuleNotFoundError: No module named 'fastapi'`**
```bash
# pip install didn't complete correctly
pip install --user fastapi uvicorn sqlalchemy
export PATH="$HOME/.local/bin:$PATH"
```

**Error: `ModuleNotFoundError: No module named 'utils.paths'`**
```bash
# The utils/ directory wasn't copied
ls /home/cdsw/poc/sowa/backend/utils/paths.py
# If missing, create it:
mkdir -p /home/cdsw/poc/sowa/backend/utils
cat > /home/cdsw/poc/sowa/backend/utils/__init__.py << 'EOF'
EOF
cat > /home/cdsw/poc/sowa/backend/utils/paths.py << 'EOF'
import os
def get_sessions_root():
    d = os.environ.get("SOW_SESSIONS_DIR", os.path.join(os.path.expanduser("~"), "sow_sessions"))
    os.makedirs(d, exist_ok=True)
    return d
def get_session_dir(session_id):
    d = os.path.join(get_sessions_root(), session_id)
    os.makedirs(d, exist_ok=True)
    return d
EOF
```

**Error: `sqlite3.OperationalError: unable to open database file`**
```bash
# Ensure the parent directory exists and is writable
mkdir -p /home/cdsw/poc/sowa
touch /home/cdsw/poc/sowa/sow.db
ls -la /home/cdsw/poc/sowa/sow.db
```

**Error: `StaticFiles directory does not exist`**
```bash
# bos-portal or admin-console is in the wrong place
ls /home/cdsw/poc/sowa/bos-portal/          # must have index.html
ls /home/cdsw/poc/sowa/backend/admin-console/ # must have index.html
```

---

## Step 7 — Set Environment Variables in CML

In CML, API keys and sensitive config must be set as **Project-level Environment Variables**, not in files.

1. Go to your CML Project
2. Click the **Settings** gear icon (top-right area of the project)
3. Click **Environment Variables** in the left menu
4. Add each variable listed below
5. Click **Save** after adding all variables

### Required Environment Variables

| Variable | Example Value | Purpose |
|----------|---------------|---------|
| `DATABASE_URL` | `sqlite:////home/cdsw/poc/sowa/sow.db` | Database file path (4 slashes = absolute path) |
| `SOW_SESSIONS_DIR` | `/home/cdsw/poc/sowa/sow_sessions` | Where uploaded documents are stored |
| `ADMIN_PASSWORD` | `YourSecurePassword123` | Admin console login password |

### Optional Environment Variables (set if using that provider)

| Variable | Example Value | Purpose |
|----------|---------------|---------|
| `ANTHROPIC_API_KEY` | `sk-ant-api03-...` | Anthropic Claude API (if using anthropic mode) |

> **Note on other API keys (OpenRouter, internal vLLM, etc.):**
> These are configured through the **Admin Console** at `/admin/` after the app starts — not as environment variables. Only `ANTHROPIC_API_KEY` is read directly from the environment.

---

## Step 8 — Create CML Application

1. In your CML Project, click **Applications** in the left sidebar
2. Click **+ New Application** (blue button)
3. Fill in the form exactly as follows:

---

### Application Configuration Form

**Name:**
```
SOW Portal
```

**Subdomain:**
```
sow-portal
```
*(This becomes: `https://sow-portal.ml-XXXXXX.your-company.com`)*

**Description:**
```
Source of Wealth document extraction, review, and report generation portal.
```

**Script:**
```
bash /home/cdsw/poc/sowa/start_cml.sh
```

**Python Version:** Select `Python 3.10` (or highest version available)

**Resource Profile:**

| Resource | Minimum | Recommended |
|----------|---------|-------------|
| CPU | 1 vCPU | 2 vCPU |
| Memory | 2 GB | 4 GB |

*Use 4 GB if processing large multi-page PDF documents or running embedding models.*

**Enable Authentication:** Optional
- Disabled: anyone on your CML domain can access the app URL
- Enabled: requires CML login before reaching the app

---

4. Click **Create Application**

CML will:
1. Allocate a container for the application
2. Run `bash /home/cdsw/poc/sowa/start_cml.sh`
3. Install packages (first run takes 3–5 minutes)
4. Start uvicorn on `$CDSW_APP_PORT`
5. Show **Running** status (green dot) when ready

---

## Step 9 — Verify the Application is Running

Once CML shows **Running** status:

### Check application logs
Click on **SOW Portal** → **Logs** tab

Look for these lines (in order):
```
[1/5] Checking project structure...
      Structure OK
[2/5] Installing Python packages...
      Dependencies installed
[3/5] Configuring storage paths...
      Session uploads : /home/cdsw/poc/sowa/sow_sessions
[4/5] Configuring database...
      Using SQLite    : /home/cdsw/poc/sowa/sow.db
[5/5] Starting uvicorn...
INFO:     Application startup complete.
```

### Open the application
Click the **application URL** shown in CML (the hyperlink next to the app name).

**First page you see:**
- If the BOS Portal loads with the upload wizard → everything is working
- If you see a blank page or 404 → check that `bos-portal/index.html` exists at `/home/cdsw/poc/sowa/bos-portal/`

**Verify admin console:**
- Navigate to `<app-url>/admin/`
- Should show the admin login page
- Login with the `ADMIN_PASSWORD` you set in Step 7

---

## Step 10 — First-Time Configuration via Admin Console

After logging into the Admin Console at `<app-url>/admin/`:

### Configure your provider mode

1. Click **Configuration** tab
2. Find **Provider Mode** setting
3. Set to `private` (if using your internal vLLM cluster) or `anthropic` (if using Anthropic API)
4. Click **Save**

### Configure LLM and other services (for private mode)

Still in **Configuration**, fill in your internal service endpoints:

| Section | Field | Value |
|---------|-------|-------|
| LLM | Base URL | `https://your-llm-coordinator.ml-XXX.company.com` |
| LLM | Model Name | `Qwen3-Next-80B-A3B-Instruct-FP8` (or your model) |
| LLM | API Key | your internal API key |
| OCR | Endpoint | your internal OCR endpoint |
| OCR | Auth URL | your token mint URL |
| VLM | Base URL | your VLM endpoint |
| Vectorisation | Base URL | your embedding endpoint |
| Reranker | Endpoint | your reranker endpoint |

Click **Save** after each section. Changes take effect immediately — **no application restart needed**.

### Test extraction
1. Go to `<app-url>/` (BOS Portal)
2. Click **New Assessment**
3. Select **Salaried Professional**
4. Upload an IRAS NOA PDF
5. Click **Process Documents**
6. Watch the extraction log in the UI

---

## Step 11 — Updating the Application

### To update code files
```bash
# In CML Terminal:
# Copy new files to the backend
cp /path/to/updated/file.py /home/cdsw/poc/sowa/backend/services/file.py
```

Then restart the CML Application:
**Applications** → **SOW Portal** → **Actions** → **Restart**

### To update config only (no restart needed)
Use the Admin Console at `<app-url>/admin/` → **Configuration**.
Changes are hot-reloaded immediately.

### To update via Git
```bash
# In CML Terminal:
cd /home/cdsw/poc/sowa
git pull origin main

# Fix admin-console placement if it changed
cp -r admin-console backend/admin-console
```

Then restart the Application.

---

## Reference — All Paths at a Glance

| What | Path on CML |
|------|-------------|
| Project root | `/home/cdsw/poc/sowa/` |
| Application startup script | `/home/cdsw/poc/sowa/start_cml.sh` |
| Backend code (Python) | `/home/cdsw/poc/sowa/backend/` |
| Main FastAPI entry point | `/home/cdsw/poc/sowa/backend/main.py` |
| BOS Portal (client UI) | `/home/cdsw/poc/sowa/bos-portal/` |
| Admin Console (admin UI) | `/home/cdsw/poc/sowa/backend/admin-console/` |
| Provider & model config | `/home/cdsw/poc/sowa/backend/config/config.yaml` |
| SQLite database | `/home/cdsw/poc/sowa/sow.db` |
| Uploaded documents | `/home/cdsw/poc/sowa/sow_sessions/<session-id>/` |
| Prompt overrides | `/home/cdsw/poc/sowa/backend/prompts_store/` |
| Audit log | `/home/cdsw/poc/sowa/backend/audit_log.jsonl` |
| Python packages | `~/.local/lib/python3.10/site-packages/` |

---

## CML Application Script (for reference)

The full `start_cml.sh` already in the project does this in order:

```
1. Verify backend/main.py, bos-portal/, backend/admin-console/ exist
2. pip install --user -r requirements-cml.txt
3. mkdir -p $SOW_SESSIONS_DIR (default: /home/cdsw/poc/sowa/sow_sessions)
4. Set DATABASE_URL to SQLite if not already set in environment
5. exec uvicorn main:app --host 0.0.0.0 --port $CDSW_APP_PORT
```

`$CDSW_APP_PORT` is injected automatically by CML. You do not set it.

---

## Pre-Flight Checklist

Run through this before clicking **Create Application**:

```
□ /home/cdsw/poc/sowa/backend/main.py               exists
□ /home/cdsw/poc/sowa/bos-portal/index.html          exists
□ /home/cdsw/poc/sowa/backend/admin-console/index.html  exists
□ /home/cdsw/poc/sowa/start_cml.sh                   exists and is executable (chmod +x)
□ /home/cdsw/poc/sowa/backend/config/config.yaml     exists with NO api keys, correct upload_dir
□ /home/cdsw/poc/sowa/backend/requirements-cml.txt   exists
□ /home/cdsw/poc/sowa/backend/utils/paths.py         exists
□ CML Environment Variable DATABASE_URL              set to sqlite:////home/cdsw/poc/sowa/sow.db
□ CML Environment Variable SOW_SESSIONS_DIR          set to /home/cdsw/poc/sowa/sow_sessions
□ CML Environment Variable ADMIN_PASSWORD            set to a secure password
□ Manual test run (Step 6) completed without errors
□ CML Application Script field = bash /home/cdsw/poc/sowa/start_cml.sh
```
