# SOW Portal — Admin Console Technical Reference

## Overview

The Admin Console is a protected single-page application (SPA) served at `http://localhost:8000/admin/`. It provides six sections for managing all runtime-configurable aspects of the SOW Portal: a live dashboard, configuration management (7 sub-tabs), prompt management with full versioning, user management, raw file sync, and an append-only audit log. All configuration and prompt changes are bi-directionally synchronised between the browser and backend — changes made via the UI are written atomically to disk and hot-reloaded in memory; changes made externally (e.g. via `vim` or CI/CD pipelines) are detected by a `watchdog` file watcher and pushed to all connected browsers over a persistent WebSocket connection. Every write action is recorded to `backend/audit_log.jsonl` with full before/after values.

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [Access & Authentication](#2-access--authentication)
3. [Admin Console Sections](#3-admin-console-sections)
4. [API Reference](#4-api-reference)
5. [Bi-directional Sync Architecture](#5-bi-directional-sync-architecture)
6. [Prompt Management Architecture](#6-prompt-management-architecture)
7. [Audit Log Format](#7-audit-log-format)
8. [New Files Reference Table](#8-new-files-reference-table)

---

## 1. Architecture Overview

```
Browser (admin-console/index.html)
        │  HTTPS REST  │  WebSocket ws://host/admin/ws/sync
        ▼              ▼
FastAPI Backend (/api/admin/*, /admin/api/*)
        │
  ┌─────┼──────────────────────────┐
  │     │                          │
ConfigManager   PromptManager   FileWatcher
  │     │                          │
config.yaml  prompts_store/    watchdog observer
  .env       *.txt + registry   (emits WS events)
  │
audit_log.jsonl  ←── every change written here
```

**Key properties:**

- All admin routes require an `X-Admin-Token` header obtained from `POST /api/admin/login`.
- The WebSocket endpoint at `/admin/ws/sync` authenticates via the first message: `{"token": "<token>"}`.
- All writes to `config.yaml` and `.env` are atomic: content is written to a `.tmp` file on the same filesystem, then renamed into place, preventing partial-read corruption.
- `ConfigManager` and `PromptManager` are singletons instantiated once at startup and shared across all requests.
- The `FileWatcher` runs in a background thread and debounces filesystem events by 500 ms before broadcasting to WebSocket clients.

---

## 2. Access & Authentication

| URL | Description |
|---|---|
| `http://localhost:8000/admin/` | Admin Console SPA |
| `http://localhost:8000/docs#tag/Admin` | Swagger docs for all admin endpoints |

### Login Credentials

| Field | Default | Override |
|---|---|---|
| Username | `admin` | `AUTH.admin_username` in `config.yaml` |
| Password | _(must be set)_ | `ADMIN_PASSWORD` env var, or `AUTH.admin_password_hash` (SHA-256) in `config.yaml` |

To generate a SHA-256 password hash for `config.yaml`:

```bash
python3 -c "import hashlib; print(hashlib.sha256('yourpassword'.encode()).hexdigest())"
```

### Session Token

- Returned by `POST /api/admin/login` as `{"token": "...", "expires_in": 28800}`.
- TTL: **8 hours** (28800 seconds).
- Stored in `sessionStorage` (cleared on tab/browser close).
- All subsequent API requests include the header: `X-Admin-Token: <token>`.
- The WebSocket handshake sends `{"token": "<token>"}` as the first message after connection.

---

## 3. Admin Console Sections

### 3.1 Dashboard

The Dashboard is the default landing section after login. It displays:

- **Stat cards (3):**
  - Active Users — count of approved users in the SQLite allowlist
  - Provider Mode — current value of `PROVIDER_MODE` from `config.yaml`
  - System Status — overall health (`OK` / `DEGRADED` / `ERROR`)
- **System Health panel:** per-capability provider status indicators — LLM, Vision, Embedding, Reranker, OCR. Each shows a green tick or red cross based on the last health probe.
- Data is fetched from `GET /api/admin/health` on login and can be manually refreshed.

### 3.2 Configuration (7 Tabs)

The Configuration section exposes all sections of `config.yaml` as form-based editors, organised into tabs:

**Provider Mode**
Dropdown selector for `PROVIDER_MODE` (e.g. `anthropic`, `openai`, `azure`, `local`). Saving writes the value to `config.yaml` immediately and hot-reloads the active provider.

**LLM / OCR / VLM / Vectorisation / Reranker**
Each tab renders form fields for the corresponding `config.yaml` section. On Save:
1. Values are written to `config.yaml` atomically.
2. The in-memory provider is hot-reloaded (no server restart required).
3. A diff panel appears showing changed keys: `{"model_name": {"old": "gpt-4", "new": "Qwen3-Next-80B"}}`.

**Auth/SSO**
Full form for the `AUTH` section:
- Provider dropdown: `demo` | `ldap` | `azure_ad` | `oauth2`
- LDAP fields: server URL, bind DN, search base, user filter
- Azure AD fields: tenant ID, client ID, client secret, redirect URI
- OAuth2 fields: authorization URL, token URL, userinfo URL, scopes
- Admin credentials: username and password hash

**Per-section buttons (present on all tabs):**

| Button | Action |
|---|---|
| **Save** | Write section to `config.yaml` + hot-reload providers + show diff |
| **↺ Reload from file** | Re-read `config.yaml` from disk and repopulate the form |
| **↓ Download config.yaml** | Export full `config.yaml` as a file download |
| **↓ Download .env** | Export `.env` as a file download |

### 3.3 Prompt Management

The Prompt Management section provides full CRUD and versioning for all system prompts.

**Prompt table columns:** Key | Description | Version | Last Modified | Edit

**Prompt editor** (opens inline on clicking Edit):
- **Monaco Editor** (loaded from CDN: `monaco-editor@0.45.0`) in plain-text mode. Falls back to a `<textarea>` if Monaco fails to load.
- **Variable fields:** variables declared in `prompts_registry.json` for that prompt are rendered as labelled text inputs above the editor.
- **Test Interpolation button:** renders the prompt with the provided variable values and displays the result in a preview pane.
- **Version dropdown + Preview:** loads a historical version in a read-only editor pane for comparison.
- **Restore button:** makes the selected historical version the current version (old current is backed up first).
- **Save button:** writes new content to the `.txt` file, increments version counter, and backs up the old version to `history/`.

**"+ New Prompt" modal fields:** key, filename, description, variables (comma-separated list), initial content.

**Delete:** shows a confirmation dialog. Soft-deletes — moves the current file and all history to `history/` with a `_deleted` suffix; removes the key from `prompts_registry.json`.

### 3.4 User Management

Manages the list of approved Active Directory (AD) users stored in the SQLite allowlist. Functionality is identical to the existing user management panel:

- View all approved users with username and date added.
- Add a user: enter username, click Add.
- Remove a user: click the delete icon beside their row.

Every add/remove action is written to `audit_log.jsonl` with `action: user_add` or `action: user_remove`.

### 3.5 File Sync

Two tabs for direct raw-text editing of the two primary configuration files:

**config.yaml Editor** | **.env Editor**

Each tab provides:
- A syntax-aware raw text editor (Monaco with YAML/dotenv mode).
- **↻ Reload from disk** — re-reads the file and overwrites editor contents.
- **💾 Save to disk** — validates syntax, then writes atomically. On error, shows a validation message without writing.
- **Import** — file upload input accepting `.yaml`/`.yml` (for config tab) or `.env` (for env tab). Replaces the current file after validation.

**WebSocket live indicator** (top-right of section): shows `🟢 Live` when the WebSocket connection to `/admin/ws/sync` is active, or `🔴 Disconnected` when the connection is lost. Reconnection is attempted automatically with exponential backoff.

### 3.6 Audit Log

Filterable, paginated read-only view of `backend/audit_log.jsonl`.

**Filter controls:** Action (dropdown) | Section (text) | Changed By (text) | Refresh button

**Table columns:** Timestamp | Action badge | Changed By | Section | Key | Old Value | New Value

**Action badge colors:**

| Action | Badge Color |
|---|---|
| `config_update` | Blue |
| `prompt_save` | Purple |
| `user_add` | Green |
| `user_remove` | Red |
| `file_change` | Orange |
| `env_update` | Teal |
| `config_reload` | Gray |
| `raw_yaml_write` | Gray |

Pagination: 50 entries per page. The Audit Log is strictly read-only and cannot be edited or deleted through the UI or API.

---

## 4. API Reference

All admin endpoints require the header `X-Admin-Token: <token>` unless noted otherwise.

### 4.1 Authentication

```
POST /api/admin/login
Content-Type: application/json

Body:   {"username": "admin", "password": "yourpassword"}
Return: {"token": "<token>", "expires_in": 28800}
```

### 4.2 Config Endpoints

| Method | Path | Description | Request Body | Response |
|---|---|---|---|---|
| GET | `/admin/api/config/yaml` | Full config.yaml as JSON object | — | `{"LLM": {...}, "OCR": {...}, ...}` |
| GET | `/admin/api/config/yaml/{section}` | Single section | — | `{"model_name": "...", ...}` |
| PUT | `/admin/api/config/yaml/{section}` | Update a section | `{"values": {"key": "value"}}` | `{"diff": {"key": {"old": X, "new": Y}}}` |
| PUT | `/admin/api/config/provider_mode` | Set PROVIDER_MODE | `{"mode": "anthropic"}` | `{"mode": "anthropic"}` |
| GET | `/admin/api/config/env` | Env vars (masked secrets) | — | `{"OPENAI_API_KEY": "sk-...***", ...}` |
| GET | `/admin/api/config/env/raw` | Env vars (unmasked) | — | `{"OPENAI_API_KEY": "sk-abc123", ...}` |
| PUT | `/admin/api/config/env` | Update env var(s) | `{"values": {"KEY": "value"}}` | `{"updated": ["KEY"]}` |
| GET | `/admin/api/config/export/yaml` | Download config.yaml | — | File download |
| GET | `/admin/api/config/export/env` | Download .env | — | File download |
| POST | `/admin/api/config/reload` | Force hot-reload all providers | — | `{"reloaded": ["LLM", "OCR", ...]}` |

### 4.3 Prompt Endpoints

| Method | Path | Description | Request Body | Response |
|---|---|---|---|---|
| GET | `/admin/api/prompts` | List all prompts | — | `[{"key": "...", "version": 3, ...}]` |
| GET | `/admin/api/prompts/{key}` | Get prompt content + metadata | — | `{"key": "...", "content": "...", "variables": [...]}` |
| PUT | `/admin/api/prompts/{key}` | Save new content | `{"content": "..."}` | `{"version": 4, "backed_up_as": "ocr_extraction_v3.txt"}` |
| POST | `/admin/api/prompts` | Create new prompt | `{"key","filename","description","variables":[],"content"}` | `{"key": "...", "version": 1}` |
| DELETE | `/admin/api/prompts/{key}` | Soft-delete prompt | — | `{"deleted": true}` |
| GET | `/admin/api/prompts/{key}/versions` | List historical versions | — | `[{"version": 1, "filename": "..._v1.txt", "modified": "..."}]` |
| GET | `/admin/api/prompts/{key}/versions/{v}` | Get historical version content | — | `{"version": 2, "content": "..."}` |
| POST | `/admin/api/prompts/{key}/restore/{v}` | Restore historical version | — | `{"restored_version": 2, "new_version": 5}` |
| POST | `/admin/api/prompts/{key}/test` | Test variable interpolation | `{"variables": {"categories_list": "..."}}` | `{"rendered": "..."}` |

### 4.4 Sync Endpoints

| Method | Path | Description | Notes |
|---|---|---|---|
| WS | `/admin/ws/sync` | WebSocket sync stream | Auth via first message `{"token": "..."}` |
| GET | `/admin/api/sync/status` | WebSocket connection count + file watcher status | — |
| GET | `/admin/api/sync/audit` | Query audit log | Params: `limit`, `offset`, `action`, `section`, `changed_by` |
| GET | `/admin/api/sync/file/yaml` | Raw config.yaml text | — |
| PUT | `/admin/api/sync/file/yaml` | Write raw config.yaml | `{"content": "..."}` — validated before write |
| GET | `/admin/api/sync/file/env` | Raw .env text | — |
| PUT | `/admin/api/sync/file/env` | Write raw .env | `{"content": "..."}` — validated before write |
| POST | `/admin/api/sync/import` | Import config.yaml or .env file | Multipart file upload; detected by extension |

**WebSocket event shape (broadcast to all clients):**

```json
{"type": "file_change", "category": "config", "timestamp": "2026-04-04T10:00:00+00:00"}
{"type": "file_change", "category": "prompt", "key": "ocr_extraction", "timestamp": "..."}
{"type": "config_reload", "sections": ["LLM", "OCR"], "timestamp": "..."}
```

### 4.5 User Management Endpoints (existing)

| Method | Path | Description |
|---|---|---|
| POST | `/api/admin/login` | Authenticate and obtain session token |
| GET | `/api/admin/users` | List all approved users |
| POST | `/api/admin/users` | Add an approved user |
| DELETE | `/api/admin/users/{username}` | Remove an approved user |
| GET | `/api/admin/users/{username}` | Get a single user's details |
| GET | `/api/admin/audit` | List user-management audit events |
| GET | `/api/admin/health` | System health probe (all providers) |

---

## 5. Bi-directional Sync Architecture

### UI → Backend Sync Flow

```
Admin edits form field
     │
     ▼
PUT /admin/api/config/yaml/{section}
     │
     ▼
ConfigManager.update_yaml_section()
     │
  ┌──┼───────────────┐
  │  │               │
  ▼  ▼               ▼
Write to     Hot-reload    Write to
config.yaml  providers     audit_log.jsonl
(atomic)     in-memory
     │
     ▼
Return diff {"key": {"old": X, "new": Y}}
     │
     ▼
Admin UI shows diff panel
```

### Backend → UI Sync Flow (File Watcher)

```
config.yaml edited externally (vim / CI/CD)
     │
     ▼
watchdog detects file change (debounced 500ms)
     │
     ▼
FileWatcher._handler.dispatch()
     │
  ┌──┼──────────────────────┐
  │  │                      │
  ▼  ▼                      ▼
Hot-reload         Broadcast ChangeEvent
ConfigManager      to all WebSocket clients
in memory
                        │
                        ▼
               Admin UI receives WS event:
               {"type":"file_change","category":"config"}
                        │
                        ▼
               Toast: "Config updated externally — refreshed"
               Auto-reload affected section in UI
```

### Atomic Write Pattern

All writes to `config.yaml`, `.env`, and prompt `.txt` files use the write-to-temp-then-rename pattern to prevent partial reads during a write:

```python
# All writes use temp-then-rename to prevent corruption
tmp = config_path.with_suffix(".tmp")
tmp.write_text(new_content)
tmp.replace(config_path)  # atomic on same filesystem
```

This guarantees that any reader of the file sees either the complete old content or the complete new content — never a partial write.

### WebSocket Reconnection

The Admin Console WebSocket client implements automatic reconnection with exponential backoff (initial delay 1 s, max delay 30 s, jitter ±20%). When reconnected, the client re-sends its token as the first message and re-subscribes to the broadcast stream. The live indicator updates accordingly.

---

## 6. Prompt Management Architecture

### Storage Layout

```
backend/prompts_store/
  prompts_registry.json    ← maps key → {filename, description, variables, version, timestamps}
  ocr_extraction.txt       ← current version
  ocr_user.txt
  field_extraction.txt     ← supports {categories_list} variable
  sow_report.txt
  history/
    ocr_extraction_v1.txt  ← automatic backups (last 10 kept)
    ocr_extraction_v2.txt
    field_extraction_v1.txt
    ...
```

`prompts_registry.json` is the source of truth for metadata. An example entry:

```json
{
  "ocr_extraction": {
    "filename": "ocr_extraction.txt",
    "description": "System prompt for OCR document extraction",
    "variables": [],
    "version": 3,
    "created_at": "2026-04-01T09:00:00+00:00",
    "updated_at": "2026-04-04T10:00:00+00:00"
  }
}
```

### Variable Interpolation

Prompts may declare named placeholders using `{variable_name}` syntax. Declared variables appear as labelled inputs in the prompt editor and are documented in `prompts_registry.json`.

```
Prompt: "Extract from categories: {categories_list}"
Call:   prompt_manager.get("field_extraction", {"categories_list": "EMPLOYMENT_INCOME, TAX_DOCUMENTS"})
Result: "Extract from categories: EMPLOYMENT_INCOME, TAX_DOCUMENTS"
```

Undeclared variables in the template string are left unreplaced and trigger a warning in the API response.

### Version Lifecycle

```
save(key, new_content):
  1. Copy current file → history/{stem}_v{N}.txt
  2. Write new content atomically
  3. Increment version in prompts_registry.json
  4. Prune history to MAX_VERSIONS=10 (delete oldest if exceeded)
```

Restore follows the same lifecycle — it treats the historical version as new content and runs through the same save path, so the restore itself becomes a versioned event.

### PromptManager as Drop-in Replacement

`PromptManager` is designed to replace hardcoded prompt imports without changing call sites significantly:

```python
# Old (hardcoded, not editable at runtime):
from prompts.ocr_prompt import get_ocr_system_prompt
system = get_ocr_system_prompt(override=config.get("ocr_system_override"))

# New (file-backed, editable at runtime via Admin Console):
from services.prompt_manager import get_prompt_manager
system = get_prompt_manager().get("ocr_extraction")
```

With variable interpolation:

```python
system = get_prompt_manager().get("field_extraction", {
    "categories_list": ", ".join(enabled_categories)
})
```

`get_prompt_manager()` returns the singleton instance and is safe to call from any request handler.

---

## 7. Audit Log Format

**File:** `backend/audit_log.jsonl`
**Format:** One JSON object per line, append-only. Never modified or truncated by the application.

### Schema

```json
{
  "timestamp": "2026-04-04T10:00:00+00:00",
  "changed_by": "admin",
  "action": "config_update",
  "section": "LLM",
  "key": "model_name",
  "old_value": "gpt-4",
  "new_value": "Qwen3-Next-80B",
  "details": null
}
```

### Action Values

| Action | Trigger |
|---|---|
| `config_update` | A config.yaml section field was changed via the form |
| `env_update` | A .env key was changed |
| `provider_mode_change` | PROVIDER_MODE was changed |
| `prompt_save` | Prompt content was saved |
| `prompt_create` | A new prompt was created |
| `prompt_delete` | A prompt was soft-deleted |
| `prompt_restore` | A historical prompt version was restored |
| `user_add` | A user was added to the allowlist |
| `user_remove` | A user was removed from the allowlist |
| `config_reload` | Providers were force-reloaded via the API |
| `raw_yaml_write` | config.yaml was written via the raw file editor |
| `raw_env_write` | .env was written via the raw file editor |
| `config_import` | config.yaml was replaced via file import |
| `env_import` | .env was replaced via file import |
| `file_change` | An external filesystem change was detected by the watcher |

The `old_value` and `new_value` fields contain the string-serialised previous and new values respectively. For bulk operations (e.g. section save with multiple changed keys), one log entry is written per changed key.

### Querying via API

```bash
# Last 50 prompt saves
curl "http://localhost:8000/admin/api/sync/audit?limit=50&action=prompt_save" \
  -H "X-Admin-Token: <token>"

# All changes by a specific user
curl "http://localhost:8000/admin/api/sync/audit?changed_by=admin&limit=100" \
  -H "X-Admin-Token: <token>"

# Changes to the LLM section
curl "http://localhost:8000/admin/api/sync/audit?section=LLM" \
  -H "X-Admin-Token: <token>"
```

---

## 8. New Files Reference Table

| File | Lines | Purpose |
|---|---|---|
| `backend/services/config_manager.py` | 254 | Bi-directional config sync: read/write/hot-reload `config.yaml` and `.env`; returns diffs on write |
| `backend/services/prompt_manager.py` | 318 | File-backed prompt CRUD with versioning, history pruning, and variable interpolation |
| `backend/services/file_watcher.py` | 169 | `watchdog`-based file monitor; debounces events and broadcasts `ChangeEvent` to all WebSocket clients |
| `backend/services/audit_logger.py` | 136 | Append-only JSONL audit trail writer; reader with filter/pagination support |
| `backend/routers/admin_config.py` | 187 | FastAPI router: REST API for config YAML/env management (10 endpoints) |
| `backend/routers/admin_prompts.py` | 149 | FastAPI router: REST API for prompt CRUD, versioning, and test interpolation (9 endpoints) |
| `backend/routers/admin_sync.py` | 236 | FastAPI router: WebSocket sync endpoint, raw file editor API, audit log query API |
| `admin-console/index.html` | ~800 | Complete Admin Console SPA — 6 sections, Monaco editor integration, WebSocket live sync |
| `backend/prompts_store/prompts_registry.json` | — | Prompt key → file mapping with metadata (description, variables, version, timestamps) |
| `backend/prompts_store/*.txt` | — | Default prompt content files (one per registered prompt key) |
| `backend/prompts_store/history/` | — | Automatic version backups, up to 10 versions per prompt key |
| `backend/audit_log.jsonl` | — | Append-only audit trail; created automatically on first write action |
