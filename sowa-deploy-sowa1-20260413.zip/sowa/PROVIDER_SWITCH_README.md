# SOW Portal — Provider, Auth & Environment Guide

How to switch AI providers, configure AD/SSO authentication, and deploy across any environment — with zero code changes.

---

## Table of Contents

1. [Switching Provider Modes](#1-switching-provider-modes)
2. [Provider Configuration Reference](#2-provider-configuration-reference)
3. [SSO / Active Directory Setup](#3-sso--active-directory-setup)
4. [Admin Console](#4-admin-console)
5. [Admin API Reference](#5-admin-api-reference)
6. [Provider Abstraction Architecture](#6-provider-abstraction-architecture)
7. [Adding a New Provider](#7-adding-a-new-provider)

---

## 1. Switching Provider Modes

Open `backend/config/config.yaml` and change one line:

```yaml
PROVIDER_MODE: "anthropic"        # ← change this
```

| Value | Description | Required Config Section |
|---|---|---|
| `anthropic` | Anthropic Claude API (default) | `ANTHROPIC` |
| `internal_vllm` | On-prem vLLM (your datacentre) | `LLM`, `VLM`, `OCR`, `VECTORISATION`, `RERANKER` |
| `openai` | Standard OpenAI API | `OPENAI` |
| `azure_openai` | Azure OpenAI Service | `AZURE_OPENAI` |
| `ollama` | Local Ollama server | `OLLAMA` |
| `bedrock` | AWS Bedrock | `BEDROCK` |
| `vertex` | Google Vertex AI | `VERTEX` |

Then restart the backend. No code changes needed.

```bash
docker compose restart backend
# or
uvicorn main:app --reload --port 8000
```

---

## 2. Provider Configuration Reference

### Anthropic (Claude API)

```yaml
PROVIDER_MODE: "anthropic"

ANTHROPIC:
  api_key: ""           # or set env: ANTHROPIC_API_KEY
  model_name: "claude-sonnet-4-20250514"
  vision_model: "claude-sonnet-4-20250514"
  temperature: 0.2
  max_tokens: 4096
```

### Internal vLLM (On-Premises / Datacentre)

```yaml
PROVIDER_MODE: "internal_vllm"

OCR:
  client_app_name: "sow-portal"
  server_app_name: "XXX-llm-coordinator"
  auth_url: "https://hy-authentication.ml-YYY.XXX.com/token_with_llm_policies/register_new_token_for_preprod_client/"
  endpoint: "https://XXX-llm-coordinator.ml-YYY.XXX.com/centralized-ocr/v1/ocr/file"
  api_key: ""

LLM:
  base_url: "https://XXX-llm-coordinator.ml-YYY.XXX.com"
  model_name: "Qwen3-Next-80B-A3B-Instruct-FP8"
  api_key: ""

VLM_TRANSFORMER:
  base_url: "https://XXX-llm-coordinator.ml-YYY.XXX.com"
  model_name_openai: "XXX-VLM"
  api_key: ""

VECTORISATION:
  base_url: "https://XXX-llm-coordinator.ml-YYY.XXX.com"
  model_name: "bge-m3"

RERANKER:
  endpoint: "https://XXX-llm-coordinator.ml-YYY.XXX.com/rerank"
  model_name: "mxbai-rerank-large-v1"
```

**Token auth** for internal endpoints is automatic. The `TokenManager` fetches a bearer token from `OCR.auth_url`, caches it, and refreshes 60 seconds before expiry.

### OpenAI

```yaml
PROVIDER_MODE: "openai"

OPENAI:
  base_url: "https://api.openai.com"
  api_key: "sk-..."
  model_name: "gpt-4o"
  vision_model: "gpt-4o"
  embedding_model: "text-embedding-3-small"
  temperature: 0.2
  max_tokens: 4096
```

### Azure OpenAI

```yaml
PROVIDER_MODE: "azure_openai"

AZURE_OPENAI:
  endpoint: "https://YOUR-RESOURCE.openai.azure.com"
  api_key: "..."
  api_version: "2024-02-01"
  deployment_name: "gpt-4o"
  embedding_deployment: "text-embedding-3-small"
```

### Ollama (Local)

```yaml
PROVIDER_MODE: "ollama"

OLLAMA:
  base_url: "http://localhost:11434"
  model_name: "llama3.2-vision"   # any pulled model with vision
  embedding_model: "nomic-embed-text"
  temperature: 0.2
  max_tokens: 4096
```

Pull the model first:
```bash
ollama pull llama3.2-vision
ollama pull nomic-embed-text
```

### AWS Bedrock

```yaml
PROVIDER_MODE: "bedrock"

BEDROCK:
  base_url: "https://bedrock-runtime.us-east-1.amazonaws.com"
  api_key: ""           # use AWS credential chain (IAM role / env vars)
  model_name: "anthropic.claude-3-5-sonnet-20241022-v2:0"
```

### Google Vertex AI

```yaml
PROVIDER_MODE: "vertex"

VERTEX:
  base_url: "https://us-central1-aiplatform.googleapis.com"
  api_key: ""           # use GCP ADC (gcloud auth application-default login)
  model_name: "gemini-1.5-pro"
```

---

## 3. SSO / Active Directory Setup

### Provider Options

Configure `AUTH.provider` in `config.yaml`:

| Value | Method | Required Config |
|---|---|---|
| `demo` | Hardcoded demo credentials (dev only) | None |
| `ldap` | LDAP/Active Directory bind | `ldap_server`, `ldap_base_dn` |
| `azure_ad` | Azure AD ROPC flow (MSAL) | `azure_tenant_id`, `azure_client_id` |
| `oauth2` | Generic OAuth2 ROPC flow | `oauth2_token_url`, `oauth2_client_id` |

### LDAP / Active Directory

```yaml
AUTH:
  provider: "ldap"
  ldap_server: "ldap://dc01.company.com"
  ldap_base_dn: "DC=company,DC=com"
  ldap_bind_user: ""        # leave empty to use the authenticating user's credentials
  ldap_bind_password: ""
  admin_username: "admin"
  admin_password_hash: ""   # SHA-256 of admin password (see below)
```

The system tries multiple DN formats automatically:
1. `username@company.com` (UPN format)
2. `CN=username,DC=company,DC=com`
3. Raw username

**Install required package:**
```bash
pip install ldap3
```

### Azure Active Directory

```yaml
AUTH:
  provider: "azure_ad"
  azure_tenant_id: "your-tenant-id"
  azure_client_id: "your-app-client-id"
```

Requires an Azure AD app registration with `User.Read` scope and ROPC flow enabled.

**Install required package:**
```bash
pip install msal
```

### Setting the Admin Password

**Option A: Plain password via environment variable (quick start)**
```bash
export ADMIN_PASSWORD=yourpassword
# or in .env:
ADMIN_PASSWORD=yourpassword
```

**Option B: Hashed password in config.yaml (production)**
```bash
python3 -c "import hashlib; print(hashlib.sha256('yourpassword'.encode()).hexdigest())"
```
Paste the output into `config.yaml`:
```yaml
AUTH:
  admin_username: "admin"
  admin_password_hash: "abc123..."   # SHA-256 hex
```

### How Login Works (User Flow)

```
User enters credentials
       │
       ▼
SSOHandler.authenticate()  ←── AUTH.provider config
       │
   ┌───┴─────────────────┐
   │ LDAP / Azure AD /   │  ← verify credentials
   │ OAuth2 / Demo       │
   └───┬─────────────────┘
       │ AuthResult(success, username, display_name, email)
       ▼
allowlist check  ←── SQLite: allowed_users table
(skipped for "demo" provider)
       │
       ▼
session token created  ←── 8-hour TTL, X-Session-Token header
       │
       ▼
User accesses portal
```

### Adding Users to the Allowlist

Users must be added by an admin before they can log in (except in demo mode). Use the Admin Console UI or REST API:

```bash
# via API
curl -X POST http://localhost:8000/api/admin/users \
  -H "X-Admin-Token: <admin-token>" \
  -H "Content-Type: application/json" \
  -d '{"username": "john.doe@company.com", "display_name": "John Doe"}'
```

---

## 4. Admin Console

A standalone web UI for user management, health checks, and audit logs.

**URL:** http://localhost:8000/admin/ (served directly from the backend)

**Login:** admin / `ADMIN_PASSWORD`

### Features

- **User Management** — Add/remove AD usernames or emails from the access allowlist
- **System Health** — Shows which AI providers are initialized (LLM, Vision, Embedding, Reranker, OCR)
- **Audit Log** — Every add/remove user action is logged with timestamp and actor

---

## 5. Admin API Reference

All admin endpoints require `X-Admin-Token` header obtained from `POST /api/admin/login`.

### Get Admin Token

```http
POST /api/admin/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin2024"
}
```

Response:
```json
{"token": "abc123...", "expires_in": 28800}
```

### User Management

```http
# List approved users
GET /api/admin/users
X-Admin-Token: <token>

# Add user
POST /api/admin/users
X-Admin-Token: <token>
{"username": "jane.doe@company.com", "display_name": "Jane Doe", "email": "jane@company.com"}

# Remove user (soft delete)
DELETE /api/admin/users/jane.doe@company.com
X-Admin-Token: <token>

# Get user details
GET /api/admin/users/jane.doe@company.com
X-Admin-Token: <token>
```

### Audit & Health

```http
# Audit log (last 100 actions)
GET /api/admin/audit?limit=100
X-Admin-Token: <token>

# System health
GET /api/admin/health
X-Admin-Token: <token>
```

Health response:
```json
{
  "status": "ok",
  "timestamp": "2026-04-03T10:00:00",
  "provider_mode": "anthropic",
  "providers": {
    "llm": true,
    "vision": true,
    "embedding": false,
    "reranker": false,
    "ocr": false
  },
  "active_users": 5
}
```

### Portal Auth (frontend ↔ backend)

```http
# Login
POST /auth/login
{"username": "john.doe", "password": "..."}
→ {"token": "...", "username": "...", "display_name": "...", "role": "user"}

# Current user
GET /auth/me
X-Session-Token: <token>

# Logout
POST /auth/logout
X-Session-Token: <token>
```

---

## 6. Provider Abstraction Architecture

```
services/
  ocr_service.py          ──► get_registry().get_vision().vision_complete(...)
  extraction_service.py   ──► get_registry().get_llm().complete(...)
  sow_writer_service.py   ──► get_registry().get_llm().stream(...)

providers/
  base.py                 Abstract interfaces
    BaseLLMProvider        .complete() .stream()
    BaseVisionProvider     .vision_complete()
    BaseEmbeddingProvider  .embed()
    BaseRerankProvider     .rerank()
    BaseOCRProvider        .ocr_file()

  anthropic_provider.py   Implements BaseLLMProvider + BaseVisionProvider
  openai_compatible_provider.py  Implements all 5 (covers vLLM/Ollama/Azure/etc.)
  token_manager.py        Bearer token cache + auto-refresh for internal endpoints

  provider_factory.py     ProviderRegistry singleton
    init_providers(config) → resolves from PROVIDER_MODE → populates registry
    get_registry()         → returns initialized registry
```

### Provider Capability Matrix

| Provider Mode | LLM | Vision/OCR | Embeddings | Reranker | Dedicated OCR |
|---|---|---|---|---|---|
| `anthropic` | ✓ Claude | ✓ Claude Vision | — | — | — |
| `internal_vllm` | ✓ Qwen/Llama | ✓ VLM | ✓ BGE | ✓ mxbai | ✓ Format AI |
| `openai` | ✓ GPT-4 | ✓ GPT-4V | ✓ ada | — | — |
| `azure_openai` | ✓ | ✓ | ✓ | — | — |
| `ollama` | ✓ | ✓ | ✓ | — | — |
| `bedrock` | ✓ | — | — | — | — |
| `vertex` | ✓ | — | — | — | — |

---

## 7. Adding a New Provider

**Step 1: Implement the interface in `providers/`**

```python
# providers/my_provider.py
from providers.base import BaseLLMProvider

class MyCustomLLMProvider(BaseLLMProvider):
    async def complete(self, system, user, model, max_tokens, temperature) -> str:
        # call your API
        ...

    async def stream(self, system, user, model, max_tokens, temperature):
        # yield tokens
        yield "token"
```

**Step 2: Register in `provider_factory.py`**

```python
def _init_my_provider(registry, config):
    from providers.my_provider import MyCustomLLMProvider
    my_cfg = config.get("MY_PROVIDER", {})
    registry.llm = MyCustomLLMProvider(base_url=my_cfg["base_url"])

# In init_providers():
elif mode == "my_provider":
    _init_my_provider(registry, config)
```

**Step 3: Add config section to `config.yaml`**

```yaml
MY_PROVIDER:
  base_url: "https://my-api.example.com"
  api_key: "..."
  model_name: "my-model-v1"
```

**Step 4: Switch**

```yaml
PROVIDER_MODE: "my_provider"
```

Restart. Done — no changes to any service file.

---

## 8. Runtime Config Changes (No Restart Required)

With the Admin Console, you can change `PROVIDER_MODE` and all provider settings **at runtime** without restarting the application.

### Via Admin Console UI

1. Go to http://localhost:8000/admin/
2. Navigate to **Configuration → Provider Mode**
3. Select the new provider from the dropdown
4. Click **Save** — config.yaml is updated and providers re-initialized in memory immediately

### Via Admin API

```bash
# Get admin token
TOKEN=$(curl -s -X POST http://localhost:8000/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin2024"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")

# Switch provider mode
curl -X PUT http://localhost:8000/admin/api/config/provider_mode \
  -H "X-Admin-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"mode": "internal_vllm"}'

# Update LLM endpoint
curl -X PUT http://localhost:8000/admin/api/config/yaml/LLM \
  -H "X-Admin-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"values": {"base_url": "https://new-llm.example.com", "model_name": "Qwen3-80B"}}'

# Force reload (if config.yaml was edited directly on disk)
curl -X POST http://localhost:8000/admin/api/config/reload \
  -H "X-Admin-Token: $TOKEN"
```

### What hot-reload does

When provider mode or config changes:
1. `config.yaml` is written atomically (temp-then-rename)
2. `ConfigManager.reload()` re-reads from disk
3. `init_providers(new_config)` re-initializes the `ProviderRegistry`
4. All subsequent LLM/OCR/Vision calls use the new provider
5. Change is appended to `audit_log.jsonl`

No process restart. No dropped requests. The switch takes <1 second.

### Audit Trail

Every config change — whether made via UI, API, or direct file edit — is logged:

```bash
curl http://localhost:8000/admin/api/sync/audit?action=provider_mode_change \
  -H "X-Admin-Token: $TOKEN"
```
