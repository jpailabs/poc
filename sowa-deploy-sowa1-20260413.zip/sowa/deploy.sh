#!/bin/bash
# =============================================================================
#  SOW Portal — CML Deployment Script
#  Usage: bash deploy.sh
#  Run from: /home/cdsw/poc/  after unzipping sowa-cml.zip
#  Creates virtual environment, installs packages, sets up all paths.
# =============================================================================

set -e

# ── Colour helpers ────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✔  $1${NC}"; }
info() { echo -e "${CYAN}  →  $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠  $1${NC}"; }
fail() { echo -e "${RED}  ✘  $1${NC}"; exit 1; }
hdr()  { echo -e "\n${BOLD}${CYAN}$1${NC}"; echo "$(printf '─%.0s' {1..60})"; }

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$SCRIPT_DIR"          # /home/cdsw/poc/sowa
BACKEND_DIR="$PROJECT_ROOT/backend"
VENV_DIR="$PROJECT_ROOT/venv"
SESSION_DIR="$PROJECT_ROOT/sow_sessions"
DB_PATH="$PROJECT_ROOT/sow.db"
CONFIG_FILE="$BACKEND_DIR/config/config.yaml"
CONFIG_CML="$BACKEND_DIR/config/config.yaml.cml"

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${CYAN}║         SOW Portal — CML Deployment Script               ║${NC}"
echo -e "${BOLD}${CYAN}║         Deploy path: $PROJECT_ROOT   ║${NC}"
echo -e "${BOLD}${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# =============================================================================
# STEP 1 — Verify location and file structure
# =============================================================================
hdr "STEP 1/7 — Verifying project structure"

# Check we are in the right directory
if [ ! -f "$BACKEND_DIR/main.py" ]; then
    fail "main.py not found at $BACKEND_DIR/main.py\n       Make sure you unzipped sowa-cml.zip under /home/cdsw/poc/ and run: bash /home/cdsw/poc/sowa/deploy.sh"
fi
ok "backend/main.py found"

if [ ! -f "$PROJECT_ROOT/bos-portal/index.html" ]; then
    fail "bos-portal/index.html not found at $PROJECT_ROOT/bos-portal/index.html"
fi
ok "bos-portal/index.html found"

if [ ! -f "$BACKEND_DIR/admin-console/index.html" ]; then
    fail "admin-console/index.html not found at $BACKEND_DIR/admin-console/index.html"
fi
ok "backend/admin-console/index.html found"

if [ ! -f "$BACKEND_DIR/requirements-cml.txt" ]; then
    fail "requirements-cml.txt not found at $BACKEND_DIR/requirements-cml.txt"
fi
ok "requirements-cml.txt found"

if [ ! -f "$BACKEND_DIR/utils/paths.py" ]; then
    fail "utils/paths.py not found — the utils/ folder may be missing from the ZIP"
fi
ok "utils/paths.py found"

# =============================================================================
# STEP 2 — Create Python virtual environment
# =============================================================================
hdr "STEP 2/7 — Creating virtual environment 'sowa'"

PYTHON_BIN=$(which python3 2>/dev/null || which python 2>/dev/null)
if [ -z "$PYTHON_BIN" ]; then
    fail "Python 3 not found. Ensure Python 3.9+ is available on this CML instance."
fi

PYTHON_VERSION=$("$PYTHON_BIN" --version 2>&1)
info "Using $PYTHON_VERSION at $PYTHON_BIN"

if [ -d "$VENV_DIR" ]; then
    warn "Virtual environment already exists at $VENV_DIR — skipping creation"
    warn "To recreate: rm -rf $VENV_DIR && bash deploy.sh"
else
    info "Creating virtual environment at $VENV_DIR ..."
    "$PYTHON_BIN" -m venv "$VENV_DIR"
    ok "Virtual environment created"
fi

# Activate the virtual environment
source "$VENV_DIR/bin/activate"
ok "Virtual environment activated"

VENV_PYTHON="$VENV_DIR/bin/python"
VENV_PIP="$VENV_DIR/bin/pip"
info "Python in venv: $($VENV_PYTHON --version)"
info "Pip in venv:    $($VENV_PIP --version)"

# =============================================================================
# STEP 3 — Install dependencies
# =============================================================================
hdr "STEP 3/7 — Installing Python dependencies"

info "Upgrading pip..."
"$VENV_PIP" install --quiet --upgrade pip

info "Installing packages from requirements-cml.txt..."
info "(This may take 3–5 minutes on first run)"

# Install with fallback handling for restricted environments
if "$VENV_PIP" install --quiet -r "$BACKEND_DIR/requirements-cml.txt"; then
    ok "All packages installed successfully"
else
    warn "Some packages failed. Trying without SSO packages (ldap3, msal)..."
    grep -v "^ldap3\|^msal" "$BACKEND_DIR/requirements-cml.txt" > /tmp/requirements-nosso.txt
    "$VENV_PIP" install --quiet -r /tmp/requirements-nosso.txt
    warn "Installed without ldap3/msal — SSO login disabled, all other features work"
fi

# Verify critical packages
info "Verifying critical packages..."
MISSING=""
for pkg in fastapi uvicorn sqlalchemy httpx pydantic yaml reportlab docx; do
    if ! "$VENV_PYTHON" -c "import $pkg" 2>/dev/null; then
        MISSING="$MISSING $pkg"
    fi
done

if [ -n "$MISSING" ]; then
    fail "Missing packages:$MISSING\nTry running: source $VENV_DIR/bin/activate && pip install$MISSING"
fi
ok "All critical packages verified"

# Check PyMuPDF separately (can fail on some Linux images)
if ! "$VENV_PYTHON" -c "import fitz" 2>/dev/null; then
    warn "PyMuPDF (fitz) not installed — trying alternate install..."
    if "$VENV_PIP" install --quiet pymupdf; then
        ok "PyMuPDF installed successfully"
    else
        warn "PyMuPDF unavailable — PDF image rendering will be limited to text extraction"
        warn "Text-based PDFs (like IRAS NOA) will still work correctly"
    fi
else
    ok "PyMuPDF (PDF processing) verified"
fi

# =============================================================================
# STEP 4 — Set up config.yaml
# =============================================================================
hdr "STEP 4/7 — Setting up configuration"

# Use the pre-sanitised config (no API keys)
if [ -f "$CONFIG_CML" ]; then
    cp "$CONFIG_CML" "$CONFIG_FILE"
    ok "Clean config.yaml deployed (API keys cleared, upload_dir set to CML path)"
elif [ -f "$CONFIG_FILE" ]; then
    warn "config.yaml.cml not found — using existing config.yaml"
    warn "Make sure API keys are cleared before deploying"
else
    fail "No config.yaml found at $CONFIG_FILE and no config.yaml.cml to fall back to"
fi

# Patch upload_dir in config to use our project path
if command -v python3 &>/dev/null; then
    "$VENV_PYTHON" -c "
import yaml, re
with open('$CONFIG_FILE') as f:
    content = f.read()
content = re.sub(
    r'upload_dir:.*',
    'upload_dir: $SESSION_DIR',
    content
)
with open('$CONFIG_FILE', 'w') as f:
    f.write(content)
print('  upload_dir updated in config.yaml')
" && ok "config.yaml upload_dir set to $SESSION_DIR"
fi

# =============================================================================
# STEP 5 — Create directories and files
# =============================================================================
hdr "STEP 5/7 — Creating required directories"

mkdir -p "$SESSION_DIR"
ok "Session uploads directory: $SESSION_DIR"

mkdir -p "$PROJECT_ROOT/backend/prompts_store/history"
ok "Prompts store directory ready"

# Touch the database file so the path is valid
touch "$DB_PATH" 2>/dev/null || true
ok "SQLite database path: $DB_PATH"

# =============================================================================
# STEP 6 — Write the CML Application startup script
# =============================================================================
hdr "STEP 6/7 — Writing CML Application startup script"

cat > "$PROJECT_ROOT/start_cml.sh" << STARTSCRIPT
#!/bin/bash
# =============================================================
# SOW Portal — CML Application Start Script
# This file is called by CML when the Application starts.
# DO NOT EDIT unless you know what you are doing.
# =============================================================
set -e

PROJECT_ROOT="$PROJECT_ROOT"
VENV_DIR="\$PROJECT_ROOT/venv"
BACKEND_DIR="\$PROJECT_ROOT/backend"
PORT="\${CDSW_APP_PORT:-8000}"

# Activate virtual environment
if [ ! -f "\$VENV_DIR/bin/activate" ]; then
    echo "ERROR: Virtual environment not found at \$VENV_DIR"
    echo "       Run: bash \$PROJECT_ROOT/deploy.sh"
    exit 1
fi

source "\$VENV_DIR/bin/activate"

# Configure paths
export DATABASE_URL="\${DATABASE_URL:-sqlite:////$DB_PATH}"
export SOW_SESSIONS_DIR="\${SOW_SESSIONS_DIR:-$SESSION_DIR}"
mkdir -p "\$SOW_SESSIONS_DIR"

echo "=========================================="
echo "  SOW Portal Starting"
echo "  Port     : \$PORT"
echo "  Database : \$DATABASE_URL"
echo "  Sessions : \$SOW_SESSIONS_DIR"
echo "=========================================="
echo ""
echo "  BOS Portal    → <CML App URL>/"
echo "  Admin Console → <CML App URL>/admin/"
echo "  API Docs      → <CML App URL>/docs"
echo ""

cd "\$BACKEND_DIR"
exec uvicorn main:app \\
    --host 0.0.0.0 \\
    --port "\$PORT" \\
    --workers 1 \\
    --loop asyncio \\
    --log-level info
STARTSCRIPT

chmod +x "$PROJECT_ROOT/start_cml.sh"
ok "start_cml.sh written and made executable"

# =============================================================================
# STEP 7 — Smoke test (start and immediately stop)
# =============================================================================
hdr "STEP 7/7 — Running smoke test"

export DATABASE_URL="sqlite:///$DB_PATH"
export SOW_SESSIONS_DIR="$SESSION_DIR"

info "Starting app on test port 8099 for 5 seconds..."

cd "$BACKEND_DIR"
"$VENV_DIR/bin/uvicorn" main:app --host 0.0.0.0 --port 8099 --log-level warning &
APP_PID=$!
sleep 5

if kill -0 $APP_PID 2>/dev/null; then
    kill $APP_PID 2>/dev/null
    wait $APP_PID 2>/dev/null || true
    ok "Smoke test PASSED — application started successfully"
else
    fail "Smoke test FAILED — application crashed on startup. Check the error above."
fi

# =============================================================================
# DONE — Print CML Application setup instructions
# =============================================================================

echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}║   ✔  DEPLOYMENT COMPLETE — FOLLOW STEPS BELOW           ║${NC}"
echo -e "${BOLD}${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BOLD}The application is deployed and tested. Now create it as a CML Application:${NC}"
echo ""

echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}  STEP A — Set Environment Variables in CML${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "  Go to: CML Project → Settings → Environment Variables"
echo "  Add these variables (click + Add Variable for each):"
echo ""
echo -e "  ${CYAN}Variable Name${NC}          ${CYAN}Value${NC}"
echo "  ─────────────────────  ───────────────────────────────────────"
echo "  DATABASE_URL           sqlite:////$DB_PATH"
echo "  SOW_SESSIONS_DIR       $SESSION_DIR"
echo "  ADMIN_PASSWORD         <choose a secure password>"
echo "  ANTHROPIC_API_KEY      <your key if using Anthropic mode>"
echo ""
echo "  Click SAVE after adding all variables."
echo ""

echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}  STEP B — Create CML Application${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "  Go to: CML Project → Applications → New Application"
echo ""
echo -e "  ${CYAN}Field${NC}               ${CYAN}Value${NC}"
echo "  ──────────────────  ────────────────────────────────────────────"
echo "  Name                SOW Portal"
echo "  Subdomain           sow-portal"
echo -e "  ${BOLD}Script${NC}              ${BOLD}bash $PROJECT_ROOT/start_cml.sh${NC}"
echo "  Python Version      Python 3.10 (or highest available)"
echo "  CPU                 2 vCPU"
echo "  Memory              4 GB"
echo ""
echo "  Click CREATE APPLICATION."
echo ""

echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}  STEP C — Configure Providers via Admin Console${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "  Once the Application shows Running:"
echo ""
echo "  1. Open:  https://sow-portal.<your-cml-domain>/admin/"
echo "  2. Login with your ADMIN_PASSWORD"
echo "  3. Go to Configuration tab"
echo "  4. Set Provider Mode to: private"
echo "  5. Fill in LLM / OCR / VLM / Vectorisation / Reranker endpoints"
echo "  6. Click Save — takes effect immediately, no restart needed"
echo ""

echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BOLD}  Quick Reference${NC}"
echo -e "${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo "  Project root  : $PROJECT_ROOT"
echo "  Virtual env   : $VENV_DIR"
echo "  Database      : $DB_PATH"
echo "  Uploads       : $SESSION_DIR"
echo "  App script    : $PROJECT_ROOT/start_cml.sh"
echo "  Config        : $BACKEND_DIR/config/config.yaml"
echo "  Prompts       : $BACKEND_DIR/prompts_store/"
echo ""
echo -e "${GREEN}${BOLD}Deployment complete. Follow Steps A → B → C above.${NC}"
echo ""
