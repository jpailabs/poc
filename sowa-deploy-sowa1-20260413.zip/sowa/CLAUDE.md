# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**FinDoc** — a financial document extraction and review platform for Bank of Singapore's Source of Wealth workflow. Clients upload financial documents (NOA, payslips, source-of-wealth summaries, business docs), the system extracts structured data via mock extractors, and reviewers verify/correct the extracted fields before marking records as verified.

## Architecture

Three components connected via REST API:

- **Backend** (`backend/`): FastAPI + SQLAlchemy 2.0 + PostgreSQL. Two app entry points:
  - `app.py` — standalone in-memory API (v1.2). Uses a `_store` dict; no database. Endpoints: `/extract`, `/documents/*`, `/schema`.
  - `main.py` — DB-backed API (v2.0, primary). Uses `database.py` + `schemas.py`. Endpoints: `/sessions/*`, `/records/*`, `/schema`. Auto-seeds on startup via `seed.py`.
- **BOS Portal** (`bos-portal/`): Vanilla HTML/CSS/JS client-facing portal. Three-step wizard: select profile (salaried/business owner) → upload documents → review & submit. Submits to `POST /sessions/extract` with multipart form data. Serve with `python -m http.server 3000`.
- **Database**: PostgreSQL 16, single table `document_sessions` with JSONB columns (`extracted_data`, `verified_data`, `diff_summary`).

### Key design decisions

- **Two entry points**: `app.py` is a self-contained in-memory demo; `main.py` is the DB-backed production API. Docker and the dev server use `main.py`. They share the same Pydantic models (via `schemas.py`).
- **Document registry** (`DOCUMENT_REGISTRY` in `backend/schemas.py`): maps doc type keys to Pydantic model classes. Contains ~20 types covering salaried and business owner profiles. Add new document types here.
- **Session vs. subsession**: A `session_id` groups all documents for one client onboarding case. A `subsession_id` represents one round of edits (enables history/audit trail). Updates create new rows (append-only history).
- **Status lifecycle**: `extracted` → `reviewing` → `verified`
- **Schema-driven**: The `/schema` endpoint returns JSON Schema for all registered models. Clients can use this to render forms dynamically.
- **BOS Portal auth**: Hardcoded demo credentials in `bos-portal/app.js` (`demo` / `gdo2024`). Client-side only; no backend auth.

## Commands

### Backend (run from `backend/`)

```bash
pip install -r requirements.txt

# Dev server (DB-backed, primary)
uvicorn main:app --reload --port 8000

# Standalone in-memory demo
uvicorn app:app --reload --port 8000

# Seed database with sample data (also auto-runs on main.py startup)
python seed.py
```

API docs at `http://localhost:8000/docs` when running.

### BOS Portal (run from `bos-portal/`)

```bash
python -m http.server 3000
```

### Docker (full stack)

```bash
docker compose up --build
# postgres: 5432, backend: 8000
```

Note: Docker runs `main.py` (DB-backed API). The `docker-compose.yml` references a `frontend/` service that may need updating — the current client app is `bos-portal/`.

## Backend API Endpoints (main.py)

| Method | Path | Description |
|--------|------|-------------|
| POST | `/sessions/extract` | Extract + persist to DB (multipart form, accepts file upload) |
| GET | `/sessions` | List all sessions (summary) |
| GET | `/sessions/{session_id}` | Latest records per doc_type for a session |
| GET | `/sessions/{session_id}/history` | Full subsession edit history |
| GET | `/records/{record_id}` | Get a single record |
| PUT | `/records/{record_id}` | Update record — saves verified_data, computes diff, creates new subsession row |
| DELETE | `/records/{record_id}` | Delete a record |
| POST | `/records/{record_id}/summarize` | Mock LLM summary of record data |
| GET | `/schema` | JSON Schema for all registered models |

## Adding a New Document Type

1. Define a Pydantic model in `backend/schemas.py` (or reuse `OtherDocData` for simple types)
2. Add an entry to `DOCUMENT_REGISTRY` in `backend/schemas.py`
3. Optionally add a mock extractor in `backend/main.py` `_mock_extract()`
4. If the doc type should appear in the BOS Portal wizard, add it to `SALARIED_DOCS` or `BUSINESS_OWNER_DOCS` in `bos-portal/app.js`

## Database

Connection string defaults to `postgresql://findoc:findoc_secret@localhost:5432/findoc_db`. Override via `DATABASE_URL` env var.

Tables are created automatically by `init_db()` (called on app startup and in `seed.py`). The seed is idempotent — skips if records already exist. To reset: drop the `document_sessions` table, then restart the app or re-run `python seed.py`.
