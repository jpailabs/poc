"""
User allowlist store — persists approved AD usernames/emails to SQLite.
Admin adds/removes users here; only listed users can SSO-authenticate.
"""
from __future__ import annotations

import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

DB_PATH = Path("/tmp/sow_users.db")
_lock = threading.Lock()


def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(str(DB_PATH))
    c.row_factory = sqlite3.Row
    return c


def init_db() -> None:
    with _lock, _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS allowed_users (
                username     TEXT PRIMARY KEY,
                display_name TEXT,
                email        TEXT,
                added_by     TEXT,
                added_at     TEXT,
                active       INTEGER DEFAULT 1
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                action     TEXT,
                username   TEXT,
                actor      TEXT,
                timestamp  TEXT
            )
        """)
        c.commit()


def add_user(username: str, display_name: str = "", email: str = "", added_by: str = "admin") -> dict:
    with _lock, _conn() as c:
        c.execute("""
            INSERT INTO allowed_users (username, display_name, email, added_by, added_at, active)
            VALUES (?, ?, ?, ?, ?, 1)
            ON CONFLICT(username) DO UPDATE SET active=1, display_name=?, email=?, added_by=?, added_at=?
        """, (username, display_name, email, added_by, datetime.utcnow().isoformat(),
              display_name, email, added_by, datetime.utcnow().isoformat()))
        c.execute("INSERT INTO audit_log (action, username, actor, timestamp) VALUES (?,?,?,?)",
                  ("ADD_USER", username, added_by, datetime.utcnow().isoformat()))
        c.commit()
    return {"username": username, "display_name": display_name, "email": email, "active": True}


def remove_user(username: str, removed_by: str = "admin") -> bool:
    with _lock, _conn() as c:
        cur = c.execute("UPDATE allowed_users SET active=0 WHERE username=?", (username,))
        c.execute("INSERT INTO audit_log (action, username, actor, timestamp) VALUES (?,?,?,?)",
                  ("REMOVE_USER", username, removed_by, datetime.utcnow().isoformat()))
        c.commit()
        return cur.rowcount > 0


def is_allowed(username: str) -> bool:
    with _lock, _conn() as c:
        row = c.execute("SELECT active FROM allowed_users WHERE username=? AND active=1", (username,)).fetchone()
        return row is not None


def list_users(include_inactive: bool = False) -> list[dict]:
    with _lock, _conn() as c:
        if include_inactive:
            rows = c.execute("SELECT * FROM allowed_users ORDER BY added_at DESC").fetchall()
        else:
            rows = c.execute("SELECT * FROM allowed_users WHERE active=1 ORDER BY added_at DESC").fetchall()
        return [dict(r) for r in rows]


def get_user(username: str) -> Optional[dict]:
    with _lock, _conn() as c:
        row = c.execute("SELECT * FROM allowed_users WHERE username=?", (username,)).fetchone()
        return dict(row) if row else None


def get_audit_log(limit: int = 100) -> list[dict]:
    with _lock, _conn() as c:
        rows = c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
