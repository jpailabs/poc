"""JWT-based session management for the SOW portal."""
from __future__ import annotations

import hashlib
import secrets
import time
from typing import Optional

# In-memory session store (replace with Redis for production)
_sessions: dict[str, dict] = {}
SESSION_TTL = 8 * 3600  # 8 hours


def create_session(username: str, display_name: str, email: str, role: str = "user") -> str:
    """Create a new session token. Returns the token string."""
    token = secrets.token_hex(32)
    _sessions[token] = {
        "username": username,
        "display_name": display_name,
        "email": email,
        "role": role,
        "created_at": time.time(),
        "expires_at": time.time() + SESSION_TTL,
    }
    return token


def validate_session(token: str) -> Optional[dict]:
    """Validate token, return session dict or None if invalid/expired."""
    session = _sessions.get(token)
    if not session:
        return None
    if time.time() > session["expires_at"]:
        del _sessions[token]
        return None
    return session


def invalidate_session(token: str) -> None:
    _sessions.pop(token, None)


def cleanup_expired() -> int:
    """Remove expired sessions. Returns count removed."""
    now = time.time()
    expired = [t for t, s in _sessions.items() if now > s["expires_at"]]
    for t in expired:
        del _sessions[t]
    return len(expired)
