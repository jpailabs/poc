"""
SSO/Auth handler — supports LDAP, SAML stub, OAuth2, Azure AD, and demo mode.
Provider is selected from AUTH.provider config key.
"""
from __future__ import annotations

import hashlib
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


class AuthResult:
    def __init__(self, success: bool, username: str = "", display_name: str = "", email: str = "", error: str = ""):
        self.success = success
        self.username = username
        self.display_name = display_name
        self.email = email
        self.error = error


class SSOHandler:
    """
    Verifies user credentials against the configured SSO/AD provider.
    Returns AuthResult with user info on success.
    """

    def __init__(self, auth_config: dict):
        self.config = auth_config
        self.provider = auth_config.get("provider", "demo").lower()

    async def authenticate(self, username: str, password: str) -> AuthResult:
        if self.provider == "ldap":
            return await self._ldap_auth(username, password)
        elif self.provider == "azure_ad":
            return await self._azure_ad_auth(username, password)
        elif self.provider == "oauth2":
            return await self._oauth2_auth(username, password)
        elif self.provider == "demo":
            return self._demo_auth(username, password)
        else:
            logger.warning("Unknown auth provider '%s', falling back to demo", self.provider)
            return self._demo_auth(username, password)

    # ── LDAP ──────────────────────────────────────────────────────────────

    async def _ldap_auth(self, username: str, password: str) -> AuthResult:
        try:
            import ldap3
            server_uri = self.config.get("ldap_server", "ldap://localhost")
            base_dn = self.config.get("ldap_base_dn", "DC=company,DC=com")
            bind_user = self.config.get("ldap_bind_user", "")
            bind_pass = self.config.get("ldap_bind_password", "")

            # Build user DN formats to try
            user_dn_formats = [
                f"{username}@{base_dn.replace('DC=', '').replace(',', '.')}",
                f"CN={username},{base_dn}",
                username,
            ]

            from ldap3 import Server, Connection, ALL, NTLM, AUTO_BIND_NO_TLS
            server = Server(server_uri, get_info=ALL, connect_timeout=10)

            for user_dn in user_dn_formats:
                try:
                    conn = Connection(server, user=user_dn, password=password, auto_bind=True)
                    if conn.bound:
                        # Search for user attributes
                        conn.search(
                            base_dn,
                            f"(sAMAccountName={username})",
                            attributes=["displayName", "mail", "sAMAccountName"],
                        )
                        display_name = username
                        email = ""
                        if conn.entries:
                            entry = conn.entries[0]
                            display_name = str(entry.displayName) if entry.displayName else username
                            email = str(entry.mail) if entry.mail else ""
                        conn.unbind()
                        return AuthResult(True, username=username, display_name=display_name, email=email)
                except Exception:
                    continue

            return AuthResult(False, error="Invalid LDAP credentials")
        except ImportError:
            logger.error("ldap3 package not installed. Install: pip install ldap3")
            return AuthResult(False, error="LDAP provider unavailable (missing ldap3 package)")
        except Exception as e:
            logger.exception("LDAP auth error")
            return AuthResult(False, error=f"LDAP error: {str(e)}")

    # ── Azure AD (MSAL) ────────────────────────────────────────────────────

    async def _azure_ad_auth(self, username: str, password: str) -> AuthResult:
        try:
            import msal
            tenant_id = self.config.get("azure_tenant_id", "")
            client_id = self.config.get("azure_client_id", "")
            authority = f"https://login.microsoftonline.com/{tenant_id}"
            scopes = ["User.Read"]

            app = msal.PublicClientApplication(client_id=client_id, authority=authority)
            result = app.acquire_token_by_username_password(username, password, scopes=scopes)

            if "access_token" in result:
                id_claims = result.get("id_token_claims", {})
                return AuthResult(
                    True,
                    username=username,
                    display_name=id_claims.get("name", username),
                    email=id_claims.get("preferred_username", username),
                )
            return AuthResult(False, error=result.get("error_description", "Azure AD auth failed"))
        except ImportError:
            return AuthResult(False, error="msal package not installed. Install: pip install msal")
        except Exception as e:
            return AuthResult(False, error=f"Azure AD error: {str(e)}")

    # ── OAuth2 (generic ROPC flow) ────────────────────────────────────────

    async def _oauth2_auth(self, username: str, password: str) -> AuthResult:
        try:
            import httpx
            token_url = self.config.get("oauth2_token_url", "")
            client_id = self.config.get("oauth2_client_id", "")
            client_secret = self.config.get("oauth2_client_secret", "")

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(token_url, data={
                    "grant_type": "password",
                    "username": username,
                    "password": password,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "scope": "openid profile email",
                })
                if resp.status_code == 200:
                    data = resp.json()
                    return AuthResult(True, username=username, email=username)
                return AuthResult(False, error=f"OAuth2 failed: {resp.status_code}")
        except Exception as e:
            return AuthResult(False, error=f"OAuth2 error: {str(e)}")

    # ── Demo (for local dev / testing) ────────────────────────────────────

    def _demo_auth(self, username: str, password: str) -> AuthResult:
        demo_users = {
            "demo": {"password": "gdo2024", "name": "Demo User", "email": "demo@sow-portal.local"},
        }
        user = demo_users.get(username.lower())
        if user and user["password"] == password:
            return AuthResult(True, username=username, display_name=user["name"], email=user["email"])
        return AuthResult(False, error="Invalid credentials")
