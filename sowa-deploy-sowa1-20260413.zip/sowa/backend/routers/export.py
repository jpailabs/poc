"""
Export router — PDF and DOCX generation with proper table rendering.

Architecture:
  LLM returns structured text with [SECTION], [NARRATIVE], [TABLE] delimiters.
  Parser converts to a SowDocument object tree.
  Rendering components (ProseBlock, KeyValueTable, DataTable, etc.) draw PDF/DOCX.
  No raw LLM text ever reaches the PDF canvas unprocessed.
"""
from __future__ import annotations

import io
import re
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1", tags=["Export"])

# ── Brand colours ──────────────────────────────────────────────────────────────
GOLD       = (154, 123, 63)
GOLD_LIGHT = (201, 168, 108)
DARK       = (26, 26, 26)
TEXT_SEC   = (102, 102, 102)
TEXT_MUTED = (153, 153, 153)
RED        = (220, 53, 69)
ROW_EVEN   = (248, 248, 247)   # very light grey for alternating rows
ROW_TOTAL  = (230, 225, 214)   # slightly darker for totals row
HEADER_BG  = (26, 26, 26)      # dark header background
HEADER_FG  = (255, 255, 255)   # white header text
TABLE_OUTER = (180, 170, 150)  # outer border colour
TABLE_INNER = (220, 215, 205)  # inner grid colour


class ExportRequest(BaseModel):
    session_id: str
    generation_id: str
    client_name: Optional[str] = "Client"
    profile_type: Optional[str] = "Private Client"
    doc_count: Optional[int] = 0
    field_count: Optional[int] = 0
    word_count: Optional[int] = 0
    # Optional inline SOW text — when provided, bypasses session_states lookup.
    # Used in mock mode so the export works even if the session was not stored.
    sow_text: Optional[str] = None
    report_ref: Optional[str] = None   # custom reference ID for filename + PDF header


# ── Structured document model ──────────────────────────────────────────────────

class TableBlock:
    """One table within a section."""
    def __init__(self, caption: str, headers: list[str],
                 rows: list[list[str]], alignments: list[str],
                 total_rows: list[list[str]]):
        self.caption    = caption
        self.headers    = headers
        self.rows       = rows
        self.alignments = alignments  # "left" | "right" | "center" per column
        self.total_rows = total_rows  # rows that should be bold/dark

    @property
    def all_rows(self) -> list[tuple[list[str], bool]]:
        """(row_cells, is_total) for every data row."""
        return [(r, False) for r in self.rows] + [(r, True) for r in self.total_rows]


class SectionBlock:
    """One [SECTION] in the report."""
    def __init__(self, title: str, narrative: str, tables: list[TableBlock]):
        self.title     = title
        self.narrative = narrative.strip()
        self.tables    = tables


class SowDocument:
    """Parsed SOW report."""
    def __init__(self, sections: list[SectionBlock]):
        self.sections = sections


# ── Structured text parser ─────────────────────────────────────────────────────

def _parse_table_block(raw: str) -> TableBlock:
    """Parse the content between [TABLE] and [/TABLE] tags."""
    caption    = ""
    headers    = []
    alignments = []
    rows       = []
    total_rows = []

    for line in raw.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        if line.upper().startswith("CAPTION:"):
            caption = line[8:].strip()
        elif line.upper().startswith("ALIGN:"):
            alignments = [a.strip().lower() for a in line[6:].split(",")]
        elif line.upper().startswith("HEADERS:"):
            headers = [h.strip() for h in line[8:].split("|")]
        elif line.upper().startswith("ROW:"):
            rows.append([c.strip() for c in line[4:].split("|")])
        elif line.upper().startswith("TOTAL:"):
            total_rows.append([c.strip() for c in line[6:].split("|")])

    # Pad alignments to header count
    n = len(headers)
    if len(alignments) < n:
        alignments = alignments + ["left"] * (n - len(alignments))

    return TableBlock(caption, headers, rows, alignments, total_rows)


def _parse_sow_document(text: str) -> SowDocument:
    """Parse structured text output from LLM into a SowDocument tree."""
    sections: list[SectionBlock] = []

    # Split on [SECTION: ...] delimiters
    section_re = re.compile(r'\[SECTION:\s*(.+?)\]', re.IGNORECASE)
    end_section_re = re.compile(r'\[/SECTION\]', re.IGNORECASE)

    parts = section_re.split(text)
    # parts[0] = preamble, then alternating: title, body, title, body ...
    i = 1
    while i < len(parts) - 1:
        title = parts[i].strip()
        body  = parts[i + 1]
        # Trim trailing [/SECTION]
        body = end_section_re.sub("", body)
        i += 2

        # Extract NARRATIVE
        narrative = ""
        narr_re = re.compile(r'\[NARRATIVE\](.*?)\[/NARRATIVE\]', re.DOTALL | re.IGNORECASE)
        narr_match = narr_re.search(body)
        if narr_match:
            narrative = narr_match.group(1).strip()
        else:
            # No delimiter — treat entire non-table content as narrative
            non_table = re.sub(r'\[TABLE\].*?\[/TABLE\]', '', body, flags=re.DOTALL | re.IGNORECASE)
            narrative = non_table.strip()

        # Extract TABLE blocks
        tables: list[TableBlock] = []
        table_re = re.compile(r'\[TABLE\](.*?)\[/TABLE\]', re.DOTALL | re.IGNORECASE)
        for tm in table_re.finditer(body):
            tb = _parse_table_block(tm.group(1))
            if tb.headers:  # only include tables with at least a header row
                tables.append(tb)

        sections.append(SectionBlock(title, narrative, tables))

    # Fallback: if no [SECTION] delimiters found, try legacy ## markdown
    if not sections:
        sections = _parse_legacy_markdown(text)

    return SowDocument(sections)


def _parse_md_table(lines: list[str]) -> "TableBlock | None":
    """Convert markdown pipe-table lines into a TableBlock for PDF rendering."""
    if len(lines) < 2:
        return None

    def parse_row(line: str) -> list[str]:
        return [c.strip() for c in line.strip().strip("|").split("|")]

    headers = parse_row(lines[0])
    if not headers:
        return None

    # Detect alignment from separator row (|:---|---:|:---:|)
    alignments: list[str] = []
    if len(lines) > 1:
        for cell in parse_row(lines[1]):
            c = cell.strip("-").strip(":")
            raw = cell.strip()
            if raw.startswith(":") and raw.endswith(":"):
                alignments.append("center")
            elif raw.endswith(":"):
                alignments.append("right")
            else:
                alignments.append("left")
    while len(alignments) < len(headers):
        alignments.append("left")

    _sep_re = re.compile(r"^\|?[\s\-:]+\|")
    data_rows = [
        parse_row(ln) for ln in lines[2:]
        if ln.strip() and not _sep_re.match(ln.strip())
    ]

    return TableBlock(caption="", headers=headers, rows=data_rows,
                      alignments=alignments, total_rows=[])


def _parse_legacy_markdown(text: str) -> list[SectionBlock]:
    """
    Parse markdown format (# / ## / ### headings + | pipe tables) into SectionBlocks.
    Tables inside each section are extracted as proper TableBlock objects so they
    render with the full dark-header / alternating-row styling in the PDF.
    """
    _sep_re = re.compile(r"^\|?[\s\-:]+\|")

    def _flush(title: str, raw_lines: list[str]) -> SectionBlock:
        """Convert accumulated lines into a SectionBlock, extracting tables."""
        narrative_lines: list[str] = []
        tables: list[TableBlock] = []
        i = 0
        while i < len(raw_lines):
            line = raw_lines[i]
            s = line.strip()
            if s.startswith("|") and not _sep_re.match(s):
                # Collect consecutive pipe-table lines
                tbl: list[str] = []
                while i < len(raw_lines) and raw_lines[i].strip().startswith("|"):
                    tbl.append(raw_lines[i])
                    i += 1
                tb = _parse_md_table(tbl)
                if tb and tb.headers:
                    tables.append(tb)
                continue
            elif not _sep_re.match(s):
                # Skip pure separator lines; keep everything else as narrative
                narrative_lines.append(line)
            i += 1
        return SectionBlock(title, "\n".join(narrative_lines).strip(), tables)

    sections: list[SectionBlock] = []
    current_title: str | None = None
    current_lines: list[str] = []

    for line in text.splitlines():
        s = line.strip()
        # Treat ## and ### as section boundaries; # is document title (skip)
        if s.startswith("## ") or s.startswith("### "):
            if current_title is not None:
                sections.append(_flush(current_title, current_lines))
            prefix = "## " if s.startswith("## ") else "### "
            current_title = re.sub(r'^\d+\.\s+', '', s[len(prefix):]).strip()
            current_lines = []
        elif s.startswith("# "):
            # Top-level title — skip or use as document title only
            if current_title is not None:
                sections.append(_flush(current_title, current_lines))
            current_title = s[2:].strip()
            current_lines = []
        elif current_title is not None:
            current_lines.append(line)

    if current_title is not None:
        sections.append(_flush(current_title, current_lines))

    return sections


# ── PDF rendering components ───────────────────────────────────────────────────

def _rl_colors():
    """Return ReportLab Color objects for all brand/table colours."""
    from reportlab.lib.colors import Color
    return {
        "gold":        Color(GOLD[0]/255,       GOLD[1]/255,       GOLD[2]/255),
        "dark":        Color(DARK[0]/255,        DARK[1]/255,       DARK[2]/255),
        "text_sec":    Color(TEXT_SEC[0]/255,    TEXT_SEC[1]/255,   TEXT_SEC[2]/255),
        "text_muted":  Color(TEXT_MUTED[0]/255,  TEXT_MUTED[1]/255, TEXT_MUTED[2]/255),
        "red":         Color(RED[0]/255,         RED[1]/255,        RED[2]/255),
        "row_even":    Color(ROW_EVEN[0]/255,    ROW_EVEN[1]/255,   ROW_EVEN[2]/255),
        "row_total":   Color(ROW_TOTAL[0]/255,   ROW_TOTAL[1]/255,  ROW_TOTAL[2]/255),
        "header_bg":   Color(HEADER_BG[0]/255,   HEADER_BG[1]/255,  HEADER_BG[2]/255),
        "header_fg":   Color(HEADER_FG[0]/255,   HEADER_FG[1]/255,  HEADER_FG[2]/255),
        "tbl_outer":   Color(TABLE_OUTER[0]/255, TABLE_OUTER[1]/255, TABLE_OUTER[2]/255),
        "tbl_inner":   Color(TABLE_INNER[0]/255, TABLE_INNER[1]/255, TABLE_INNER[2]/255),
        "white":       Color(1, 1, 1),
    }


def _build_pdf_data_table(tb: TableBlock, content_width: float, c, styles):
    """
    Build a ReportLab Table from a TableBlock.
    Returns a list of flowables: [caption Paragraph, Table].
    """
    from reportlab.platypus import Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER

    col_count  = len(tb.headers)
    if col_count == 0:
        return []

    align_map  = {"left": TA_LEFT, "right": TA_RIGHT, "center": TA_CENTER}
    alignments = tb.alignments + ["left"] * col_count  # pad

    # Header row
    header_cells = [
        Paragraph(h, styles["tbl_header"]) for h in tb.headers
    ]

    # Data rows
    data_rows = []
    for i, (cells, is_total) in enumerate(tb.all_rows):
        # Pad / trim cells to column count
        padded = list(cells) + [""] * col_count
        padded = padded[:col_count]
        style  = styles["tbl_total"] if is_total else styles["tbl_body"]
        # Per-cell alignment
        row_cells = []
        for j, cell_text in enumerate(padded):
            align = alignments[j] if j < len(alignments) else "left"
            cell_style = ParagraphStyle_from_base(
                style, f"cell_{i}_{j}", alignment=align_map.get(align, TA_LEFT)
            )
            row_cells.append(Paragraph(cell_text, cell_style))
        data_rows.append(row_cells)

    table_data = [header_cells] + data_rows

    # Column widths: distribute proportionally, right-align numeric columns are narrower
    col_widths = _calc_col_widths(tb.headers, tb.alignments, content_width)

    tbl = Table(table_data, colWidths=col_widths, repeatRows=1)

    # Build table style commands
    cmd = [
        # Header row: dark background, white text
        ("BACKGROUND",  (0, 0), (-1, 0), c["header_bg"]),
        ("TEXTCOLOR",   (0, 0), (-1, 0), c["header_fg"]),
        # Outer border
        ("BOX",         (0, 0), (-1, -1), 1.2, c["tbl_outer"]),
        # Inner grid
        ("INNERGRID",   (0, 0), (-1, -1), 0.5, c["tbl_inner"]),
        # Padding
        ("TOPPADDING",  (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING",(0, 0), (-1, -1), 7),
        ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
        # Alternating row shading (skip header row 0)
    ]
    for i, (_, is_total) in enumerate(tb.all_rows):
        row_idx = i + 1  # +1 for header
        if is_total:
            cmd.append(("BACKGROUND", (0, row_idx), (-1, row_idx), c["row_total"]))
        elif i % 2 == 1:
            cmd.append(("BACKGROUND", (0, row_idx), (-1, row_idx), c["row_even"]))

    tbl.setStyle(TableStyle(cmd))

    elements = []
    if tb.caption:
        elements.append(Paragraph(tb.caption, styles["tbl_caption"]))
        elements.append(Spacer(1, 3))
    elements.append(tbl)
    elements.append(Spacer(1, 10))
    return elements


def ParagraphStyle_from_base(base_style, new_name: str, **kwargs):
    """Clone a ParagraphStyle with overrides."""
    from reportlab.lib.styles import ParagraphStyle
    new_style = ParagraphStyle(new_name, parent=base_style)
    for k, v in kwargs.items():
        setattr(new_style, k, v)
    return new_style


def _calc_col_widths(headers: list[str], alignments: list[str], total_width: float) -> list[float]:
    """
    Calculate proportional column widths.
    Right-aligned columns (numeric) get a smaller base weight.
    """
    weights = []
    for i, h in enumerate(headers):
        align = alignments[i] if i < len(alignments) else "left"
        # Estimate: right-aligned numeric columns are narrower
        base = 0.7 if align == "right" else 1.0
        # Weight by header text length too
        weights.append(base + len(h) * 0.02)
    total_weight = sum(weights) or 1
    return [total_width * w / total_weight for w in weights]


def _make_pdf_styles(c: dict):
    """Return all ParagraphStyle objects needed for the PDF."""
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_CENTER

    return {
        "brand":       ParagraphStyle("brand",       fontName="Helvetica-Bold",   fontSize=14, textColor=c["dark"],       leading=17),
        "sow_title":   ParagraphStyle("sow_title",   fontName="Helvetica-Bold",   fontSize=10, textColor=c["gold"],       leading=13, spaceAfter=4,  tracking=200),
        "confidential":ParagraphStyle("confidential",fontName="Helvetica-Bold",   fontSize=8,  textColor=c["red"],        leading=10, spaceAfter=12, tracking=150),
        "meta_label":  ParagraphStyle("meta_label",  fontName="Helvetica",        fontSize=9,  textColor=c["text_muted"], leading=12),
        "meta_value":  ParagraphStyle("meta_value",  fontName="Helvetica-Bold",   fontSize=9,  textColor=c["dark"],       leading=12),
        "h1":          ParagraphStyle("h1",          fontName="Helvetica-Bold",   fontSize=13, textColor=c["dark"],       leading=17, spaceBefore=20, spaceAfter=8,  leftIndent=10),
        "h2":          ParagraphStyle("h2",          fontName="Helvetica-Bold",   fontSize=11, textColor=c["text_sec"],   leading=14, spaceBefore=12, spaceAfter=5),
        "body":        ParagraphStyle("body",        fontName="Helvetica",        fontSize=10, textColor=c["dark"],       leading=15, spaceAfter=8),
        "tbl_header":  ParagraphStyle("tbl_header",  fontName="Helvetica-Bold",   fontSize=9,  textColor=c["header_fg"], leading=12),
        "tbl_body":    ParagraphStyle("tbl_body",    fontName="Helvetica",        fontSize=9,  textColor=c["dark"],       leading=12),
        "tbl_total":   ParagraphStyle("tbl_total",   fontName="Helvetica-Bold",   fontSize=9,  textColor=c["dark"],       leading=12),
        "tbl_caption": ParagraphStyle("tbl_caption", fontName="Helvetica-Oblique",fontSize=8.5,textColor=c["text_sec"],   leading=11, spaceBefore=6),
        "outstanding": ParagraphStyle("outstanding", fontName="Helvetica",        fontSize=9,  textColor=c["dark"],       leading=13, leftIndent=12, spaceAfter=4),
    }


def _generate_pdf(sow_text: str, meta: ExportRequest) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, KeepTogether
    )

    buffer     = io.BytesIO()
    page_w, page_h = A4
    margin     = 2.5 * cm
    content_w  = page_w - 2 * margin

    c       = _rl_colors()
    styles  = _make_pdf_styles(c)

    ref_id   = meta.report_ref or ("SOW-" + (meta.session_id[:8].upper() if meta.session_id else "00000000"))
    gen_date = datetime.now().strftime("%d %B %Y")
    gen_time = datetime.now().strftime("%H:%M")

    elements = []

    # ── Brand header ──
    elements.append(Paragraph(
        "Source <font color='#9A7B3F'><i>of</i></font> Wealth", styles["brand"]
    ))
    elements.append(Spacer(1, 6))
    elements.append(Paragraph("SOURCE OF WEALTH REPORT", styles["sow_title"]))
    elements.append(Paragraph("PRIVATE &amp; CONFIDENTIAL", styles["confidential"]))

    # ── Meta key-value table ──
    meta_rows = [
        ("Client",             meta.client_name or "—"),
        ("Date Generated",     gen_date),
        ("Reference ID",       ref_id),
        ("Profile Type",       meta.profile_type or "—"),
        ("Documents Analysed", str(meta.doc_count or 0)),
        ("Data Points Verified",str(meta.field_count or 0)),
    ]
    meta_data = [
        [Paragraph(lbl, styles["meta_label"]), Paragraph(val, styles["meta_value"])]
        for lbl, val in meta_rows
    ]
    meta_tbl = Table(meta_data, colWidths=[4.5 * cm, 11 * cm])
    meta_tbl.setStyle(TableStyle([
        ("VALIGN",        (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING",    (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LEFTPADDING",   (0, 0), (-1, -1), 0),
    ]))
    elements.append(meta_tbl)
    elements.append(Spacer(1, 12))

    # ── Gold divider ──
    elements.append(HRFlowable(
        width="100%", thickness=2, lineCap="round",
        color=c["gold"], spaceBefore=4, spaceAfter=20
    ))

    # ── Parse and render sections ──
    doc_tree = _parse_sow_document(sow_text)

    for section in doc_tree.sections:
        # Section heading with gold left border
        h1_tbl = Table(
            [[Paragraph(section.title, styles["h1"])]],
            colWidths=[content_w],
        )
        h1_tbl.setStyle(TableStyle([
            ("LEFTPADDING",  (0, 0), (-1, -1), 10),
            ("TOPPADDING",   (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING",(0, 0), (-1, -1), 4),
            ("LINEBEFORE",   (0, 0), (0, -1),  3, c["gold"]),
        ]))
        elements.append(h1_tbl)

        # Narrative prose (only if non-empty)
        if section.narrative:
            for para in section.narrative.split("\n\n"):
                para = para.strip()
                if para:
                    elements.append(Paragraph(para, styles["body"]))

        # Tables
        for tb in section.tables:
            tbl_elements = _build_pdf_data_table(tb, content_w, c, styles)
            if tbl_elements:
                elements.extend(tbl_elements)

    # ── Page template ──
    def _draw_page(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(HexColor("#E5E5E5"))
        canvas.setLineWidth(0.5)
        canvas.line(margin, page_h - margin + 10, page_w - margin, page_h - margin + 10)
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(HexColor("#999999"))
        canvas.drawString(margin, page_h - margin + 16, "SOURCE OF WEALTH")
        canvas.drawRightString(page_w - margin, page_h - margin + 16, gen_date)
        canvas.line(margin, margin - 8, page_w - margin, margin - 8)
        canvas.setFont("Helvetica-Oblique", 6.5)
        canvas.drawCentredString(
            page_w / 2, margin - 18,
            f"Generated by Source of Wealth Portal  \u00B7  {gen_date} {gen_time}  \u00B7  Reference: {ref_id}"
        )
        canvas.setFont("Helvetica", 7)
        canvas.drawString(margin, margin - 30, f"Page {doc.page}")
        canvas.drawRightString(page_w - margin, margin - 30, ref_id)
        # Watermark
        canvas.setFillColor(HexColor("#F0F0F0"))
        canvas.setFont("Helvetica-Bold", 54)
        canvas.saveState()
        canvas.translate(page_w / 2, page_h / 2)
        canvas.rotate(45)
        canvas.drawCentredString(0, 0, "CONFIDENTIAL")
        canvas.restoreState()
        canvas.restoreState()

    pdf_doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=margin, rightMargin=margin,
        topMargin=margin + 15, bottomMargin=margin + 10,
    )
    pdf_doc.build(elements, onFirstPage=_draw_page, onLaterPages=_draw_page)
    return buffer.getvalue()


# ── DOCX rendering ─────────────────────────────────────────────────────────────

def _generate_docx(sow_text: str, meta: ExportRequest) -> bytes:
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ROW_HEIGHT_RULE
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    document  = Document()
    ref_id    = meta.report_ref or ("SOW-" + (meta.session_id[:8].upper() if meta.session_id else "00000000"))
    gen_date  = datetime.now().strftime("%d %B %Y")
    gen_time  = datetime.now().strftime("%H:%M")

    style = document.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)
    style.font.color.rgb = RGBColor(*DARK)
    style.paragraph_format.space_after  = Pt(6)
    style.paragraph_format.line_spacing = 1.3

    for section in document.sections:
        section.top_margin = section.bottom_margin = section.left_margin = section.right_margin = Cm(2.5)
        hdr = section.header
        hdr.is_linked_to_previous = False
        hp = hdr.paragraphs[0] if hdr.paragraphs else hdr.add_paragraph()
        hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for txt, bold, italic, color in [
            ("Source ", True, False, DARK),
            ("of ",     False, True,  GOLD),
            ("Wealth",  True,  False, DARK),
        ]:
            r = hp.add_run(txt)
            r.font.size  = Pt(12)
            r.font.bold  = bold
            r.font.italic = italic
            r.font.color.rgb = RGBColor(*color)
        ftr = section.footer
        ftr.is_linked_to_previous = False
        fp = ftr.paragraphs[0] if ftr.paragraphs else ftr.add_paragraph()
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = fp.add_run("Page ")
        r.font.size = Pt(7)
        r.font.color.rgb = RGBColor(*TEXT_MUTED)
        fld = r._element.makeelement(qn("w:fldSimple"), {qn("w:instr"): "PAGE"})
        r._element.addnext(fld)
        r2 = fp.add_run(f"    {ref_id}")
        r2.font.size = Pt(7)
        r2.font.color.rgb = RGBColor(*TEXT_MUTED)

    # Title
    p = document.add_paragraph()
    r = p.add_run("SOURCE OF WEALTH REPORT")
    r.font.size = Pt(10); r.font.bold = True
    r.font.color.rgb = RGBColor(*GOLD)
    p.paragraph_format.space_after = Pt(2)

    p = document.add_paragraph()
    r = p.add_run("PRIVATE & CONFIDENTIAL")
    r.font.size = Pt(8); r.font.bold = True
    r.font.color.rgb = RGBColor(*RED)
    p.paragraph_format.space_after = Pt(12)

    # Meta table
    meta_rows_data = [
        ("Client",              meta.client_name or "—"),
        ("Date Generated",      gen_date),
        ("Reference ID",        ref_id),
        ("Profile Type",        meta.profile_type or "—"),
        ("Documents Analysed",  str(meta.doc_count or 0)),
        ("Data Points Verified",str(meta.field_count or 0)),
    ]
    meta_tbl = document.add_table(rows=len(meta_rows_data), cols=2)
    meta_tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
    for i, (lbl, val) in enumerate(meta_rows_data):
        cl = meta_tbl.cell(i, 0); cr = meta_tbl.cell(i, 1)
        cl.width = Cm(4.5)
        pl = cl.paragraphs[0]; pr = cr.paragraphs[0]
        rl = pl.add_run(lbl); rl.font.size = Pt(9); rl.font.color.rgb = RGBColor(*TEXT_MUTED)
        rr = pr.add_run(val);  rr.font.size = Pt(9); rr.font.bold = True; rr.font.color.rgb = RGBColor(*DARK)
    _remove_tbl_borders(meta_tbl, qn)

    document.add_paragraph()
    _add_gold_divider(document, qn)

    # Sections
    doc_tree = _parse_sow_document(sow_text)
    for section in doc_tree.sections:
        # Section heading with gold left border
        p = document.add_paragraph()
        p.paragraph_format.space_before = Pt(16)
        p.paragraph_format.space_after  = Pt(6)
        pPr = p._element.get_or_add_pPr()
        pBdr = pPr.makeelement(qn("w:pBdr"), {})
        left = pBdr.makeelement(qn("w:left"), {
            qn("w:val"): "single", qn("w:sz"): "18",
            qn("w:space"): "6",   qn("w:color"): "9A7B3F",
        })
        pBdr.append(left); pPr.append(pBdr)
        r = p.add_run(section.title)
        r.font.size = Pt(13); r.font.bold = True; r.font.color.rgb = RGBColor(*DARK)

        # Narrative
        if section.narrative:
            for para in section.narrative.split("\n\n"):
                para = para.strip()
                if para:
                    p = document.add_paragraph()
                    r = p.add_run(para)
                    r.font.size = Pt(10); r.font.color.rgb = RGBColor(*DARK)

        # Tables
        for tb in section.tables:
            if tb.caption:
                p = document.add_paragraph()
                r = p.add_run(tb.caption)
                r.font.size = Pt(8.5); r.font.italic = True; r.font.color.rgb = RGBColor(*TEXT_SEC)
                p.paragraph_format.space_before = Pt(6)

            col_count = len(tb.headers)
            if col_count == 0:
                continue
            all_rows = tb.all_rows
            tbl = document.add_table(rows=1 + len(all_rows), cols=col_count)
            tbl.alignment = WD_TABLE_ALIGNMENT.LEFT

            # Header row
            hdr_row = tbl.rows[0]
            for j, hdr_text in enumerate(tb.headers):
                cell = hdr_row.cells[j]
                cell._tc.get_or_add_tcPr()
                _set_cell_bg(cell, "1A1A1A", qn)
                p = cell.paragraphs[0]
                r = p.add_run(hdr_text)
                r.font.size = Pt(9); r.font.bold = True; r.font.color.rgb = RGBColor(255,255,255)
                align = tb.alignments[j] if j < len(tb.alignments) else "left"
                p.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                               "right": WD_ALIGN_PARAGRAPH.RIGHT,
                               "center": WD_ALIGN_PARAGRAPH.CENTER}.get(align, WD_ALIGN_PARAGRAPH.LEFT)

            # Data rows
            for i, (cells, is_total) in enumerate(all_rows):
                row = tbl.rows[i + 1]
                bg_hex = "E6E1D6" if is_total else ("F8F8F7" if i % 2 == 1 else "FFFFFF")
                padded = list(cells) + [""] * col_count
                padded = padded[:col_count]
                for j, cell_text in enumerate(padded):
                    cell = row.cells[j]
                    _set_cell_bg(cell, bg_hex, qn)
                    p = cell.paragraphs[0]
                    r = p.add_run(cell_text)
                    r.font.size = Pt(9)
                    r.font.bold = is_total
                    r.font.color.rgb = RGBColor(*DARK)
                    align = tb.alignments[j] if j < len(tb.alignments) else "left"
                    p.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                                   "right": WD_ALIGN_PARAGRAPH.RIGHT,
                                   "center": WD_ALIGN_PARAGRAPH.CENTER}.get(align, WD_ALIGN_PARAGRAPH.LEFT)

            _style_tbl_borders(tbl, qn)
            document.add_paragraph()

    # Footer note
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(f"Generated by Source of Wealth Portal · {gen_date} {gen_time} · Reference: {ref_id}")
    r.font.size = Pt(7.5); r.font.italic = True; r.font.color.rgb = RGBColor(*TEXT_MUTED)

    buf = io.BytesIO()
    document.save(buf)
    return buf.getvalue()


def _remove_tbl_borders(tbl, qn):
    for row in tbl.rows:
        for cell in row.cells:
            tc   = cell._tc
            tcPr = tc.get_or_add_tcPr()
            tBdr = tcPr.makeelement(qn("w:tcBorders"), {})
            for name in ["top","left","bottom","right"]:
                b = tBdr.makeelement(qn(f"w:{name}"), {qn("w:val"):"none",qn("w:sz"):"0",qn("w:space"):"0"})
                tBdr.append(b)
            tcPr.append(tBdr)


def _add_gold_divider(document, qn):
    p   = document.add_paragraph()
    p.paragraph_format.space_before = p.paragraph_format.space_after = 8
    pPr = p._element.get_or_add_pPr()
    pBdr = pPr.makeelement(qn("w:pBdr"), {})
    b = pBdr.makeelement(qn("w:bottom"), {qn("w:val"):"single",qn("w:sz"):"12",qn("w:space"):"1",qn("w:color"):"9A7B3F"})
    pBdr.append(b); pPr.append(pBdr)


def _set_cell_bg(cell, hex_color: str, qn):
    from docx.oxml import OxmlElement
    tcPr = cell._tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_color)
    tcPr.append(shd)


def _style_tbl_borders(tbl, qn):
    from docx.oxml import OxmlElement
    tbl_element = tbl._tbl
    tbl_pr = tbl_element.find(qn("w:tblPr"))
    if tbl_pr is None:
        tbl_pr = OxmlElement("w:tblPr")
        tbl_element.insert(0, tbl_pr)
    tbl_borders = OxmlElement("w:tblBorders")
    for name, color, sz in [
        ("top",    "B4AA96", "12"),
        ("bottom", "B4AA96", "12"),
        ("left",   "B4AA96", "12"),
        ("right",  "B4AA96", "12"),
        ("insideH","DCD7CD",  "4"),
        ("insideV","DCD7CD",  "4"),
    ]:
        b = OxmlElement(f"w:{name}")
        b.set(qn("w:val"),   "single")
        b.set(qn("w:sz"),    sz)
        b.set(qn("w:space"), "0")
        b.set(qn("w:color"), color)
        tbl_borders.append(b)
    tbl_pr.append(tbl_borders)


# ── Endpoint ───────────────────────────────────────────────────────────────────

@router.post("/export/{format}")
async def export_document(format: str, body: ExportRequest):
    from routers.upload import session_states
    if format not in ("pdf", "docx"):
        raise HTTPException(400, f"Unsupported format: {format}. Use 'pdf' or 'docx'.")

    # Use inline sow_text if provided (mock mode bypass — no session lookup needed)
    if body.sow_text:
        sow_text = body.sow_text
    else:
        state = session_states.get(body.session_id)
        if state is None:
            raise HTTPException(404, f"Session {body.session_id} not found.")
        if state.get("generation_id") != body.generation_id:
            raise HTTPException(400, "Generation ID does not match session state.")
        sow_text = state.get("generation_result")
        if not sow_text:
            raise HTTPException(400, "No generated SOW text found. Run generation first.")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # Use custom report_ref for filename if provided, otherwise fall back to session ID
    ref_short = body.report_ref or (body.session_id[:8] if body.session_id else "report")
    safe_ref  = ref_short.replace(" ", "_").replace("/", "-")

    if format == "pdf":
        content = _generate_pdf(sow_text, body)
        return StreamingResponse(io.BytesIO(content), media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="SOW_{safe_ref}_{timestamp}.pdf"'})
    else:
        content = _generate_docx(sow_text, body)
        return StreamingResponse(io.BytesIO(content),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f'attachment; filename="SOW_{safe_ref}_{timestamp}.docx"'})
