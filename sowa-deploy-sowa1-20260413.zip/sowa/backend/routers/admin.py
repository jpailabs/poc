"""
Admin Console API — user management endpoints.
All routes require admin authentication via X-Admin-Token header.

Endpoints:
  POST   /api/admin/login             → get admin token
  GET    /api/admin/users             → list all allowed users
  POST   /api/admin/users             → add a user
  DELETE /api/admin/users/{username}  → remove a user
  GET    /api/admin/users/{username}  → get user details
  GET    /api/admin/audit             → audit log
  GET    /api/admin/health            → system health check
"""
from __future__ import annotations

import hashlib
import os
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel

router = APIRouter(prefix="/api/admin", tags=["Admin"])

# ── Admin auth ────────────────────────────────────────────────────────────

def _load_auth_config() -> dict:
    """Load AUTH config section from config.yaml."""
    try:
        from services.config_loader import load_config
        return load_config().get("AUTH", {})
    except Exception:
        return {}


def _verify_admin(x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token")) -> str:
    """Dependency — validates admin token in header."""
    if not x_admin_token:
        raise HTTPException(401, "Missing X-Admin-Token header")
    # Compare against stored admin token (set at login)
    import auth.session_manager as sm
    session = sm.validate_session(x_admin_token)
    if not session or session.get("role") != "admin":
        raise HTTPException(403, "Invalid or expired admin token")
    return session["username"]


# ── Request/Response models ────────────────────────────────────────────────

class AdminLoginRequest(BaseModel):
    username: str
    password: str


class AddUserRequest(BaseModel):
    username: str
    display_name: str = ""
    email: str = ""


class AdminLoginResponse(BaseModel):
    token: str
    expires_in: int = 28800  # 8 hours


# ── Endpoints ─────────────────────────────────────────────────────────────

@router.post("/login", response_model=AdminLoginResponse)
async def admin_login(body: AdminLoginRequest):
    """
    Admin login — verify against admin_username + admin_password_hash in config.
    Returns an admin session token to use in X-Admin-Token header.
    """
    auth_cfg = _load_auth_config()
    expected_user = auth_cfg.get("admin_username", os.environ.get("ADMIN_USERNAME", "admin"))
    expected_hash = auth_cfg.get("admin_password_hash", os.environ.get("ADMIN_PASSWORD_HASH", ""))

    # Support plain password via env for initial setup
    plain_password = os.environ.get("ADMIN_PASSWORD", "")

    if body.username != expected_user:
        raise HTTPException(401, "Invalid admin credentials")

    # Check hashed password
    input_hash = hashlib.sha256(body.password.encode()).hexdigest()
    if expected_hash and input_hash != expected_hash:
        raise HTTPException(401, "Invalid admin credentials")
    elif not expected_hash and plain_password and body.password != plain_password:
        raise HTTPException(401, "Invalid admin credentials")
    elif not expected_hash and not plain_password:
        raise HTTPException(500, "Admin password not configured. Set ADMIN_PASSWORD env var.")

    import auth.session_manager as sm
    token = sm.create_session(
        username=body.username,
        display_name="Administrator",
        email="",
        role="admin",
    )
    return AdminLoginResponse(token=token)


@router.get("/users")
async def list_users(
    include_inactive: bool = False,
    admin: str = Depends(_verify_admin),
):
    """List all users in the allowlist."""
    from auth.user_store import list_users
    users = list_users(include_inactive=include_inactive)
    return {"users": users, "count": len(users)}


@router.post("/users", status_code=201)
async def add_user(
    body: AddUserRequest,
    admin: str = Depends(_verify_admin),
):
    """Add a user to the allowlist. Existing inactive users are re-activated."""
    from auth.user_store import add_user
    user = add_user(
        username=body.username,
        display_name=body.display_name,
        email=body.email,
        added_by=admin,
    )
    return {"message": f"User '{body.username}' added successfully", "user": user}


@router.delete("/users/{username}")
async def remove_user(
    username: str,
    admin: str = Depends(_verify_admin),
):
    """Remove a user from the allowlist (soft-delete, sets active=0)."""
    from auth.user_store import remove_user
    removed = remove_user(username=username, removed_by=admin)
    if not removed:
        raise HTTPException(404, f"User '{username}' not found")
    return {"message": f"User '{username}' removed successfully"}


@router.get("/users/{username}")
async def get_user(
    username: str,
    admin: str = Depends(_verify_admin),
):
    """Get details for a specific user."""
    from auth.user_store import get_user
    user = get_user(username)
    if not user:
        raise HTTPException(404, f"User '{username}' not found")
    return user


@router.get("/audit")
async def audit_log(
    limit: int = 100,
    admin: str = Depends(_verify_admin),
):
    """Retrieve audit log of admin actions."""
    from auth.user_store import get_audit_log
    return {"log": get_audit_log(limit=limit)}


@router.get("/health")
async def health(admin: str = Depends(_verify_admin)):
    """System health check — provider status, DB, session count."""
    import auth.session_manager as sm
    from auth.user_store import list_users

    try:
        # Force-read PROVIDER_MODE directly from config.yaml (bypasses all caches).
        # This ensures the health endpoint always reflects the last-saved value,
        # even across module reloads or multiple worker processes.
        from pathlib import Path
        import yaml as _yaml
        _cfg_path = Path(__file__).resolve().parent.parent / "config" / "config.yaml"
        with open(_cfg_path, encoding="utf-8") as _f:
            _cfg = _yaml.safe_load(_f) or {}
        provider_mode = str(_cfg.get("PROVIDER_MODE", "anthropic")).lower()
    except Exception:
        provider_mode = "anthropic"

    # Only surface services relevant to the active provider mode.
    # private = all five self-hosted endpoints; all other modes use only llm (+ vision for some).
    SERVICES_BY_MODE: dict[str, list[str]] = {
        "anthropic":    ["llm", "vision"],
        "openai":       ["llm", "vision", "embedding"],
        "azure_openai": ["llm", "vision", "embedding"],
        "ollama":       ["llm", "vision", "embedding"],
        "bedrock":      ["llm"],
        "vertex":       ["llm"],
        "private":      ["llm", "vision", "embedding", "reranker", "ocr"],
    }
    relevant = SERVICES_BY_MODE.get(provider_mode, ["llm"])

    # Canonical display names — sent to frontend, never raw backend keys
    DISPLAY_NAMES: dict[str, str] = {
        "llm":       "LLM",
        "vision":    "VLM",
        "embedding": "Vectorisation",
        "reranker":  "Reranker",
        "ocr":       "OCR",
    }

    try:
        from providers.provider_factory import get_registry
        registry = get_registry()
        all_providers = {
            "llm":       registry.llm       is not None,
            "vision":    registry.vision    is not None,
            "embedding": registry.embedding is not None,
            "reranker":  registry.reranker  is not None,
            "ocr":       registry.ocr       is not None,
        }
    except Exception:
        all_providers = {k: False for k in ["llm", "vision", "embedding", "reranker", "ocr"]}

    # Filter to only relevant services and use canonical display names as keys
    providers = {
        DISPLAY_NAMES.get(svc, svc): all_providers.get(svc, False)
        for svc in relevant
        if svc in all_providers
    }

    # Derive system status from relevant services only
    all_ready = all(v for v in providers.values())
    any_missing = any(not v for v in providers.values())
    status = "ok" if all_ready else ("degraded" if any_missing else "error")

    return {
        "status": status,
        "timestamp": datetime.utcnow().isoformat(),
        "provider_mode": provider_mode,
        "providers": providers,
        "active_users": len(list_users()),
    }
