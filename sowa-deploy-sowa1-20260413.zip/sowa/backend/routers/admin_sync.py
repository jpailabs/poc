"""
Admin Sync Router — WebSocket sync + file manager + audit log endpoints.

Endpoints:
  WS   /admin/ws/sync                     → WebSocket for real-time file change events
  GET  /admin/api/sync/status             → watcher status + connected clients
  GET  /admin/api/sync/audit              → read audit_log.jsonl (filterable)
  GET  /admin/api/sync/file/yaml          → raw config.yaml text
  PUT  /admin/api/sync/file/yaml          → write raw config.yaml text
  GET  /admin/api/sync/file/env           → raw .env text
  PUT  /admin/api/sync/file/env           → write raw .env text
  POST /admin/api/sync/import             → upload .env or .yaml file
"""
from __future__ import annotations

import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Admin Sync"])

# Connected WebSocket clients (admin token → WebSocket)
_ws_clients: dict[str, WebSocket] = {}


def _admin_dep(x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token")) -> str:
    import auth.session_manager as sm
    if not x_admin_token:
        raise HTTPException(401, "Missing X-Admin-Token header")
    session = sm.validate_session(x_admin_token)
    if not session or session.get("role") != "admin":
        raise HTTPException(403, "Invalid or expired admin token")
    return session["username"]


# ── WebSocket ─────────────────────────────────────────────────────────────────

@router.websocket("/admin/ws/sync")
async def ws_sync(websocket: WebSocket):
    """
    WebSocket endpoint for real-time config/prompt file change notifications.
    Client must send admin token as first message: {"token": "<X-Admin-Token>"}
    """
    import auth.session_manager as sm
    from services.file_watcher import register_ws_callback, unregister_ws_callback

    await websocket.accept()

    # Authenticate via first message
    try:
        auth_msg = await websocket.receive_text()
        data = json.loads(auth_msg)
        token = data.get("token", "")
        session = sm.validate_session(token)
        if not session or session.get("role") != "admin":
            await websocket.send_text(json.dumps({"type": "error", "message": "Unauthorized"}))
            await websocket.close()
            return
        client_id = session["username"]
    except Exception:
        await websocket.close()
        return

    # Register callback to push messages to this client
    async def send_to_client(msg: str):
        try:
            await websocket.send_text(msg)
        except Exception:
            pass

    register_ws_callback(send_to_client)
    _ws_clients[client_id] = websocket
    await websocket.send_text(json.dumps({"type": "connected", "message": f"Watching config & prompt files"}))
    logger.info("Admin WS: client '%s' connected", client_id)

    try:
        while True:
            # Keep connection alive; client can send pings
            msg = await websocket.receive_text()
            if msg == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        logger.info("Admin WS: client '%s' disconnected", client_id)
    finally:
        unregister_ws_callback(send_to_client)
        _ws_clients.pop(client_id, None)


# ── Status ────────────────────────────────────────────────────────────────────

@router.get("/admin/api/sync/status")
async def sync_status(admin: str = Depends(_admin_dep)):
    from services.file_watcher import _watcher_started
    return {
        "watcher_running": _watcher_started,
        "connected_clients": list(_ws_clients.keys()),
        "client_count": len(_ws_clients),
    }


# ── Audit Log ─────────────────────────────────────────────────────────────────

@router.get("/admin/api/sync/audit")
async def read_audit(
    limit: int = 100,
    offset: int = 0,
    action: Optional[str] = None,
    section: Optional[str] = None,
    changed_by: Optional[str] = None,
    admin: str = Depends(_admin_dep),
):
    from services.audit_logger import read, count
    entries = read(
        limit=limit, offset=offset,
        action_filter=action, section_filter=section,
        changed_by_filter=changed_by,
    )
    total = count()
    return {"entries": entries, "total": total, "limit": limit, "offset": offset}


# ── Raw file editor ───────────────────────────────────────────────────────────

@router.get("/admin/api/sync/file/yaml", response_class=PlainTextResponse)
async def get_raw_yaml(admin: str = Depends(_admin_dep)):
    from services.config_manager import get_config_manager
    return PlainTextResponse(get_config_manager().export_yaml(), media_type="text/plain")


class RawFileBody(BaseModel):
    content: str


@router.put("/admin/api/sync/file/yaml")
async def put_raw_yaml(body: RawFileBody, admin: str = Depends(_admin_dep)):
    """Write raw YAML text directly to config.yaml (validates YAML syntax first)."""
    import yaml as _yaml
    from services.config_manager import get_config_manager, _CONFIG_YAML_PATH
    from services.audit_logger import log

    try:
        parsed = _yaml.safe_load(body.content)
    except _yaml.YAMLError as e:
        raise HTTPException(422, f"Invalid YAML: {e}")

    mgr = get_config_manager()
    old_yaml = mgr.export_yaml()
    # Atomic write
    import tempfile, os
    from pathlib import Path
    cfg_path = Path(str(_CONFIG_YAML_PATH))
    tmp = cfg_path.with_suffix(".tmp")
    tmp.write_text(body.content, encoding="utf-8")
    tmp.replace(cfg_path)
    mgr.reload()
    log("raw_yaml_write", changed_by=admin, section="config.yaml")
    return {"ok": True, "message": "config.yaml updated and reloaded"}


@router.get("/admin/api/sync/file/env", response_class=PlainTextResponse)
async def get_raw_env(admin: str = Depends(_admin_dep)):
    from services.config_manager import get_config_manager
    return PlainTextResponse(get_config_manager().export_env(), media_type="text/plain")


@router.put("/admin/api/sync/file/env")
async def put_raw_env(body: RawFileBody, admin: str = Depends(_admin_dep)):
    """Parse and write raw .env text."""
    from services.config_manager import get_config_manager
    from services.audit_logger import log

    # Parse the raw env text
    new_env: dict[str, str] = {}
    for line in body.content.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, _, v = line.partition("=")
            new_env[k.strip()] = v.strip()

    mgr = get_config_manager()
    diff = mgr.update_env(new_env, changed_by=admin)
    log("raw_env_write", changed_by=admin, section=".env", details={"changed_keys": len(diff)})
    return {"ok": True, "changed_keys": len(diff)}


# ── Import ────────────────────────────────────────────────────────────────────

@router.post("/admin/api/sync/import")
async def import_config_file(
    file: UploadFile = File(...),
    admin: str = Depends(_admin_dep),
):
    """Import an uploaded .env or .yaml config file, replacing the existing one."""
    import yaml as _yaml
    from services.config_manager import get_config_manager
    from services.audit_logger import log

    content = (await file.read()).decode("utf-8")
    filename = file.filename or ""

    if filename.endswith(".yaml") or filename.endswith(".yml"):
        try:
            _yaml.safe_load(content)
        except _yaml.YAMLError as e:
            raise HTTPException(422, f"Invalid YAML: {e}")
        from services.config_manager import _CONFIG_YAML_PATH
        from pathlib import Path
        cfg_path = Path(str(_CONFIG_YAML_PATH))
        tmp = cfg_path.with_suffix(".tmp")
        tmp.write_text(content, encoding="utf-8")
        tmp.replace(cfg_path)
        get_config_manager().reload()
        log("config_import", changed_by=admin, section="config.yaml", details={"filename": filename})
        return {"ok": True, "type": "yaml", "message": f"Imported {filename} as config.yaml"}

    elif filename.endswith(".env") or filename == ".env":
        new_env = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                k, _, v = line.partition("=")
                new_env[k.strip()] = v.strip()
        get_config_manager().update_env(new_env, changed_by=admin)
        log("env_import", changed_by=admin, section=".env", details={"filename": filename, "keys": len(new_env)})
        return {"ok": True, "type": "env", "keys_imported": len(new_env)}

    raise HTTPException(400, "File must be .yaml, .yml, or .env")
