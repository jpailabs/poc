"""
Upload router — file upload and session status tracking.
"""

from __future__ import annotations

import os
from utils.paths import get_sessions_root, get_session_dir
import uuid
from typing import Any, Dict, List

from typing import Optional

from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/api/v1", tags=["Upload"])

# In-memory session state tracking (shared across routers via import)
session_states: Dict[str, Dict[str, Any]] = {}


def _category_hint(filename: str) -> str:
    """Guess document category from filename."""
    name = filename.lower()
    if "noa" in name or "notice" in name or "assessment" in name:
        return "noa"
    elif "payslip" in name or "pay_slip" in name or "salary" in name:
        return "payslip"
    elif "summary" in name or "sow" in name:
        return "summary"
    elif "bank" in name or "statement" in name:
        return "bank_statement"
    elif "business" in name or "acra" in name:
        return "business_registration"
    elif "tax" in name:
        return "tax_return"
    elif "property" in name or "deed" in name:
        return "property"
    elif "investment" in name or "portfolio" in name:
        return "investment"
    else:
        return "other"


@router.post("/upload")
async def upload_files(
    files: List[UploadFile] = File(...),
    profile_type: str = Form(...),
    file_metadata: Optional[str] = Form(None),
):
    """
    Accept multipart file uploads. Saves files to /tmp/sow_sessions/{session_id}/
    and returns metadata about each uploaded file.
    """
    session_id = str(uuid.uuid4())
    session_dir = get_session_dir(session_id)
    os.makedirs(session_dir, exist_ok=True)

    # Parse per-file category metadata from frontend
    doc_categories: dict[str, str] = {}
    if file_metadata:
        try:
            import json as _json
            meta_list = _json.loads(file_metadata)
            for item in meta_list:
                fname = item.get("filename", "")
                cat_id = item.get("category_id", "")
                if fname and cat_id:
                    doc_categories[fname] = cat_id
        except Exception:
            pass

    uploaded_files = []

    for upload_file in files:
        file_id = str(uuid.uuid4())
        filename = upload_file.filename or f"unnamed_{file_id}"
        file_path = os.path.join(session_dir, filename)

        content = await upload_file.read()
        with open(file_path, "wb") as f:
            f.write(content)

        size_kb = round(len(content) / 1024, 2)
        pages = None

        # Count pages for PDFs using PyMuPDF
        if filename.lower().endswith(".pdf"):
            try:
                import fitz  # PyMuPDF

                doc = fitz.open(file_path)
                pages = len(doc)
                doc.close()
            except Exception:
                pages = None

        uploaded_files.append(
            {
                "file_id": file_id,
                "filename": filename,
                "pages": pages,
                "size_kb": size_kb,
                "category_hint": _category_hint(filename),
            }
        )

    # Track session state
    session_states[session_id] = {
        "status": "uploaded",
        "profile_type": profile_type,
        "files": uploaded_files,
        "files_count": len(uploaded_files),
        "extraction_id": None,
        "extraction_result": None,
        "generation_id": None,
        "generation_result": None,
        "doc_categories": doc_categories,
    }

    return {"session_id": session_id, "uploaded_files": uploaded_files}


@router.get("/session/{session_id}/status")
async def get_session_status(session_id: str):
    """
    Return current pipeline state for a session (for reconnection).
    """
    state = session_states.get(session_id)

    if state is None:
        # Check if directory exists on disk even if not in memory
        session_dir = get_session_dir(session_id)
        if os.path.isdir(session_dir):
            files_count = len(
                [
                    f
                    for f in os.listdir(session_dir)
                    if os.path.isfile(os.path.join(session_dir, f))
                ]
            )
            return {
                "session_id": session_id,
                "status": "uploaded",
                "files_count": files_count,
                "extraction_id": None,
                "generation_id": None,
            }
        raise HTTPException(404, f"Session {session_id} not found.")

    return {
        "session_id": session_id,
        "status": state["status"],
        "files_count": state["files_count"],
        "extraction_id": state.get("extraction_id"),
        "generation_id": state.get("generation_id"),
    }


@router.get("/session/{session_id}/file/{filename}")
async def serve_session_file(session_id: str, filename: str):
    """Serve an uploaded file so the frontend preview panel can display it."""
    import urllib.parse
    from fastapi.responses import FileResponse
    from utils.paths import get_session_dir

    safe_name = os.path.basename(urllib.parse.unquote(filename))
    file_path = os.path.join(get_session_dir(session_id), safe_name)

    if not os.path.isfile(file_path):
        raise HTTPException(404, f"File '{safe_name}' not found in session.")

    # Determine media type so the browser renders it inline
    ext = safe_name.lower().rsplit(".", 1)[-1] if "." in safe_name else ""
    media_map = {
        "pdf": "application/pdf",
        "png": "image/png",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "gif": "image/gif",
        "webp": "image/webp",
    }
    media_type = media_map.get(ext, "application/octet-stream")

    return FileResponse(file_path, media_type=media_type,
                        headers={"Content-Disposition": "inline"})


@router.delete("/session/{session_id}")
async def cancel_session(session_id: str):
    """
    Cancel and clean up a session — stops any in-progress work,
    removes uploaded files, and clears session state.
    """
    import shutil

    # Remove from in-memory state
    session_states.pop(session_id, None)

    # Remove files from disk
    session_dir = get_session_dir(session_id)
    if os.path.isdir(session_dir):
        shutil.rmtree(session_dir, ignore_errors=True)

    return {"detail": f"Session {session_id} cancelled and cleaned up."}
