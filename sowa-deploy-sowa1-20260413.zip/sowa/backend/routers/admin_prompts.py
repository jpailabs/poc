"""
Admin Prompts Router — CRUD + versioning for prompt management.

All routes require X-Admin-Token.

Endpoints:
  GET    /admin/api/prompts                         → list all prompts
  GET    /admin/api/prompts/{key}                   → get prompt content + meta
  PUT    /admin/api/prompts/{key}                   → save prompt content
  POST   /admin/api/prompts                         → create new prompt
  DELETE /admin/api/prompts/{key}                   → delete prompt
  GET    /admin/api/prompts/{key}/versions          → list version history
  GET    /admin/api/prompts/{key}/versions/{v}      → get specific version content
  POST   /admin/api/prompts/{key}/restore/{v}       → restore a version
  POST   /admin/api/prompts/{key}/test              → test interpolation with variables
"""
from __future__ import annotations

from typing import Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel

router = APIRouter(prefix="/admin/api/prompts", tags=["Admin Prompts"])


def _admin_dep(x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token")) -> str:
    import auth.session_manager as sm
    if not x_admin_token:
        raise HTTPException(401, "Missing X-Admin-Token header")
    session = sm.validate_session(x_admin_token)
    if not session or session.get("role") != "admin":
        raise HTTPException(403, "Invalid or expired admin token")
    return session["username"]


class SavePromptRequest(BaseModel):
    content: str


class CreatePromptRequest(BaseModel):
    key: str
    filename: str
    description: str
    variables: List[str] = []
    content: str = ""


class TestPromptRequest(BaseModel):
    variables: Dict[str, str] = {}


@router.get("")
async def list_prompts(admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    prompts = get_prompt_manager().list_all()
    return {"prompts": prompts, "count": len(prompts)}


@router.get("/{key}")
async def get_prompt(key: str, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    try:
        text, meta = get_prompt_manager().get_raw(key)
        return {"key": key, "content": text, "meta": meta}
    except KeyError:
        raise HTTPException(404, f"Prompt '{key}' not found")


@router.put("/{key}")
async def save_prompt(key: str, body: SavePromptRequest, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    from services.audit_logger import log
    try:
        result = get_prompt_manager().save(key, body.content, changed_by=admin)
        log("prompt_save", changed_by=admin, section="prompts", key=key,
            details={"version": result["version"], "diff_lines": result["diff_lines"]})
        return {"ok": True, "key": key, "version": result["version"], "diff_lines": result["diff_lines"]}
    except KeyError:
        raise HTTPException(404, f"Prompt '{key}' not found")


@router.post("")
async def create_prompt(body: CreatePromptRequest, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    from services.audit_logger import log
    try:
        meta = get_prompt_manager().create(
            key=body.key, filename=body.filename,
            description=body.description, variables=body.variables,
            content=body.content, changed_by=admin,
        )
        log("prompt_create", changed_by=admin, section="prompts", key=body.key)
        return {"ok": True, "key": body.key, "meta": meta}
    except ValueError as e:
        raise HTTPException(409, str(e))


@router.delete("/{key}")
async def delete_prompt(key: str, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    from services.audit_logger import log
    deleted = get_prompt_manager().delete(key, changed_by=admin)
    if not deleted:
        raise HTTPException(404, f"Prompt '{key}' not found")
    log("prompt_delete", changed_by=admin, section="prompts", key=key)
    return {"ok": True, "deleted": key}


@router.get("/{key}/versions")
async def list_versions(key: str, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    try:
        versions = get_prompt_manager().get_versions(key)
        return {"key": key, "versions": versions}
    except KeyError:
        raise HTTPException(404, f"Prompt '{key}' not found")


@router.get("/{key}/versions/{version}")
async def get_version(key: str, version: int, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    try:
        content = get_prompt_manager().get_version_content(key, version)
        return {"key": key, "version": version, "content": content}
    except (KeyError, FileNotFoundError) as e:
        raise HTTPException(404, str(e))


@router.post("/{key}/restore/{version}")
async def restore_version(key: str, version: int, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    from services.audit_logger import log
    try:
        result = get_prompt_manager().restore_version(key, version, changed_by=admin)
        log("prompt_restore", changed_by=admin, section="prompts", key=key,
            details={"restored_version": version, "new_version": result["version"]})
        return {"ok": True, "key": key, "restored_from": version, "new_version": result["version"]}
    except (KeyError, FileNotFoundError) as e:
        raise HTTPException(404, str(e))


@router.post("/{key}/test")
async def test_prompt(key: str, body: TestPromptRequest, admin: str = Depends(_admin_dep)):
    from services.prompt_manager import get_prompt_manager
    try:
        rendered = get_prompt_manager().get(key, variables=body.variables)
        return {"key": key, "rendered": rendered, "variables_used": list(body.variables.keys())}
    except KeyError:
        raise HTTPException(404, f"Prompt '{key}' not found")
