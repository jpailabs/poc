"""
Auth API — login, logout, check session for the SOW portal frontend.

POST /auth/login    → authenticate user (SSO/AD/demo), return session token
POST /auth/logout   → invalidate session
GET  /auth/me       → get current user info from session token
"""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel

router = APIRouter(prefix="/auth", tags=["Auth"])


class LoginRequest(BaseModel):
    username: str
    password: str


class LoginResponse(BaseModel):
    token: str
    username: str
    display_name: str
    email: str
    role: str = "user"


@router.post("/login", response_model=LoginResponse)
async def login(body: LoginRequest):
    """
    Authenticate a user.
    1. Verify credentials against SSO provider (LDAP/Azure AD/OAuth2/demo)
    2. Check username is in the admin-approved allowlist
    3. Return session token
    """
    from services.config_loader import load_config
    from auth.sso_handler import SSOHandler
    from auth.user_store import is_allowed
    import auth.session_manager as sm

    config = load_config()
    auth_cfg = config.get("AUTH", {"provider": "demo"})

    handler = SSOHandler(auth_cfg)
    result = await handler.authenticate(body.username, body.password)

    if not result.success:
        raise HTTPException(401, result.error or "Authentication failed")

    # Check allowlist (skip for demo provider to allow initial setup)
    if auth_cfg.get("provider", "demo") != "demo":
        if not is_allowed(result.username):
            raise HTTPException(403, f"User '{result.username}' is not approved for access. Contact your administrator.")

    token = sm.create_session(
        username=result.username,
        display_name=result.display_name,
        email=result.email,
        role="user",
    )
    return LoginResponse(
        token=token,
        username=result.username,
        display_name=result.display_name,
        email=result.email,
    )


@router.post("/logout")
async def logout(x_session_token: Optional[str] = Header(None, alias="X-Session-Token")):
    """Invalidate the current session."""
    if x_session_token:
        import auth.session_manager as sm
        sm.invalidate_session(x_session_token)
    return {"message": "Logged out successfully"}


@router.get("/me")
async def me(x_session_token: Optional[str] = Header(None, alias="X-Session-Token")):
    """Return current user info from session token."""
    if not x_session_token:
        raise HTTPException(401, "Missing X-Session-Token header")
    import auth.session_manager as sm
    session = sm.validate_session(x_session_token)
    if not session:
        raise HTTPException(401, "Invalid or expired session")
    return {
        "username": session["username"],
        "display_name": session["display_name"],
        "email": session["email"],
        "role": session["role"],
    }
