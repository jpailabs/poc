"""
Admin Config Router — bi-directional config management via REST API.

All routes require X-Admin-Token header.

Endpoints:
  GET  /admin/api/config/yaml              → full config.yaml as JSON
  GET  /admin/api/config/yaml/{section}    → single section
  PUT  /admin/api/config/yaml/{section}    → update section, write to disk, hot-reload
  PUT  /admin/api/config/provider_mode     → update PROVIDER_MODE
  GET  /admin/api/config/env               → full .env as key-value JSON
  PUT  /admin/api/config/env               → update .env keys
  GET  /admin/api/config/export/yaml       → download config.yaml
  GET  /admin/api/config/export/env        → download .env
  POST /admin/api/config/reload            → force hot-reload from disk
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse

logger = logging.getLogger(__name__)
from pydantic import BaseModel
from typing import Any, Dict, Optional

router = APIRouter(prefix="/admin/api/config", tags=["Admin Config"])


def _verify_admin(x_admin_token: Optional[str] = None):
    from fastapi import Header
    return x_admin_token


from fastapi import Header


def _admin_dep(x_admin_token: Optional[str] = Header(None, alias="X-Admin-Token")) -> str:
    import auth.session_manager as sm
    if not x_admin_token:
        raise HTTPException(401, "Missing X-Admin-Token header")
    session = sm.validate_session(x_admin_token)
    if not session or session.get("role") != "admin":
        raise HTTPException(403, "Invalid or expired admin token")
    return session["username"]


class SectionUpdateRequest(BaseModel):
    values: Dict[str, Any]


class EnvUpdateRequest(BaseModel):
    values: Dict[str, str]


class ProviderModeRequest(BaseModel):
    mode: str


# ── YAML endpoints ────────────────────────────────────────────────────────────

@router.get("/yaml")
async def get_full_yaml(admin: str = Depends(_admin_dep)):
    """Return complete config.yaml as JSON."""
    from services.config_manager import get_config_manager
    return get_config_manager().get_yaml()


@router.get("/yaml/{section}")
async def get_yaml_section(section: str, admin: str = Depends(_admin_dep)):
    """Return a single top-level config.yaml section."""
    from services.config_manager import get_config_manager
    cfg = get_config_manager().get_yaml()
    if section == "PROVIDER_MODE":
        return {"PROVIDER_MODE": cfg.get("PROVIDER_MODE", "anthropic")}
    if section not in cfg:
        raise HTTPException(404, f"Section '{section}' not found in config.yaml")
    return {section: cfg[section]}


@router.put("/yaml/{section}")
async def update_yaml_section(
    section: str,
    body: SectionUpdateRequest,
    admin: str = Depends(_admin_dep),
):
    """Update a config.yaml section, write to disk, hot-reload in memory."""
    from services.config_manager import get_config_manager
    from services.audit_logger import log_diff
    from services.service_registry import reload_service_registry

    mgr = get_config_manager()
    diff = mgr.update_yaml_section(section, body.values, changed_by=admin)
    log_diff("config_update", diff, section=section, changed_by=admin)
    # Reload the service registry so new provider credentials take effect immediately
    try:
        reload_service_registry()
    except Exception as e:
        logger.warning("Service registry reload after config update failed: %s", e)
    return {"ok": True, "section": section, "diff": diff, "changed_keys": len(diff)}


@router.put("/provider_mode")
async def update_provider_mode(body: ProviderModeRequest, admin: str = Depends(_admin_dep)):
    from services.config_manager import get_config_manager
    from services.audit_logger import log
    from services.service_registry import reload_service_registry

    mgr = get_config_manager()
    old_mode = mgr.get_provider_mode()
    diff = mgr.update_provider_mode(body.mode, changed_by=admin)
    log("provider_mode_change", changed_by=admin, section="PROVIDER_MODE",
        key="PROVIDER_MODE", old_value=old_mode, new_value=body.mode)
    # Reload the service registry so the new provider mode is used immediately
    try:
        reload_service_registry()
    except Exception as e:
        logger.warning("Service registry reload after provider_mode change failed: %s", e)
    return {"ok": True, "provider_mode": body.mode, "diff": diff}


# ── .env endpoints ────────────────────────────────────────────────────────────

@router.get("/env")
async def get_env(admin: str = Depends(_admin_dep)):
    """Return .env as key-value JSON. Masks secrets."""
    from services.config_manager import get_config_manager
    env = get_config_manager().get_env()
    # Mask sensitive keys
    masked = {}
    for k, v in env.items():
        if any(s in k.upper() for s in ("KEY", "SECRET", "PASSWORD", "TOKEN", "PASS")):
            masked[k] = "••••••" if v else ""
        else:
            masked[k] = v
    return {"env": masked}


@router.get("/env/raw")
async def get_env_raw(admin: str = Depends(_admin_dep)):
    """Return .env as raw key-value (unmasked — use carefully)."""
    from services.config_manager import get_config_manager
    return {"env": get_config_manager().get_env()}


@router.put("/env")
async def update_env(body: EnvUpdateRequest, admin: str = Depends(_admin_dep)):
    """Update .env keys and reload."""
    from services.config_manager import get_config_manager
    from services.audit_logger import log_diff

    mgr = get_config_manager()
    # Mask values in audit log for secrets
    sanitised = {}
    for k, v in body.values.items():
        sanitised[k] = "••••••" if any(s in k.upper() for s in ("KEY", "SECRET", "PASSWORD", "TOKEN")) else v

    diff = mgr.update_env(body.values, changed_by=admin)
    # Log with masked values
    masked_diff = {k: {"old": "••••••" if any(s in k.upper() for s in ("KEY","SECRET","PASSWORD","TOKEN")) else v["old"],
                       "new": "••••••" if any(s in k.upper() for s in ("KEY","SECRET","PASSWORD","TOKEN")) else v["new"]}
                  for k, v in diff.items()}
    log_diff("env_update", masked_diff, section=".env", changed_by=admin)
    return {"ok": True, "diff": masked_diff, "changed_keys": len(diff)}


# ── Export endpoints ──────────────────────────────────────────────────────────

@router.get("/export/yaml", response_class=PlainTextResponse)
async def export_yaml(admin: str = Depends(_admin_dep)):
    """Download current config.yaml content."""
    from services.config_manager import get_config_manager
    content = get_config_manager().export_yaml()
    return PlainTextResponse(
        content=content,
        media_type="application/x-yaml",
        headers={"Content-Disposition": "attachment; filename=config.yaml"},
    )


@router.get("/export/env", response_class=PlainTextResponse)
async def export_env(admin: str = Depends(_admin_dep)):
    """Download current .env content."""
    from services.config_manager import get_config_manager
    content = get_config_manager().export_env()
    return PlainTextResponse(
        content=content,
        media_type="text/plain",
        headers={"Content-Disposition": "attachment; filename=.env"},
    )


# ── Reload ────────────────────────────────────────────────────────────────────

@router.post("/reload")
async def force_reload(admin: str = Depends(_admin_dep)):
    """Force hot-reload of config from disk."""
    from services.config_manager import get_config_manager
    from services.audit_logger import log
    get_config_manager().reload()
    log("config_reload", changed_by=admin, section="all")
    return {"ok": True, "message": "Config reloaded from disk"}


# ── Health check per service ───────────────────────────────────────────────

class HealthCheckRequest(BaseModel):
    service: str            # "llm" | "ocr" | "vlm" | "vectorisation" | "reranker"
    base_url: str
    api_key: str = "EMPTY"
    timeout: float = 10.0
    ssl_verify: bool = True
    ca_bundle_path: str = ""


@router.post("/health_check")
async def health_check_service(body: HealthCheckRequest, admin: str = Depends(_admin_dep)):
    """
    Test connectivity to a service endpoint before saving config.
    Tries GET {base_url}/v1/models (standard OpenAI health check endpoint).
    Returns status, latency_ms, and any error message.
    """
    import time
    import httpx as _httpx

    url = body.base_url.rstrip("/")
    if not url.endswith("/v1"):
        url = url + "/v1"
    url = url + "/models"

    headers = {}
    if body.api_key and body.api_key not in ("EMPTY", "none", "dummy", ""):
        headers["Authorization"] = f"Bearer {body.api_key}"

    verify: bool | str = True
    if body.ca_bundle_path:
        verify = body.ca_bundle_path
    elif not body.ssl_verify:
        verify = False

    start = time.monotonic()
    try:
        async with _httpx.AsyncClient(timeout=body.timeout, verify=verify) as client:
            resp = await client.get(url, headers=headers)
        latency_ms = round((time.monotonic() - start) * 1000)

        if resp.status_code in (200, 401, 403):
            # 401/403 means server is reachable but auth failed — endpoint is up
            reachable = True
            note = "OK" if resp.status_code == 200 else f"Reachable (HTTP {resp.status_code} — check api_key)"
        else:
            reachable = False
            note = f"HTTP {resp.status_code}"

        return {
            "ok": reachable,
            "service": body.service,
            "url": url,
            "status_code": resp.status_code,
            "latency_ms": latency_ms,
            "message": note,
        }
    except _httpx.ConnectError as e:
        latency_ms = round((time.monotonic() - start) * 1000)
        return {"ok": False, "service": body.service, "url": url, "latency_ms": latency_ms,
                "message": f"Connection refused: {e}"}
    except _httpx.TimeoutException:
        latency_ms = round((time.monotonic() - start) * 1000)
        return {"ok": False, "service": body.service, "url": url, "latency_ms": latency_ms,
                "message": f"Timeout after {body.timeout}s"}
    except Exception as e:
        latency_ms = round((time.monotonic() - start) * 1000)
        return {"ok": False, "service": body.service, "url": url, "latency_ms": latency_ms,
                "message": str(e)}


@router.get("/schema/{provider_mode}")
async def get_provider_schema(provider_mode: str, admin: str = Depends(_admin_dep)):
    """Return the config schema (field definitions) for a given provider mode."""
    schemas = {
        "private": {
            "services": ["llm", "ocr", "vlm", "vectorisation", "reranker"],
            "per_service_fields": [
                {"key": "base_url", "label": "Base URL", "type": "url", "required": True,
                 "placeholder": "http://localhost:8000/v1", "help": "OpenAI-compatible endpoint (include /v1 if needed)"},
                {"key": "api_key", "label": "API Key", "type": "password", "required": False,
                 "placeholder": "EMPTY", "help": "Use 'EMPTY' or 'none' if your vLLM server has no auth"},
                {"key": "model_name", "label": "Model Name", "type": "text", "required": True,
                 "placeholder": "mistral-7b-instruct", "help": "Model identifier as registered in the vLLM server"},
                {"key": "timeout", "label": "Timeout (s)", "type": "number", "required": False,
                 "default": 120, "help": "Request timeout in seconds"},
                {"key": "max_retries", "label": "Max Retries", "type": "number", "required": False,
                 "default": 3, "help": "Retry attempts on transient failures"},
            ],
            "has_ssl": True,
        },
        "openai": {
            "services": [],
            "fields": [
                {"key": "api_key", "label": "API Key", "type": "password", "required": True},
                {"key": "model_name", "label": "Model", "type": "text", "placeholder": "gpt-4o"},
                {"key": "vision_model", "label": "Vision Model", "type": "text", "placeholder": "gpt-4o"},
                {"key": "embedding_model", "label": "Embedding Model", "type": "text", "placeholder": "text-embedding-3-small"},
                {"key": "base_url", "label": "Base URL (override)", "type": "url", "required": False,
                 "placeholder": "https://api.openai.com"},
                {"key": "organization_id", "label": "Organization ID", "type": "text", "required": False},
                {"key": "temperature", "label": "Temperature", "type": "number", "default": 0.2},
                {"key": "max_tokens", "label": "Max Tokens", "type": "number", "default": 4096},
            ],
        },
        "anthropic": {
            "services": [],
            "fields": [
                {"key": "api_key", "label": "API Key", "type": "password", "required": True},
                {"key": "model_name", "label": "Model", "type": "text", "placeholder": "claude-sonnet-4-20250514"},
                {"key": "vision_model", "label": "Vision Model", "type": "text"},
                {"key": "temperature", "label": "Temperature", "type": "number", "default": 0.2},
                {"key": "max_tokens", "label": "Max Tokens", "type": "number", "default": 4096},
            ],
        },
        "azure_openai": {
            "services": [],
            "fields": [
                {"key": "endpoint", "label": "Endpoint URL", "type": "url", "required": True,
                 "placeholder": "https://YOUR-RESOURCE.openai.azure.com"},
                {"key": "api_key", "label": "API Key", "type": "password", "required": True},
                {"key": "api_version", "label": "API Version", "type": "text", "placeholder": "2024-02-01"},
                {"key": "deployment_name", "label": "Deployment Name", "type": "text", "placeholder": "gpt-4o"},
                {"key": "embedding_deployment", "label": "Embedding Deployment", "type": "text"},
                {"key": "temperature", "label": "Temperature", "type": "number", "default": 0.2},
                {"key": "max_tokens", "label": "Max Tokens", "type": "number", "default": 4096},
            ],
        },
        "ollama": {
            "services": [],
            "fields": [
                {"key": "base_url", "label": "Ollama URL", "type": "url", "required": True,
                 "placeholder": "http://localhost:11434"},
                {"key": "model_name", "label": "Model", "type": "text", "placeholder": "llama3.2-vision"},
                {"key": "embedding_model", "label": "Embedding Model", "type": "text", "placeholder": "nomic-embed-text"},
                {"key": "temperature", "label": "Temperature", "type": "number", "default": 0.2},
                {"key": "max_tokens", "label": "Max Tokens", "type": "number", "default": 4096},
            ],
        },
        "bedrock": {
            "services": [],
            "fields": [
                {"key": "base_url", "label": "Bedrock URL", "type": "url", "required": True},
                {"key": "api_key", "label": "AWS Access Key", "type": "password"},
                {"key": "model_name", "label": "Model ID", "type": "text",
                 "placeholder": "anthropic.claude-3-5-sonnet-20241022-v2:0"},
            ],
        },
        "vertex": {
            "services": [],
            "fields": [
                {"key": "base_url", "label": "Vertex URL", "type": "url", "required": True},
                {"key": "api_key", "label": "API Key", "type": "password"},
                {"key": "model_name", "label": "Model", "type": "text", "placeholder": "gemini-1.5-pro"},
            ],
        },
        "internal_vllm": {
            "services": [],
            "fields": [
                {"key": "base_url", "label": "LLM Base URL", "type": "url"},
                {"key": "model_name", "label": "LLM Model", "type": "text"},
                {"key": "api_key", "label": "API Key", "type": "password"},
            ],
        },
    }
    schema = schemas.get(provider_mode.lower())
    if not schema:
        raise HTTPException(404, f"No schema defined for provider_mode '{provider_mode}'")
    return {"provider_mode": provider_mode, "schema": schema}
