"""
PromptManager — file-backed prompt storage with versioning and variable interpolation.

Storage layout:
  backend/prompts_store/
    prompts_registry.json      — maps key → {filename, description, variables, version}
    ocr_extraction.txt
    field_extraction.txt
    sow_report.txt
    history/
      ocr_extraction_v1.txt
      ocr_extraction_v2.txt
      ...
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_BACKEND_DIR = Path(__file__).resolve().parent.parent
_STORE_DIR = _BACKEND_DIR / "prompts_store"
_REGISTRY_PATH = _STORE_DIR / "prompts_registry.json"
_HISTORY_DIR = _STORE_DIR / "history"
MAX_VERSIONS = 10


@dataclass
class PromptMeta:
    key: str
    filename: str
    description: str = ""
    variables: list[str] = field(default_factory=list)
    version: int = 1
    last_modified: str = ""
    created_at: str = ""


class PromptManager:
    """
    Thread-safe manager for prompt files.
    All prompts are plain .txt files with {variable} placeholders.
    """

    def __init__(self):
        self._lock = threading.Lock()
        _STORE_DIR.mkdir(parents=True, exist_ok=True)
        _HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        self._ensure_defaults()

    # ── Registry ──────────────────────────────────────────────────────────────

    def _load_registry(self) -> dict[str, dict]:
        if not _REGISTRY_PATH.exists():
            return {}
        with open(_REGISTRY_PATH, encoding="utf-8") as f:
            return json.load(f)

    def _save_registry(self, registry: dict) -> None:
        tmp = _REGISTRY_PATH.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(registry, f, indent=2)
        tmp.replace(_REGISTRY_PATH)

    # ── Defaults ──────────────────────────────────────────────────────────────

    def _ensure_defaults(self) -> None:
        """Seed the prompts_store with default prompts if empty."""
        registry = self._load_registry()
        defaults = {
            "ocr_extraction": {
                "filename": "ocr_extraction.txt",
                "description": "System prompt for OCR page text extraction via Vision model",
                "variables": [],
                "version": 1,
            },
            "ocr_user": {
                "filename": "ocr_user.txt",
                "description": "User prompt sent with each document page image for OCR",
                "variables": [],
                "version": 1,
            },
            "field_extraction": {
                "filename": "field_extraction.txt",
                "description": "System prompt for structured financial field extraction from OCR text",
                "variables": ["categories_list"],
                "version": 1,
            },
            "sow_report": {
                "filename": "sow_report.txt",
                "description": "System prompt for generating the Source of Wealth report narrative",
                "variables": [],
                "version": 1,
            },
        }
        default_contents = {
            "ocr_extraction.txt": (
                "You are a financial document OCR specialist. Extract ALL text from the provided "
                "document page image exactly as written. Preserve all numbers, dates, currencies, "
                "percentages, names, and labels with 100% fidelity. Output raw text only — "
                "no interpretation, no summary."
            ),
            "ocr_user.txt": (
                "Extract all text visible on this document page. Preserve every number, "
                "currency symbol, date format, and label exactly as printed."
            ),
            "field_extraction.txt": (
                "You are a senior financial analyst. Extract all key financial data points from "
                "the provided document text. Classify each under the correct category from: "
                "{categories_list}. Always return valid JSON matching the exact schema. "
                "Never invent data not present in the source text."
            ),
            "sow_report.txt": (
                "You are an experienced Relationship Manager at a private banking institution "
                "writing a Source of Wealth (SOW) report for KYC and compliance purposes. "
                "Write in formal, precise financial prose. Every factual claim must cite a "
                "source document. Do not invent, extrapolate, or assume any data not explicitly "
                "provided. Use Singapore financial regulatory context (MAS Notice SFA 04-N13)."
            ),
        }
        changed = False
        now = datetime.now(timezone.utc).isoformat()
        for key, meta in defaults.items():
            if key not in registry:
                registry[key] = {**meta, "last_modified": now, "created_at": now}
                changed = True
            fpath = _STORE_DIR / meta["filename"]
            if not fpath.exists():
                fpath.write_text(default_contents.get(meta["filename"], f"# Prompt: {key}\n"), encoding="utf-8")
        if changed:
            self._save_registry(registry)

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def list_all(self) -> list[dict]:
        with self._lock:
            registry = self._load_registry()
            result = []
            for key, meta in registry.items():
                fpath = _STORE_DIR / meta["filename"]
                entry = {"key": key, **meta, "exists": fpath.exists()}
                result.append(entry)
            return result

    def get(self, key: str, variables: dict | None = None) -> str:
        """
        Load prompt text, optionally interpolating {variable} placeholders.
        Raises KeyError if prompt key not found.
        """
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                raise KeyError(f"Prompt key '{key}' not found in registry.")
            fpath = _STORE_DIR / registry[key]["filename"]
            if not fpath.exists():
                raise FileNotFoundError(f"Prompt file {fpath} not found.")
            text = fpath.read_text(encoding="utf-8")

        if variables:
            for var_name, var_val in variables.items():
                text = text.replace(f"{{{var_name}}}", str(var_val))
        return text

    def get_raw(self, key: str) -> tuple[str, dict]:
        """Return (raw_text, meta) without interpolation."""
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                raise KeyError(f"Prompt key '{key}' not found.")
            meta = registry[key]
            fpath = _STORE_DIR / meta["filename"]
            text = fpath.read_text(encoding="utf-8") if fpath.exists() else ""
            return text, meta

    def save(self, key: str, content: str, changed_by: str = "admin") -> dict:
        """
        Save updated prompt content. Backs up the current version to history/.
        Returns {"version": N, "diff_lines": N}.
        """
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                raise KeyError(f"Prompt key '{key}' not found.")
            meta = registry[key]
            fpath = _STORE_DIR / meta["filename"]

            # Backup current version
            old_text = fpath.read_text(encoding="utf-8") if fpath.exists() else ""
            old_version = meta.get("version", 1)
            self._backup_version(key, meta["filename"], old_text, old_version)

            # Write new content atomically
            tmp = fpath.with_suffix(".tmp")
            tmp.write_text(content, encoding="utf-8")
            tmp.replace(fpath)

            # Update registry
            new_version = old_version + 1
            registry[key]["version"] = new_version
            registry[key]["last_modified"] = datetime.now(timezone.utc).isoformat()
            self._save_registry(registry)

            # Compute diff line count
            diff_lines = sum(1 for a, b in zip(old_text.splitlines(), content.splitlines()) if a != b)
            logger.info("PromptManager: saved prompt '%s' v%d by %s", key, new_version, changed_by)
            return {"version": new_version, "diff_lines": diff_lines, "old_text": old_text}

    def create(self, key: str, filename: str, description: str, variables: list[str], content: str = "", changed_by: str = "admin") -> dict:
        """Register a new prompt."""
        with self._lock:
            registry = self._load_registry()
            if key in registry:
                raise ValueError(f"Prompt key '{key}' already exists.")
            if not filename.endswith(".txt"):
                filename += ".txt"
            now = datetime.now(timezone.utc).isoformat()
            fpath = _STORE_DIR / filename
            fpath.write_text(content, encoding="utf-8")
            registry[key] = {
                "filename": filename,
                "description": description,
                "variables": variables,
                "version": 1,
                "last_modified": now,
                "created_at": now,
            }
            self._save_registry(registry)
            return registry[key]

    def delete(self, key: str, changed_by: str = "admin") -> bool:
        """Remove prompt from registry (moves file to history as backup)."""
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                return False
            meta = registry[key]
            fpath = _STORE_DIR / meta["filename"]
            if fpath.exists():
                backup = _HISTORY_DIR / f"_deleted_{key}_{meta['filename']}"
                shutil.move(str(fpath), str(backup))
            del registry[key]
            self._save_registry(registry)
            return True

    # ── Version history ───────────────────────────────────────────────────────

    def _backup_version(self, key: str, filename: str, content: str, version: int) -> None:
        """Save version snapshot to history/ dir, keeping only last MAX_VERSIONS."""
        stem = Path(filename).stem
        vpath = _HISTORY_DIR / f"{stem}_v{version}.txt"
        vpath.write_text(content, encoding="utf-8")
        # Prune old versions
        old_versions = sorted(_HISTORY_DIR.glob(f"{stem}_v*.txt"),
                              key=lambda p: int(p.stem.rsplit("_v", 1)[-1]))
        while len(old_versions) > MAX_VERSIONS:
            old_versions.pop(0).unlink(missing_ok=True)

    def get_versions(self, key: str) -> list[dict]:
        """Return list of available versions for a prompt key."""
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                raise KeyError(f"Prompt key '{key}' not found.")
            stem = Path(registry[key]["filename"]).stem
            versions = []
            for vfile in sorted(_HISTORY_DIR.glob(f"{stem}_v*.txt")):
                try:
                    v_num = int(vfile.stem.rsplit("_v", 1)[-1])
                    versions.append({
                        "version": v_num,
                        "filename": vfile.name,
                        "size": vfile.stat().st_size,
                        "modified": datetime.fromtimestamp(vfile.stat().st_mtime, tz=timezone.utc).isoformat(),
                    })
                except (ValueError, OSError):
                    continue
            return sorted(versions, key=lambda x: x["version"], reverse=True)

    def get_version_content(self, key: str, version: int) -> str:
        """Return content of a specific historical version."""
        with self._lock:
            registry = self._load_registry()
            if key not in registry:
                raise KeyError(f"Prompt key '{key}' not found.")
            stem = Path(registry[key]["filename"]).stem
            vpath = _HISTORY_DIR / f"{stem}_v{version}.txt"
            if not vpath.exists():
                raise FileNotFoundError(f"Version {version} not found for prompt '{key}'.")
            return vpath.read_text(encoding="utf-8")

    def restore_version(self, key: str, version: int, changed_by: str = "admin") -> dict:
        """Restore a historical version as the current content."""
        old_content = self.get_version_content(key, version)
        return self.save(key, old_content, changed_by=changed_by)

    def reload(self, key: str) -> str:
        """Force re-read of prompt file from disk (bypasses any future caching)."""
        text, _ = self.get_raw(key)
        return text


# Module-level singleton
_prompt_manager: PromptManager | None = None


def get_prompt_manager() -> PromptManager:
    global _prompt_manager
    if _prompt_manager is None:
        _prompt_manager = PromptManager()
    return _prompt_manager
