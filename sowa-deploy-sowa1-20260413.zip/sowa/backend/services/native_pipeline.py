"""
Pipeline B — Native Foundation Model Pipeline (5 Stages)

For provider_mode = openai, anthropic, bedrock, azure_openai, ollama, vertex.
The configured foundation model handles text + vision natively in one call per page.
Output schema is identical to PrivatePipeline so downstream components work unchanged.
"""
from __future__ import annotations

import base64
import json
import logging
import re
import uuid
from pathlib import Path
from typing import AsyncGenerator

logger = logging.getLogger(__name__)

NATIVE_TEXT_MIN_CHARS = 80


class NativePipeline:
    """5-stage foundation model pipeline for all non-private provider modes."""

    def __init__(self, session_id: str, job_id: str, provider_mode: str, profile_type: str):
        self.session_id  = session_id
        self.job_id      = job_id
        self.provider_mode = provider_mode
        self.profile_type  = profile_type

    def _provider_label(self) -> str:
        """Human-readable provider name for status messages."""
        return self.provider_mode.replace("_", " ").title()

    async def run(self, files: list[str]) -> AsyncGenerator[dict, None]:
        from services.pipeline_status import (
            PipelineStatusEmitter,
            evt_received, evt_classifying_page, evt_page_native,
            evt_native_page_visual, evt_native_page_complete,
            evt_native_field_extraction, evt_doc_type_identified,
            evt_native_extraction_complete, evt_populating_review, evt_ready,
        )
        from providers.provider_factory import get_registry

        registry = get_registry()
        provider = self._provider_label()
        emitter = PipelineStatusEmitter(self.session_id, self.job_id)

        import asyncio

        pipeline_task = asyncio.create_task(
            self._run_pipeline(files, registry, emitter, provider)
        )

        async for ev in emitter:
            payload = json.loads(ev.to_sse()[6:])
            yield payload

        try:
            result = await pipeline_task
            if result:
                yield result
        except Exception as e:
            logger.error("NativePipeline failed: %s", e)
            yield {"type": "info", "message": f"Native pipeline error ({type(e).__name__}), using fallback."}
            async for event in self._mock_fallback(files):
                yield event

    async def _run_pipeline(self, files: list[str], registry, emitter, provider: str) -> dict | None:
        from services.pipeline_status import (
            evt_received, evt_classifying_page, evt_page_native,
            evt_native_page_visual, evt_native_page_complete,
            evt_native_field_extraction, evt_doc_type_identified,
            evt_native_extraction_complete, evt_populating_review, evt_ready,
        )

        try:
            emitter.emit(evt_received())

            # Determine model name
            try:
                from services.config_loader import get_model_config
                model_name = get_model_config().get("name", self.provider_mode)
            except Exception:
                model_name = self.provider_mode

            # ── Stage 1+2: Page classification + extraction ────────────────────
            text_corpus: dict[str, str] = {}
            all_metadata: list[dict] = []

            for file_path in files:
                filename = Path(file_path).name
                pages, meta = await self._process_file(
                    file_path, filename, provider, model_name, registry, emitter
                )
                text_corpus[filename] = "\n\n--- Page Break ---\n\n".join(
                    p.get("text", "") for p in pages if p.get("text")
                )
                all_metadata.append(meta)

            # ── Stage 3: Field extraction ──────────────────────────────────────
            # Get doc_categories from session state if available
            doc_categories = {}
            profile_type = self.profile_type
            try:
                from routers.upload import session_states
                sess = session_states.get(self.session_id, {})
                doc_categories = sess.get("doc_categories", {})
            except Exception:
                pass

            emitter.emit(evt_native_field_extraction(provider, model_name))
            extraction_result = await self._extract_fields(
                text_corpus, registry,
                doc_categories=doc_categories,
                profile_type=profile_type,
                emitter=emitter,
            )

            doc_type = extraction_result.get("doc_type", "document")
            emitter.emit(evt_doc_type_identified(doc_type))

            total = sum(len(v) for v in extraction_result.get("categories", {}).values())
            emitter.emit(evt_native_extraction_complete(total))

            # ── Stage 4+5: Review section ──────────────────────────────────────
            emitter.emit(evt_populating_review())
            emitter.emit(evt_ready())
            emitter.done()

            from prompts.extraction_prompt import CATEGORY_TO_DISPLAY
            categories = extraction_result.get("categories", {})
            cat_list = [
                {
                    "category_name": CATEGORY_TO_DISPLAY.get(k, k.replace("_", " ").title()),
                    "icon_key": k.lower(),
                    "fields": v,
                }
                for k, v in categories.items() if v
            ]

            return {
                "type": "complete",
                "extraction_id": extraction_result.get("extraction_id", str(uuid.uuid4())),
                "total_fields": total,
                "categories": [c["category_name"] for c in cat_list],
                "doc_type": doc_type,
                "extraction_metadata": all_metadata,
                "_categories_full": cat_list,
            }

        except Exception as e:
            logger.error("NativePipeline stage error: %s", e)
            emitter.done()
            raise

    async def _process_file(
        self, file_path: str, filename: str,
        provider: str, model_name: str, registry, emitter
    ) -> tuple[list[dict], dict]:
        from services.pipeline_status import (
            evt_classifying_page, evt_page_native,
            evt_native_page_visual, evt_native_page_complete,
        )

        ext = Path(file_path).suffix.lower()

        if ext not in (".pdf",):
            # Image file
            with open(file_path, "rb") as f:
                page_b64 = base64.b64encode(f.read()).decode("utf-8")
            emitter.emit(evt_native_page_visual(1, provider, model_name, 1))
            text = await self._extract_page_with_llm(page_b64, registry, model_name)
            emitter.emit(evt_native_page_complete(1, 1))
            pages = [{"page_num": 1, "text": text, "method": "native_llm", "model": model_name}]
            meta = {"filename": filename,
                    "summary": {"total_pages": 1, "methods": {"native_llm": 1}, "failed_pages": []},
                    "pages": [{"page": 1, "method": "native_llm", "model": model_name, "error": None}]}
            return pages, meta

        import fitz
        try:
            doc = fitz.open(file_path)
        except Exception as e:
            return [], {"filename": filename, "error": str(e),
                        "summary": {}, "pages": []}

        total_pages = len(doc)
        pages = []
        page_meta = []

        for page_idx in range(total_pages):
            page_num = page_idx + 1
            emitter.emit(evt_classifying_page(page_num, total_pages))
            page = doc.load_page(page_idx)

            # Stage 1: native text
            try:
                native_text = page.get_text("text").strip()
            except Exception:
                native_text = ""

            if len(" ".join(native_text.split())) >= NATIVE_TEXT_MIN_CHARS:
                emitter.emit(evt_page_native(page_num, total_pages))
                # For native text pages use LLM text-only (no image rendering)
                pages.append({"page_num": page_num, "text": native_text,
                               "method": "native", "model": ""})
                page_meta.append({"page": page_num, "method": "native",
                                   "model": "", "error": None})
            else:
                # Stage 2: foundation model vision
                emitter.emit(evt_native_page_visual(page_num, provider, model_name, total_pages))
                zoom = 200 / 72.0
                mat = fitz.Matrix(zoom, zoom)
                pix = page.get_pixmap(matrix=mat)
                page_b64 = base64.b64encode(pix.tobytes("png")).decode("utf-8")
                text = await self._extract_page_with_llm(page_b64, registry, model_name)
                emitter.emit(evt_native_page_complete(page_num, total_pages))
                pages.append({"page_num": page_num, "text": text,
                               "method": "native_llm", "model": model_name})
                page_meta.append({"page": page_num, "method": "native_llm",
                                   "model": model_name, "error": None if text else "empty"})

        doc.close()
        methods_summary: dict[str, int] = {}
        for p in pages:
            m = p.get("method", "unknown")
            methods_summary[m] = methods_summary.get(m, 0) + 1

        meta = {
            "filename": filename,
            "summary": {"total_pages": total_pages, "methods": methods_summary,
                        "failed_pages": []},
            "pages": page_meta,
        }
        return pages, meta

    async def _extract_page_with_llm(
        self, page_b64: str, registry, model_name: str
    ) -> str:
        """Single foundation model call for text + vision extraction."""
        from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
        system = get_ocr_system_prompt()
        user   = get_ocr_user_prompt()

        try:
            llm = registry.get_llm()
            if hasattr(llm, 'chat'):
                def _sync_native_llm():
                    return llm.chat.completions.create(
                        timeout=60,
                        model=model_name,
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user", "content": [
                                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                                {"type": "text", "text": user},
                            ]},
                        ],
                        max_tokens=4096,
                    )
                import asyncio as _asyncio
                loop = _asyncio.get_running_loop()
                resp = await loop.run_in_executor(None, _sync_native_llm)
                return resp.choices[0].message.content or ""
            else:
                # BaseLLMProvider (Anthropic etc.)
                vision = registry.vision
                return await vision.vision_complete(
                    system=system, user_text=user,
                    image_b64=page_b64, image_media_type="image/png",
                    model=model_name, max_tokens=4096, temperature=0.1,
                )
        except Exception as e:
            logger.warning("Native LLM page extraction failed: %s", e)
            return ""

    async def _extract_fields(
        self, text_corpus: dict, registry,
        doc_categories: dict | None = None,
        profile_type: str | None = None,
        emitter=None,
    ) -> dict:
        """Stage 3: Use existing extraction_service for field extraction."""
        from services.extraction_service import extract_fields
        try:
            return await extract_fields(
                text_corpus, self.session_id,
                doc_categories=doc_categories,
                profile_type=profile_type,
                emitter=emitter,
            )
        except Exception as e:
            logger.error("Native pipeline field extraction failed: %s", e)
            return {"extraction_id": str(uuid.uuid4()), "categories": {}, "total_fields": 0}

    async def _mock_fallback(self, files: list[str]) -> AsyncGenerator[dict, None]:
        from routers.extract import _run_mock_pipeline
        session_dir = str(Path(files[0]).parent) if files else "/tmp"
        file_names = [Path(f).name for f in files]
        async for event in _run_mock_pipeline(self.session_id, session_dir, file_names):
            yield event
