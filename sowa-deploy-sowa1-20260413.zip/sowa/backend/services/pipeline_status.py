"""
Pipeline Status Event System

Every stage of both Pipeline A (private) and Pipeline B (native) emits
precise, human-readable status events through this module.

Events are:
  - Pushed to the caller as async-generator items (for SSE streaming)
  - Stored to the database against the processing job ID
  - Retrievable if the user refreshes mid-processing
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import AsyncGenerator, Optional

logger = logging.getLogger(__name__)


@dataclass
class StatusEvent:
    """A single pipeline status event."""
    stage: str                      # e.g. "page_classification", "ocr", "vectorisation"
    message: str                    # Human-readable status text
    progress: int                   # 0–100 percentage
    service: str = ""               # Service being used (e.g. "OCR", "VLM", "LLM")
    model: str = ""                 # Model name being called
    page: Optional[int] = None      # Page number being processed (if applicable)
    total_pages: Optional[int] = None
    is_error: bool = False
    is_warning: bool = False
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_sse(self) -> str:
        """Format as SSE data line."""
        payload = {
            "type": "status",
            "stage": self.stage,
            "message": self.message,
            "progress": self.progress,
            "service": self.service,
            "model": self.model,
            "page": self.page,
            "total_pages": self.total_pages,
            "is_error": self.is_error,
            "is_warning": self.is_warning,
            "status_type": ("error" if self.is_error else "warning" if self.is_warning else "processing"),
            "detail": "",        # populated by higher-level emitters if needed
            "page_current": self.page,
            "page_total": self.total_pages,
            "timestamp": self.timestamp,
        }
        return f"data: {json.dumps(payload)}\n\n"

    def to_dict(self) -> dict:
        return asdict(self)


class PipelineStatusEmitter:
    """
    Collects status events and provides async iteration.
    Used as a shared queue between pipeline stages and the SSE response.
    """

    def __init__(self, session_id: str, job_id: str):
        self.session_id = session_id
        self.job_id = job_id
        self._queue: asyncio.Queue[Optional[StatusEvent]] = asyncio.Queue()
        self._done = False

    def emit(self, event: StatusEvent) -> None:
        """Emit an event (non-blocking, called from any stage)."""
        self._queue.put_nowait(event)
        # Persist to DB asynchronously (fire-and-forget)
        try:
            asyncio.get_running_loop().create_task(
                _store_event(self.session_id, self.job_id, event)
            )
        except RuntimeError:
            pass  # No running event loop — skip DB write

    def done(self) -> None:
        """Signal that no more events will be emitted."""
        self._done = True
        self._queue.put_nowait(None)  # sentinel

    async def __aiter__(self) -> AsyncGenerator[StatusEvent, None]:
        while True:
            event = await self._queue.get()
            if event is None:
                break
            yield event


async def _store_event(session_id: str, job_id: str, event: StatusEvent) -> None:
    """Write a status event to the pipeline_jobs table."""
    try:
        from database import SessionLocal
        with SessionLocal() as db:
            db.execute(
                "INSERT INTO pipeline_jobs "
                "(session_id, job_id, stage, message, progress, service, model, "
                " page_num, is_error, is_warning, timestamp) "
                "VALUES (:session_id, :job_id, :stage, :message, :progress, :service, "
                "        :model, :page, :is_error, :is_warning, :timestamp)",
                {
                    "session_id": session_id,
                    "job_id": job_id,
                    "stage": event.stage,
                    "message": event.message,
                    "progress": event.progress,
                    "service": event.service or "",
                    "model": event.model or "",
                    "page": event.page,
                    "is_error": event.is_error,
                    "is_warning": event.is_warning,
                    "timestamp": event.timestamp,
                }
            )
            db.commit()
    except Exception as e:
        logger.debug("Could not store status event: %s", e)


def get_job_history(session_id: str) -> list[dict]:
    """Retrieve stored status events for a session."""
    try:
        from database import SessionLocal
        with SessionLocal() as db:
            rows = db.execute(
                "SELECT stage, message, progress, service, model, page_num, "
                "       is_error, is_warning, timestamp "
                "FROM pipeline_jobs WHERE session_id = :sid "
                "ORDER BY timestamp ASC",
                {"sid": session_id}
            ).fetchall()
            return [dict(r._mapping) for r in rows]
    except Exception:
        return []


# ── Convenience constructors for every spec-defined status message ─────────────

def evt_uploading() -> StatusEvent:
    return StatusEvent("upload", "Uploading document...", 0, service="Upload")

def evt_received() -> StatusEvent:
    return StatusEvent("received", "Document received. Analysing structure...", 2, service="System")

def evt_classifying_page(page: int, total: int) -> StatusEvent:
    pct = 5 + int((page / max(total, 1)) * 10)
    return StatusEvent("classification",
        f"Classifying pages — Page {page} of {total}: checking for extractable text...",
        pct, page=page, total_pages=total)

def evt_page_native(page: int, total: int) -> StatusEvent:
    pct = 5 + int((page / max(total, 1)) * 10)
    return StatusEvent("classification",
        f"Page {page}: Native text extraction successful — no AI needed",
        pct, service="Native", page=page, total_pages=total)

def evt_page_image_detected(page: int, total: int) -> StatusEvent:
    pct = 5 + int((page / max(total, 1)) * 10)
    return StatusEvent("classification",
        f"Page {page}: Image-based page detected — routing to OCR service...",
        pct, service="OCR", page=page, total_pages=total)

def evt_ocr_auth_request(page: int) -> StatusEvent:
    return StatusEvent("ocr_auth",
        f"Page {page}: Requesting OCR authentication token...",
        15, service="OCR", page=page)

def evt_ocr_auth_received(page: int) -> StatusEvent:
    return StatusEvent("ocr_auth",
        f"Page {page}: OCR token received. Sending to OCR service...",
        16, service="OCR", page=page)

def evt_ocr_complete(page: int, char_count: int, model: str = "") -> StatusEvent:
    return StatusEvent("ocr",
        f"Page {page}: OCR extraction complete — {char_count} characters extracted",
        17, service="OCR", model=model, page=page)

def evt_vlm_enhance(page: int, model: str) -> StatusEvent:
    return StatusEvent("vlm",
        f"Page {page}: Sending to VLM for visual enhancement...",
        20, service="VLM", model=model, page=page)

def evt_vlm_complete(page: int) -> StatusEvent:
    return StatusEvent("vlm",
        f"Page {page}: VLM enhancement complete — tables and visual elements identified",
        22, service="VLM", page=page)

def evt_llm_vision_fallback(page: int, model: str) -> StatusEvent:
    return StatusEvent("llm_vision",
        f"Page {page}: LLM vision fallback — sending to {model}...",
        17, service="LLM", model=model, page=page)

def evt_all_extracted() -> StatusEvent:
    return StatusEvent("structuring",
        "All pages extracted. Structuring document content with LLM...",
        40, service="LLM")

def evt_doc_type_identified(doc_type: str) -> StatusEvent:
    return StatusEvent("structuring",
        f"Document type identified: {doc_type.replace('_', ' ').title()}",
        45, service="LLM")

def evt_vectorising(chunk_count: int, model: str) -> StatusEvent:
    return StatusEvent("vectorisation",
        f"Generating text embeddings for {chunk_count} content chunks via {model}...",
        50, service="Vectorisation", model=model)

def evt_semantic_search() -> StatusEvent:
    return StatusEvent("rag",
        "Embeddings stored. Running semantic search for field extraction...",
        55, service="Vectorisation")

def evt_reranking(candidate_count: int, model: str) -> StatusEvent:
    return StatusEvent("reranker",
        f"Reranking {candidate_count} candidate passages via {model}...",
        60, service="Reranker", model=model)

def evt_extracting_category(category: str, pct: int) -> StatusEvent:
    return StatusEvent("extraction",
        f"Extracting fields: {category}...",
        pct, service="LLM")

def evt_extraction_complete(total: int, high_conf: int, needs_review: int) -> StatusEvent:
    return StatusEvent("extraction",
        f"Field extraction complete — {total} fields extracted, "
        f"{high_conf} high confidence, {needs_review} require review",
        85, service="LLM")

def evt_validating() -> StatusEvent:
    return StatusEvent("validation", "Validating extraction quality...", 90, service="System")

def evt_populating_review() -> StatusEvent:
    return StatusEvent("review", "Populating review section...", 95, service="System")

def evt_ready() -> StatusEvent:
    return StatusEvent("complete", "Ready for review.", 100, service="System")

# Native mode events
def evt_native_page_visual(page: int, provider: str, model: str, total: int) -> StatusEvent:
    pct = 5 + int((page / max(total, 1)) * 30)
    return StatusEvent("extraction",
        f"Page {page}: Visual content detected — sending to {provider} {model}...",
        pct, service=provider, model=model, page=page, total_pages=total)

def evt_native_page_complete(page: int, total: int) -> StatusEvent:
    pct = 5 + int((page / max(total, 1)) * 30)
    return StatusEvent("extraction",
        f"Page {page}: Extraction complete",
        pct, page=page, total_pages=total)

def evt_native_field_extraction(provider: str, model: str) -> StatusEvent:
    return StatusEvent("extraction",
        f"All pages extracted. Running field identification via {provider} {model}...",
        50, service=provider, model=model)

def evt_native_extraction_complete(total: int) -> StatusEvent:
    return StatusEvent("extraction",
        f"Field extraction complete — {total} fields extracted",
        85, service="System")

# Error/warning events
def evt_ocr_unavailable(page: int) -> StatusEvent:
    return StatusEvent("fallback",
        f"Page {page}: OCR service unreachable — falling back to VLM...",
        0, is_warning=True, page=page)

def evt_vlm_unavailable(page: int) -> StatusEvent:
    return StatusEvent("fallback",
        f"Page {page}: VLM service unreachable — falling back to LLM vision...",
        0, is_warning=True, page=page)

def evt_llm_vision_failed(page: int) -> StatusEvent:
    return StatusEvent("fallback",
        f"Page {page}: LLM vision fallback failed — page marked for manual review",
        0, is_error=True, page=page)

def evt_page_failed(page: int, retries: int, reason: str) -> StatusEvent:
    return StatusEvent("extraction",
        f"Page {page}: Extraction failed after {retries} retries — {reason}. "
        "Continuing with remaining pages...",
        0, is_error=True, page=page)

def evt_vectorisation_unavailable() -> StatusEvent:
    return StatusEvent("vectorisation",
        "Warning: Vectorisation service unavailable — using direct LLM extraction (reduced accuracy)",
        0, is_warning=True)

def evt_reranker_unavailable() -> StatusEvent:
    return StatusEvent("reranker",
        "Warning: Reranker service unavailable — using vector search results directly",
        0, is_warning=True)

def evt_evaluation_scoring() -> StatusEvent:
    return StatusEvent("evaluation",
        "Evaluating report quality via semantic comparison...",
        97, service="System")
