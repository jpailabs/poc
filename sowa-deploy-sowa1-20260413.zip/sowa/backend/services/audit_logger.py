"""
AuditLogger — append-only JSONL audit log for all admin actions.

Log file: backend/audit_log.jsonl
Each line is a JSON object:
  {
    "timestamp": "2026-04-03T10:00:00Z",
    "changed_by": "admin" | "backend_watcher",
    "action": "config_update" | "prompt_save" | "user_add" | "user_remove" | "file_change" | ...,
    "section": "LLM" | "AUTH" | "ocr_extraction" | ...,
    "key": "model_name" | null,
    "old_value": "..." | null,
    "new_value": "..." | null,
    "details": {} | null
  }
"""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

_BACKEND_DIR = Path(__file__).resolve().parent.parent
_LOG_PATH = _BACKEND_DIR / "audit_log.jsonl"
_lock = threading.Lock()


def _write(entry: dict) -> None:
    with _lock:
        try:
            with open(_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.error("AuditLogger: failed to write: %s", e)


def log(
    action: str,
    changed_by: str = "admin",
    section: Optional[str] = None,
    key: Optional[str] = None,
    old_value: Any = None,
    new_value: Any = None,
    details: Optional[dict] = None,
) -> None:
    """Append a single audit log entry."""
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "changed_by": changed_by,
        "action": action,
        "section": section,
        "key": key,
        "old_value": old_value,
        "new_value": new_value,
        "details": details,
    }
    _write(entry)


def log_diff(
    action: str,
    diff: dict,
    section: str,
    changed_by: str = "admin",
) -> None:
    """Log each key in a diff dict as a separate audit entry."""
    for k, v in diff.items():
        log(
            action=action,
            changed_by=changed_by,
            section=section,
            key=k,
            old_value=v.get("old"),
            new_value=v.get("new"),
        )


def read(
    limit: int = 200,
    offset: int = 0,
    action_filter: Optional[str] = None,
    section_filter: Optional[str] = None,
    changed_by_filter: Optional[str] = None,
) -> list[dict]:
    """Read audit log entries, newest first."""
    if not _LOG_PATH.exists():
        return []
    with _lock:
        with open(_LOG_PATH, encoding="utf-8") as f:
            lines = f.readlines()

    entries = []
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if action_filter and entry.get("action") != action_filter:
            continue
        if section_filter and entry.get("section") != section_filter:
            continue
        if changed_by_filter and entry.get("changed_by") != changed_by_filter:
            continue
        entries.append(entry)

    return entries[offset: offset + limit]


def count(action_filter: Optional[str] = None) -> int:
    if not _LOG_PATH.exists():
        return 0
    with _lock:
        with open(_LOG_PATH, encoding="utf-8") as f:
            lines = f.readlines()
    if not action_filter:
        return sum(1 for l in lines if l.strip())
    count_ = 0
    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
            if e.get("action") == action_filter:
                count_ += 1
        except Exception:
            pass
    return count_
