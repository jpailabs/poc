"""
ConfigManager — bi-directional sync between in-memory config and disk files.

Handles:
  - Reading .env and config.yaml from disk
  - Writing changes back atomically (write-to-temp-then-rename)
  - Hot-reloading in-memory config without restart
  - Computing diffs between old and new values
  - Validating config values before writing

File locations resolved at runtime:
  - config.yaml  → backend/config/config.yaml
  - .env         → project root (.env)
"""
from __future__ import annotations

import copy
import logging
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Paths resolved relative to this file
_BACKEND_DIR = Path(__file__).resolve().parent.parent
_CONFIG_YAML_PATH = _BACKEND_DIR / "config" / "config.yaml"

# .env search order: project root → backend dir → /app/.env (Docker mount)
def _find_env_path() -> Path:
    candidates = [
        _BACKEND_DIR.parent / ".env",   # project root (local dev)
        _BACKEND_DIR / ".env",           # backend dir (Docker: ./backend:/app mount)
        Path("/app/.env"),               # explicit Docker mount
    ]
    for p in candidates:
        if p.exists():
            return p
    # Default to project root even if not yet created (writes will create it)
    return _BACKEND_DIR.parent / ".env"

_ENV_PATH = _find_env_path()

# Sentinel so callers can tell "key was absent" from "key was empty string"
_MISSING = object()


class ConfigManager:
    """
    Singleton for reading, writing and hot-reloading application config.
    Thread-safe via a module-level lock.
    """

    def __init__(self):
        import threading
        self._lock = threading.Lock()
        self._yaml_cache: dict[str, Any] = {}
        self._env_cache: dict[str, str] = {}
        self._loaded = False

    # ── Load ──────────────────────────────────────────────────────────────────

    def load(self) -> None:
        """Load both files into memory. Called at startup and on hot-reload."""
        with self._lock:
            self._yaml_cache = self._read_yaml()
            self._env_cache = self._read_env()
            self._loaded = True
            logger.info("ConfigManager: loaded config.yaml + .env")

    def _read_yaml(self) -> dict:
        if not _CONFIG_YAML_PATH.exists():
            logger.warning("config.yaml not found at %s", _CONFIG_YAML_PATH)
            return {}
        with open(_CONFIG_YAML_PATH, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def _read_env(self) -> dict[str, str]:
        result: dict[str, str] = {}
        if not _ENV_PATH.exists():
            return result
        with open(_ENV_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, _, val = line.partition("=")
                    result[key.strip()] = val.strip()
        return result

    # ── Get ───────────────────────────────────────────────────────────────────

    def get_yaml(self) -> dict[str, Any]:
        """Return a deep copy of the current in-memory YAML config."""
        if not self._loaded:
            self.load()
        with self._lock:
            return copy.deepcopy(self._yaml_cache)

    def get_env(self) -> dict[str, str]:
        """Return a copy of the current in-memory .env config."""
        if not self._loaded:
            self.load()
        with self._lock:
            return dict(self._env_cache)

    def get_section(self, section: str) -> dict[str, Any]:
        """Return a specific top-level YAML section (e.g. 'LLM', 'AUTH')."""
        return self.get_yaml().get(section, {})

    def get_provider_mode(self) -> str:
        return self.get_yaml().get("PROVIDER_MODE", "anthropic")

    # ── Write ─────────────────────────────────────────────────────────────────

    def update_yaml_section(
        self, section: str, updates: dict[str, Any], changed_by: str = "admin"
    ) -> dict[str, Any]:
        """
        Merge `updates` into a top-level YAML section and write to disk.
        Returns a diff dict: {"key": {"old": ..., "new": ...}}.
        Thread-safe, atomic write.
        """
        with self._lock:
            old_section = copy.deepcopy(self._yaml_cache.get(section, {}))

            # Merge updates into current section
            if section not in self._yaml_cache:
                self._yaml_cache[section] = {}

            diff = {}
            for k, v in updates.items():
                old_v = old_section.get(k, _MISSING)
                if old_v is _MISSING or old_v != v:
                    diff[k] = {"old": None if old_v is _MISSING else old_v, "new": v}
                self._yaml_cache[section][k] = v

            # Special case: PROVIDER_MODE lives at root level
            if section == "PROVIDER_MODE" and isinstance(updates, str):
                old_v = self._yaml_cache.get("PROVIDER_MODE")
                if old_v != updates:
                    diff["PROVIDER_MODE"] = {"old": old_v, "new": updates}
                self._yaml_cache["PROVIDER_MODE"] = updates

            self._write_yaml_atomic(self._yaml_cache)
            logger.info("ConfigManager: updated YAML section '%s' by %s — %d keys changed", section, changed_by, len(diff))
            return diff

    def update_provider_mode(self, mode: str, changed_by: str = "admin") -> dict:
        with self._lock:
            old = self._yaml_cache.get("PROVIDER_MODE", "anthropic")
            diff = {}
            if old != mode:
                diff["PROVIDER_MODE"] = {"old": old, "new": mode}
            self._yaml_cache["PROVIDER_MODE"] = mode
            self._write_yaml_atomic(self._yaml_cache)

        # Invalidate config_loader cache so get_provider_mode() returns the new value
        try:
            from services.config_loader import reload_config
            reload_config()
        except Exception:
            pass
        return diff

    def update_env(
        self, updates: dict[str, str], changed_by: str = "admin"
    ) -> dict[str, Any]:
        """
        Update keys in the .env file and in-memory cache.
        Returns diff dict.
        """
        with self._lock:
            diff = {}
            for k, v in updates.items():
                old_v = self._env_cache.get(k, _MISSING)
                if old_v is _MISSING or old_v != v:
                    diff[k] = {"old": None if old_v is _MISSING else old_v, "new": v}
                self._env_cache[k] = v
                os.environ[k] = v  # also update live process env

            self._write_env_atomic(self._env_cache)
            logger.info("ConfigManager: updated .env by %s — %d keys changed", changed_by, len(diff))
            return diff

    # ── Hot reload ────────────────────────────────────────────────────────────

    def reload(self) -> None:
        """Re-read both files from disk, updating in-memory caches."""
        self.load()
        # Propagate to the services/config_loader singleton cache
        try:
            from services.config_loader import reload_config
            reload_config()
        except Exception as e:
            logger.warning("Could not reload config_loader cache: %s", e)
        # Re-initialize providers from new config
        try:
            from providers.provider_factory import init_providers
            init_providers(self._yaml_cache)
        except Exception as e:
            logger.warning("Could not re-init providers after reload: %s", e)

    # ── Atomic writes ─────────────────────────────────────────────────────────

    def _write_yaml_atomic(self, data: dict) -> None:
        """Write dict to config.yaml atomically via temp file."""
        _CONFIG_YAML_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _CONFIG_YAML_PATH.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
        tmp.replace(_CONFIG_YAML_PATH)

    def _write_env_atomic(self, data: dict[str, str]) -> None:
        """Write dict to .env atomically. Preserves comments from existing file."""
        # Read existing lines (to preserve comments)
        existing_lines: list[str] = []
        if _ENV_PATH.exists():
            with open(_ENV_PATH, encoding="utf-8") as f:
                existing_lines = f.readlines()

        # Build a set of keys already in the file
        existing_keys = set()
        output_lines: list[str] = []
        for line in existing_lines:
            stripped = line.strip()
            if stripped.startswith("#") or not stripped:
                output_lines.append(line if line.endswith("\n") else line + "\n")
                continue
            if "=" in stripped:
                k = stripped.split("=", 1)[0].strip()
                existing_keys.add(k)
                if k in data:
                    output_lines.append(f"{k}={data[k]}\n")
                else:
                    output_lines.append(line if line.endswith("\n") else line + "\n")

        # Append new keys not already in file
        for k, v in data.items():
            if k not in existing_keys:
                output_lines.append(f"{k}={v}\n")

        _ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _ENV_PATH.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.writelines(output_lines)
        tmp.replace(_ENV_PATH)

    # ── Export ────────────────────────────────────────────────────────────────

    def export_yaml(self) -> str:
        """Return current config as a YAML string."""
        return yaml.dump(self.get_yaml(), default_flow_style=False, allow_unicode=True, sort_keys=False)

    def export_env(self) -> str:
        """Return current .env content as a string."""
        lines = [f"{k}={v}" for k, v in self.get_env().items()]
        return "\n".join(lines)


# Module-level singleton
_config_manager: ConfigManager | None = None


def get_config_manager() -> ConfigManager:
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
        _config_manager.load()
    return _config_manager
