"""
Config loader — reads config.yaml and exposes typed helpers.
Falls back to model_config.yaml for legacy compatibility.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

_cached_config: dict | None = None

CONFIG_PATHS = [
    Path(__file__).resolve().parent.parent / "config" / "config.yaml",
    Path(__file__).resolve().parent.parent / "config" / "model_config.yaml",
]


def load_config() -> dict[str, Any]:
    global _cached_config
    if _cached_config is not None:
        return _cached_config

    for path in CONFIG_PATHS:
        if path.exists():
            with open(path) as f:
                _cached_config = yaml.safe_load(f) or {}
            return _cached_config

    _cached_config = {}
    return _cached_config


def reload_config() -> dict[str, Any]:
    """Force reload from disk (useful for testing or hot-reload)."""
    global _cached_config
    _cached_config = None
    return load_config()


def get_model_config() -> dict[str, Any]:
    """Returns the model config section (legacy + new provider config)."""
    cfg = load_config()
    mode = cfg.get("PROVIDER_MODE", "anthropic").lower()
    # Return provider-specific config merged with legacy model section
    provider_cfg = cfg.get(mode.upper(), cfg.get("ANTHROPIC", {}))
    legacy = cfg.get("model", {})
    return {
        "name": provider_cfg.get("model_name", legacy.get("name", "claude-sonnet-4-20250514")),
        "temperature": provider_cfg.get("temperature", legacy.get("temperature", 0.2)),
        "max_tokens": provider_cfg.get("max_tokens", legacy.get("max_tokens", 4096)),
        "vision_enabled": legacy.get("vision_enabled", True),
        "ocr_dpi": legacy.get("ocr_dpi", 200),
        "provider_mode": mode,
    }


def get_prompt_overrides() -> dict[str, Any]:
    return load_config().get("prompts", {})


def get_session_config() -> dict[str, Any]:
    return load_config().get("session", {
        "cleanup_after_hours": 2,
        "upload_dir": "/tmp/sow_sessions",
        "max_file_size_mb": 50,
    })


def get_auth_config() -> dict[str, Any]:
    return load_config().get("AUTH", {"provider": "demo"})


def get_provider_mode() -> str:
    return load_config().get("PROVIDER_MODE", "anthropic").lower()


# ── Simulation mode flag ──────────────────────────────────────────────────────
# APP_MODE controls whether the app uses live OCR/VLM/LLM pipelines ("real")
# or reads pre-rendered files from the render/ folder ("mock").
# Allowed values: "mock" | "real"
# Set to "mock" for demo purposes; "real" activates the full AI pipeline.
APP_MODE: str = "mock"


def get_app_mode() -> str:
    """Return the current application mode: 'mock' or 'real'."""
    return APP_MODE
