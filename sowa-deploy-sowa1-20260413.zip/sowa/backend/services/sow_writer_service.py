"""Source of Wealth report generation — structured text output, no markdown.

Provider routing:
  - private / internal_vllm  → service_registry.get_async_llm() (OpenAI-compatible httpx)
  - anthropic / openai / etc → provider_factory.get_registry().get_llm() (native provider)

Both paths use the same system + user prompt; only the underlying transport differs.
"""

import logging
import re
import uuid
from typing import Any, AsyncGenerator

from services.config_loader import get_model_config, get_prompt_overrides

logger = logging.getLogger(__name__)

_SECTION_PATTERN = re.compile(r"\[SECTION:\s*(.+?)\]")

_PRIVATE_MODES = {"private", "internal_vllm"}


def _get_system_prompt() -> str:
    overrides = get_prompt_overrides()
    override = overrides.get("sow_system_override")
    if override:
        return override
    from prompts.sow_prompt import get_sow_system_prompt
    return get_sow_system_prompt()


def _count_words(text: str) -> int:
    return len(text.split())


def _get_llm_and_model():
    """
    Return (llm_provider, model_name) for the current provider mode.
    Handles both private (service_registry) and native (provider_factory) modes.
    """
    from services.config_loader import get_provider_mode
    mode = get_provider_mode()
    config = get_model_config()
    model = config.get("name", "claude-sonnet-4-6")

    if mode in _PRIVATE_MODES:
        # Private mode: use service_registry's async LLM (OpenAI-compatible httpx)
        from services.service_registry import get_service_registry
        reg = get_service_registry()
        llm = reg.get_async_llm()
        model = reg.get_llm_model()
        return llm, model, False   # (llm, model, supports_streaming)

    # Native provider modes: use provider_factory
    from providers.provider_factory import get_registry
    registry = get_registry()
    llm = registry.get_llm()
    return llm, model, True        # native providers support streaming


async def generate_sow(
    verified_fields: list, profile_type: str, session_id: str
) -> AsyncGenerator[dict[str, Any], None]:
    """
    Generate a Source of Wealth report and stream it as token/section events.

    Yields:
        {"type": "token", "text": str}
        {"type": "section_start", "section": str}
        {"type": "section_complete", "section": str, "word_count": int}
        {"type": "complete", "generation_id": str, "total_words": int}
    """
    from prompts.sow_prompt import get_sow_user_prompt

    config = get_model_config()
    generation_id = str(uuid.uuid4())
    system_prompt = _get_system_prompt()
    user_prompt = get_sow_user_prompt(verified_fields, profile_type)
    # SOW reports require substantial output — 8 sections of professional prose + tables.
    # Use a high token ceiling so the model doesn't truncate mid-report.
    max_tokens = max(config.get("max_tokens", 4096), 8000)
    temperature = config.get("temperature", 0.3)  # slight warmth for flowing prose

    logger.warning(
        "generate_sow: session=%s fields=%d prompt_len=%d",
        session_id[:8], len(verified_fields), len(user_prompt),
    )

    try:
        llm, model, supports_streaming = _get_llm_and_model()
    except Exception as e:
        raise RuntimeError(f"No LLM provider available for SOW generation: {e}") from e

    total_text = ""
    current_section: str | None = None
    current_section_text = ""

    if supports_streaming:
        # ── Native provider — true streaming ─────────────────────────────
        line_buffer = ""
        async for text_chunk in llm.stream(
            system=system_prompt, user=user_prompt,
            model=model, max_tokens=max_tokens, temperature=temperature,
        ):
            total_text += text_chunk
            line_buffer += text_chunk
            yield {"type": "token", "text": text_chunk}

            while "\n" in line_buffer:
                line, line_buffer = line_buffer.split("\n", 1)
                match = _SECTION_PATTERN.match(line.strip())
                if match:
                    if current_section is not None:
                        yield {
                            "type": "section_complete",
                            "section": current_section,
                            "word_count": _count_words(current_section_text),
                        }
                    current_section = match.group(1).strip()
                    current_section_text = ""
                    yield {"type": "section_start", "section": current_section}
                else:
                    current_section_text += line + "\n"

        # flush remaining buffer
        if line_buffer.strip():
            match = _SECTION_PATTERN.match(line_buffer.strip())
            if match:
                if current_section is not None:
                    yield {
                        "type": "section_complete",
                        "section": current_section,
                        "word_count": _count_words(current_section_text),
                    }
                current_section = match.group(1).strip()
                yield {"type": "section_start", "section": current_section}
            else:
                current_section_text += line_buffer
                total_text += line_buffer

    else:
        # ── Private/OpenAI-compat provider — complete() then emit preserving structure ─
        full_response = await llm.complete(
            system=system_prompt, user=user_prompt,
            model=model, max_tokens=max_tokens, temperature=temperature,
        )
        total_text = full_response

        # CRITICAL: emit ALL lines as tokens — including structural delimiters like
        # [SECTION:], [/SECTION], [NARRATIVE], [TABLE], ROW: etc. — so that generate.py
        # accumulates a full_text that the export.py parser can correctly parse.
        # Splitting by words loses newlines and structural tags, making the parser fail.
        line_buf = ""
        for line in full_response.split("\n"):
            match = _SECTION_PATTERN.match(line.strip())
            if match:
                # Flush buffered prose before section transition
                if line_buf:
                    yield {"type": "token", "text": line_buf}
                    line_buf = ""
                if current_section is not None:
                    yield {
                        "type": "section_complete",
                        "section": current_section,
                        "word_count": _count_words(current_section_text),
                    }
                current_section = match.group(1).strip()
                current_section_text = ""
                yield {"type": "section_start", "section": current_section}
                # Emit the delimiter line as a token to preserve it in full_text
                yield {"type": "token", "text": line + "\n"}
            else:
                current_section_text += line + "\n"
                line_buf += line + "\n"
                # Flush every 5 lines for UI responsiveness
                if line_buf.count("\n") >= 5:
                    yield {"type": "token", "text": line_buf}
                    line_buf = ""

        # Flush remaining buffer
        if line_buf:
            yield {"type": "token", "text": line_buf}

    # Final section completion
    if current_section is not None:
        yield {
            "type": "section_complete",
            "section": current_section,
            "word_count": _count_words(current_section_text),
        }

    logger.warning(
        "generate_sow: complete session=%s words=%d",
        session_id[:8], _count_words(total_text),
    )

    yield {
        "type": "complete",
        "generation_id": generation_id,
        "total_words": _count_words(total_text),
    }
