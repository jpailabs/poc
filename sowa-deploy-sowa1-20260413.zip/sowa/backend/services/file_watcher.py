"""
FileWatcher — watchdog-based file change monitor for config and prompt files.

Monitors:
  - backend/config/config.yaml
  - project_root/.env
  - backend/prompts_store/*.txt

On change: broadcasts a WebSocket event to all connected admin clients.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)

_BACKEND_DIR = Path(__file__).resolve().parent.parent
_WATCH_PATHS = [
    _BACKEND_DIR / "config" / "config.yaml",
    _BACKEND_DIR.parent / ".env",
    _BACKEND_DIR / "prompts_store",
]


class ChangeEvent:
    def __init__(self, event_type: str, path: str, category: str):
        self.event_type = event_type  # "modified" | "created" | "deleted"
        self.path = path
        self.category = category      # "config" | "prompt" | "env"
        self.timestamp = __import__("datetime").datetime.utcnow().isoformat()

    def to_dict(self) -> dict:
        return {
            "type": "file_change",
            "event": self.event_type,
            "path": self.path,
            "category": self.category,
            "timestamp": self.timestamp,
        }


# Global set of WebSocket send callbacks registered by connected admin clients
_ws_callbacks: set[Callable] = set()
_callbacks_lock = threading.Lock()


def register_ws_callback(callback: Callable) -> None:
    with _callbacks_lock:
        _ws_callbacks.add(callback)


def unregister_ws_callback(callback: Callable) -> None:
    with _callbacks_lock:
        _ws_callbacks.discard(callback)


def broadcast_change(event: ChangeEvent) -> None:
    """Send change event to all registered WebSocket callbacks."""
    global _ws_callbacks  # explicit global declaration prevents UnboundLocalError
    msg = json.dumps(event.to_dict())
    with _callbacks_lock:
        dead = set()
        for cb in _ws_callbacks:
            try:
                # callbacks may be sync or async
                if asyncio.iscoroutinefunction(cb):
                    try:
                        loop = asyncio.get_event_loop()
                        asyncio.run_coroutine_threadsafe(cb(msg), loop)
                    except RuntimeError:
                        pass  # no running loop in this thread
                else:
                    cb(msg)
            except Exception:
                dead.add(cb)
        _ws_callbacks -= dead


class _ChangeHandler:
    """Debounced file change handler."""

    def __init__(self, loop: asyncio.AbstractEventLoop | None = None):
        self._loop = loop
        self._debounce: dict[str, float] = {}
        self._debounce_delay = 0.5  # seconds

    def dispatch(self, event_type: str, src_path: str) -> None:
        now = time.monotonic()
        # Debounce — ignore rapid repeated events for same file
        last = self._debounce.get(src_path, 0)
        if now - last < self._debounce_delay:
            return
        self._debounce[src_path] = now

        # Skip temp files and __pycache__
        if src_path.endswith((".tmp", ".pyc")) or "__pycache__" in src_path:
            return

        # Determine category
        p = Path(src_path)
        if "prompts_store" in str(p) and p.suffix == ".txt":
            category = "prompt"
        elif p.name == "config.yaml":
            category = "config"
        elif p.name == ".env":
            category = "env"
        else:
            return

        logger.info("FileWatcher: %s detected on %s (%s)", event_type, p.name, category)
        event = ChangeEvent(event_type=event_type, path=str(p), category=category)

        # Hot-reload in memory
        try:
            from services.config_manager import get_config_manager
            if category in ("config", "env"):
                get_config_manager().reload()
        except Exception as e:
            logger.warning("FileWatcher: hot-reload failed: %s", e)

        broadcast_change(event)


_handler = _ChangeHandler()
_watcher_started = False


def start_file_watcher(loop: asyncio.AbstractEventLoop | None = None) -> None:
    """Start the watchdog observer in a background thread. Call once at startup."""
    global _watcher_started
    if _watcher_started:
        return

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler

        class _WatchdogHandler(FileSystemEventHandler):
            def on_modified(self, event):
                if not event.is_directory:
                    _handler.dispatch("modified", event.src_path)

            def on_created(self, event):
                if not event.is_directory:
                    _handler.dispatch("created", event.src_path)

            def on_deleted(self, event):
                if not event.is_directory:
                    _handler.dispatch("deleted", event.src_path)

        observer = Observer()
        handler = _WatchdogHandler()

        watched_dirs: set[str] = set()
        for watch_path in _WATCH_PATHS:
            watch_dir = str(watch_path if watch_path.is_dir() else watch_path.parent)
            if watch_dir not in watched_dirs:
                observer.schedule(handler, watch_dir, recursive=False)
                watched_dirs.add(watch_dir)
                logger.info("FileWatcher: watching %s", watch_dir)

        observer.start()
        _watcher_started = True
        logger.info("FileWatcher: started successfully")
    except ImportError:
        logger.warning("FileWatcher: watchdog not installed, file watching disabled")
    except Exception as e:
        logger.error("FileWatcher: failed to start: %s", e)
