"""
Document Ingestion Service

Implements the document processing pipeline:
  Rule 2: Native text extraction first for every PDF page
  Rule 3: OCR model for image-based pages when configured
  Rule 4: VLM model when no OCR but VLM configured
  Rule 5: LLM vision fallback when neither OCR nor VLM configured

Outputs a DocumentExtractionResult with per-page metadata showing
which method and model handled each page.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import AsyncGenerator, Optional

logger = logging.getLogger(__name__)

# Minimum characters from native extraction to consider a page "text-extractable"
NATIVE_TEXT_MIN_CHARS = 80


@dataclass
class PageResult:
    page_num: int            # 1-indexed
    text: str                # extracted text
    method: str              # "native", "ocr", "vlm", "llm_vision", "failed"
    model: str               # model name used (empty for native)
    error: Optional[str] = None


@dataclass
class DocumentExtractionResult:
    filename: str
    total_pages: int
    pages: list[PageResult] = field(default_factory=list)
    failed_pages: list[int] = field(default_factory=list)

    @property
    def full_text(self) -> str:
        return "\n\n--- Page Break ---\n\n".join(
            p.text for p in self.pages if p.text
        )

    @property
    def extraction_summary(self) -> dict:
        methods = {}
        for p in self.pages:
            methods[p.method] = methods.get(p.method, 0) + 1
        return {
            "total_pages": self.total_pages,
            "methods": methods,
            "failed_pages": self.failed_pages,
        }


# ── Native text extraction ────────────────────────────────────────────────────

def _extract_native_text(page) -> str:
    """Extract text from a PyMuPDF page object using native extraction."""
    try:
        text = page.get_text("text")
        return text.strip()
    except Exception:
        return ""


def _is_text_sufficient(text: str) -> bool:
    """Rule 2: determine if native extraction yielded enough readable content."""
    if not text:
        return False
    # Strip whitespace and check length
    cleaned = " ".join(text.split())
    return len(cleaned) >= NATIVE_TEXT_MIN_CHARS


# ── Image rendering ───────────────────────────────────────────────────────────

def _render_page_to_base64(page, dpi: int = 200) -> str:
    """Render a PDF page to a base64-encoded PNG for vision models."""
    import fitz
    zoom = dpi / 72.0
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat)
    png_bytes = pix.tobytes("png")
    return base64.b64encode(png_bytes).decode("utf-8")


# ── AI extraction per page ────────────────────────────────────────────────────

async def _extract_via_ocr(
    page_b64: str, filename: str, page_num: int, registry
) -> str:
    """Rule 3: Extract text using dedicated OCR service (OpenAI client)."""
    import openai
    client = registry.get_ocr_client()
    model  = registry.get_ocr_model()

    from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
    system = get_ocr_system_prompt()
    user   = get_ocr_user_prompt()

    max_retries = registry._ocr_cfg.max_retries if registry._ocr_cfg else 3
    for attempt in range(max_retries):
        try:
            def _sync_ocr_call():
                return client.chat.completions.create(
                    timeout=60,
                    model=model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": [
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                            {"type": "text", "text": user},
                        ]},
                    ],
                    max_tokens=4096,
                )
            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_ocr_call)
            return resp.choices[0].message.content or ""
        except openai.RateLimitError:
            if attempt < max_retries - 1:
                await asyncio.sleep(2 ** attempt)
            else:
                raise
        except Exception as e:
            if attempt < max_retries - 1:
                await asyncio.sleep(1)
            else:
                raise


async def _extract_via_vlm(
    page_b64: str, filename: str, page_num: int, registry
) -> str:
    """Rule 4: Extract text using VLM (vision-language model)."""
    import openai
    client = registry.get_vlm_client()
    model  = registry.get_vlm_model()

    from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
    system = get_ocr_system_prompt()
    user   = get_ocr_user_prompt()

    # client may be an OpenAI client (private mode) or a BaseLLMProvider wrapper
    if hasattr(client, 'chat'):
        # OpenAI client — sync SDK, must run in executor
        max_retries = registry._vlm_cfg.max_retries if registry._vlm_cfg else 3
        for attempt in range(max_retries):
            try:
                def _sync_vlm_call():
                    return client.chat.completions.create(
                        timeout=60,
                        model=model,
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user", "content": [
                                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                                {"type": "text", "text": user},
                            ]},
                        ],
                        max_tokens=4096,
                    )
                loop = asyncio.get_running_loop()
                resp = await loop.run_in_executor(None, _sync_vlm_call)
                return resp.choices[0].message.content or ""
            except Exception as e:
                if attempt < max_retries - 1:
                    await asyncio.sleep(1)
                else:
                    raise
    else:
        # BaseLLMProvider (provider_factory path)
        return await client.vision_complete(
            system=system, user_text=user,
            image_b64=page_b64, image_media_type="image/png",
            model=model, max_tokens=4096, temperature=0.1,
        )


async def _extract_via_llm_vision(
    page_b64: str, filename: str, page_num: int, registry
) -> str:
    """Rule 5: LLM vision fallback."""
    llm = registry.get_llm_client()
    model = registry.get_llm_model()

    from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
    system = get_ocr_system_prompt()
    user   = get_ocr_user_prompt()

    if hasattr(llm, 'chat'):
        # OpenAI client — sync SDK, must run in executor
        def _sync_llm_vision_call():
            return llm.chat.completions.create(
                timeout=60,
                model=model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": [
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                        {"type": "text", "text": user},
                    ]},
                ],
                max_tokens=4096,
            )
        loop = asyncio.get_running_loop()
        resp = await loop.run_in_executor(None, _sync_llm_vision_call)
        return resp.choices[0].message.content or ""
    else:
        # BaseLLMProvider (e.g. AnthropicLLMProvider wraps vision)
        try:
            from providers.provider_factory import get_registry as get_provider_registry
            vision = get_provider_registry().vision
            return await vision.vision_complete(
                system=system, user_text=user,
                image_b64=page_b64, image_media_type="image/png",
                model=model, max_tokens=4096, temperature=0.1,
            )
        except Exception:
            raise RuntimeError(
                f"LLM vision fallback failed for page {page_num} of {filename}. "
                "Configure an OCR or VLM service in Admin → Configuration."
            )


# ── Main ingestion entry point ────────────────────────────────────────────────

async def ingest_document(
    file_path: str,
    session_id: str,
    dpi: int = 200,
) -> AsyncGenerator[dict, None]:
    """
    Process a document file from disk, yielding progress events then result.

    Yields dicts:
      {"type": "progress", "page": N, "total": M, "method": "...", "filename": "..."}
      {"type": "result", "filename": "...", "extraction": DocumentExtractionResult}
      {"type": "error", "message": "..."}
    """
    from services.service_registry import get_service_registry
    registry = get_service_registry()
    path = Path(file_path)
    filename = path.name

    try:
        import fitz
        doc = fitz.open(file_path)
    except Exception as e:
        yield {"type": "error", "message": f"Cannot open {filename}: {e}"}
        return

    total_pages = len(doc)
    result = DocumentExtractionResult(filename=filename, total_pages=total_pages)

    for page_idx in range(total_pages):
        page_num = page_idx + 1
        page = doc.load_page(page_idx)

        # Rule 2: Try native text extraction first
        native_text = _extract_native_text(page)
        if _is_text_sufficient(native_text):
            result.pages.append(PageResult(
                page_num=page_num, text=native_text,
                method="native", model=""
            ))
            yield {"type": "progress", "page": page_num, "total": total_pages,
                   "method": "native", "filename": filename}
            continue

        # Page needs AI extraction — render to image
        try:
            page_b64 = _render_page_to_base64(page, dpi=dpi)
        except Exception as e:
            result.pages.append(PageResult(
                page_num=page_num, text=native_text,
                method="failed", model="", error=f"Render failed: {e}"
            ))
            result.failed_pages.append(page_num)
            yield {"type": "progress", "page": page_num, "total": total_pages,
                   "method": "failed", "filename": filename}
            continue

        extractor = registry.get_image_extractor_name()

        try:
            if extractor == "ocr":
                text = await _extract_via_ocr(page_b64, filename, page_num, registry)
                method, model = "ocr", registry.get_ocr_model()

            elif extractor == "vlm":
                text = await _extract_via_vlm(page_b64, filename, page_num, registry)
                method, model = "vlm", registry.get_vlm_model()

            elif extractor == "llm_vision":
                text = await _extract_via_llm_vision(page_b64, filename, page_num, registry)
                method, model = "llm_vision", registry.get_llm_model()

            else:
                # Rule 5 error: no vision capability at all
                raise RuntimeError(
                    f"Page {page_num} requires image extraction but no vision-capable service "
                    "is configured. Add an OCR or VLM service in Admin → Configuration → "
                    "private mode tabs, or ensure your LLM supports vision inputs."
                )

            result.pages.append(PageResult(
                page_num=page_num, text=text, method=method, model=model
            ))
            yield {"type": "progress", "page": page_num, "total": total_pages,
                   "method": method, "filename": filename}

        except Exception as e:
            logger.warning("Page %d extraction failed (%s): %s", page_num, extractor, e)
            # Partial success: mark failed, keep going (never block entire document)
            result.pages.append(PageResult(
                page_num=page_num,
                text=native_text,  # use whatever native text we had
                method="failed", model="",
                error=str(e)
            ))
            result.failed_pages.append(page_num)
            yield {"type": "progress", "page": page_num, "total": total_pages,
                   "method": "failed", "filename": filename}

    doc.close()
    yield {"type": "result", "filename": filename, "extraction": result}


async def ingest_image_file(
    file_path: str,
    session_id: str,
) -> DocumentExtractionResult:
    """
    Process a non-PDF image file (PNG, JPG, TIFF).
    Always routes to OCR → VLM → LLM (Rule 3-5, no native extraction for images).
    """
    from services.service_registry import get_service_registry
    registry = get_service_registry()
    filename = Path(file_path).name

    with open(file_path, "rb") as f:
        img_bytes = f.read()
    page_b64 = base64.b64encode(img_bytes).decode("utf-8")

    extractor = registry.get_image_extractor_name()
    result = DocumentExtractionResult(filename=filename, total_pages=1)

    try:
        if extractor == "ocr":
            text = await _extract_via_ocr(page_b64, filename, 1, registry)
            method, model = "ocr", registry.get_ocr_model()
        elif extractor == "vlm":
            text = await _extract_via_vlm(page_b64, filename, 1, registry)
            method, model = "vlm", registry.get_vlm_model()
        elif extractor == "llm_vision":
            text = await _extract_via_llm_vision(page_b64, filename, 1, registry)
            method, model = "llm_vision", registry.get_llm_model()
        else:
            raise RuntimeError("No vision-capable service configured for image extraction.")

        result.pages.append(PageResult(page_num=1, text=text, method=method, model=model))
    except Exception as e:
        result.pages.append(PageResult(page_num=1, text="", method="failed", model="", error=str(e)))
        result.failed_pages.append(1)

    return result
