"""OCR service for extracting text from PDF documents using Claude vision.

Uses PyMuPDF (fitz) for PDF rendering and the provider abstraction layer for
vision-based text extraction. Retries are handled internally by the provider.
"""

import base64
import logging
from typing import Any, AsyncGenerator

import fitz  # PyMuPDF

from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
from providers.provider_factory import get_registry
from services.config_loader import get_model_config, get_prompt_overrides

logger = logging.getLogger(__name__)


async def ocr_page(page_image_b64: str, config: dict[str, Any]) -> str:
    """Call the vision provider to extract text from a single page image.

    Retries are handled internally by the provider implementation.
    """
    prompt_overrides = get_prompt_overrides()
    system_prompt = get_ocr_system_prompt(
        override=prompt_overrides.get("ocr_system_override")
    )
    user_prompt = get_ocr_user_prompt()

    return await get_registry().get_vision().vision_complete(
        system=system_prompt,
        user_text=user_prompt,
        image_b64=page_image_b64,
        image_media_type="image/png",
        model=config["name"],
        max_tokens=config["max_tokens"],
        temperature=config["temperature"],
    )


async def process_document(
    file_path: str, session_id: str
) -> AsyncGenerator[dict[str, Any], None]:
    """Process a PDF document: render pages and extract text via OCR.

    Opens the PDF, renders each page to a base64 PNG at the configured DPI,
    and calls the vision provider to extract text. Yields progress events and
    finally yields the aggregated result.

    On page failure after retries: logs warning, skips page, continues.
    """
    config = get_model_config()
    dpi = config.get("ocr_dpi", 200)
    filename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path

    doc = fitz.open(file_path)
    total_pages = len(doc)
    page_texts: list[str] = []

    for page_num in range(total_pages):
        yield {
            "type": "progress",
            "page": page_num + 1,
            "total": total_pages,
            "filename": filename,
        }

        try:
            page = doc.load_page(page_num)
            # Render page to pixmap at configured DPI
            zoom = dpi / 72.0
            matrix = fitz.Matrix(zoom, zoom)
            pixmap = page.get_pixmap(matrix=matrix)
            png_bytes = pixmap.tobytes("png")
            page_b64 = base64.b64encode(png_bytes).decode("utf-8")

            text = await ocr_page(page_b64, config)
            page_texts.append(text)
        except Exception as e:
            logger.warning(
                "OCR failed for page %d of %s (session %s) after retries: %s",
                page_num + 1,
                filename,
                session_id,
                str(e),
            )
            # Skip failed page but continue processing
            page_texts.append("")

    doc.close()

    aggregated_text = "\n\n--- Page Break ---\n\n".join(page_texts)
    yield {
        "type": "result",
        "filename": filename,
        "text": aggregated_text,
    }
