"""Export service for generating PDF and DOCX Source of Wealth reports.

Parses the [SECTION]/[NARRATIVE]/[TABLE] structured text format produced by the SOW
generation prompt and renders it into properly formatted PDF and DOCX files.
"""

import io
import logging
import re
from datetime import date
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Inches

logger = logging.getLogger(__name__)

_SOW_GOLD = colors.Color(0.788, 0.659, 0.298)   # #C9A84C
_SOW_DARK = colors.Color(0.12, 0.18, 0.28)       # dark navy
_SOW_GOLD_RGB = RGBColor(0xC9, 0xA8, 0x4C)

# ── Placeholder detection ─────────────────────────────────────────────────────

_PLACEHOLDER_PATTERNS = [
    r"\bthe verified (?:net |annual |gross |monthly |total )?(?:amount|value|income|salary|capital|balance|payment|tax)\b",
    r"\bthe declared (?:annual |monthly |gross |net |total )?(?:amount|value|income|salary|dividend|revenue)\b",
    r"\bthe relevant (?:year|period|date|quarter|month|assessment)\b",
    r"\bthe assessed (?:income|tax|amount|value)\b",
    r"\bthe registered (?:UEN|company|entity|address)\b",
    r"\bthe recorded (?:date|amount|balance|value)\b",
    r"\bthe reported (?:balance|income|amount|value)\b",
    r"\bthe applicable (?:amount|rate|value|period)\b",
    r"\bthe specified (?:amount|value|date|period)\b",
    r"\bthe configured (?:amount|value|model|endpoint)\b",
    r"\bSignificant\b(?=\s+(?:shareholding|equity|stake|interest|ownership))",
]
_PLACEHOLDER_RE = re.compile("|".join(_PLACEHOLDER_PATTERNS), re.IGNORECASE)


def detect_placeholders(text: str) -> list[str]:
    """Return list of placeholder phrases found in text."""
    return [m.group(0) for m in _PLACEHOLDER_RE.finditer(text)]


# ── Structured text parser ────────────────────────────────────────────────────

def _parse_structured_sow(sow_text: str) -> list[dict[str, Any]]:
    """
    Parse [SECTION]/[NARRATIVE]/[TABLE] structured SOW text into a list of blocks.
    Each block is a dict: {type: 'section'|'narrative'|'table', ...}.
    """
    blocks: list[dict] = []
    lines = sow_text.splitlines()
    i = 0

    while i < len(lines):
        line = lines[i].strip()

        # Section start
        m = re.match(r"\[SECTION:\s*(.+?)\]", line)
        if m:
            blocks.append({"type": "section_start", "title": m.group(1).strip()})
            i += 1
            continue

        if line == "[/SECTION]":
            blocks.append({"type": "section_end"})
            i += 1
            continue

        # Narrative block
        if line == "[NARRATIVE]":
            i += 1
            para_lines = []
            while i < len(lines) and lines[i].strip() != "[/NARRATIVE]":
                para_lines.append(lines[i])
                i += 1
            i += 1  # skip [/NARRATIVE]
            text = "\n".join(para_lines).strip()
            if text:
                blocks.append({"type": "narrative", "text": text})
            continue

        # Table block
        if line == "[TABLE]":
            i += 1
            caption = ""
            align: list[str] = []
            headers: list[str] = []
            rows: list[tuple[str, ...]] = []
            total_row: tuple[str, ...] | None = None

            while i < len(lines) and lines[i].strip() != "[/TABLE]":
                tline = lines[i].strip()
                if tline.startswith("CAPTION:"):
                    caption = tline[8:].strip()
                elif tline.startswith("ALIGN:"):
                    align = [a.strip() for a in tline[6:].split(",")]
                elif tline.startswith("HEADERS:"):
                    headers = [h.strip() for h in tline[8:].split("|")]
                elif tline.startswith("ROW:"):
                    rows.append(tuple(c.strip() for c in tline[4:].split("|")))
                elif tline.startswith("TOTAL:"):
                    total_row = tuple(c.strip() for c in tline[6:].split("|"))
                i += 1
            i += 1  # skip [/TABLE]

            if headers or rows:
                blocks.append({
                    "type": "table",
                    "caption": caption,
                    "align": align,
                    "headers": headers,
                    "rows": rows,
                    "total": total_row,
                })
            continue

        # Skip delimiter-only lines
        if line in ("[/NARRATIVE]", "[/TABLE]", "[/SECTION]", ""):
            i += 1
            continue

        # Plain text outside structured blocks (shouldn't occur, but handle gracefully)
        if line and not line.startswith("["):
            blocks.append({"type": "narrative", "text": line})

        i += 1

    return blocks


# ── PDF generation ────────────────────────────────────────────────────────────

def _build_pdf_styles() -> dict:
    base = getSampleStyleSheet()
    return {
        "h1": ParagraphStyle(
            "SOWH1", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=13,
            spaceBefore=14, spaceAfter=6,
            textColor=_SOW_DARK,
        ),
        "caption": ParagraphStyle(
            "SOWCaption", parent=base["Normal"],
            fontName="Helvetica-Oblique", fontSize=9,
            spaceBefore=6, spaceAfter=3,
            textColor=colors.Color(0.4, 0.4, 0.4),
        ),
        "body": ParagraphStyle(
            "SOWBody", parent=base["Normal"],
            fontName="Helvetica", fontSize=10,
            leading=14, spaceBefore=2, spaceAfter=5,
        ),
        "th": ParagraphStyle(
            "SOWTableHead", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=9,
            textColor=colors.white,
        ),
        "td": ParagraphStyle(
            "SOWTableCell", parent=base["Normal"],
            fontName="Helvetica", fontSize=9,
            leading=12,
        ),
        "td_right": ParagraphStyle(
            "SOWTableCellRight", parent=base["Normal"],
            fontName="Helvetica", fontSize=9,
            leading=12, alignment=TA_RIGHT,
        ),
        "td_total": ParagraphStyle(
            "SOWTableTotal", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=9,
            leading=12,
        ),
        "td_total_right": ParagraphStyle(
            "SOWTableTotalRight", parent=base["Normal"],
            fontName="Helvetica-Bold", fontSize=9,
            leading=12, alignment=TA_RIGHT,
        ),
    }


_ALIGN_MAP = {"left": TA_LEFT, "right": TA_RIGHT, "center": TA_CENTER}


def _build_pdf_table(block: dict, styles: dict, page_width: float) -> list:
    """Convert a parsed table block into ReportLab Table flowables."""
    headers = block.get("headers", [])
    rows = block.get("rows", [])
    total = block.get("total")
    align_spec = block.get("align", [])
    caption = block.get("caption", "")
    n_cols = max(len(headers), max((len(r) for r in rows), default=0))
    if total:
        n_cols = max(n_cols, len(total))

    # Pad align spec
    while len(align_spec) < n_cols:
        align_spec.append("left")

    def _cell_style(col: int, is_total: bool = False) -> ParagraphStyle:
        a = align_spec[col] if col < len(align_spec) else "left"
        if is_total:
            return styles["td_total_right"] if a == "right" else styles["td_total"]
        return styles["td_right"] if a == "right" else styles["td"]

    def _pad(row: tuple, n: int) -> list:
        lst = list(row)
        while len(lst) < n:
            lst.append("")
        return lst[:n]

    table_data = []
    # Header row
    if headers:
        table_data.append([Paragraph(h, styles["th"]) for h in _pad(tuple(headers), n_cols)])

    # Data rows
    for row in rows:
        table_data.append([
            Paragraph(v, _cell_style(ci)) for ci, v in enumerate(_pad(row, n_cols))
        ])

    # Total row
    if total:
        table_data.append([
            Paragraph(v, _cell_style(ci, is_total=True))
            for ci, v in enumerate(_pad(total, n_cols))
        ])

    if not table_data:
        return []

    # Column widths: first col wider, rest equal
    available = page_width - 4 * cm
    if n_cols == 1:
        col_widths = [available]
    elif n_cols == 2:
        col_widths = [available * 0.55, available * 0.45]
    elif n_cols == 3:
        col_widths = [available * 0.45, available * 0.30, available * 0.25]
    else:
        col_widths = [available / n_cols] * n_cols

    ts = TableStyle([
        # Header styling
        ("BACKGROUND", (0, 0), (-1, 0), _SOW_DARK),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.Color(0.96, 0.97, 0.99)]),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.Color(0.8, 0.8, 0.8)),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ])

    # Total row styling
    if total:
        last = len(table_data) - 1
        ts.add("BACKGROUND", (0, last), (-1, last), colors.Color(0.93, 0.94, 0.97))
        ts.add("LINEABOVE", (0, last), (-1, last), 1, _SOW_DARK)
        ts.add("FONTNAME", (0, last), (-1, last), "Helvetica-Bold")

    tbl = Table(table_data, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(ts)

    result = []
    if caption:
        result.append(Paragraph(caption, styles["caption"]))
    result.append(tbl)
    result.append(Spacer(1, 4 * mm))
    return result


def _draw_header_footer(canvas, doc, session_id: str, report_ref: str):
    canvas.saveState()
    width, height = A4

    # Header bar
    canvas.setFillColor(_SOW_DARK)
    canvas.rect(0, height - 2.2 * cm, width, 2.2 * cm, fill=1, stroke=0)

    canvas.setFillColor(colors.white)
    canvas.setFont("Helvetica-Bold", 10)
    canvas.drawString(2 * cm, height - 1.0 * cm, "SOURCE OF WEALTH REPORT")
    canvas.setFont("Helvetica", 9)
    canvas.drawRightString(width - 2 * cm, height - 1.0 * cm, date.today().strftime("%d %B %Y"))
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(_SOW_GOLD)
    canvas.drawString(2 * cm, height - 1.7 * cm, "PRIVATE & CONFIDENTIAL")
    canvas.drawRightString(width - 2 * cm, height - 1.7 * cm, report_ref)

    # Diagonal watermark
    canvas.setFont("Helvetica-Bold", 55)
    canvas.setFillColor(colors.Color(0.93, 0.93, 0.93))
    canvas.saveState()
    canvas.translate(width / 2, height / 2)
    canvas.rotate(35)
    canvas.drawCentredString(0, 0, "CONFIDENTIAL")
    canvas.restoreState()

    # Footer
    canvas.setFillColor(colors.Color(0.8, 0.8, 0.8))
    canvas.rect(0, 0, width, 1.6 * cm, fill=1, stroke=0)
    canvas.setFillColor(colors.Color(0.3, 0.3, 0.3))
    canvas.setFont("Helvetica", 8)
    canvas.drawCentredString(width / 2, 0.6 * cm, f"Page {doc.page}")
    canvas.drawString(2 * cm, 0.6 * cm, "MAS Notice SFA 04-N13 — Source of Wealth Assessment")
    canvas.drawRightString(width - 2 * cm, 0.6 * cm, f"Ref: {session_id[:12].upper()}")

    canvas.restoreState()


def _blocks_to_flowables(
    blocks: list[dict], styles: dict, page_width: float
) -> list:
    """Convert parsed blocks into ReportLab flowables."""
    flowables = []
    section_count = 0

    for block in blocks:
        btype = block["type"]

        if btype == "section_start":
            section_count += 1
            if section_count > 1:
                flowables.append(PageBreak())
            title = block["title"]
            flowables.append(Paragraph(
                f"{section_count}. {title}",
                styles["h1"],
            ))
            flowables.append(Spacer(1, 3 * mm))

        elif btype == "section_end":
            flowables.append(Spacer(1, 4 * mm))

        elif btype == "narrative":
            for para in block["text"].split("\n\n"):
                para = para.strip()
                if para:
                    # Replace single newlines with space within a paragraph
                    para = re.sub(r"\n", " ", para)
                    flowables.append(Paragraph(para, styles["body"]))
            flowables.append(Spacer(1, 2 * mm))

        elif btype == "table":
            flowables.extend(_build_pdf_table(block, styles, page_width))

    return flowables


def generate_pdf(
    sow_text: str, session_id: str, profile_type: str, client_name: str
) -> bytes:
    """Generate a branded PDF Source of Wealth report from structured SOW text."""
    # Detect placeholders before rendering
    found = detect_placeholders(sow_text)
    if found:
        logger.warning(
            "generate_pdf: %d placeholder(s) detected in SOW text before rendering: %s",
            len(found), found[:5],
        )

    buffer = io.BytesIO()
    width, height = A4
    styles = _build_pdf_styles()

    report_ref = "SOW-" + session_id[:8].upper()

    frame = Frame(
        2 * cm, 1.8 * cm,
        width - 4 * cm, height - 4.2 * cm,
        id="main",
    )

    def on_page(canvas, doc):
        _draw_header_footer(canvas, doc, session_id, report_ref)

    page_template = PageTemplate(id="main", frames=[frame], onPage=on_page)
    doc = BaseDocTemplate(
        buffer, pagesize=A4,
        title=f"SOW Report — {client_name}",
        author="SOW Compliance Portal",
    )
    doc.addPageTemplates([page_template])

    # Title block on first page
    flowables: list = []
    flowables.append(Spacer(1, 6 * mm))
    flowables.append(Paragraph(f"Applicant: {client_name}", styles["body"]))
    flowables.append(Paragraph(f"Profile: {profile_type.title()}", styles["body"]))
    flowables.append(Paragraph(f"Report Reference: {report_ref}", styles["body"]))
    flowables.append(Paragraph(f"Date: {date.today().strftime('%d %B %Y')}", styles["body"]))
    flowables.append(Spacer(1, 8 * mm))

    # Parse structured text and render
    blocks = _parse_structured_sow(sow_text)
    if blocks:
        flowables.extend(_blocks_to_flowables(blocks, styles, width))
    else:
        # Fallback: render plain text if structured format not detected
        logger.warning("generate_pdf: no structured blocks found, falling back to plain text render")
        for line in sow_text.splitlines():
            stripped = line.strip()
            if stripped:
                flowables.append(Paragraph(stripped, styles["body"]))

    doc.build(flowables)
    return buffer.getvalue()


# ── DOCX generation ───────────────────────────────────────────────────────────

def _add_docx_table(document: Document, block: dict):
    """Add a formatted table to the DOCX document."""
    headers = block.get("headers", [])
    rows = block.get("rows", [])
    total = block.get("total")
    caption = block.get("caption", "")
    align_spec = block.get("align", [])

    if caption:
        p = document.add_paragraph(caption)
        p.runs[0].font.italic = True
        p.runs[0].font.size = Pt(9)
        p.runs[0].font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    n_cols = max(len(headers), max((len(r) for r in rows), default=0))
    if total:
        n_cols = max(n_cols, len(total))
    if n_cols == 0:
        return

    all_rows = []
    if headers:
        all_rows.append(list(headers) + [""] * (n_cols - len(headers)))
    for row in rows:
        all_rows.append(list(row) + [""] * (n_cols - len(row)))
    if total:
        all_rows.append(list(total) + [""] * (n_cols - len(total)))

    tbl = document.add_table(rows=len(all_rows), cols=n_cols)
    tbl.style = "Table Grid"

    for ri, row_data in enumerate(all_rows):
        tr = tbl.rows[ri]
        is_header = ri == 0 and bool(headers)
        is_total = total and ri == len(all_rows) - 1
        for ci, cell_val in enumerate(row_data):
            cell = tr.cells[ci]
            p = cell.paragraphs[0]
            run = p.add_run(str(cell_val))
            run.font.size = Pt(9)
            run.font.bold = is_header or bool(is_total)
            if is_header:
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                # Dark background via XML shading
                tc = cell._tc
                tcPr = tc.get_or_add_tcPr()
                shd = OxmlElement("w:shd")
                shd.set(qn("w:val"), "clear")
                shd.set(qn("w:color"), "auto")
                shd.set(qn("w:fill"), "1E2D47")
                tcPr.append(shd)
            # Alignment
            a = align_spec[ci] if ci < len(align_spec) else "left"
            if a == "right":
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif a == "center":
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

    document.add_paragraph()


def generate_docx(
    sow_text: str, session_id: str, profile_type: str, client_name: str
) -> bytes:
    """Generate a branded DOCX Source of Wealth report from structured SOW text."""
    found = detect_placeholders(sow_text)
    if found:
        logger.warning(
            "generate_docx: %d placeholder(s) detected: %s", len(found), found[:5]
        )

    document = Document()

    # Header
    for section in document.sections:
        header = section.header
        header.is_linked_to_previous = False
        hp = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        hp.clear()
        run = hp.add_run("SOURCE OF WEALTH REPORT  —  PRIVATE & CONFIDENTIAL")
        run.font.size = Pt(9)
        run.font.bold = True
        run.font.color.rgb = _SOW_GOLD_RGB
        hp.alignment = WD_ALIGN_PARAGRAPH.CENTER

        # Footer
        footer = section.footer
        footer.is_linked_to_previous = False
        fp = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        fp.clear()
        frun = fp.add_run(f"SOW-{session_id[:8].upper()}  |  MAS Notice SFA 04-N13  |  ")
        frun.font.size = Pt(8)
        # page number field
        r = fp.add_run()
        fldC = OxmlElement("w:fldChar")
        fldC.set(qn("w:fldCharType"), "begin")
        r._r.append(fldC)
        r2 = fp.add_run()
        instrT = OxmlElement("w:instrText")
        instrT.text = "PAGE"
        r2._r.append(instrT)
        r3 = fp.add_run()
        fldC2 = OxmlElement("w:fldChar")
        fldC2.set(qn("w:fldCharType"), "end")
        r3._r.append(fldC2)
        fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT

    # Title block
    p = document.add_paragraph()
    run = p.add_run("Source of Wealth Report")
    run.font.size = Pt(16)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1E, 0x2D, 0x47)
    document.add_paragraph(f"Applicant: {client_name}").runs[0].font.size = Pt(11)
    document.add_paragraph(f"Profile: {profile_type.title()}").runs[0].font.size = Pt(11)
    document.add_paragraph(f"Report Reference: SOW-{session_id[:8].upper()}").runs[0].font.size = Pt(11)
    document.add_paragraph(f"Date: {date.today().strftime('%d %B %Y')}").runs[0].font.size = Pt(11)
    document.add_paragraph()

    # Parse and render blocks
    blocks = _parse_structured_sow(sow_text)
    section_count = 0

    for block in blocks:
        btype = block["type"]

        if btype == "section_start":
            section_count += 1
            p = document.add_paragraph()
            run = p.add_run(f"{section_count}. {block['title']}")
            run.font.size = Pt(13)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0x1E, 0x2D, 0x47)

        elif btype == "narrative":
            for para in block["text"].split("\n\n"):
                para = para.strip()
                if para:
                    p = document.add_paragraph(re.sub(r"\n", " ", para))
                    p.runs[0].font.size = Pt(10) if p.runs else None

        elif btype == "table":
            _add_docx_table(document, block)

    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()
