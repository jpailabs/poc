"""Field extraction service for financial documents.

Takes OCR text from multiple documents and extracts structured fields
using a single LLM call with JSON schema guidance.
"""

import json
import logging
import uuid
from enum import Enum
from typing import Any

from providers.provider_factory import get_registry
from services.config_loader import get_model_config, get_prompt_overrides

logger = logging.getLogger(__name__)


class Category(str, Enum):
    """Categories for extracted financial document fields."""

    EMPLOYMENT_INCOME = "EMPLOYMENT_INCOME"
    TAX_DOCUMENTS = "TAX_DOCUMENTS"
    SHAREHOLDING = "SHAREHOLDING"
    DIVIDENDS = "DIVIDENDS"
    INVESTMENTS = "INVESTMENTS"
    BANK_SAVINGS = "BANK_SAVINGS"
    IDENTITY = "IDENTITY"
    OTHER_FINANCIAL = "OTHER_FINANCIAL"


# JSON schema describing the expected extraction output
_EXTRACTION_SCHEMA = {
    "type": "object",
    "description": "Extracted fields grouped by financial category.",
    "additionalProperties": {
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Field name/label"},
                "value": {
                    "type": "string",
                    "description": "Extracted value as a string",
                },
                "confidence": {
                    "type": "number",
                    "minimum": 0,
                    "maximum": 1,
                    "description": "Confidence score 0-1",
                },
                "source_file": {
                    "type": "string",
                    "description": "Filename the field was extracted from",
                },
                "source_page": {
                    "type": "integer",
                    "description": "Page number (1-indexed) where the field was found",
                },
            },
            "required": ["key", "value", "confidence", "source_file"],
        },
    },
}

_VALID_CATEGORIES = {c.value for c in Category}


def _build_extraction_prompt(text_corpus: dict[str, str]) -> str:
    """Build the user prompt containing all document texts and the JSON schema."""
    categories_list = ", ".join(_VALID_CATEGORIES)

    documents_section = ""
    for filename, text in text_corpus.items():
        documents_section += f"\n\n=== DOCUMENT: {filename} ===\n{text}"

    return (
        f"Extract all relevant financial fields from the following documents.\n\n"
        f"Categorize each field into one of these categories: {categories_list}\n\n"
        f"Return a JSON object where each key is a category name and the value is "
        f"an array of extracted fields matching this schema:\n"
        f"```json\n{json.dumps(_EXTRACTION_SCHEMA, indent=2)}\n```\n\n"
        f"Documents:{documents_section}\n\n"
        f"Return ONLY valid JSON. No explanation, no markdown fences."
    )


def _get_system_prompt() -> str:
    """Return the extraction system prompt, applying any override from config."""
    overrides = get_prompt_overrides()
    override = overrides.get("extraction_system_override")
    if override:
        return override
    return (
        "You are a financial document data extraction specialist. "
        "Extract structured fields from OCR text with high accuracy. "
        "Always return valid JSON matching the requested schema. "
        "Include confidence scores reflecting extraction certainty."
    )


def _parse_extraction_response(raw: str) -> dict[str, Any] | None:
    """Attempt to parse the LLM response as JSON.

    Handles cases where the model wraps JSON in markdown code fences.
    Returns None if parsing fails.
    """
    text = raw.strip()
    # Strip markdown code fences if present
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first line (```json or ```) and last line (```)
        lines = [l for l in lines[1:] if not l.strip().startswith("```")]
        text = "\n".join(lines)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _enrich_fields(
    parsed: dict[str, Any], extraction_id: str
) -> dict[str, list[dict[str, Any]]]:
    """Add unique IDs to each field and filter to valid categories.

    Returns a clean dict with only valid category keys.
    """
    result: dict[str, list[dict[str, Any]]] = {}

    for category, fields in parsed.items():
        # Normalize category name
        cat_upper = category.upper().replace(" ", "_")
        if cat_upper not in _VALID_CATEGORIES:
            # Put unrecognized categories under OTHER_FINANCIAL
            cat_upper = Category.OTHER_FINANCIAL.value

        if cat_upper not in result:
            result[cat_upper] = []

        if not isinstance(fields, list):
            continue

        for field in fields:
            if not isinstance(field, dict):
                continue
            enriched = {
                "id": str(uuid.uuid4()),
                "key": field.get("key", ""),
                "value": field.get("value", ""),
                "confidence": field.get("confidence", 0.0),
                "source_file": field.get("source_file", ""),
                "source_page": field.get("source_page"),
            }
            result[cat_upper].append(enriched)

    return result


async def classify_document_type(text_corpus: dict[str, str], session_id: str) -> list[str]:
    """
    Classify the document into one or more types from the 29-type taxonomy.
    Returns a list of matching DOCUMENT_TYPES values.
    """
    from services.service_registry import get_service_registry
    from prompts.extraction_prompt import get_classification_system_prompt, get_classification_user_prompt

    registry = get_service_registry()
    sample_text = ""
    for fname, text in text_corpus.items():
        sample_text += f"\n--- {fname} ---\n{text[:2000]}\n"
        if len(sample_text) > 5000:
            break

    system_prompt = get_classification_system_prompt()
    user_prompt = get_classification_user_prompt(sample_text)

    try:
        raw_text = await _call_llm_for_extraction(registry, system_prompt, user_prompt, session_id)
        import re as _re
        raw_text = _re.sub(r"```json\s*", "", raw_text)
        raw_text = _re.sub(r"```\s*", "", raw_text)
        parsed = json.loads(raw_text.strip())
        doc_types = parsed.get("doc_types", parsed.get("doc_type", ["UNKNOWN"]))
        if isinstance(doc_types, str):
            doc_types = [doc_types]
        return [t for t in doc_types if t]
    except Exception as e:
        logger.warning("Document classification failed: %s", e)
        return ["UNKNOWN"]


async def extract_fields(
    text_corpus: dict[str, str],
    session_id: str,
    doc_categories: dict[str, str] | None = None,
    profile_type: str | None = None,
    emitter=None,
) -> dict[str, Any]:
    """
    Universal field extraction with secondary passes for specific document types.
    Uses RAG when vectorisation is available. Returns enriched fields grouped by category.
    emitter: optional PipelineStatusEmitter — used to emit intermediate status events.
    """
    from services.service_registry import get_service_registry
    from prompts.extraction_prompt import (
        get_extraction_system_prompt, get_extraction_user_prompt,
        get_secondary_extraction_prompt, CATEGORY_TO_DISPLAY
    )
    registry = get_service_registry()
    extraction_id = str(uuid.uuid4())

    def _emit(event):
        if emitter is not None:
            try:
                emitter.emit(event)
            except Exception:
                pass

    # Step 1: Determine primary category from frontend metadata
    primary_category = None
    if doc_categories:
        for fname in text_corpus.keys():
            cat = doc_categories.get(fname) or doc_categories.get(fname.rsplit("/", 1)[-1])
            if cat:
                primary_category = cat
                break
        if not primary_category:
            for cat_val in doc_categories.values():
                if cat_val:
                    primary_category = cat_val
                    break

    # Step 1: Classify document type.
    # Skip the LLM classify call when we already know the category from the frontend
    # — this saves one full LLM round-trip (30-120 s on private providers).
    if primary_category:
        from prompts.extraction_prompt import get_strategy_for_category
        cat_strategy = get_strategy_for_category(primary_category)
        cat_doc_type = cat_strategy.get("doc_type", "")
        if cat_doc_type and cat_doc_type != "UNKNOWN":
            doc_types = [cat_doc_type]
            logger.debug("extract_fields: skipping classify — category hint=%s → %s", primary_category, cat_doc_type)
        else:
            doc_types = await classify_document_type(text_corpus, session_id)
    else:
        doc_types = await classify_document_type(text_corpus, session_id)

    doc_type_str = doc_types[0] if doc_types else "UNKNOWN"
    logger.debug("extract_fields: doc_types=%s", doc_types)

    # Step 2: build context (vectorised if available)
    context_text = ""
    if registry.capabilities.has_vectorisation:
        context_text = await _build_vectorised_context(text_corpus, session_id, registry)
    if not context_text:
        for fname, text in text_corpus.items():
            context_text += f"\n\n=== DOCUMENT: {fname} ===\n{text}"

    # Step 3: universal extraction pass
    from services.pipeline_status import StatusEvent
    _emit(StatusEvent(
        stage="field_extraction", message="Extracting fields from documents...",
        progress=75, service="LLM", model=registry.get_llm_model(),
    ))
    system_prompt = get_extraction_system_prompt()
    user_prompt = get_extraction_user_prompt(
        {"context": context_text[:10000]},
        category_id=primary_category,
        profile_type=profile_type,
    )

    logger.warning("extract_fields: calling LLM (model=%s, prompt_len=%d)",
                   registry.get_llm_model(), len(user_prompt))
    try:
        raw_text = await _call_llm_for_extraction(registry, system_prompt, user_prompt, session_id)
    except Exception as e:
        logger.error("Universal extraction LLM call failed: %s", e)
        _emit(StatusEvent(
            stage="field_extraction",
            message=f"LLM extraction failed: {type(e).__name__} — check provider config",
            progress=75, service="LLM", model=registry.get_llm_model(), is_error=True,
        ))
        return {"extraction_id": extraction_id, "session_id": session_id,
                "categories": {}, "doc_type": doc_type_str, "doc_types": doc_types,
                "total_fields": 0}
    logger.warning("extract_fields: LLM responded (%d chars). Preview: %s",
                   len(raw_text or ""), (raw_text or "")[:300])

    all_fields = _parse_universal_response(raw_text, extraction_id)

    # Also include doc types derived from the known category
    if primary_category:
        from prompts.extraction_prompt import get_strategy_for_category
        cat_strategy = get_strategy_for_category(primary_category)
        cat_doc_type = cat_strategy.get("doc_type", "")
        if cat_doc_type and cat_doc_type != "UNKNOWN" and cat_doc_type not in doc_types:
            doc_types = [cat_doc_type] + doc_types

    # Step 4: secondary passes for specific doc types
    full_text = "\n\n".join(text_corpus.values())
    for doc_type in doc_types:
        secondary_prompt = get_secondary_extraction_prompt(doc_type, full_text)
        if not secondary_prompt:
            continue
        _emit(StatusEvent(
            stage="field_extraction", message=f"Running detailed extraction for {doc_type}...",
            progress=85, service="LLM", model=registry.get_llm_model(),
        ))
        logger.debug("extract_fields: secondary pass for %s", doc_type)
        try:
            sec_raw = await _call_llm_for_extraction(
                registry,
                get_extraction_system_prompt(),
                secondary_prompt,
                session_id
            )
            secondary_fields = _parse_universal_response(sec_raw, extraction_id)
            # Merge — secondary fields override universal on same field_name
            existing_names = {f.get("key", f.get("field_name", "")): i
                              for i, f in enumerate(all_fields)}
            for sf in secondary_fields:
                name = sf.get("key", sf.get("field_name", ""))
                if name in existing_names:
                    all_fields[existing_names[name]] = sf  # override
                else:
                    all_fields.append(sf)
                    existing_names[name] = len(all_fields) - 1
            logger.debug("extract_fields: secondary pass done (%d fields merged)", len(secondary_fields))
        except Exception as e:
            logger.warning("Secondary extraction failed for %s: %s", doc_type, e)

    # Step 5: group into categories for the review section
    categories = _group_fields_into_categories(all_fields)

    return {
        "extraction_id": extraction_id,
        "session_id": session_id,
        "categories": categories,
        "doc_type": doc_type_str,
        "doc_types": doc_types,
        "total_fields": sum(len(v) for v in categories.values()),
    }


def _parse_universal_response(raw_text: str, extraction_id: str) -> list[dict]:
    """Parse the universal extraction JSON response into a flat list of field dicts.

    Handles:
    - Markdown code fences (```json ... ```)
    - Thinking-model <think>...</think> blocks (qwen3, deepseek-r1, etc.)
    - Both {"fields": [...]} and flat list [] structures
    - Mixed key names: field_name/key, raw_value/value
    """
    import re as _re

    if not raw_text or not raw_text.strip():
        logger.warning("_parse_universal_response: received empty response")
        return []

    cleaned = raw_text

    # Strip <think>...</think> blocks produced by reasoning/thinking models
    cleaned = _re.sub(r"<think>.*?</think>", "", cleaned, flags=_re.DOTALL)

    # Strip markdown code fences
    cleaned = _re.sub(r"```json\s*", "", cleaned)
    cleaned = _re.sub(r"```\s*", "", cleaned)
    cleaned = cleaned.strip()

    if not cleaned:
        logger.warning("_parse_universal_response: response was empty after stripping think/fences. Raw: %s", raw_text[:200])
        return []

    # Find the first JSON object/array in the cleaned text (in case there's preamble)
    json_match = _re.search(r'(\{|\[)', cleaned)
    if json_match:
        cleaned = cleaned[json_match.start():]

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.warning("_parse_universal_response: JSON parse failed: %s. First 500 chars of response: %s",
                       e, raw_text[:500])
        return []

    # Support {"fields": [...]} or a top-level list
    if isinstance(parsed, list):
        fields_raw = parsed
    elif isinstance(parsed, dict):
        fields_raw = parsed.get("fields", [])
        # Also try top-level keys that are lists of field dicts
        if not fields_raw:
            for v in parsed.values():
                if isinstance(v, list) and v and isinstance(v[0], dict):
                    fields_raw = v
                    break
    else:
        logger.warning("_parse_universal_response: unexpected parsed type %s", type(parsed))
        return []

    if not isinstance(fields_raw, list):
        logger.warning("_parse_universal_response: fields is not a list: %s", type(fields_raw))
        return []

    result = []
    for f in fields_raw:
        if not isinstance(f, dict):
            continue
        field_name = f.get("field_name") or f.get("key", "")
        value = f.get("raw_value") or f.get("value", "")
        if not field_name or value is None:
            continue
        # Allow zero / false-y numeric values — only skip truly missing values
        if value == "" and not isinstance(value, (int, float)):
            continue
        result.append({
            "id": str(uuid.uuid4()),
            "key": field_name,
            "value": str(value),
            "display_label": f.get("display_label", field_name.replace("_", " ").title()),
            "normalised_value": f.get("normalised_value", str(value)),
            "currency": f.get("currency"),
            "confidence": f.get("confidence", 0.75) if isinstance(f.get("confidence"), (int, float))
                          else (0.95 if f.get("confidence") == "high"
                                else (0.7 if f.get("confidence") == "medium" else 0.4)),
            "source_file": f.get("source_file", ""),
            "source_page": f.get("page_number") or f.get("source_page", 1),
            "source_snippet": f.get("source_snippet", ""),
            "display_category": f.get("display_category", "Other Wealth Sources"),
        })

    logger.warning("_parse_universal_response: parsed %d fields from %d-char response",
                   len(result), len(raw_text))
    return result


def _group_fields_into_categories(fields: list[dict]) -> dict[str, list[dict]]:
    """Group flat field list into category dict for the review section."""
    from prompts.extraction_prompt import REVIEW_DISPLAY_CATEGORIES
    groups: dict[str, list] = {cat: [] for cat in REVIEW_DISPLAY_CATEGORIES}
    groups["Other Wealth Sources"] = groups.get("Other Wealth Sources", [])

    for f in fields:
        cat = f.get("display_category", "Other Wealth Sources")
        if cat not in groups:
            cat = "Other Wealth Sources"
        groups[cat].append(f)

    # Remove empty groups and convert to expected format for session_states
    # Convert from display category names back to internal keys for compatibility
    result = {}
    cat_key_map = {
        "Personal & Identity": "IDENTITY",
        "Employment Income": "EMPLOYMENT_INCOME",
        "Tax & Assessment": "TAX_DOCUMENTS",
        "Business & Corporate Income": "BUSINESS",
        "Investment Portfolio": "INVESTMENTS",
        "Property & Real Estate": "PROPERTY",
        "Banking & Cash": "BANK_SAVINGS",
        "Dividends & Shareholdings": "DIVIDENDS",
        "Other Wealth Sources": "OTHER_FINANCIAL",
        "CPF & Retirement": "CPF",
    }
    for display_cat, field_list in groups.items():
        if field_list:
            key = cat_key_map.get(display_cat, display_cat.upper().replace(" ", "_"))
            result[key] = field_list

    return result


async def _call_llm_for_extraction(registry, system_prompt: str, user_prompt: str, session_id: str) -> str:
    """
    Call the LLM for field extraction.

    Both the OpenAI-compatible SDK and the Anthropic SDK use synchronous
    blocking HTTP clients. Running them directly in an async function blocks
    the event loop, freezing SSE delivery and making the UI appear stuck.

    We wrap synchronous calls in run_in_executor so the event loop stays free,
    and enforce a 120-second hard timeout so a hung/overloaded API unblocks
    the pipeline automatically.
    """
    import asyncio as _asyncio
    from services.config_loader import get_model_config
    cfg    = get_model_config()
    client = registry.get_llm_client()
    model  = registry.get_llm_model()
    max_tokens  = cfg.get("max_tokens", 4096)
    temperature = cfg.get("temperature", 0.2)

    # Use the async LLM provider (httpx-based, 60 s timeout) instead of the sync
    # openai.OpenAI SDK. The sync SDK ignores per-request timeouts when the server
    # uses HTTP chunked encoding, causing threads to hang indefinitely and exhaust
    # the ThreadPoolExecutor pool — freezing all subsequent pipeline operations.
    async_llm = registry.get_async_llm()
    return await async_llm.complete(
        system=system_prompt,
        user=user_prompt,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
    )


async def _build_vectorised_context(
    text_corpus: dict[str, str], session_id: str, registry
) -> str:
    """
    Rule 6+7: chunk, embed, search, and optionally rerank to build
    the most relevant context for field extraction.
    """
    from services.vector_store import get_vector_store

    store = get_vector_store(session_id)

    # Add all document pages to vector store
    for fname, text in text_corpus.items():
        # text_corpus keys are filenames; try to infer page info
        page_num = 1
        await store.add_document(text, fname, page_num)

    if not store.chunks:
        return ""

    # Search for relevant chunks per major field category
    category_queries = [
        "name date of birth nationality identity",
        "income salary employment employer",
        "bank account balance transactions",
        "property asset valuation ownership",
        "shares company shareholding director",
        "tax assessment income tax payable",
        "investments portfolio securities",
        "dividends dividend payment",
    ]

    # Collect all unique candidates from all queries first
    all_candidates: list[dict] = []
    seen_texts: set[str] = set()
    for query in category_queries:
        results = await store.search(query, top_k=4)
        for r in results:
            if r["text"] not in seen_texts:
                seen_texts.add(r["text"])
                all_candidates.append(r)

    if not all_candidates:
        return ""

    # Single batch rerank (Rule 7) — one HTTP request for all candidates
    if registry.capabilities.has_reranker:
        combined_query = " ".join(category_queries)
        all_results = await store.rerank_batch(combined_query, all_candidates, top_k=30)
    else:
        all_results = all_candidates

    # Build context string with source references
    context = ""
    for r in all_results[:30]:  # cap at 30 chunks to stay within token limit
        context += (f"\n--- Source: {r['source_file']} p.{r['page_num']} ---\n{r['text']}\n")

    logger.info("Vectorised context: %d chunks for session %s", len(all_results), session_id)
    return context


def _build_extraction_prompt_with_doctype(context: str, doc_type: str) -> str:
    """Build extraction user prompt including document type hint."""
    categories_list = ", ".join(_VALID_CATEGORIES)
    return (
        f"Document type detected: {doc_type}\n\n"
        f"Extract all relevant financial and identity fields from the following document content.\n"
        f"Categorize each field into one of: {categories_list}\n\n"
        f"Return a JSON object where each key is a category name and the value is "
        f"an array of extracted fields matching this schema:\n"
        f"```json\n{json.dumps(_EXTRACTION_SCHEMA, indent=2)}\n```\n\n"
        f"Document content:\n{context}\n\n"
        f"Return ONLY valid JSON. No explanation, no markdown fences."
    )
