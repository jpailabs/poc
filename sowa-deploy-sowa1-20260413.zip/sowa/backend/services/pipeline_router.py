"""
Pipeline Router — selects Pipeline A (private) or Pipeline B (native)
based on the current provider_mode from config.

This is the single entry point every document processing request flows through.
The caller never knows which pipeline is running underneath.
"""
from __future__ import annotations

import logging
import uuid
from typing import AsyncGenerator, Optional

logger = logging.getLogger(__name__)

PRIVATE_MODE = "private"
INTERNAL_VLLM_MODE = "internal_vllm"  # Also uses specialist services


async def process_document(
    session_id: str,
    files: list[str],           # list of file paths on disk
    profile_type: str = "salaried",
) -> AsyncGenerator[dict, None]:
    """
    Top-level document processing entry point.

    Reads provider_mode from config, selects Pipeline A or B, and streams
    status + result events back to the caller.

    Yields dicts of the form:
      {"type": "status", "message": ..., "progress": ..., ...}   — status updates
      {"type": "progress", ...}                                    — per-page progress (legacy compat)
      {"type": "category_complete", ...}                           — field category done
      {"type": "complete", "extraction_id": ..., ...}              — final result
      {"type": "info", "message": ...}                             — informational
      {"type": "error", "message": ...}                            — error
    """
    # Read provider mode fresh on every request — never cache at request level
    try:
        from services.config_manager import get_config_manager
        provider_mode = get_config_manager().get_provider_mode()
    except Exception:
        from services.config_loader import get_provider_mode
        provider_mode = get_provider_mode()

    job_id = str(uuid.uuid4())
    logger.info(
        "[PipelineRouter] session=%s job=%s provider_mode=%s files=%d",
        session_id[:8], job_id[:8], provider_mode, len(files)
    )

    if provider_mode in (PRIVATE_MODE, INTERNAL_VLLM_MODE):
        logger.info("[PipelineRouter] → Pipeline A (Private/Specialist)")
        from services.private_pipeline import PrivatePipeline
        pipeline = PrivatePipeline(session_id, job_id, profile_type)
    else:
        logger.info("[PipelineRouter] → Pipeline B (Native: %s)", provider_mode)
        from services.native_pipeline import NativePipeline
        pipeline = NativePipeline(session_id, job_id, provider_mode, profile_type)

    async for event in pipeline.run(files):
        yield event
