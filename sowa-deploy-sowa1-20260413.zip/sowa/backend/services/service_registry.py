"""
Service Registry — single source of truth for AI service routing.

Implements the 9 routing rules:
  Rule 1:  LLM is mandatory in private mode; all others optional
  Rule 2:  Always attempt native text extraction first for PDFs
  Rule 3:  OCR → image-based pages when OCR service is configured
  Rule 4:  VLM → image-based pages when VLM configured but no OCR
  Rule 5:  LLM vision fallback → when neither OCR nor VLM configured
  Rule 6:  Vectorisation → chunk + embed + search when configured
  Rule 7:  Reranker → rerank after vector search when configured
  Rule 8:  All services use OpenAI-compatible client (openai library)
  Rule 9:  SSL settings apply to every service client
"""
from __future__ import annotations

import logging
import ssl
import time
from pathlib import Path
from typing import Optional, Any

logger = logging.getLogger(__name__)


# ── Service capability flags ──────────────────────────────────────────────────

class ServiceCapabilities:
    """
    Boolean flags indicating which services are available.
    Consumed by routing logic throughout the pipeline.
    """
    def __init__(self):
        self.has_llm: bool = False
        self.has_ocr: bool = False
        self.has_vlm: bool = False
        self.has_vectorisation: bool = False
        self.has_reranker: bool = False
        self.llm_has_vision: bool = False  # True if LLM supports image inputs

    def __repr__(self):
        parts = []
        if self.has_llm:  parts.append(f"LLM(vision={self.llm_has_vision})")
        if self.has_ocr:  parts.append("OCR")
        if self.has_vlm:  parts.append("VLM")
        if self.has_vectorisation: parts.append("Vectorisation")
        if self.has_reranker:      parts.append("Reranker")
        return f"ServiceCapabilities({', '.join(parts) or 'none'})"


# ── OpenAI client builder (Rule 8 + 9) ───────────────────────────────────────

def _build_openai_client(
    base_url: str,
    api_key: str = "EMPTY",
    timeout: float = 120,
    ssl_config: dict | None = None,
):
    """
    Build an openai.OpenAI client with an optional httpx transport for SSL config.
    Rule 8: all services use OpenAI library.
    Rule 9: SSL settings applied uniformly.

    IMPORTANT: Uses httpx.Timeout with a short connect timeout (10 s) so that
    threads started via run_in_executor fail fast when an endpoint is unreachable.
    The OpenAI SDK default (max_retries=2, timeout=600) would keep each thread
    alive for up to 30 minutes, exhausting the ThreadPoolExecutor and freezing
    the event loop.  We set max_retries=0 here; retry logic lives in the callers.
    """
    try:
        import openai
        import httpx

        # Short connect timeout prevents threads from hanging on dead endpoints.
        # Read timeout capped at 60 s: asyncio.wait_for doesn't reliably cancel
        # threads in Python 3.10, so we rely on httpx to kill the request.
        read_timeout = min(float(timeout), 60.0)
        http_timeout = httpx.Timeout(
            connect=10.0,         # fail fast if host unreachable
            read=read_timeout,    # max wait for LLM response per attempt
            write=10.0,
            pool=5.0,
        )

        http_client_kwargs: dict = {"timeout": http_timeout}

        if ssl_config:
            verify: bool | str | ssl.SSLContext = ssl_config.get("verify", True)
            ca_bundle = ssl_config.get("ca_bundle_path", "")
            cert_path = ssl_config.get("ssl_cert_path", "")
            key_path  = ssl_config.get("ssl_key_path", "")
            if ca_bundle:
                verify = ca_bundle
            elif not (verify if isinstance(verify, bool) else True):
                verify = False
            http_client_kwargs["verify"] = verify
            if cert_path and key_path:
                http_client_kwargs["cert"] = (cert_path, key_path)
            elif cert_path:
                http_client_kwargs["cert"] = cert_path

        http_client = httpx.Client(**http_client_kwargs)
        effective_key = api_key if api_key and api_key not in ("EMPTY", "none", "dummy", "") else "EMPTY"
        return openai.OpenAI(
            base_url=base_url.rstrip("/"),
            api_key=effective_key,
            http_client=http_client,
            max_retries=0,  # don't retry inside the thread — asyncio timeout handles it
        )
    except ImportError:
        raise RuntimeError("openai package not installed. Run: pip install openai")


# ── Service configs ───────────────────────────────────────────────────────────

class ServiceConfig:
    """Holds config for a single AI service."""
    def __init__(self, base_url: str, api_key: str, model_name: str,
                 timeout: float = 120, max_retries: int = 3):
        self.base_url = base_url
        self.api_key = api_key
        self.model_name = model_name
        self.timeout = timeout
        self.max_retries = max_retries


# ── Registry ──────────────────────────────────────────────────────────────────

class ServiceRegistry:
    """
    Builds and caches OpenAI-compatible clients for each configured service.
    Hot-reloadable: call reload() after admin saves new config.
    """

    def __init__(self):
        self.capabilities = ServiceCapabilities()
        self._llm_cfg:    Optional[ServiceConfig] = None
        self._ocr_cfg:    Optional[ServiceConfig] = None
        self._vlm_cfg:    Optional[ServiceConfig] = None
        self._vec_cfg:    Optional[ServiceConfig] = None
        self._rerank_cfg: Optional[ServiceConfig] = None
        self._ssl_config: Optional[dict]          = None
        self._llm_client  = None
        self._ocr_client  = None
        self._vlm_client  = None
        self._vec_client  = None
        self._rerank_client = None
        self._loaded = False

    # ── Load from config ──────────────────────────────────────────────────────

    def load(self) -> None:
        """Read current config and build all service clients."""
        try:
            from services.config_manager import get_config_manager
            cfg = get_config_manager().get_yaml()
        except Exception:
            from services.config_loader import load_config
            cfg = load_config()

        mode = str(cfg.get("PROVIDER_MODE", "anthropic")).lower()
        self._ssl_config = self._extract_ssl(cfg)

        if mode == "private":
            self._load_private(cfg)
        elif mode == "anthropic":
            self._load_anthropic(cfg)
        elif mode in ("openai", "bedrock", "vertex"):
            self._load_openai_compat(cfg, mode)
        elif mode == "azure_openai":
            self._load_azure(cfg)
        elif mode == "ollama":
            self._load_ollama(cfg)
        elif mode == "internal_vllm":
            self._load_internal_vllm(cfg)
        else:
            logger.warning("ServiceRegistry: unknown PROVIDER_MODE '%s', defaulting to anthropic path", mode)
            self._load_anthropic(cfg)

        self._loaded = True
        logger.info("ServiceRegistry loaded. %s", self.capabilities)

        # Rule 1: validate LLM is present in private mode
        if mode == "private" and not self.capabilities.has_llm:
            raise RuntimeError(
                "PROVIDER_MODE is 'private' but no LLM is configured. "
                "Go to Admin → Configuration → LLM tab and set a Base URL and Model Name."
            )

    def reload(self) -> None:
        """Reset all clients and reload from current config."""
        self._llm_client = self._ocr_client = self._vlm_client = None
        self._vec_client = self._rerank_client = None
        self._llm_cfg = self._ocr_cfg = self._vlm_cfg = None
        self._vec_cfg = self._rerank_cfg = None
        self.capabilities = ServiceCapabilities()
        self._loaded = False
        self.load()

    # ── Mode loaders ──────────────────────────────────────────────────────────

    def _load_private(self, cfg: dict) -> None:
        private = cfg.get("private", {})
        ssl = self._ssl_config

        llm = private.get("llm", {})
        if llm.get("base_url"):
            self._llm_cfg = ServiceConfig(
                base_url=llm["base_url"], api_key=llm.get("api_key","EMPTY"),
                model_name=llm.get("model_name","default"),
                timeout=float(llm.get("timeout",120)), max_retries=int(llm.get("max_retries",3))
            )
            self._llm_client = _build_openai_client(llm["base_url"], llm.get("api_key","EMPTY"), float(llm.get("timeout",120)), ssl)
            self.capabilities.has_llm = True
            self.capabilities.llm_has_vision = True  # assume vLLM vision models support images

        vlm = private.get("vlm", {})
        if vlm.get("base_url"):
            self._vlm_cfg = ServiceConfig(
                base_url=vlm["base_url"], api_key=vlm.get("api_key","EMPTY"),
                model_name=vlm.get("model_name","default"),
                timeout=float(vlm.get("timeout",120)), max_retries=int(vlm.get("max_retries",3))
            )
            self._vlm_client = _build_openai_client(vlm["base_url"], vlm.get("api_key","EMPTY"), float(vlm.get("timeout",120)), ssl)
            self.capabilities.has_vlm = True

        ocr = private.get("ocr", {})
        if ocr.get("base_url"):
            self._ocr_cfg = ServiceConfig(
                base_url=ocr["base_url"], api_key=ocr.get("api_key","EMPTY"),
                model_name=ocr.get("model_name","default"),
                timeout=float(ocr.get("timeout",120)), max_retries=int(ocr.get("max_retries",3))
            )
            self._ocr_client = _build_openai_client(ocr["base_url"], ocr.get("api_key","EMPTY"), float(ocr.get("timeout",120)), ssl)
            self.capabilities.has_ocr = True

        vec = private.get("vectorisation", {})
        if vec.get("base_url"):
            self._vec_cfg = ServiceConfig(
                base_url=vec["base_url"], api_key=vec.get("api_key","EMPTY"),
                model_name=vec.get("model_name","default"),
                timeout=float(vec.get("timeout",60)), max_retries=int(vec.get("max_retries",3))
            )
            self._vec_client = _build_openai_client(vec["base_url"], vec.get("api_key","EMPTY"), float(vec.get("timeout",60)), ssl)
            self.capabilities.has_vectorisation = True

        rerank = private.get("reranker", {})
        if rerank.get("base_url"):
            self._rerank_cfg = ServiceConfig(
                base_url=rerank["base_url"], api_key=rerank.get("api_key","EMPTY"),
                model_name=rerank.get("model_name","default"),
                timeout=float(rerank.get("timeout",60)), max_retries=int(rerank.get("max_retries",3))
            )
            self._rerank_client = _build_openai_client(rerank["base_url"], rerank.get("api_key","EMPTY"), float(rerank.get("timeout",60)), ssl)
            self.capabilities.has_reranker = True

    def _load_anthropic(self, cfg: dict) -> None:
        """Anthropic: use existing anthropic SDK providers via provider_factory."""
        self.capabilities.has_llm = True
        self.capabilities.llm_has_vision = True  # Claude supports vision
        # For Anthropic, we delegate to the existing provider_factory registry
        # The service_registry just sets capability flags; actual calls go via get_registry()
        logger.info("ServiceRegistry: anthropic mode — delegating to provider_factory")

    def _load_openai_compat(self, cfg: dict, mode: str) -> None:
        key = mode.upper()
        mode_cfg = cfg.get(key, cfg.get("LLM", {}))
        base_url = mode_cfg.get("base_url", "https://api.openai.com")
        api_key  = mode_cfg.get("api_key", "")
        model    = mode_cfg.get("model_name", "gpt-4o")
        ssl = self._ssl_config
        self._llm_cfg = ServiceConfig(base_url=base_url, api_key=api_key, model_name=model)
        self._llm_client = _build_openai_client(base_url, api_key, 120, ssl)
        self.capabilities.has_llm = True
        self.capabilities.llm_has_vision = True

    def _load_azure(self, cfg: dict) -> None:
        az = cfg.get("AZURE_OPENAI", {})
        base_url = az.get("endpoint","").rstrip("/") + "/openai"
        api_key  = az.get("api_key","")
        model    = az.get("deployment_name","gpt-4o")
        self._llm_cfg = ServiceConfig(base_url=base_url, api_key=api_key, model_name=model)
        self._llm_client = _build_openai_client(base_url, api_key, 120, self._ssl_config)
        self.capabilities.has_llm = True
        self.capabilities.llm_has_vision = True

    def _load_ollama(self, cfg: dict) -> None:
        ol = cfg.get("OLLAMA", {})
        base_url = ol.get("base_url","http://localhost:11434")
        model    = ol.get("model_name","llama3.2-vision")
        self._llm_cfg = ServiceConfig(base_url=base_url, api_key="ollama", model_name=model)
        self._llm_client = _build_openai_client(base_url, "ollama", 120, self._ssl_config)
        self.capabilities.has_llm = True
        self.capabilities.llm_has_vision = "vision" in model.lower() or "llava" in model.lower()

    def _load_internal_vllm(self, cfg: dict) -> None:
        """Legacy internal_vllm mode — delegate to provider_factory."""
        self.capabilities.has_llm = True
        self.capabilities.llm_has_vision = True
        llm_cfg = cfg.get("LLM", {})
        if llm_cfg.get("base_url"):
            self._llm_cfg = ServiceConfig(
                base_url=llm_cfg["base_url"],
                api_key=llm_cfg.get("api_key","EMPTY"),
                model_name=llm_cfg.get("model_name","default")
            )
        # OCR via InternalOCRProvider is handled by provider_factory for this mode
        ocr_cfg = cfg.get("OCR", {})
        if ocr_cfg.get("endpoint") and ocr_cfg.get("auth_url"):
            self.capabilities.has_ocr = True
        vec_cfg = cfg.get("VECTORISATION", {})
        if vec_cfg.get("base_url"):
            self.capabilities.has_vectorisation = True
        rerank_cfg = cfg.get("RERANKER", {})
        if rerank_cfg.get("endpoint"):
            self.capabilities.has_reranker = True

    # ── SSL ───────────────────────────────────────────────────────────────────

    @staticmethod
    def _extract_ssl(cfg: dict) -> dict | None:
        ssl_cfg = cfg.get("ssl", {})
        if not ssl_cfg.get("enabled", False):
            return None
        return {
            "verify":          ssl_cfg.get("verify", True),
            "ca_bundle_path":  ssl_cfg.get("ca_bundle_path",""),
            "ssl_cert_path":   ssl_cfg.get("ssl_cert_path",""),
            "ssl_key_path":    ssl_cfg.get("ssl_key_path",""),
        }

    # ── Client accessors ──────────────────────────────────────────────────────

    def get_llm_client(self):
        """Return LLM OpenAI client. Falls back to provider_factory for non-private modes."""
        if self._llm_client:
            return self._llm_client
        # Non-private modes: use provider_factory's registry
        try:
            from providers.provider_factory import get_registry
            reg = get_registry()
            return reg.llm  # BaseLLMProvider — wraps the call
        except Exception:
            raise RuntimeError("No LLM client available. Configure an LLM in the admin page.")

    def get_async_llm(self):
        """
        Return an async OpenAICompatibleLLMProvider (uses httpx, non-blocking).
        Preferred over get_llm_client() for calling from async code — no thread pool needed.
        Falls back to get_llm_client() for non-private modes (which are already async).
        """
        if self._llm_cfg:
            from providers.openai_compatible_provider import OpenAICompatibleLLMProvider
            return OpenAICompatibleLLMProvider(
                base_url=self._llm_cfg.base_url,
                api_key=self._llm_cfg.api_key or "EMPTY",
                ssl_config=self._ssl_config,
                timeout=60.0,
                max_retries=1,
            )
        # Non-private: fall back to existing async provider
        try:
            from providers.provider_factory import get_registry
            return get_registry().llm
        except Exception:
            raise RuntimeError("No LLM provider available.")

    def get_llm_model(self) -> str:
        if self._llm_cfg:
            return self._llm_cfg.model_name
        try:
            from services.config_loader import get_model_config
            return get_model_config().get("name","default")
        except Exception:
            return "default"

    def get_ocr_client(self):
        if not self.capabilities.has_ocr or not self._ocr_client:
            raise RuntimeError("OCR service not configured. Add OCR endpoint in admin → Configuration → OCR tab.")
        return self._ocr_client

    def get_ocr_model(self) -> str:
        return self._ocr_cfg.model_name if self._ocr_cfg else "default"

    def get_vlm_client(self):
        if not self.capabilities.has_vlm or not self._vlm_client:
            # Fall back to provider_factory vision provider
            try:
                from providers.provider_factory import get_registry
                return get_registry().vision
            except Exception:
                raise RuntimeError("VLM service not configured.")
        return self._vlm_client

    def get_vlm_model(self) -> str:
        return self._vlm_cfg.model_name if self._vlm_cfg else self.get_llm_model()

    def get_vec_client(self):
        if not self.capabilities.has_vectorisation or not self._vec_client:
            raise RuntimeError("Vectorisation service not configured.")
        return self._vec_client

    def get_vec_model(self) -> str:
        return self._vec_cfg.model_name if self._vec_cfg else "default"

    def get_rerank_client(self):
        if not self.capabilities.has_reranker or not self._rerank_client:
            raise RuntimeError("Reranker service not configured.")
        return self._rerank_client

    def get_rerank_model(self) -> str:
        return self._rerank_cfg.model_name if self._rerank_cfg else "default"

    def get_rerank_endpoint(self) -> str:
        if self._rerank_cfg:
            return self._rerank_cfg.base_url.rstrip("/") + "/rerank"
        return ""

    # ── Routing helpers (implement routing rules 3-7) ─────────────────────────

    def get_image_extractor_name(self) -> str:
        """Rule 3/4/5: Return name of service used for image-based page extraction."""
        if self.capabilities.has_ocr:   return "ocr"
        if self.capabilities.has_vlm:   return "vlm"
        if self.capabilities.llm_has_vision: return "llm_vision"
        return "llm_no_vision"  # Rule 5 error case

    def can_extract_images(self) -> bool:
        """True if at least one vision-capable service is available."""
        return (self.capabilities.has_ocr or self.capabilities.has_vlm
                or self.capabilities.llm_has_vision)


# ── Module-level singleton ────────────────────────────────────────────────────

_registry: Optional[ServiceRegistry] = None


def get_service_registry() -> ServiceRegistry:
    global _registry
    if _registry is None:
        _registry = ServiceRegistry()
        _registry.load()
    return _registry


def reload_service_registry() -> ServiceRegistry:
    global _registry
    if _registry is None:
        _registry = ServiceRegistry()
    _registry.reload()
    return _registry
