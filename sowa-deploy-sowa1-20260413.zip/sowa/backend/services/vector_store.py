"""
Vector Store — in-memory chunk/embed/search for vectorisation + reranking.

ALL synchronous OpenAI SDK embedding calls are run in a thread-pool executor
so they never block the asyncio event loop. Without this, each embedding call
freezes the server — SSE events stop flowing and the UI appears stuck.

Reranking is batched: all candidate chunks from all queries are collected first,
then ONE batch rerank request is made instead of N requests (one per query).
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

CHUNK_SIZE    = 800   # characters per chunk
CHUNK_OVERLAP = 100   # overlap between consecutive chunks
TOP_K_DEFAULT = 8     # chunks to retrieve per query
EMBED_TIMEOUT = 30    # seconds per embedding call
RERANK_TIMEOUT = 20   # seconds for the single batch rerank call


@dataclass
class Chunk:
    text: str
    source_file: str
    page_num: int
    chunk_idx: int
    embedding: Optional[list[float]] = None


class VectorStore:
    """Session-scoped in-memory vector store — one instance per extraction session."""

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.chunks: list[Chunk] = []

    # ── Chunking ──────────────────────────────────────────────────────────────

    def _chunk_text(self, text: str, source_file: str, page_num: int) -> list[Chunk]:
        chunks, start, idx = [], 0, 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunk_text = text[start:end].strip()
            if chunk_text:
                chunks.append(Chunk(text=chunk_text, source_file=source_file,
                                    page_num=page_num, chunk_idx=idx))
                idx += 1
            start = end - CHUNK_OVERLAP
        return chunks

    # ── Embedding ─────────────────────────────────────────────────────────────

    async def add_document(self, text: str, source_file: str, page_num: int) -> int:
        """Chunk text, embed each chunk (non-blocking), and store."""
        from services.service_registry import get_service_registry
        registry = get_service_registry()

        if not registry.capabilities.has_vectorisation:
            return 0

        new_chunks = self._chunk_text(text, source_file, page_num)
        if not new_chunks:
            return 0

        try:
            client = registry.get_vec_client()
            model  = registry.get_vec_model()
            texts  = [c.text for c in new_chunks]

            # Run the synchronous OpenAI embeddings call in a thread-pool executor
            # so it does NOT block the async event loop.
            def _sync_embed():
                return client.embeddings.create(model=model, input=texts)

            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_embed)
            embeddings = [item.embedding for item in sorted(resp.data, key=lambda x: x.index)]

            for chunk, emb in zip(new_chunks, embeddings):
                chunk.embedding = emb

            self.chunks.extend(new_chunks)
            logger.debug("VectorStore: added %d chunks from %s p.%d",
                         len(new_chunks), source_file, page_num)
            return len(new_chunks)

        except asyncio.TimeoutError:
            logger.warning("VectorStore: embedding timed out after %ds — using keyword fallback",
                           EMBED_TIMEOUT)
            for c in new_chunks:
                c.embedding = None
            self.chunks.extend(new_chunks)
            return len(new_chunks)
        except Exception as e:
            logger.warning("VectorStore: embedding failed: %s — using keyword fallback", e)
            for c in new_chunks:
                c.embedding = None
            self.chunks.extend(new_chunks)
            return len(new_chunks)

    async def _embed_query(self, query: str, registry) -> Optional[list[float]]:
        """Embed a single query string — non-blocking."""
        try:
            client = registry.get_vec_client()
            model  = registry.get_vec_model()

            def _sync_embed():
                return client.embeddings.create(model=model, input=[query])

            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_embed)
            return resp.data[0].embedding
        except Exception as e:
            logger.warning("VectorStore: query embedding failed: %s", e)
            return None

    # ── Search ────────────────────────────────────────────────────────────────

    async def search(self, query: str, top_k: int = TOP_K_DEFAULT) -> list[dict]:
        """Semantic search with keyword fallback — non-blocking."""
        if not self.chunks:
            return []

        from services.service_registry import get_service_registry
        registry = get_service_registry()

        chunks_with_emb = [c for c in self.chunks if c.embedding]
        if chunks_with_emb and registry.capabilities.has_vectorisation:
            q_emb = await self._embed_query(query, registry)
            if q_emb:
                scored = [(c, _cosine(q_emb, c.embedding)) for c in chunks_with_emb]
                scored.sort(key=lambda x: x[1], reverse=True)
                return [_chunk_to_dict(c, score) for c, score in scored[:top_k]]

        # Keyword fallback
        q_words = set(query.lower().split())
        scored_kw = [
            (c, len(q_words & set(c.text.lower().split())) / max(len(q_words), 1))
            for c in self.chunks
        ]
        scored_kw.sort(key=lambda x: x[1], reverse=True)
        return [_chunk_to_dict(c, score) for c, score in scored_kw[:top_k]]

    # ── Reranking ─────────────────────────────────────────────────────────────

    async def rerank_batch(self, query: str, candidates: list[dict], top_k: int = 5) -> list[dict]:
        """
        Batch rerank: ONE HTTP request for all candidates.
        Called once after all searches are complete — not once per query.
        Falls back to original order if reranker is unavailable or errors.
        """
        from services.service_registry import get_service_registry
        registry = get_service_registry()

        if not registry.capabilities.has_reranker or not candidates:
            return candidates[:top_k]

        try:
            import httpx
            endpoint = registry.get_rerank_endpoint()
            model    = registry.get_rerank_model()
            api_key  = registry._rerank_cfg.api_key if registry._rerank_cfg else ""
            docs     = [c["text"] for c in candidates]

            payload = {"model": model, "query": query, "documents": docs, "top_n": top_k}
            async with httpx.AsyncClient(timeout=RERANK_TIMEOUT) as hx:
                resp = await hx.post(
                    endpoint,
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {api_key}",
                        "Content-Type": "application/json",
                    },
                )
                resp.raise_for_status()
                results = resp.json().get("results", resp.json().get("data", []))

            reranked = sorted(
                results,
                key=lambda x: x.get("relevance_score", x.get("score", 0)),
                reverse=True,
            )
            return [
                candidates[r["index"]]
                for r in reranked
                if r.get("index", 0) < len(candidates)
            ][:top_k]

        except asyncio.TimeoutError:
            logger.warning("VectorStore: reranker timed out after %ds — using vector order",
                           RERANK_TIMEOUT)
            return candidates[:top_k]
        except Exception as e:
            logger.warning("VectorStore: reranking failed: %s — using vector order", e)
            return candidates[:top_k]

    # Keep old per-query rerank for backward compat but delegate to batch version
    async def rerank(self, query: str, candidates: list[dict], top_k: int = 5) -> list[dict]:
        return await self.rerank_batch(query, candidates, top_k)


# ── Session store manager ─────────────────────────────────────────────────────

_session_stores: dict[str, VectorStore] = {}


def get_vector_store(session_id: str) -> VectorStore:
    if session_id not in _session_stores:
        _session_stores[session_id] = VectorStore(session_id)
    return _session_stores[session_id]


def clear_vector_store(session_id: str) -> None:
    _session_stores.pop(session_id, None)


# ── Utilities ─────────────────────────────────────────────────────────────────

def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na  = math.sqrt(sum(x * x for x in a))
    nb  = math.sqrt(sum(x * x for x in b))
    return 0.0 if na == 0 or nb == 0 else dot / (na * nb)


def _chunk_to_dict(chunk: Chunk, score: float) -> dict:
    return {
        "text":        chunk.text,
        "source_file": chunk.source_file,
        "page_num":    chunk.page_num,
        "chunk_idx":   chunk.chunk_idx,
        "score":       round(score, 4),
    }
