"""
Pipeline A — Private Mode (9-Stage Specialist Pipeline)

Uses dedicated specialist services (OCR, VLM, LLM, Vectorisation, Reranker)
all via OpenAI-compatible API calls to private vLLM servers.

Stage 1:  Page Classification (native text vs AI-needed)
Stage 2:  OCR Extraction (with optional pre-call token mint auth)
Stage 3:  VLM Visual Enhancement (enriches OCR for image/chart pages)
Stage 4:  LLM Content Structuring (summarise + document type)
Stage 5:  Vectorisation (chunk → embed → store)
Stage 6:  Field Extraction with RAG (vector search → rerank → LLM extract)
Stage 7:  Review Section Population (output to caller)
Stage 8:  SOW Generation (called separately by generate router)
Stage 9:  Evaluation and Scoring (called after generation)
"""
from __future__ import annotations

import asyncio
import base64
import json
import logging
import re
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator

logger = logging.getLogger(__name__)

NATIVE_TEXT_MIN_CHARS = 80
OCR_CATEGORY_QUERIES = [
    "name date of birth nationality identity document number",
    "employer employment income salary remuneration",
    "bank account balance transactions credits deposits",
    "property asset valuation ownership title",
    "shares company shareholding director ownership percentage",
    "tax assessment income tax payable IRAS",
    "investment portfolio securities funds",
    "dividend payment declared",
]
FIELD_CATEGORIES_WITH_PCT = [
    ("Identity Information", 65),
    ("Financial Data", 70),
    ("Asset Information", 75),
    ("Income Details", 80),
]


class PrivatePipeline:
    """9-stage specialist pipeline for provider_mode = private."""

    def __init__(self, session_id: str, job_id: str, profile_type: str):
        self.session_id = session_id
        self.job_id = job_id
        self.profile_type = profile_type

    async def run(self, files: list[str]) -> AsyncGenerator[dict, None]:
        """Stream status events then final extraction result."""
        from services.pipeline_status import (
            PipelineStatusEmitter,
            evt_received, evt_classifying_page, evt_page_native,
            evt_page_image_detected, evt_all_extracted,
            evt_doc_type_identified, evt_vectorising, evt_semantic_search,
            evt_reranking, evt_extracting_category, evt_extraction_complete,
            evt_validating, evt_populating_review, evt_ready,
            evt_vectorisation_unavailable, evt_reranker_unavailable,
        )
        from services.service_registry import get_service_registry

        registry = get_service_registry()
        emitter = PipelineStatusEmitter(self.session_id, self.job_id)

        # --- yield emitter events as SSE dicts ---
        async def drain():
            async for ev in emitter:
                yield ev.to_sse()

        # Run the pipeline in a background task, drain events concurrently
        pipeline_task = asyncio.create_task(
            self._run_pipeline(files, registry, emitter)
        )

        # Stream status events as they come
        async for sse_line in drain():
            # Convert SSE line to dict for the router
            if sse_line.startswith("data: "):
                try:
                    payload = json.loads(sse_line[6:])
                    yield payload
                except Exception:
                    pass

        # Wait for pipeline to finish and get result
        try:
            result = await pipeline_task
            if result:
                yield result
        except Exception as e:
            logger.error("PrivatePipeline failed: %s", e)
            yield {"type": "error", "message": f"Pipeline failed: {type(e).__name__}: {e}"}

    async def _run_pipeline(self, files: list[str], registry, emitter) -> dict | None:
        """Execute all 9 stages, emitting status events throughout."""
        from services.pipeline_status import (
            evt_received, evt_classifying_page, evt_page_native,
            evt_page_image_detected, evt_all_extracted, evt_doc_type_identified,
            evt_vectorising, evt_semantic_search, evt_reranking,
            evt_extracting_category, evt_extraction_complete,
            evt_validating, evt_populating_review, evt_ready,
            evt_vectorisation_unavailable, evt_reranker_unavailable,
        )

        try:
            emitter.emit(evt_received())

            # ── Stage 1 + 2 + 3: Classify, OCR, VLM enhance per page ──────────
            all_page_results: dict[str, list[dict]] = {}  # filename → list of PageResult dicts
            for file_path in files:
                filename = Path(file_path).name
                page_results = await self._process_file(file_path, filename, registry, emitter)
                all_page_results[filename] = page_results

            # ── Stage 4: LLM Content Structuring ─────────────────────────────
            emitter.emit(evt_all_extracted())
            full_text_corpus: dict[str, str] = {}
            doc_type = "document"
            for filename, pages in all_page_results.items():
                combined = "\n\n--- Page Break ---\n\n".join(
                    p.get("text", "") for p in pages if p.get("text")
                )
                full_text_corpus[filename] = combined

            structured = await self._stage4_structure(full_text_corpus, registry)
            doc_type = structured.get("doc_type", "document")
            emitter.emit(evt_doc_type_identified(doc_type))

            # ── Stage 5: Vectorisation ────────────────────────────────────────
            if registry.capabilities.has_vectorisation:
                chunk_count = await self._stage5_vectorise(
                    structured.get("clean_text", "\n".join(full_text_corpus.values())),
                    registry, emitter
                )
                emitter.emit(evt_semantic_search())
            else:
                emitter.emit(evt_vectorisation_unavailable())

            # ── Stage 6: Field Extraction with RAG ───────────────────────────
            for cat_label, pct in FIELD_CATEGORIES_WITH_PCT:
                emitter.emit(evt_extracting_category(cat_label, pct))

            extraction_result = await self._stage6_extract_fields(
                full_text_corpus, doc_type, registry, emitter
            )

            categories = extraction_result.get("categories", {})
            total = sum(len(v) for v in categories.values())
            high_conf = sum(
                1 for c in categories.values()
                for f in c if float(f.get("confidence", 0)) >= 0.9
            )
            needs_review = max(0, total - high_conf)
            emitter.emit(evt_extraction_complete(total, high_conf, needs_review))

            # ── Stage 7: Populate review ──────────────────────────────────────
            emitter.emit(evt_validating())
            emitter.emit(evt_populating_review())
            emitter.emit(evt_ready())

            # Build extraction metadata from page results
            extraction_metadata = self._build_metadata(all_page_results)

            emitter.done()

            # Return the final event (matched to what extract.py expects)
            from prompts.extraction_prompt import CATEGORY_TO_DISPLAY
            cat_list = []
            for cat_key, field_list in categories.items():
                if field_list:
                    display_name = CATEGORY_TO_DISPLAY.get(cat_key, cat_key.replace("_", " ").title())
                    cat_list.append({
                        "category_name": display_name,
                        "icon_key": cat_key.lower(),
                        "fields": field_list,
                    })

            return {
                "type": "complete",
                "extraction_id": extraction_result.get("extraction_id", str(uuid.uuid4())),
                "total_fields": total,
                "categories": [c["category_name"] for c in cat_list],
                "doc_type": doc_type,
                "extraction_metadata": extraction_metadata,
                "_categories_full": cat_list,  # for session_states storage
            }

        except Exception as e:
            logger.error("Pipeline stage error: %s", e)
            emitter.done()
            raise

    # ── Stage 2+3: Per-file page processing ───────────────────────────────────

    async def _process_file(
        self, file_path: str, filename: str, registry, emitter
    ) -> list[dict]:
        from services.pipeline_status import (
            evt_classifying_page, evt_page_native, evt_page_image_detected,
            evt_ocr_auth_request, evt_ocr_auth_received, evt_ocr_complete,
            evt_vlm_enhance, evt_vlm_complete,
            evt_llm_vision_fallback, evt_ocr_unavailable, evt_vlm_unavailable,
            evt_llm_vision_failed, evt_page_failed,
        )
        import fitz

        ext = Path(file_path).suffix.lower()
        if ext not in (".pdf",):
            # Image file — classify as image-dominant immediately
            return [await self._extract_image_page(
                file_path, 1, 1, filename, registry, emitter
            )]

        try:
            doc = fitz.open(file_path)
        except Exception as e:
            logger.warning("Cannot open %s: %s", filename, e)
            return [{"page_num": 1, "text": "", "method": "failed",
                     "model": "", "error": str(e)}]

        total_pages = len(doc)
        page_results = []

        for page_idx in range(total_pages):
            page_num = page_idx + 1
            emitter.emit(evt_classifying_page(page_num, total_pages))

            page = doc.load_page(page_idx)

            # Stage 1: Native text check
            native_text = self._native_text(page)
            if self._text_sufficient(native_text):
                emitter.emit(evt_page_native(page_num, total_pages))
                page_results.append({
                    "page_num": page_num, "text": native_text,
                    "method": "native", "model": "", "error": None
                })
                continue

            # Image-based page — need AI
            emitter.emit(evt_page_image_detected(page_num, total_pages))
            page_b64 = self._render_page(page)

            result = await self._ai_extract_page(
                page_b64, page_num, total_pages, filename, registry, emitter,
                fallback_text=native_text
            )
            page_results.append(result)

        doc.close()
        return page_results

    async def _extract_image_page(
        self, file_path: str, page_num: int, total: int, filename: str, registry, emitter
    ) -> dict:
        """Handle standalone image files."""
        with open(file_path, "rb") as f:
            page_b64 = base64.b64encode(f.read()).decode("utf-8")
        return await self._ai_extract_page(
            page_b64, page_num, total, filename, registry, emitter, fallback_text=""
        )

    async def _ai_extract_page(
        self, page_b64: str, page_num: int, total: int,
        filename: str, registry, emitter, fallback_text: str = ""
    ) -> dict:
        """Route image-based page through OCR → VLM → LLM chain."""
        from services.pipeline_status import (
            evt_ocr_auth_request, evt_ocr_auth_received, evt_ocr_complete,
            evt_vlm_enhance, evt_vlm_complete, evt_llm_vision_fallback,
            evt_ocr_unavailable, evt_vlm_unavailable, evt_llm_vision_failed,
            evt_page_failed,
        )

        ocr_text = ""
        method = "failed"
        model_used = ""

        # --- Stage 2: OCR ---
        if registry.capabilities.has_ocr:
            try:
                ocr_text, model_used = await self._call_ocr(
                    page_b64, page_num, registry, emitter
                )
                method = "ocr"
            except Exception as e:
                logger.warning("OCR failed page %d: %s", page_num, e)
                emitter.emit(evt_ocr_unavailable(page_num))

        # --- Stage 3: VLM Enhancement ---
        if registry.capabilities.has_vlm:
            try:
                vlm_model = registry.get_vlm_model()
                emitter.emit(evt_vlm_enhance(page_num, vlm_model))
                enhanced = await self._call_vlm_enhance(
                    page_b64, ocr_text or fallback_text, registry
                )
                if enhanced:
                    ocr_text = enhanced
                    method = "vlm" if not ocr_text else "ocr+vlm"
                    model_used = vlm_model
                emitter.emit(evt_vlm_complete(page_num))
            except Exception as e:
                logger.warning("VLM enhance failed page %d: %s", page_num, e)
                emitter.emit(evt_vlm_unavailable(page_num))
        elif not ocr_text:
            # No OCR, no VLM — LLM vision fallback
            if registry.can_extract_images():
                llm_model = registry.get_llm_model()
                emitter.emit(evt_llm_vision_fallback(page_num, llm_model))
                try:
                    ocr_text = await self._call_llm_vision(page_b64, registry)
                    method = "llm_vision"
                    model_used = llm_model
                except Exception as e:
                    logger.error("LLM vision fallback failed page %d: %s", page_num, e)
                    emitter.emit(evt_llm_vision_failed(page_num))
                    emitter.emit(evt_page_failed(page_num, 3, str(e)))
            else:
                emitter.emit(evt_llm_vision_failed(page_num))
                emitter.emit(evt_page_failed(page_num, 0, "no vision service configured"))

        char_count = len(ocr_text)
        if method not in ("failed", "llm_vision") and ocr_text:
            emitter.emit(evt_ocr_complete(page_num, char_count, model_used))

        return {
            "page_num": page_num, "text": ocr_text or fallback_text,
            "method": method, "model": model_used, "error": None if ocr_text else "extraction failed"
        }

    async def _call_ocr(self, page_b64: str, page_num: int, registry, emitter) -> tuple[str, str]:
        """Call OCR service. Handles both auth-endpoint and direct API key patterns."""
        from services.pipeline_status import evt_ocr_auth_request, evt_ocr_auth_received

        ocr_client = registry.get_ocr_client()
        ocr_model  = registry.get_ocr_model()

        # Check if OCR uses auth-endpoint token-mint pattern
        # (registry stores this info in _ocr_cfg.auth_url if configured)
        needs_token_mint = (
            hasattr(registry, '_ocr_cfg') and
            registry._ocr_cfg and
            hasattr(registry._ocr_cfg, 'auth_url') and
            getattr(registry._ocr_cfg, 'auth_url', None)
        )

        if needs_token_mint:
            emitter.emit(evt_ocr_auth_request(page_num))
            # Token mint is handled by the TokenManager embedded in InternalOCRProvider
            # For OpenAI-compat OCR with auth_url, we use the token manager
            if hasattr(registry, '_ocr_token_manager') and registry._ocr_token_manager:
                token = await registry._ocr_token_manager.get_token()
                emitter.emit(evt_ocr_auth_received(page_num))
            else:
                emitter.emit(evt_ocr_auth_received(page_num))

        from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
        system = get_ocr_system_prompt()
        user   = get_ocr_user_prompt()

        # Use OpenAI-compatible vision call — sync SDK, must run in executor
        if hasattr(ocr_client, 'chat'):
            def _sync_ocr():
                return ocr_client.chat.completions.create(
                    timeout=60,
                    model=ocr_model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": [
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                            {"type": "text", "text": user},
                        ]},
                    ],
                    max_tokens=4096,
                )
            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_ocr)
            return resp.choices[0].message.content or "", ocr_model
        else:
            # BaseLLMProvider path
            result = await ocr_client.vision_complete(
                system=system, user_text=user,
                image_b64=page_b64, image_media_type="image/png",
                model=ocr_model, max_tokens=4096, temperature=0.1,
            )
            return result, ocr_model

    async def _call_vlm_enhance(self, page_b64: str, ocr_text: str, registry) -> str:
        """Stage 3: VLM enriches OCR output for image-heavy/chart pages."""
        vlm_client = registry.get_vlm_client()
        vlm_model  = registry.get_vlm_model()

        prompt = (
            "You are a document understanding specialist. You have received OCR-extracted text "
            "from a financial document page. Your task is to:\n"
            "1. Correct any OCR errors\n"
            "2. Identify and reconstruct any tables, preserving structure\n"
            "3. Interpret charts, graphs, or diagrams and describe their data in text\n"
            "4. Return a semantically complete, clean representation of all information on this page.\n\n"
            f"OCR OUTPUT TO ENHANCE:\n{ocr_text}\n\n"
            "Return the enhanced, corrected, and complete text content only."
        )

        if hasattr(vlm_client, 'chat'):
            def _sync_vlm():
                return vlm_client.chat.completions.create(
                    timeout=60,
                    model=vlm_model,
                    messages=[
                        {"role": "user", "content": [
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                            {"type": "text", "text": prompt},
                        ]},
                    ],
                    max_tokens=4096,
                )
            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_vlm)
            return resp.choices[0].message.content or ""
        else:
            return await vlm_client.vision_complete(
                system="You are a document understanding specialist.",
                user_text=prompt,
                image_b64=page_b64, image_media_type="image/png",
                model=vlm_model, max_tokens=4096, temperature=0.1,
            )

    async def _call_llm_vision(self, page_b64: str, registry) -> str:
        """LLM vision fallback for image extraction."""
        from prompts.ocr_prompt import get_ocr_system_prompt, get_ocr_user_prompt
        system = get_ocr_system_prompt()
        user   = get_ocr_user_prompt()

        llm = registry.get_llm_client()
        model = registry.get_llm_model()

        if hasattr(llm, 'chat'):
            def _sync_llm_vision():
                return llm.chat.completions.create(
                    timeout=60,
                    model=model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": [
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{page_b64}"}},
                            {"type": "text", "text": user},
                        ]},
                    ],
                    max_tokens=4096,
                )
            loop = asyncio.get_running_loop()
            resp = await loop.run_in_executor(None, _sync_llm_vision)
            return resp.choices[0].message.content or ""
        else:
            from providers.provider_factory import get_registry
            vision = get_registry().vision
            return await vision.vision_complete(
                system=system, user_text=user,
                image_b64=page_b64, image_media_type="image/png",
                model=model, max_tokens=4096, temperature=0.1,
            )

    # ── Stage 4: LLM Content Structuring ──────────────────────────────────────

    async def _stage4_structure(self, text_corpus: dict[str, str], registry) -> dict:
        """Stage 4: LLM summarises and structures all page text."""
        combined = "\n\n".join(
            f"=== {fname} ===\n{text[:3000]}"
            for fname, text in text_corpus.items()
            if text
        )
        if not combined.strip():
            return {"doc_type": "document", "clean_text": ""}

        system = (
            "You are a financial document analyst. Given raw extracted text from a financial document, "
            "return a JSON object with:\n"
            '  "doc_type": one of bank_statement/tax_return/payslip/employment_contract/'
            'property_valuation/investment_portfolio/business_ownership/identity_document/other\n'
            '  "clean_text": the cleaned and structured full text content\n'
            "Return only valid JSON, no markdown."
        )
        user = f"Structure this financial document:\n\n{combined[:8000]}"

        try:
            llm = registry.get_llm_client()
            model = registry.get_llm_model()
            if hasattr(llm, 'chat'):
                def _sync_stage4():
                    return llm.chat.completions.create(
                        timeout=60,
                        model=model,
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user", "content": user},
                        ],
                        max_tokens=2048, temperature=0.1,
                    )
                loop = asyncio.get_running_loop()
                resp = await loop.run_in_executor(None, _sync_stage4)
                raw = resp.choices[0].message.content or ""
            else:
                from providers.provider_factory import get_registry
                raw = await get_registry().get_llm().complete(
                    system=system, user=user, model=model,
                    max_tokens=2048, temperature=0.1,
                )

            # Strip markdown fences
            raw = re.sub(r"```json\s*", "", raw)
            raw = re.sub(r"```\s*", "", raw)
            return json.loads(raw.strip())
        except Exception as e:
            logger.warning("Stage4 structuring failed: %s", e)
            return {
                "doc_type": "document",
                "clean_text": "\n\n".join(text_corpus.values()),
            }

    # ── Stage 5: Vectorisation ─────────────────────────────────────────────────

    async def _stage5_vectorise(self, text: str, registry, emitter) -> int:
        from services.vector_store import get_vector_store
        from services.pipeline_status import evt_vectorising
        store = get_vector_store(self.session_id)
        vec_model = registry.get_vec_model()
        # Estimate chunk count before embedding
        chunk_count = max(1, len(text) // 800)
        emitter.emit(evt_vectorising(chunk_count, vec_model))
        added = await store.add_document(text, "document", 1)
        return added

    # ── Stage 6: Field Extraction with RAG ────────────────────────────────────

    async def _stage6_extract_fields(
        self, text_corpus: dict[str, str], doc_type: str, registry, emitter
    ) -> dict:
        from services.pipeline_status import evt_reranking, evt_reranker_unavailable
        from services.extraction_service import extract_fields
        # Get doc_categories from session state
        doc_categories = {}
        try:
            from routers.upload import session_states
            sess = session_states.get(self.session_id, {})
            doc_categories = sess.get("doc_categories", {})
        except Exception:
            pass

        try:
            if registry.capabilities.has_reranker:
                emitter.emit(evt_reranking(8, registry.get_rerank_model()))
            else:
                emitter.emit(evt_reranker_unavailable())
            result = await extract_fields(
                text_corpus, self.session_id,
                doc_categories=doc_categories,
                profile_type=self.profile_type,
                emitter=emitter,
            )
            return result
        except Exception as e:
            logger.error("Stage6 extraction failed: %s", e)
            return {"extraction_id": str(uuid.uuid4()), "categories": {}, "total_fields": 0, "doc_type": doc_type}

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _native_text(self, page) -> str:
        try:
            return page.get_text("text").strip()
        except Exception:
            return ""

    def _text_sufficient(self, text: str) -> bool:
        return len(" ".join(text.split())) >= NATIVE_TEXT_MIN_CHARS

    def _render_page(self, page, dpi: int = 200) -> str:
        import fitz
        zoom = dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat)
        png_bytes = pix.tobytes("png")
        return base64.b64encode(png_bytes).decode("utf-8")

    def _build_metadata(self, all_page_results: dict[str, list[dict]]) -> list[dict]:
        metadata = []
        for filename, pages in all_page_results.items():
            methods = {}
            for p in pages:
                m = p.get("method", "unknown")
                methods[m] = methods.get(m, 0) + 1
            metadata.append({
                "filename": filename,
                "summary": {"total_pages": len(pages), "methods": methods,
                            "failed_pages": [p["page_num"] for p in pages if p.get("error")]},
                "pages": [{"page": p["page_num"], "method": p.get("method",""),
                           "model": p.get("model",""), "error": p.get("error")} for p in pages]
            })
        return metadata

    async def _mock_fallback(self, files: list[str]) -> AsyncGenerator[dict, None]:
        """Emergency fallback to mock pipeline."""
        from routers.extract import _run_mock_pipeline
        session_dir = str(Path(files[0]).parent) if files else "/tmp"
        file_names = [Path(f).name for f in files]
        async for event in _run_mock_pipeline(self.session_id, session_dir, file_names):
            yield event
