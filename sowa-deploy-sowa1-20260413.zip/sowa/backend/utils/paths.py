"""Centralised path configuration for CML / non-Docker deployments.

Set SOW_SESSIONS_DIR env var to override the upload directory.
Defaults to ~/sow_sessions — works on CML where home dir is persistent.
"""
import os

def get_sessions_root() -> str:
    default = os.path.join(os.path.expanduser("~"), "sow_sessions")
    d = os.environ.get("SOW_SESSIONS_DIR", default)
    os.makedirs(d, exist_ok=True)
    return d

def get_session_dir(session_id: str) -> str:
    d = os.path.join(get_sessions_root(), session_id)
    os.makedirs(d, exist_ok=True)
    return d
