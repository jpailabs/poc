"""
OpenAI-compatible provider.
Works with: vLLM endpoints, Azure OpenAI, Ollama, LM Studio,
AWS Bedrock (OpenAI compat), and standard OpenAI.
"""
from __future__ import annotations

import asyncio
import logging
from typing import AsyncGenerator, Optional

import httpx

from providers.base import BaseLLMProvider, BaseVisionProvider, BaseEmbeddingProvider, BaseRerankProvider, BaseOCRProvider
from providers.token_manager import TokenManager

logger = logging.getLogger(__name__)
RETRY_CODES = {429, 500, 502, 503}
MAX_RETRIES = 3


def _backoff(attempt: int) -> float:
    return min(2 ** attempt, 30)


def _normalize_base_url(url: str) -> str:
    """
    Normalise a base_url so that appending /v1/... never doubles the prefix.
    Strips any trailing slash and any trailing /v1 segment.

    Examples:
      https://openrouter.ai/api/v1   → https://openrouter.ai/api
      https://openrouter.ai/api/v1/  → https://openrouter.ai/api
      https://openrouter.ai/api      → https://openrouter.ai/api   (unchanged)
      http://localhost:8080/v1       → http://localhost:8080
    """
    url = url.rstrip("/")
    if url.endswith("/v1"):
        url = url[:-3]
    return url


def _build_httpx_client(timeout: float = 120, ssl_config: dict | None = None, stream: bool = False) -> httpx.AsyncClient:
    """
    Build an httpx.AsyncClient with optional SSL configuration.
    ssl_config keys: verify (bool|str), ssl_cert_path (str), ssl_key_path (str), ca_bundle_path (str)
    """
    kwargs: dict = {"timeout": timeout}

    if ssl_config:
        verify = ssl_config.get("verify", True)
        ca_bundle = ssl_config.get("ca_bundle_path", "")
        cert_path = ssl_config.get("ssl_cert_path", "")
        key_path = ssl_config.get("ssl_key_path", "")

        # Use CA bundle path as verify if provided, else use bool
        if ca_bundle:
            kwargs["verify"] = ca_bundle
        else:
            kwargs["verify"] = verify

        # Client certificate (mTLS)
        if cert_path and key_path:
            kwargs["cert"] = (cert_path, key_path)
        elif cert_path:
            kwargs["cert"] = cert_path
    else:
        kwargs["verify"] = True

    return httpx.AsyncClient(**kwargs)


class OpenAICompatibleLLMProvider(BaseLLMProvider):
    """
    LLM provider for any OpenAI-compatible endpoint.
    Used for: vLLM, Ollama, LM Studio, Azure OpenAI, standard OpenAI.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "dummy",
        token_manager: Optional[TokenManager] = None,
        extra_headers: Optional[dict] = None,
        ssl_config: dict | None = None,
        timeout: float = 120,
        max_retries: int = 3,
    ):
        self.base_url = _normalize_base_url(base_url)
        self.api_key = api_key
        self.token_manager = token_manager
        self.extra_headers = extra_headers or {}
        self.ssl_config = ssl_config
        self.timeout = timeout
        self.max_retries = max_retries

    async def _headers(self) -> dict:
        h = {"Content-Type": "application/json", **self.extra_headers}
        if self.token_manager:
            token = await self.token_manager.get_token()
            h["Authorization"] = f"Bearer {token}"
        elif self.api_key and self.api_key != "dummy":
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def complete(self, system, user, model, max_tokens, temperature) -> str:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }
        for attempt in range(self.max_retries):
            async with _build_httpx_client(self.timeout, self.ssl_config) as client:
                try:
                    resp = await client.post(
                        f"{self.base_url}/v1/chat/completions",
                        json=payload,
                        headers=await self._headers(),
                    )
                    if resp.status_code in RETRY_CODES and attempt < self.max_retries - 1:
                        await asyncio.sleep(_backoff(attempt))
                        continue
                    if not resp.is_success:
                        # Log the full error body so we can diagnose 400/422/etc.
                        logger.error(
                            "LLM API error %d for model=%s url=%s body=%s",
                            resp.status_code, model,
                            f"{self.base_url}/v1/chat/completions",
                            resp.text[:1000],
                        )
                    resp.raise_for_status()
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"]
                    logger.debug("LLM response: model=%s tokens_used=%s content_len=%d",
                                 model,
                                 data.get("usage", {}).get("total_tokens", "?"),
                                 len(content or ""))
                    return content
                except httpx.TimeoutException:
                    if attempt < self.max_retries - 1:
                        await asyncio.sleep(_backoff(attempt))
                        continue
                    raise
        raise RuntimeError("Max retries exceeded")

    async def stream(self, system, user, model, max_tokens, temperature) -> AsyncGenerator[str, None]:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": True,
        }
        headers = await self._headers()
        async with _build_httpx_client(self.timeout, self.ssl_config, stream=True) as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/v1/chat/completions",
                json=payload,
                headers=headers,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    chunk = line[6:]
                    if chunk.strip() == "[DONE]":
                        break
                    try:
                        import json
                        data = json.loads(chunk)
                        delta = data["choices"][0].get("delta", {})
                        text = delta.get("content", "")
                        if text:
                            yield text
                    except Exception:
                        continue


class OpenAICompatibleVisionProvider(BaseVisionProvider):
    """Vision provider for OpenAI-compatible VLM endpoints (MiniCPM, LLaVA, etc.)."""

    def __init__(
        self,
        base_url: str,
        api_key: str = "dummy",
        token_manager: Optional[TokenManager] = None,
        ssl_config: dict | None = None,
        timeout: float = 120,
        max_retries: int = 3,
    ):
        self.base_url = _normalize_base_url(base_url)
        self.api_key = api_key
        self.token_manager = token_manager
        self.ssl_config = ssl_config
        self.timeout = timeout
        self.max_retries = max_retries

    async def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.token_manager:
            token = await self.token_manager.get_token()
            h["Authorization"] = f"Bearer {token}"
        elif self.api_key and self.api_key != "dummy":
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def vision_complete(
        self, system, user_text, image_b64, image_media_type, model, max_tokens, temperature
    ) -> str:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": f"data:{image_media_type};base64,{image_b64}"}},
                        {"type": "text", "text": user_text},
                    ],
                },
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        async with _build_httpx_client(self.timeout, self.ssl_config) as client:
            resp = await client.post(
                f"{self.base_url}/v1/chat/completions",
                json=payload,
                headers=await self._headers(),
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]


class OpenAICompatibleEmbeddingProvider(BaseEmbeddingProvider):
    """Embedding provider for OpenAI-compatible endpoints (bge-m3, etc.)."""

    def __init__(
        self,
        base_url: str,
        api_key: str = "dummy",
        token_manager: Optional[TokenManager] = None,
        ssl_config: dict | None = None,
        timeout: float = 60,
        max_retries: int = 3,
    ):
        self.base_url = _normalize_base_url(base_url)
        self.api_key = api_key
        self.token_manager = token_manager
        self.ssl_config = ssl_config
        self.timeout = timeout
        self.max_retries = max_retries

    async def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.token_manager:
            h["Authorization"] = f"Bearer {await self.token_manager.get_token()}"
        elif self.api_key and self.api_key != "dummy":
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def embed(self, texts: list[str], model: str) -> list[list[float]]:
        async with _build_httpx_client(self.timeout, self.ssl_config) as client:
            resp = await client.post(
                f"{self.base_url}/v1/embeddings",
                json={"model": model, "input": texts},
                headers=await self._headers(),
            )
            resp.raise_for_status()
            data = resp.json()
            # Sort by index to preserve order
            return [item["embedding"] for item in sorted(data["data"], key=lambda x: x["index"])]


class OpenAICompatibleRerankProvider(BaseRerankProvider):
    """Reranker for vLLM-hosted rerank endpoints."""

    def __init__(
        self,
        endpoint: str,
        api_key: str = "dummy",
        token_manager: Optional[TokenManager] = None,
        ssl_config: dict | None = None,
        timeout: float = 60,
        max_retries: int = 3,
    ):
        self.endpoint = endpoint
        self.api_key = api_key
        self.token_manager = token_manager
        self.ssl_config = ssl_config
        self.timeout = timeout
        self.max_retries = max_retries

    async def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self.token_manager:
            h["Authorization"] = f"Bearer {await self.token_manager.get_token()}"
        elif self.api_key and self.api_key != "dummy":
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def rerank(self, query, documents, model, top_n=5) -> list[dict]:
        payload = {"model": model, "query": query, "documents": documents, "top_n": top_n}
        async with _build_httpx_client(self.timeout, self.ssl_config) as client:
            resp = await client.post(self.endpoint, json=payload, headers=await self._headers())
            resp.raise_for_status()
            data = resp.json()
            # Normalize to [{index, score, document}] format
            results = data.get("results", data.get("data", []))
            return sorted(results, key=lambda x: x.get("relevance_score", x.get("score", 0)), reverse=True)


class InternalOCRProvider(BaseOCRProvider):
    """
    Dedicated OCR provider for internal Format AI OCR service.
    Fetches token, uploads file, returns extracted text.
    """

    def __init__(
        self,
        endpoint: str,
        token_manager: TokenManager,
    ):
        self.endpoint = endpoint
        self.token_manager = token_manager

    async def ocr_file(self, file_path: str) -> str:
        token = await self.token_manager.get_token()
        async with httpx.AsyncClient(timeout=300) as client:
            with open(file_path, "rb") as f:
                resp = await client.post(
                    self.endpoint,
                    files={"file": (file_path.rsplit("/", 1)[-1], f, "application/octet-stream")},
                    headers={"Authorization": f"Bearer {token}"},
                )
            resp.raise_for_status()
            data = resp.json()
            # Handle common response shapes
            return (
                data.get("text")
                or data.get("extracted_text")
                or data.get("content")
                or str(data)
            )
