"""
Provider factory — resolves provider implementations from config.

PROVIDER_MODE in config selects the concrete provider for each capability:
  - anthropic        → Anthropic Claude API
  - openai           → OpenAI API (GPT-4, etc.)
  - internal_vllm    → Internal vLLM endpoints with token auth
  - azure_openai     → Azure OpenAI Service
  - ollama           → Local Ollama server
  - bedrock          → AWS Bedrock (OpenAI-compat endpoint)
  - vertex           → Google Vertex AI (OpenAI-compat endpoint)
"""
from __future__ import annotations

import logging
from functools import lru_cache
from typing import Optional

from providers.base import (
    BaseLLMProvider, BaseVisionProvider,
    BaseEmbeddingProvider, BaseRerankProvider, BaseOCRProvider,
)

logger = logging.getLogger(__name__)


class ProviderRegistry:
    """Singleton registry holding initialized provider instances."""

    def __init__(self):
        self.llm: Optional[BaseLLMProvider] = None
        self.vision: Optional[BaseVisionProvider] = None
        self.embedding: Optional[BaseEmbeddingProvider] = None
        self.reranker: Optional[BaseRerankProvider] = None
        self.ocr: Optional[BaseOCRProvider] = None

    def get_llm(self) -> BaseLLMProvider:
        if not self.llm:
            raise RuntimeError("LLM provider not initialized. Check PROVIDER_MODE config.")
        return self.llm

    def get_vision(self) -> BaseVisionProvider:
        if not self.vision:
            raise RuntimeError("Vision provider not initialized.")
        return self.vision

    def get_embedding(self) -> BaseEmbeddingProvider:
        if not self.embedding:
            raise RuntimeError("Embedding provider not initialized.")
        return self.embedding

    def get_reranker(self) -> BaseRerankProvider:
        if not self.reranker:
            raise RuntimeError("Reranker provider not initialized.")
        return self.reranker

    def get_ocr(self) -> BaseOCRProvider:
        if not self.ocr:
            raise RuntimeError("OCR provider not initialized.")
        return self.ocr

    @property
    def has_llm(self) -> bool:
        return self.llm is not None

    @property
    def has_vision(self) -> bool:
        return self.vision is not None

    @property
    def has_vlm(self) -> bool:
        return self.vision is not None

    @property
    def has_ocr(self) -> bool:
        return self.ocr is not None

    @property
    def has_vectorisation(self) -> bool:
        return self.embedding is not None

    @property
    def has_reranker(self) -> bool:
        return self.reranker is not None

    @property
    def llm_has_vision(self) -> bool:
        """True if the current LLM + Vision setup supports image inputs."""
        return self.vision is not None


_registry: Optional[ProviderRegistry] = None


def get_registry() -> ProviderRegistry:
    global _registry
    if _registry is None:
        raise RuntimeError("Provider registry not initialized. Call init_providers() at startup.")
    return _registry


def init_providers(config: dict) -> ProviderRegistry:
    """
    Initialize all providers from config dict.
    Call once at application startup (main.py lifespan).

    Config must have PROVIDER_MODE key. Example:
        config = load_full_config()  # parses config.yaml
        init_providers(config)
    """
    global _registry
    registry = ProviderRegistry()
    mode = config.get("PROVIDER_MODE", "anthropic").lower()
    logger.info("Initializing providers with mode: %s", mode)

    if mode == "anthropic":
        _init_anthropic(registry, config)
    elif mode in ("openai",):
        _init_openai(registry, config)
    elif mode == "internal_vllm":
        _init_internal_vllm(registry, config)
    elif mode == "azure_openai":
        _init_azure_openai(registry, config)
    elif mode == "ollama":
        _init_ollama(registry, config)
    elif mode in ("bedrock", "vertex"):
        _init_openai_compat_generic(registry, config, mode)
    elif mode == "private":
        _init_private(registry, config)
    else:
        raise ValueError(f"Unknown PROVIDER_MODE: {mode}. Valid: anthropic, openai, internal_vllm, azure_openai, ollama, bedrock, vertex, private")

    _registry = registry
    return registry


# ── Mode initializers ──────────────────────────────────────────────────────

def _init_anthropic(registry: ProviderRegistry, config: dict) -> None:
    from providers.anthropic_provider import AnthropicLLMProvider, AnthropicVisionProvider
    registry.llm = AnthropicLLMProvider()
    registry.vision = AnthropicVisionProvider()
    logger.info("Anthropic LLM + Vision providers initialized.")


def _init_openai(registry: ProviderRegistry, config: dict) -> None:
    from providers.openai_compatible_provider import (
        OpenAICompatibleLLMProvider, OpenAICompatibleVisionProvider,
        OpenAICompatibleEmbeddingProvider,
    )
    llm_cfg = config.get("LLM", {})
    base_url = llm_cfg.get("base_url", "https://api.openai.com")
    api_key = llm_cfg.get("api_key", "")
    registry.llm = OpenAICompatibleLLMProvider(base_url=base_url, api_key=api_key)
    registry.vision = OpenAICompatibleVisionProvider(base_url=base_url, api_key=api_key)
    registry.embedding = OpenAICompatibleEmbeddingProvider(base_url=base_url, api_key=api_key)
    logger.info("OpenAI-compatible providers initialized (base_url=%s)", base_url)


def _init_internal_vllm(registry: ProviderRegistry, config: dict) -> None:
    from providers.openai_compatible_provider import (
        OpenAICompatibleLLMProvider, OpenAICompatibleVisionProvider,
        OpenAICompatibleEmbeddingProvider, OpenAICompatibleRerankProvider,
        InternalOCRProvider,
    )
    from providers.token_manager import TokenManager

    llm_cfg = config.get("LLM", {})
    vlm_cfg = config.get("VLM", {})
    vlm_t_cfg = config.get("VLM_TRANSFORMER", {})
    vec_cfg = config.get("VECTORISATION", {})
    rerank_cfg = config.get("RERANKER", {})
    ocr_cfg = config.get("OCR", {})

    # Build shared token manager if OCR config has auth_url
    ocr_token_mgr = None
    if ocr_cfg.get("auth_url"):
        ocr_token_mgr = TokenManager(
            auth_url=ocr_cfg["auth_url"],
            client_app_name=ocr_cfg.get("client_app_name", "sow-portal"),
            server_app_name=ocr_cfg.get("server_app_name", "llm-coordinator"),
            api_key=ocr_cfg.get("api_key", ""),
        )

    registry.llm = OpenAICompatibleLLMProvider(
        base_url=llm_cfg.get("base_url", ""),
        api_key=llm_cfg.get("api_key", "dummy"),
    )

    # Vision: prefer VLM_TRANSFORMER (OpenAI-compatible), fallback to VLM
    vlm_base = vlm_t_cfg.get("base_url") or vlm_cfg.get("endpoint", "").rsplit("/v1", 1)[0]
    registry.vision = OpenAICompatibleVisionProvider(
        base_url=vlm_base,
        api_key=vlm_t_cfg.get("api_key", vlm_cfg.get("api_key", "dummy")),
    )

    if vec_cfg.get("base_url"):
        registry.embedding = OpenAICompatibleEmbeddingProvider(
            base_url=vec_cfg["base_url"],
            api_key=vec_cfg.get("api_key", "dummy"),
        )

    if rerank_cfg.get("endpoint"):
        registry.reranker = OpenAICompatibleRerankProvider(
            endpoint=rerank_cfg["endpoint"],
            api_key=rerank_cfg.get("api_key", "dummy"),
        )

    if ocr_cfg.get("endpoint") and ocr_token_mgr:
        registry.ocr = InternalOCRProvider(
            endpoint=ocr_cfg["endpoint"],
            token_manager=ocr_token_mgr,
        )

    logger.info("Internal vLLM providers initialized.")


def _init_azure_openai(registry: ProviderRegistry, config: dict) -> None:
    from providers.openai_compatible_provider import (
        OpenAICompatibleLLMProvider, OpenAICompatibleVisionProvider,
        OpenAICompatibleEmbeddingProvider,
    )
    az_cfg = config.get("AZURE_OPENAI", {})
    # Azure OpenAI uses: {endpoint}/openai/deployments/{deployment}/...?api-version=...
    endpoint = az_cfg.get("endpoint", "").rstrip("/")
    api_key = az_cfg.get("api_key", "")
    api_version = az_cfg.get("api_version", "2024-02-01")
    # Use custom headers for Azure
    headers = {"api-key": api_key}
    base_url = f"{endpoint}/openai"
    registry.llm = OpenAICompatibleLLMProvider(base_url=base_url, api_key=api_key, extra_headers={"api-version": api_version})
    registry.vision = OpenAICompatibleVisionProvider(base_url=base_url, api_key=api_key)
    registry.embedding = OpenAICompatibleEmbeddingProvider(base_url=base_url, api_key=api_key)
    logger.info("Azure OpenAI providers initialized (endpoint=%s)", endpoint)


def _init_ollama(registry: ProviderRegistry, config: dict) -> None:
    from providers.openai_compatible_provider import (
        OpenAICompatibleLLMProvider, OpenAICompatibleVisionProvider,
        OpenAICompatibleEmbeddingProvider,
    )
    ol_cfg = config.get("OLLAMA", {})
    base_url = ol_cfg.get("base_url", "http://localhost:11434")
    registry.llm = OpenAICompatibleLLMProvider(base_url=base_url, api_key="ollama")
    registry.vision = OpenAICompatibleVisionProvider(base_url=base_url, api_key="ollama")
    registry.embedding = OpenAICompatibleEmbeddingProvider(base_url=base_url, api_key="ollama")
    logger.info("Ollama providers initialized (base_url=%s)", base_url)


def _build_ssl_config(config: dict) -> dict | None:
    """Extract SSL settings from config. Returns None if SSL disabled."""
    ssl_cfg = config.get("ssl", {})
    if not ssl_cfg.get("enabled", False):
        return None
    return {
        "verify": ssl_cfg.get("verify", True),
        "ca_bundle_path": ssl_cfg.get("ca_bundle_path", ""),
        "ssl_cert_path": ssl_cfg.get("ssl_cert_path", ""),
        "ssl_key_path": ssl_cfg.get("ssl_key_path", ""),
    }


def _init_private(registry: ProviderRegistry, config: dict) -> None:
    """
    Private mode: all services use separate OpenAI-compatible endpoints.
    Each service (LLM, OCR/VLM, Vectorisation, Reranker) has its own
    base_url, api_key, model_name, timeout, and max_retries.
    Uses the openai Python library internally via OpenAICompatibleLLMProvider.
    Works with both http:// and https:// endpoints (SSL config applied).
    """
    from providers.openai_compatible_provider import (
        OpenAICompatibleLLMProvider,
        OpenAICompatibleVisionProvider,
        OpenAICompatibleEmbeddingProvider,
        OpenAICompatibleRerankProvider,
    )

    private_cfg = config.get("private", {})
    ssl_config = _build_ssl_config(config)

    # ── LLM ──
    llm_cfg = private_cfg.get("llm", {})
    if llm_cfg.get("base_url"):
        registry.llm = OpenAICompatibleLLMProvider(
            base_url=llm_cfg["base_url"],
            api_key=llm_cfg.get("api_key", "EMPTY") or "EMPTY",
            ssl_config=ssl_config,
            timeout=float(llm_cfg.get("timeout", 120)),
            max_retries=int(llm_cfg.get("max_retries", 3)),
        )
        logger.info("Private LLM: %s (model=%s)", llm_cfg["base_url"], llm_cfg.get("model_name"))

    # ── OCR / Vision ──
    vlm_cfg = private_cfg.get("vlm", {})
    ocr_cfg = private_cfg.get("ocr", {})
    # Use VLM endpoint for vision; OCR can fall back to VLM if not separately configured
    vision_cfg = vlm_cfg if vlm_cfg.get("base_url") else ocr_cfg
    if vision_cfg.get("base_url"):
        registry.vision = OpenAICompatibleVisionProvider(
            base_url=vision_cfg["base_url"],
            api_key=vision_cfg.get("api_key", "EMPTY") or "EMPTY",
            ssl_config=ssl_config,
            timeout=float(vision_cfg.get("timeout", 120)),
            max_retries=int(vision_cfg.get("max_retries", 3)),
        )
        logger.info("Private Vision/VLM: %s", vision_cfg["base_url"])

    # ── Embeddings / Vectorisation ──
    vec_cfg = private_cfg.get("vectorisation", {})
    if vec_cfg.get("base_url"):
        registry.embedding = OpenAICompatibleEmbeddingProvider(
            base_url=vec_cfg["base_url"],
            api_key=vec_cfg.get("api_key", "EMPTY") or "EMPTY",
            ssl_config=ssl_config,
            timeout=float(vec_cfg.get("timeout", 60)),
            max_retries=int(vec_cfg.get("max_retries", 3)),
        )
        logger.info("Private Embeddings: %s (model=%s)", vec_cfg["base_url"], vec_cfg.get("model_name"))

    # ── Reranker ──
    rerank_cfg = private_cfg.get("reranker", {})
    if rerank_cfg.get("base_url"):
        # Reranker endpoint: base_url + /rerank
        rerank_endpoint = rerank_cfg["base_url"].rstrip("/") + "/rerank"
        registry.reranker = OpenAICompatibleRerankProvider(
            endpoint=rerank_endpoint,
            api_key=rerank_cfg.get("api_key", "EMPTY") or "EMPTY",
            ssl_config=ssl_config,
            timeout=float(rerank_cfg.get("timeout", 60)),
            max_retries=int(rerank_cfg.get("max_retries", 3)),
        )
        logger.info("Private Reranker: %s", rerank_endpoint)

    logger.info("Private mode providers initialized (ssl=%s).", "enabled" if ssl_config else "disabled")


def _init_openai_compat_generic(registry: ProviderRegistry, config: dict, mode: str) -> None:
    from providers.openai_compatible_provider import OpenAICompatibleLLMProvider, OpenAICompatibleVisionProvider
    cfg_key = mode.upper()
    cfg = config.get(cfg_key, config.get("LLM", {}))
    base_url = cfg.get("base_url", cfg.get("endpoint", ""))
    api_key = cfg.get("api_key", "")
    registry.llm = OpenAICompatibleLLMProvider(base_url=base_url, api_key=api_key)
    registry.vision = OpenAICompatibleVisionProvider(base_url=base_url, api_key=api_key)
    logger.info("%s providers initialized (base_url=%s)", mode, base_url)
