"""
Token manager for internal vLLM endpoints that require bearer token auth.
Fetches tokens from an auth_url, caches them, and auto-refreshes on expiry.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Optional

import httpx

logger = logging.getLogger(__name__)


class TokenManager:
    """
    Manages bearer tokens for internal endpoints.

    Fetches a new token from auth_url when needed,
    caches it for the token TTL, and refreshes automatically.
    """

    def __init__(
        self,
        auth_url: str,
        client_app_name: str,
        server_app_name: str,
        api_key: str = "",
        token_ttl_seconds: int = 3600,
    ):
        self.auth_url = auth_url
        self.client_app_name = client_app_name
        self.server_app_name = server_app_name
        self.api_key = api_key
        self.token_ttl = token_ttl_seconds

        self._token: Optional[str] = None
        self._token_expiry: float = 0.0
        self._lock = asyncio.Lock()

    def _is_expired(self) -> bool:
        return time.monotonic() >= self._token_expiry - 60  # refresh 60s early

    async def get_token(self) -> str:
        """Return a valid bearer token, fetching/refreshing as needed."""
        if self._token and not self._is_expired():
            return self._token

        async with self._lock:
            # Double-check after acquiring lock
            if self._token and not self._is_expired():
                return self._token
            await self._fetch_token()
            return self._token  # type: ignore

    async def _fetch_token(self) -> None:
        """Fetch a new token from the auth endpoint."""
        payload = {
            "client_app_name": self.client_app_name,
            "server_app_name": self.server_app_name,
        }
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(self.auth_url, json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()

        # Support common token response shapes
        self._token = (
            data.get("access_token")
            or data.get("token")
            or data.get("Bearer")
            or str(data)
        )
        self._token_expiry = time.monotonic() + self.token_ttl
        logger.info("Token refreshed successfully for %s", self.client_app_name)
