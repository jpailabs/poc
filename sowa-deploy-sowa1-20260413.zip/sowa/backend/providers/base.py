"""Abstract base classes for all AI provider capabilities."""
from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Optional
import base64


class BaseLLMProvider(ABC):
    """Text completion/chat provider."""

    @abstractmethod
    async def complete(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> str:
        """Non-streaming text completion. Returns response text."""
        ...

    @abstractmethod
    async def stream(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> AsyncGenerator[str, None]:
        """Streaming text generation. Yields text tokens."""
        ...


class BaseVisionProvider(ABC):
    """Vision/VLM provider for image + text inputs."""

    @abstractmethod
    async def vision_complete(
        self,
        system: str,
        user_text: str,
        image_b64: str,
        image_media_type: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> str:
        """Process image + text prompt, return text response."""
        ...


class BaseEmbeddingProvider(ABC):
    """Text embedding provider."""

    @abstractmethod
    async def embed(self, texts: list[str], model: str) -> list[list[float]]:
        """Embed a list of texts. Returns list of float vectors."""
        ...


class BaseRerankProvider(ABC):
    """Document reranking provider."""

    @abstractmethod
    async def rerank(
        self,
        query: str,
        documents: list[str],
        model: str,
        top_n: int = 5,
    ) -> list[dict]:
        """Rerank documents by relevance to query. Returns sorted list with scores."""
        ...


class BaseOCRProvider(ABC):
    """Dedicated OCR provider (non-vision-LLM based)."""

    @abstractmethod
    async def ocr_file(self, file_path: str) -> str:
        """Extract text from a file at given path. Returns extracted text."""
        ...
