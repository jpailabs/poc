"""Anthropic Claude provider implementation.

All synchronous Anthropic SDK calls are run in a thread-pool executor so they
never block the asyncio event loop. Without this, a slow or overloaded API
call freezes the entire server — SSE events stop flowing, the browser shows
the last status message forever, and the app appears stuck.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import AsyncGenerator

import anthropic

from providers.base import BaseLLMProvider, BaseVisionProvider

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_CODES = {429, 529, 500, 502, 503}
# Hard timeout per LLM call (seconds). Prevents indefinite hangs on API issues.
LLM_TIMEOUT_SECONDS = 120


def _get_client() -> anthropic.Anthropic:
    import os
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set.")
    return anthropic.Anthropic(api_key=api_key)


class AnthropicLLMProvider(BaseLLMProvider):
    """LLM provider using Anthropic Claude API — non-blocking async wrapper."""

    async def complete(self, system, user, model, max_tokens, temperature) -> str:
        """
        Run the synchronous Anthropic SDK in a thread-pool executor so the
        asyncio event loop stays free during the API call. Also enforces a
        hard timeout so overloaded/slow API calls don't hang indefinitely.
        """
        def _sync_call() -> str:
            client = _get_client()
            last_error: Exception | None = None
            for attempt in range(MAX_RETRIES):
                try:
                    resp = client.messages.create(
                        model=model,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        system=system,
                        messages=[{"role": "user", "content": user}],
                    )
                    return resp.content[0].text
                except anthropic.APIStatusError as e:
                    last_error = e
                    if e.status_code in RETRY_CODES and attempt < MAX_RETRIES - 1:
                        backoff = 2 ** attempt
                        logger.warning(
                            "Anthropic API %d (attempt %d/%d), retrying in %ds",
                            e.status_code, attempt + 1, MAX_RETRIES, backoff,
                        )
                        time.sleep(backoff)  # sync sleep — fine inside a thread
                        continue
                    raise
                except Exception as e:
                    last_error = e
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(2 ** attempt)
                        continue
                    raise
            raise last_error or RuntimeError("Max retries exceeded")

        loop = asyncio.get_running_loop()
        try:
            return await asyncio.wait_for(
                loop.run_in_executor(None, _sync_call),
                timeout=LLM_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"Anthropic LLM call timed out after {LLM_TIMEOUT_SECONDS}s. "
                "The API may be overloaded — please retry."
            )

    async def stream(self, system, user, model, max_tokens, temperature) -> AsyncGenerator[str, None]:
        """
        Stream tokens using the sync Anthropic streaming SDK, but run the
        entire stream collection in a thread so the event loop stays free.
        Buffers all chunks and yields them asynchronously.
        """
        def _collect_chunks() -> list[str]:
            client = _get_client()
            chunks: list[str] = []
            with client.messages.stream(
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system,
                messages=[{"role": "user", "content": user}],
            ) as stream:
                for chunk in stream.text_stream:
                    chunks.append(chunk)
            return chunks

        loop = asyncio.get_running_loop()
        try:
            chunks = await asyncio.wait_for(
                loop.run_in_executor(None, _collect_chunks),
                timeout=LLM_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"Anthropic streaming timed out after {LLM_TIMEOUT_SECONDS}s."
            )

        # Yield collected chunks so callers see progressive output
        for chunk in chunks:
            yield chunk
            await asyncio.sleep(0)  # yield control between chunks


class AnthropicVisionProvider(BaseVisionProvider):
    """Vision provider using Anthropic Claude Vision — non-blocking."""

    async def vision_complete(
        self, system, user_text, image_b64, image_media_type, model, max_tokens, temperature
    ) -> str:
        def _sync_call() -> str:
            client = _get_client()
            last_error: Exception | None = None
            for attempt in range(MAX_RETRIES):
                try:
                    resp = client.messages.create(
                        model=model,
                        max_tokens=max_tokens,
                        temperature=temperature,
                        system=system,
                        messages=[{
                            "role": "user",
                            "content": [
                                {"type": "image", "source": {
                                    "type": "base64",
                                    "media_type": image_media_type,
                                    "data": image_b64,
                                }},
                                {"type": "text", "text": user_text},
                            ],
                        }],
                    )
                    return resp.content[0].text
                except anthropic.APIStatusError as e:
                    last_error = e
                    if e.status_code in RETRY_CODES and attempt < MAX_RETRIES - 1:
                        backoff = 2 ** attempt
                        logger.warning(
                            "Anthropic Vision API %d (attempt %d/%d), retrying in %ds",
                            e.status_code, attempt + 1, MAX_RETRIES, backoff,
                        )
                        time.sleep(backoff)
                        continue
                    raise
                except Exception as e:
                    last_error = e
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(2 ** attempt)
                        continue
                    raise
            raise last_error or RuntimeError("Max retries exceeded")

        loop = asyncio.get_running_loop()
        try:
            return await asyncio.wait_for(
                loop.run_in_executor(None, _sync_call),
                timeout=LLM_TIMEOUT_SECONDS,
            )
        except asyncio.TimeoutError:
            raise RuntimeError(
                f"Anthropic Vision call timed out after {LLM_TIMEOUT_SECONDS}s."
            )
