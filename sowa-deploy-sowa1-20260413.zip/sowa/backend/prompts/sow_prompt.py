"""SOW report prompt templates — enterprise private banking compliance standard."""

from __future__ import annotations


# ── System Prompt ─────────────────────────────────────────────────────────────

_DEFAULT_SOW_SYSTEM_PROMPT = """\
You are a senior compliance officer and relationship manager at a top-tier global private bank. \
You are writing a Source of Wealth report that will be read by the onboarding relationship manager, \
the compliance committee, and potentially the regulatory examiner. \
This report must read as if written by an experienced banking professional — \
authoritative, precise, and structured. It covers the client's complete wealth profile \
under MAS Notice SFA 04-N13.

━━━ TONE AND WRITING STANDARD ━━━

Write with the authority and confidence of a senior private banking compliance officer. \
Every sentence must be a direct, declarative statement of verified fact. \
The relationship manager reading this report is an expert — write at their level.

Third person formal throughout. Refer to the individual by full name on first mention \
in each section, then as "the applicant". Never "client". Never first person.

No hedging. No qualifiers. No speculation. State facts. State conclusions. Nothing else.

The report must flow as polished professional prose — not a checklist, not a data dump. \
Tables carry the quantitative data. The narrative introduces the context, states the \
key verified facts, and closes with a definitive compliance conclusion.

━━━ ABSOLUTE PROHIBITIONS ━━━

Never write: "it appears", "it would seem", "this suggests", "this indicates", \
"consistent with", "it is noted", "for the avoidance of doubt", "this may reflect", \
"demonstrating", "reflecting financial capacity", or any phrase that infers rather than states.

Never write speculative analysis. Never explain why data might be absent. \
Never compare the applicant to a population benchmark.

Never write placeholder text under any circumstances. If a value is not in the \
verified fields provided, omit that sentence or table row entirely. \
Do not write "the declared amount", "the verified income", "the relevant year", \
"significant" as a shareholding value, or any descriptive substitute for a real number. \
Omission is always correct. Substitution is never acceptable.

No bullet points in narrative sections. No markdown. No hashtag headers. No asterisks. \
No pipe characters outside TABLE blocks.

━━━ SECTION STRUCTURE — FIXED ORDER ━━━

Produce exactly these sections in this order. Do not add, remove, or rename any section.

1. Executive Summary
2. Employment History & Income
3. Business Interests & Shareholding
4. Investment Portfolio
5. Tax Compliance Evidence
6. Other Financial Indicators
7. Risk Assessment Summary
8. Conclusion & Certification

For sections with no verified data, write one sentence only:
"No verified data pertaining to [topic] has been submitted for this applicant; \
this section is not applicable to the current review."

━━━ EXECUTIVE SUMMARY REQUIREMENTS ━━━

Open with a strong, authoritative paragraph establishing who the applicant is, \
their wealth profile type, and the scope of this assessment. Name the primary \
verified wealth source explicitly. State the MAS regulatory basis. \
Include a Summary of Verified Wealth table covering all wealth sources assessed.

━━━ EMPLOYMENT SECTION REQUIREMENTS ━━━

State the employer, designation, and verified income figures in confident prose. \
Reference the year of assessment. Close with a one-sentence compliance conclusion \
confirming the income is fully documented and consistent with the stated wealth profile.

━━━ TAX COMPLIANCE REQUIREMENTS ━━━

Present the full tax computation as a table. State the year of assessment and \
the issuing authority. The narrative must confirm tax compliance status definitively. \
Do not list tax components in prose — put them in the table.

━━━ RISK ASSESSMENT REQUIREMENTS ━━━

Derive the risk rating only from what is verified. Rules:
LOW — single documented wealth source, government-issued Singapore documentation, no complex structures.
MEDIUM — multiple wealth sources or any complexity requiring additional documentation.
HIGH — unverified claims, unexplained wealth, jurisdictional risk, structural complexity.
Never rate risk from the absence of data.

━━━ OUTPUT FORMAT — MANDATORY ━━━

[SECTION: Section Title]
[NARRATIVE]
Paragraph prose. Professional. Declarative. No markdown. No lists.
[/NARRATIVE]
[TABLE]
CAPTION: Brief description
ALIGN: left,right
HEADERS: Column One | Column Two
ROW: Label | Value
TOTAL: Total Label | Total Value
[/TABLE]
[/SECTION]

Rules: Pipe character | only inside TABLE blocks. No ## headings. No bold markers. \
Every [TABLE] requires CAPTION, ALIGN, HEADERS, and at least one ROW.\
"""

SOW_REPORT_SECTIONS = [
    "Executive Summary",
    "Employment History & Income",
    "Business Interests & Shareholding",
    "Investment Portfolio",
    "Tax Compliance Evidence",
    "Other Financial Indicators",
    "Risk Assessment Summary",
    "Conclusion & Certification",
]


def get_sow_system_prompt(override: str | None = None) -> str:
    if override:
        return override
    return _DEFAULT_SOW_SYSTEM_PROMPT


def get_sow_user_prompt(verified_fields: list, profile_type: str) -> str:
    """
    Build the SOW generation prompt. Fields are passed as clean label: value pairs —
    no source_file clutter, no page numbers, no confidence scores in the prompt.
    The LLM should write professional prose, not annotated extraction output.
    """
    from datetime import datetime

    # Group fields by display_category
    by_category: dict[str, list] = {}
    for f in verified_fields:
        if not isinstance(f, dict):
            continue
        cat = f.get("display_category") or f.get("category") or "Other"
        by_category.setdefault(cat, []).append(f)

    # Build clean label: value pairs — no source annotations
    field_lines = []
    for cat, fields in by_category.items():
        field_lines.append(f"\n{cat.upper()}:")
        for f in fields:
            label = f.get("display_label") or f.get("key", "")
            val = f.get("value", "")
            if label and val:
                field_lines.append(f"  {label}: {val}")

    fields_block = "\n".join(field_lines) if field_lines else "  (no verified fields available)"

    # Detect which sections have data
    cat_to_section = {
        "Employment Income": "Employment History & Income",
        "EMPLOYMENT_INCOME": "Employment History & Income",
        "Business & Corporate Income": "Business Interests & Shareholding",
        "BUSINESS": "Business Interests & Shareholding",
        "Dividends & Shareholdings": "Business Interests & Shareholding",
        "DIVIDENDS": "Business Interests & Shareholding",
        "SHAREHOLDING": "Business Interests & Shareholding",
        "Investment Portfolio": "Investment Portfolio",
        "INVESTMENTS": "Investment Portfolio",
        "Tax & Assessment": "Tax Compliance Evidence",
        "TAX_DOCUMENTS": "Tax Compliance Evidence",
        "Banking & Cash": "Other Financial Indicators",
        "BANK_SAVINGS": "Other Financial Indicators",
        "CPF & Retirement": "Other Financial Indicators",
        "CPF": "Other Financial Indicators",
        "Property & Real Estate": "Other Financial Indicators",
        "PROPERTY": "Other Financial Indicators",
        "Personal & Identity": "Executive Summary",
        "IDENTITY": "Executive Summary",
        "Other Wealth Sources": "Other Financial Indicators",
        "OTHER_FINANCIAL": "Other Financial Indicators",
    }

    sections_with_data = {"Executive Summary", "Risk Assessment Summary", "Conclusion & Certification"}
    for cat in by_category:
        sec = cat_to_section.get(cat)
        if sec:
            sections_with_data.add(sec)

    absent = [s for s in SOW_REPORT_SECTIONS if s not in sections_with_data]

    gen_date = datetime.now().strftime("%d %B %Y")

    sections_list = "\n".join(
        f"  {i}. {s}" for i, s in enumerate(SOW_REPORT_SECTIONS, 1)
    )

    present_note = (
        f"WEALTH CATEGORIES WITH VERIFIED DATA: {', '.join(c for c in by_category if c not in ('Personal & Identity','IDENTITY'))}\n"
        if by_category else ""
    )
    absent_note = (
        f"SECTIONS WITH NO DATA (write one 'not applicable' sentence): {', '.join(absent)}\n"
        if absent else ""
    )

    return (
        f"Report date: {gen_date}\n"
        f"Client profile type: {profile_type}\n"
        f"Total verified data points: {len(verified_fields)}\n\n"
        f"{present_note}"
        f"{absent_note}\n"
        f"VERIFIED DATA (use only these values — write professional prose around them):\n"
        f"{fields_block}\n\n"
        f"Write a complete, professional Source of Wealth report covering all "
        f"{len(SOW_REPORT_SECTIONS)} sections in order:\n{sections_list}\n\n"
        f"The report must read as polished private banking compliance documentation. "
        f"Use only the verified values above. Never invent, estimate, or use placeholder language. "
        f"Tables carry the numbers. Prose carries the assessment and conclusion."
    )
