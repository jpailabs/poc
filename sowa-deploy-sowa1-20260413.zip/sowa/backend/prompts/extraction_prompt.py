"""
Universal financial document extraction prompts with per-category strategies.

Every upload category from the frontend has a dedicated extraction strategy
that specifies exact field lists and extraction instructions for that doc type.
"""
from __future__ import annotations

import json
from enum import Enum


# ── 29-type document classification taxonomy ──────────────────────────────────

DOCUMENT_TYPES = [
    "EMPLOYMENT_PAYSLIP", "EMPLOYMENT_CONTRACT", "IRAS_NOA", "IRAS_TAX_CLEARANCE",
    "CORPORATE_FINANCIAL_STATEMENT", "CORPORATE_ANNUAL_REPORT",
    "DIRECTOR_REMUNERATION_NOTICE", "DIVIDEND_NOTICE", "SHAREHOLDING_CERTIFICATE",
    "INVESTMENT_PORTFOLIO_STATEMENT", "BROKERAGE_STATEMENT", "UNIT_TRUST_STATEMENT",
    "FIXED_DEPOSIT_CERTIFICATE", "PROPERTY_VALUATION_REPORT", "PROPERTY_TITLE_DEED",
    "LOAN_AGREEMENT", "BANK_STATEMENT", "BANK_REFERENCE_LETTER", "CPF_STATEMENT",
    "INHERITANCE_DOCUMENT", "GIFT_LETTER", "BUSINESS_REGISTRATION",
    "PARTNERSHIP_AGREEMENT", "TRUST_DEED", "FOREIGN_TAX_DOCUMENT",
    "CRYPTO_STATEMENT", "PENSION_STATEMENT", "INSURANCE_VALUATION", "UNKNOWN",
]

DOCUMENT_TYPES_STR = ", ".join(DOCUMENT_TYPES)


class FinancialCategory(str, Enum):
    EMPLOYMENT_INCOME = "EMPLOYMENT_INCOME"
    TAX_DOCUMENTS = "TAX_DOCUMENTS"
    SHAREHOLDING = "SHAREHOLDING"
    DIVIDENDS = "DIVIDENDS"
    INVESTMENTS = "INVESTMENTS"
    BANK_SAVINGS = "BANK_SAVINGS"
    IDENTITY = "IDENTITY"
    OTHER_FINANCIAL = "OTHER_FINANCIAL"


REVIEW_DISPLAY_CATEGORIES = [
    "Personal & Identity", "Employment Income", "Tax & Assessment",
    "Business & Corporate Income", "Investment Portfolio",
    "Property & Real Estate", "Banking & Cash",
    "Dividends & Shareholdings", "Other Wealth Sources", "CPF & Retirement",
]

CATEGORY_TO_DISPLAY = {
    "IDENTITY": "Personal & Identity",
    "EMPLOYMENT_INCOME": "Employment Income",
    "TAX_DOCUMENTS": "Tax & Assessment",
    "SHAREHOLDING": "Dividends & Shareholdings",
    "DIVIDENDS": "Dividends & Shareholdings",
    "INVESTMENTS": "Investment Portfolio",
    "BANK_SAVINGS": "Banking & Cash",
    "OTHER_FINANCIAL": "Other Wealth Sources",
    "PROPERTY": "Property & Real Estate",
    "BUSINESS": "Business & Corporate Income",
    "CPF": "CPF & Retirement",
}

SALARIED_PRIORITY = [
    "Personal & Identity", "Employment Income", "Tax & Assessment",
    "Banking & Cash", "CPF & Retirement", "Investment Portfolio",
    "Property & Real Estate", "Dividends & Shareholdings",
    "Business & Corporate Income", "Other Wealth Sources",
]

BUSINESS_OWNER_PRIORITY = [
    "Personal & Identity", "Business & Corporate Income",
    "Dividends & Shareholdings", "Investment Portfolio",
    "Tax & Assessment", "Banking & Cash", "Employment Income",
    "Property & Real Estate", "CPF & Retirement", "Other Wealth Sources",
]


# ── Per-category extraction strategies ────────────────────────────────────────
# Maps frontend doc category ID → {doc_type, display_category, field_instructions}

CATEGORY_STRATEGIES: dict[str, dict] = {

    # ── SALARIED PROFESSIONAL ─────────────────────────────────────────────────

    "income_tax": {
        "doc_type": "IRAS_NOA",
        "display_name": "IRAS Notice of Assessment",
        "display_category": "Tax & Assessment",
        "field_instructions": """
DOCUMENT TYPE: IRAS Notice of Assessment (NOA) — Singapore personal income tax.

Extract EVERY field present including:
IDENTIFICATION: full name, NRIC/Tax ref number, address, year of assessment
INCOME SECTION — extract each line individually:
  employment_income, trade_income, rent_income, interest_income,
  dividend_income, other_income, total_income
RELIEFS & DEDUCTIONS — extract EVERY line item individually with amount:
  earned_income_relief, cpf_relief (employee + employer separately),
  nsman_relief, spouse_relief, parent_relief, child_relief, course_fees_relief,
  life_insurance_relief, cpf_cash_top_up_relief, charitable_donations,
  any other relief listed with its exact name and amount
COMPUTATION:
  total_income, total_reliefs, chargeable_income,
  tax_on_first_20k (or applicable tier), tax_rate, tax_on_balance,
  gross_tax, personal_tax_rebate, net_tax_payable
ADMIN: document_reference_number, amendment_deadline, payment_due_date,
  issuing_authority (IRAS), assessment_date
""",
    },

    "payslips": {
        "doc_type": "EMPLOYMENT_PAYSLIP",
        "display_name": "Payslip",
        "display_category": "Employment Income",
        "field_instructions": """
DOCUMENT TYPE: Employment Payslip.

Extract EVERY line individually — do NOT aggregate or group:
IDENTIFICATION: employee_name, employee_id, employer_name, employer_cpf_number,
  pay_period_start, pay_period_end, payment_date, department, designation
EARNINGS — extract EACH line item separately:
  basic_salary, fixed_allowance_transport, fixed_allowance_meals,
  fixed_allowance_housing, fixed_allowance_other (each named),
  overtime_pay, shift_allowance, performance_bonus, contractual_bonus,
  annual_bonus, commission, variable_pay, any other earnings line
DEDUCTIONS — extract EACH line item separately:
  cpf_employee_contribution, income_tax_deduction, loan_repayment_deduction,
  advance_recovery, any other deduction line with its name
TOTALS: gross_pay, total_deductions, net_pay
CPF: cpf_ordinary_account_contribution, cpf_special_account_contribution,
  cpf_medisave_contribution, cpf_employer_contribution_total,
  cpf_employee_contribution_total, employee_cpf_account_number
""",
    },

    "employment_letter": {
        "doc_type": "EMPLOYMENT_CONTRACT",
        "display_name": "Employment Letter",
        "display_category": "Employment Income",
        "field_instructions": """
DOCUMENT TYPE: Employment Letter, Offer Letter, or Confirmation of Employment.

Extract:
employee_name, employer_name, employer_registration_number, employer_address,
job_title, department, employment_type (permanent/contract/part-time),
employment_start_date, employment_end_date (if stated),
probation_period, letter_date, letter_reference_number,
basic_salary_monthly, basic_salary_annual,
fixed_allowances (list each with name and amount),
variable_components (bonus target, commission structure),
total_package_annual, notice_period,
signatory_name, signatory_designation
""",
    },

    "bank_statements": {
        "doc_type": "BANK_STATEMENT",
        "display_name": "Personal Bank Statement",
        "display_category": "Banking & Cash",
        "field_instructions": """
DOCUMENT TYPE: Personal Bank Statement.

Extract:
ACCOUNT DETAILS: bank_name, branch, account_holder_name, account_number,
  account_type, currency, statement_period_start, statement_period_end
BALANCES: opening_balance, closing_balance, average_daily_balance
PERIOD TOTALS: total_credits, total_debits

TOP TRANSACTIONS — extract top 10 credit transactions:
  For each: transaction_date, amount, description, running_balance
TOP TRANSACTIONS — extract top 10 debit transactions:
  For each: transaction_date, amount, description, running_balance

INCOME PATTERNS — identify and extract:
  Regular salary credits (employer name, amount, frequency),
  dividend credits, interest credited, any investment proceeds,
  any other regular income pattern

MONTHLY BREAKDOWN (if multi-month): for each month extract
  month, total_credits, total_debits, closing_balance

FLAG: Any single transaction above SGD 10,000 with date and description
FLAG: Any unusual or irregular large credits requiring explanation
""",
    },

    "cpf_statement": {
        "doc_type": "CPF_STATEMENT",
        "display_name": "CPF Statement",
        "display_category": "CPF & Retirement",
        "field_instructions": """
DOCUMENT TYPE: CPF Contribution History Statement.

Extract:
member_name, nric, statement_period, statement_date
ACCOUNT BALANCES:
  cpf_ordinary_account_balance, cpf_special_account_balance,
  cpf_medisave_account_balance, cpf_retirement_account_balance (if applicable),
  total_cpf_balance
CONTRIBUTIONS (per month if shown):
  month, employer_name, employee_cpf_contribution,
  employer_cpf_contribution, ordinary_wages, additional_wages
ANNUAL TOTALS:
  total_employee_contributions, total_employer_contributions,
  total_ordinary_wages, total_additional_wages
INVESTMENT DETAILS (if CPF Investment Scheme shown):
  investment_type, investment_amount, current_value
""",
    },

    "bonus_letter": {
        "doc_type": "EMPLOYMENT_PAYSLIP",
        "display_name": "Bonus / Variable Pay Document",
        "display_category": "Employment Income",
        "field_instructions": """
DOCUMENT TYPE: Bonus letter, RSU/ESOP vesting statement, or commission statement.

Extract:
employee_name, employer_name, document_date, document_reference,
bonus_type (performance/contractual/annual/sign-on/retention/RSU/ESOP/commission),
bonus_amount_gross, bonus_amount_net, bonus_period_covered,
performance_rating (if shown), basis_of_calculation,
vesting_date (for RSU/ESOP), number_of_units_vested,
price_per_unit (for RSU/ESOP), total_vested_value,
withholding_tax_amount, payment_date,
signatory_name, signatory_designation
""",
    },

    "identification": {
        "doc_type": "UNKNOWN",
        "display_name": "Identity Document",
        "display_category": "Personal & Identity",
        "field_instructions": """
DOCUMENT TYPE: Passport, NRIC, or Employment Pass.

Extract:
document_type (Passport/NRIC/EP), full_legal_name, date_of_birth, gender,
nationality, country_of_birth, identity_number (NRIC/Passport/EP number),
issue_date, expiry_date, issuing_country, issuing_authority,
residential_address (if shown on document),
fin_number (for Employment Pass holders), pass_type, pass_expiry
""",
    },

    # ── BUSINESS OWNER ────────────────────────────────────────────────────────

    "biz_reg": {
        "doc_type": "BUSINESS_REGISTRATION",
        "display_name": "Business Registration Certificate",
        "display_category": "Business & Corporate Income",
        "field_instructions": """
DOCUMENT TYPE: Business Registration or Certificate of Incorporation.

Extract:
company_name, company_registration_number (UEN for Singapore),
date_of_incorporation, registered_address, business_activity (SSIC code if shown),
company_type (Pte Ltd/Ltd/Partnership/Sole Proprietor/LLP),
paid_up_capital, authorised_capital (if shown),
registered_office_address, financial_year_end,
issuing_authority, registration_date, certificate_number,
current_status (active/struck off/etc)
""",
    },

    "ownership_structure": {
        "doc_type": "SHAREHOLDING_CERTIFICATE",
        "display_name": "Shareholding Structure",
        "display_category": "Dividends & Shareholdings",
        "field_instructions": """
DOCUMENT TYPE: Shareholder Register, ACRA shareholders listing, or ownership chart.

Extract FOR EACH SHAREHOLDER listed:
  shareholder_name, shareholder_identity_number,
  nationality_or_country_of_incorporation,
  number_of_shares_held, share_class, percentage_shareholding,
  paid_up_value_per_share, total_paid_up_value

COMPANY DETAILS:
  company_name, uen, total_shares_issued, share_classes,
  total_paid_up_capital, document_date, document_reference

APPLICANT'S POSITION:
  applicant_shareholding_percentage, applicant_number_of_shares,
  applicant_share_class, applicant_voting_rights
""",
    },

    "biz_financials": {
        "doc_type": "CORPORATE_FINANCIAL_STATEMENT",
        "display_name": "Audited Financial Statements",
        "display_category": "Business & Corporate Income",
        "field_instructions": """
DOCUMENT TYPE: Audited or Unaudited Company Financial Statements / Annual Report.

INCOME STATEMENT — extract EVERY line individually:
  revenue_total, revenue_breakdown (each line), cost_of_goods_sold,
  gross_profit, selling_expenses, admin_expenses, other_operating_expenses,
  total_operating_expenses, EBITDA, depreciation_and_amortisation, EBIT,
  finance_costs (interest expense), other_income, profit_before_tax,
  income_tax_expense, profit_after_tax, net_profit_margin_percentage

BALANCE SHEET SUMMARY:
  total_current_assets, total_non_current_assets, total_assets,
  total_current_liabilities, total_non_current_liabilities, total_liabilities,
  shareholders_equity, retained_earnings, share_capital

DIRECTOR/OWNER INFORMATION (from notes):
  director_remuneration_total, each_director_name_and_fees,
  related_party_transactions (describe each),
  dividends_declared_total, dividends_per_share

DOCUMENT METADATA:
  company_name, financial_year_end, audit_firm_name,
  date_of_auditors_report, directors_who_signed
""",
    },

    "bank_statements_biz": {
        "doc_type": "BANK_STATEMENT",
        "display_name": "Business Bank Statement",
        "display_category": "Banking & Cash",
        "field_instructions": """
DOCUMENT TYPE: Business / Corporate Bank Statement — this is the PRIMARY failing case.

ACCOUNT DETAILS:
  bank_name, branch, account_holder_name (company name), account_number,
  account_type (current/savings/corporate), currency,
  statement_period_start, statement_period_end, statement_date

BALANCES:
  opening_balance, closing_balance, average_daily_balance,
  highest_balance_in_period (with date), lowest_balance_in_period (with date)

PERIOD TOTALS:
  total_credits_for_period, total_debits_for_period,
  net_change_in_balance

INCOME PATTERNS — identify and list:
  regular_business_revenue_credits (describe pattern, amount range),
  invoice_payments_received (amounts, frequency),
  intercompany_transfers_in (counterparty, amounts),
  loan_proceeds_received,
  investment_returns_received,
  any_other_regular_credit_pattern

EXPENSE PATTERNS — identify and list:
  regular_payroll_payments, regular_supplier_payments,
  loan_repayment_transactions, tax_payment_transactions,
  intercompany_transfers_out, dividend_payments_out,
  director_fee_payments, any_large_irregular_outflows

TOP 10 CREDIT TRANSACTIONS — for each:
  transaction_date, credit_amount, transaction_description,
  counterparty_name (if shown), transaction_type_classification
  (revenue/intercompany/loan/investment/other)

TOP 10 DEBIT TRANSACTIONS — for each:
  transaction_date, debit_amount, transaction_description,
  counterparty_name (if shown), transaction_type_classification
  (payroll/supplier/loan_repayment/tax/dividend/intercompany/other)

MONTHLY BREAKDOWN (if multi-month statement) — for each month:
  month_year, total_credits, total_debits, closing_balance

FLAG: Any single transaction above SGD 50,000 — extract date, amount, description
FLAG: Any cash deposits — extract date and amount
FLAG: Any transactions with unusual counterparties requiring explanation
FLAG: Any returned/rejected transactions
""",
    },

    "personal_bank_statements": {
        "doc_type": "BANK_STATEMENT",
        "display_name": "Personal Bank Statement (Business Owner)",
        "display_category": "Banking & Cash",
        "field_instructions": """
DOCUMENT TYPE: Personal Bank Statement for a Business Owner/Director.

Same as BANK_STATEMENT personal, with additional focus on:
  director_fee_credits (identify by description),
  dividend_payments_received (from companies),
  salary_credits (if employed elsewhere),
  intercompany_loan_repayments_received,
  any_business_related_transactions

Extract all fields from the personal bank statement strategy PLUS:
bank_name, account_holder_name, account_number, account_type, currency,
statement_period_start, statement_period_end,
opening_balance, closing_balance, total_credits, total_debits,
top_10_credits (date, amount, description each),
top_10_debits (date, amount, description each),
identified_income_sources (list each type: salary/director fee/dividend/other),
monthly_breakdown (month, credits, debits, closing balance)
""",
    },

    "dividend_record": {
        "doc_type": "DIVIDEND_NOTICE",
        "display_name": "Dividend Records",
        "display_category": "Dividends & Shareholdings",
        "field_instructions": """
DOCUMENT TYPE: Dividend Notice, Board Resolution, or Dividend Voucher.

Extract:
company_name, company_registration_number,
shareholder_name, shareholder_nric_or_id,
dividend_type (interim/final/special),
financial_year_covered, declaration_date, payment_date,
ex_dividend_date (if listed),
dividend_per_share, number_of_shares_held,
total_dividend_entitlement, currency,
withholding_tax_rate, withholding_tax_amount,
net_dividend_payable,
payment_method (cash/scrip/reinvestment),
authorising_director_names,
document_reference_number, resolution_number
""",
    },

    "director_fee": {
        "doc_type": "DIRECTOR_REMUNERATION_NOTICE",
        "display_name": "Director Fee Evidence",
        "display_category": "Business & Corporate Income",
        "field_instructions": """
DOCUMENT TYPE: Director Remuneration Notice, Service Contract, IR8A, or Board Resolution.

Extract:
director_name, company_name, company_registration_number,
director_fee_amount, remuneration_period (from-to dates),
payment_date, payment_frequency (monthly/quarterly/annual),
total_annual_director_fees,
other_remuneration_components (salary, allowances, benefits-in-kind),
total_package_value,
director_appointment_date, board_resolution_date, resolution_number,
ir8a_year_of_income (if IR8A), ir8a_reference_number,
tax_withheld_at_source, net_payment_amount,
signatory_name, signatory_designation
""",
    },

    "tax_returns_biz": {
        "doc_type": "IRAS_NOA",
        "display_name": "Corporate Tax Returns / NOA",
        "display_category": "Tax & Assessment",
        "field_instructions": """
DOCUMENT TYPE: Corporate IRAS Notice of Assessment or Company Tax Filing.

Extract:
company_name, company_registration_number (UEN),
year_of_assessment, basis_period (from-to),
accounting_profit_before_tax, add_back_disallowed_expenses,
less_exempt_income, less_capital_allowances,
adjusted_profit_chargeable_to_tax, partial_tax_exemption_amount,
chargeable_income_after_exemption, tax_rate_applied,
corporate_tax_payable, tax_rebate (if any), net_tax_payable,
estimated_chargeable_income_amount, filing_deadline,
payment_due_date, document_reference_number, assessment_date
""",
    },

    "biz_contracts": {
        "doc_type": "UNKNOWN",
        "display_name": "Business Contracts",
        "display_category": "Business & Corporate Income",
        "field_instructions": """
DOCUMENT TYPE: Business Contract, Service Agreement, or Revenue Contract.

Extract:
contract_parties (all party names and registration numbers),
contract_date, contract_start_date, contract_end_date,
contract_value_total, contract_currency, payment_terms,
payment_schedule (milestone amounts and dates if shown),
services_or_goods_description,
monthly_or_annual_recurring_value,
renewal_terms, termination_notice_period,
governing_law, contract_reference_number,
signatory_names and_designations
""",
    },

    "asset_documents": {
        "doc_type": "PROPERTY_VALUATION_REPORT",
        "display_name": "Asset Ownership Documents",
        "display_category": "Property & Real Estate",
        "field_instructions": """
DOCUMENT TYPE: Property Valuation Report, Title Deed, Investment Statement, or Asset Document.

For PROPERTY documents extract:
  property_address, property_type, title_number, lot_number,
  ownership_percentage, co_owners (if any),
  purchase_price, purchase_date, current_valuation, valuation_date,
  valuation_firm, outstanding_mortgage_amount,
  annual_rental_income, net_annual_yield,
  property_tax_annual, maintenance_fees

For INVESTMENT/PORTFOLIO documents extract:
  custodian_name, account_number, statement_date, total_portfolio_value,
  cash_balance, for each holding:
    (asset_name, isin_or_ticker, quantity, current_price,
     market_value, pct_of_portfolio, cost_basis, unrealised_pnl),
  total_unrealised_gains, dividends_received_period,
  interest_received_period

For VEHICLE or OTHER ASSET documents extract:
  asset_type, asset_description, registration_number_if_applicable,
  purchase_price, purchase_date, current_estimated_value
""",
    },

    "ubo_declaration": {
        "doc_type": "BUSINESS_REGISTRATION",
        "display_name": "UBO Declaration",
        "display_category": "Business & Corporate Income",
        "field_instructions": """
DOCUMENT TYPE: Ultimate Beneficial Owner (UBO) Declaration Form.

Extract:
company_name, company_registration_number,
FOR EACH UBO listed:
  ubo_full_name, ubo_nric_or_passport, ubo_nationality,
  ubo_date_of_birth, ubo_residential_address,
  ubo_shareholding_percentage, ubo_control_method,
  ubo_politically_exposed_person_status (PEP yes/no),
  ubo_declaration_date
document_completion_date, declarant_name, declarant_designation,
witness_name (if shown), notarisation_details (if notarised)
""",
    },

    "identification_biz": {
        "doc_type": "UNKNOWN",
        "display_name": "Identity Document (Business Owner)",
        "display_category": "Personal & Identity",
        "field_instructions": """
DOCUMENT TYPE: Passport or NRIC of the Business Owner/Director.

Extract:
document_type, full_legal_name, date_of_birth, gender,
nationality, identity_number, issue_date, expiry_date,
issuing_country, issuing_authority,
residential_address (if shown),
any_business_directorships_listed (if shown on document)
""",
    },
}

# Default strategy for any unknown category
_DEFAULT_STRATEGY = {
    "doc_type": "UNKNOWN",
    "display_name": "Financial Document",
    "display_category": "Other Wealth Sources",
    "field_instructions": """
Extract ALL financially significant fields present in this document including:
any names, dates, amounts, account numbers, reference numbers,
income figures, balance figures, and any other data relevant to
Source of Wealth assessment.
""",
}


def get_strategy_for_category(category_id: str) -> dict:
    """Return the extraction strategy for a given upload category ID."""
    return CATEGORY_STRATEGIES.get(category_id, _DEFAULT_STRATEGY)


# ── Classification prompt ─────────────────────────────────────────────────────

_CLASSIFICATION_SYSTEM_PROMPT = (
    "You are a financial compliance analyst. Classify the document type. "
    f"Valid types: {DOCUMENT_TYPES_STR}. "
    "A document may belong to multiple types. "
    'Return JSON: {"doc_types": ["TYPE1"]} — only valid JSON, no commentary.'
)


def get_classification_system_prompt(override: str | None = None) -> str:
    return override if override else _CLASSIFICATION_SYSTEM_PROMPT


def get_classification_user_prompt(sample_text: str) -> str:
    return f"Classify this financial document:\n\n{sample_text[:4000]}"


# ── Universal extraction system prompt ───────────────────────────────────────

_UNIVERSAL_EXTRACTION_BASE = """\
You are a senior financial compliance analyst performing a Source of Wealth \
assessment for a private banking institution under MAS Notice SFA 04-N13.

RULES:
- Extract EVERY field present in the document. Do not skip fields.
- Do not invent or assume values not present in the document.
- Return low confidence (0.4) rather than guessing ambiguous values.
- For every field return the standard schema below.

FIELD SCHEMA (return for every extracted field):
{
  "field_name": "snake_case canonical name",
  "display_label": "Human-readable label",
  "raw_value": "exact value as printed in document",
  "normalised_value": "number as plain numeral / date as YYYY-MM-DD / currency with ISO code",
  "currency": "ISO 4217 code or null",
  "page_number": 1,
  "source_snippet": "verbatim text from document supporting this value (max 50 words)",
  "confidence": 0.95,
  "display_category": "one of: Personal & Identity / Employment Income / Tax & Assessment / Business & Corporate Income / Investment Portfolio / Property & Real Estate / Banking & Cash / Dividends & Shareholdings / Other Wealth Sources / CPF & Retirement"
}

Return: {"fields": [<field objects>]}
Return ONLY valid JSON. No markdown. No commentary.\
"""


def get_extraction_system_prompt(override: str | None = None) -> str:
    return override if override else _UNIVERSAL_EXTRACTION_BASE


def get_extraction_user_prompt(
    text_corpus: dict,
    json_schema: dict | None = None,
    category_id: str | None = None,
    profile_type: str | None = None,
) -> str:
    """Build extraction prompt. Uses category-specific instructions when available."""
    corpus_block = json.dumps(text_corpus, indent=2, ensure_ascii=False)[:10000]

    strategy = get_strategy_for_category(category_id) if category_id else _DEFAULT_STRATEGY
    category_instructions = strategy.get("field_instructions", "").strip()
    category_name = strategy.get("display_name", "Financial Document")

    profile_note = ""
    if profile_type == "business":
        profile_note = "\nCLIENT PROFILE: Business Owner — prioritise business income, corporate, and ownership fields."
    elif profile_type == "salaried":
        profile_note = "\nCLIENT PROFILE: Salaried Professional — prioritise employment income and personal tax fields."

    return (
        f"Document category: {category_name}{profile_note}\n\n"
        f"CATEGORY-SPECIFIC EXTRACTION INSTRUCTIONS:\n{category_instructions}\n\n"
        f"--- DOCUMENT CONTENT ---\n{corpus_block}\n\n"
        "Extract ALL fields present. Return JSON: {\"fields\": [<field objects>]}"
    )


# ── Secondary extraction prompts ─────────────────────────────────────────────

_SECONDARY_PROMPTS: dict[str, str] = {
    "IRAS_NOA": (
        "This is an IRAS Notice of Assessment. Extract EVERY line item in the tax "
        "computation table including all relief types and their exact amounts. "
        "Also extract: amendment deadline date, all tax payment schedule dates, "
        "chargeable income breakdown. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "EMPLOYMENT_PAYSLIP": (
        "This is a payslip. Extract EVERY individual earnings line and EVERY individual "
        "deduction line separately — do not aggregate. Include all CPF components "
        "separately. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "CORPORATE_FINANCIAL_STATEMENT": (
        "This is a corporate financial statement. Extract every line from the income "
        "statement, balance sheet summary, director remuneration from notes, related "
        "party transactions, and dividend declarations. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "INVESTMENT_PORTFOLIO_STATEMENT": (
        "This is an investment portfolio statement. Extract EVERY holding individually "
        "with: asset name, ISIN/ticker, quantity, price, market value, % of portfolio, "
        "cost basis, unrealised P&L. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "BROKERAGE_STATEMENT": (
        "This is a brokerage statement. Extract every holding individually. Also extract "
        "top 10 buy and top 10 sell transactions. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "BANK_STATEMENT": (
        "This is a bank statement. Extract: top 10 credit transactions and top 10 debit "
        "transactions each with date, amount, description. Extract monthly totals for "
        "multi-month statements. Identify regular income patterns. "
        "Return JSON: {\"fields\": [<field objects>]}"
    ),
    "DIVIDEND_NOTICE": (
        "This is a dividend document. Extract: exact shareholding %, number of shares, "
        "share class, voting rights, dividend per share, total entitlement, ex-date, "
        "payment date. Return JSON: {\"fields\": [<field objects>]}"
    ),
    "SHAREHOLDING_CERTIFICATE": (
        "This is a shareholding certificate. Extract exact shareholding %, number of shares, "
        "share class, voting rights, certificate number, issue date, company registration. "
        "Return JSON: {\"fields\": [<field objects>]}"
    ),
    "CPF_STATEMENT": (
        "This is a CPF statement. Extract all account balances (OA, SA, MA, RA) and "
        "monthly contributions (employer + employee separately for each month). "
        "Return JSON: {\"fields\": [<field objects>]}"
    ),
}


def get_secondary_extraction_prompt(doc_type: str, page_content: str) -> str | None:
    base = _SECONDARY_PROMPTS.get(doc_type)
    if not base:
        return None
    return f"{base}\n\n--- DOCUMENT CONTENT ---\n{page_content[:6000]}"
