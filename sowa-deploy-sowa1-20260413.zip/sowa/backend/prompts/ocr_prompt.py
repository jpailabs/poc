"""OCR prompt templates for financial document text extraction."""

_DEFAULT_OCR_SYSTEM_PROMPT = (
    "You are a financial document OCR specialist. "
    "Extract ALL text from the provided document page image exactly as written. "
    "Preserve all numbers, dates, currencies, percentages, names, and labels "
    "with 100% fidelity. Output raw text only — no interpretation, no summary."
)

_DEFAULT_OCR_USER_PROMPT = (
    "Extract all text visible on this document page. "
    "Preserve every number, currency symbol, date format, and label exactly as printed."
)


def get_ocr_system_prompt(override: str | None = None) -> str:
    """Return the OCR system prompt.

    Args:
        override: Optional custom system prompt. If provided, it replaces the
            default prompt entirely.

    Returns:
        The system prompt string to use for OCR calls.
    """
    if override:
        return override
    return _DEFAULT_OCR_SYSTEM_PROMPT


def get_ocr_user_prompt() -> str:
    """Return the OCR user prompt.

    Returns:
        The user prompt string to send alongside the document page image.
    """
    return _DEFAULT_OCR_USER_PROMPT
