# Source of Wealth (SOW) Documentation Portal
## Complete Architecture & Technical Documentation

---

## Table of Contents

1. [Application Overview](#1-application-overview)
2. [Architecture Diagram](#2-architecture-diagram)
3. [End-to-End Flow Diagram](#3-end-to-end-flow-diagram)
4. [Technology Stack](#4-technology-stack)
5. [Project Structure & File Reference](#5-project-structure--file-reference)
6. [Backend Architecture](#6-backend-architecture)
7. [Frontend Architecture](#7-frontend-architecture)
8. [Configuration](#8-configuration)
9. [API Reference](#9-api-reference)
10. [Database Schema](#10-database-schema)
11. [How to Run — Standalone](#11-how-to-run--standalone)
12. [How to Run — Docker](#12-how-to-run--docker)
13. [Environment Variables](#13-environment-variables)
14. [Troubleshooting](#14-troubleshooting)

---

## 1. Application Overview

The **Source of Wealth (SOW) Documentation Portal** is a financial document extraction and review platform designed for private banking KYC (Know Your Customer) compliance workflows. Clients upload financial documents (NOA, payslips, bank statements, business registrations), the system extracts structured data via OCR + LLM, generates a formal SOW report, and exports it as PDF/DOCX.

### Key Capabilities

- **5-step guided wizard** for document submission and report generation
- **Real-time OCR** using a configurable Vision provider (Claude Vision, OpenAI Vision, or internal vLLM)
- **AI-powered field extraction** with confidence scoring
- **Live SOW report generation** streamed via Server-Sent Events (SSE)
- **Professional PDF/DOCX export** with branded headers, watermarks, and formatting
- **Graceful fallback** to intelligent mock data when no LLM provider is available
- **Multi-provider LLM abstraction** — switch between Anthropic, OpenAI, Azure OpenAI, Ollama, AWS Bedrock, Google Vertex, or internal vLLM via a single config change
- **Authentication system** — multi-provider SSO (LDAP, Azure AD, OAuth2, demo mode) with a SQLite user allowlist
- **Admin console** — web UI and API for managing approved users and viewing system/provider health
- **Admin Console SPA** at `/admin/` with 6 sections: Dashboard, Configuration, Prompt Management, User Management, File Sync, Audit Log
- **Bi-directional config sync**: Admin UI ↔ `config.yaml` / `.env` with hot-reload, no restart required
- **Prompt management**: All AI prompts stored as editable `.txt` files in `prompts_store/` with version history, variable interpolation, and Monaco editor
- **Real-time file watcher**: watchdog monitors config and prompt files; WebSocket pushes change events to Admin UI
- **Audit trail**: every admin action appended to `audit_log.jsonl` (append-only)

### User Workflow

```
Login → Select Profile → Upload Documents → Review Extraction → Generate SOW → Download Report
```

---

## 2. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            CLIENT (Browser)                                  │
│                                                                               │
│  ┌──────────────────────┐   ┌──────────────────────────────────────────────┐ │
│  │   BOS Portal          │   │         Admin Console                        │ │
│  │   bos-portal/         │   │         admin-console/index.html             │ │
│  │   index.html + app.js │   │         (standalone, served at /admin/)      │ │
│  │   5-step wizard       │   │         User allowlist, provider health      │ │
│  └──────────┬────────────┘   └──────────────────┬───────────────────────────┘ │
│             │                                   │                             │
└─────────────┼───────────────────────────────────┼─────────────────────────────┘
              │                                   │
     HTTP / SSE (port 3000 → 8000)     HTTP (port 8000)
     X-Session-Token header             X-Admin-Token header
              │                                   │
┌─────────────┼───────────────────────────────────┼─────────────────────────────┐
│                          BACKEND (FastAPI)                                    │
│                                                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐   │
│  │                        main.py (App Entry)                             │   │
│  │  • CORS middleware        • Auto-seed database                         │   │
│  │  • Router registration    • Session cleanup background task            │   │
│  │  • Static file mounts     • Legacy /sessions/* endpoints               │   │
│  │    (/admin/ → admin-console, /static → bos-portal)                    │   │
│  └────────────────┬───────────────────────────────────────────────────────┘   │
│                   │                                                            │
│  ┌────────────────┴───────────────────────────────────────────────────────┐   │
│  │                           ROUTERS                                       │   │
│  │                                                                         │   │
│  │  upload.py      extract.py    generate.py    export.py                 │   │
│  │  POST /upload   POST /extract POST /generate POST /export              │   │
│  │  GET  /status   GET  /result  (SSE stream)   (binary)                 │   │
│  │  DELETE /session (SSE stream)                                          │   │
│  │                                                                         │   │
│  │  auth_router.py                admin.py                                │   │
│  │  POST /auth/login              GET  /api/admin/users                   │   │
│  │  POST /auth/logout             POST /api/admin/users                   │   │
│  │  GET  /auth/me                 DELETE /api/admin/users/{username}      │   │
│  │                                GET  /api/admin/audit                   │   │
│  │                                GET  /api/admin/health                  │   │
│  └────────────────┬───────────────────────────────────────────────────────┘   │
│                   │                                                            │
│  ┌────────────────┴───────────────────────────────────────────────────────┐   │
│  │                     AUTH LAYER                                          │   │
│  │                                                                         │   │
│  │  auth/user_store.py          auth/sso_handler.py                       │   │
│  │  SQLite allowlist             LDAP / Azure AD / OAuth2 / demo           │   │
│  │  /tmp/sow_users.db                                                      │   │
│  │                                                                         │   │
│  │  auth/session_manager.py                                                │   │
│  │  In-memory sessions, 8-hour TTL, X-Session-Token header                │   │
│  └────────────────┬───────────────────────────────────────────────────────┘   │
│                   │                                                            │
│  ┌────────────────┴───────────────────────────────────────────────────────┐   │
│  │                         SERVICES                                        │   │
│  │                                                                         │   │
│  │  ocr_service.py          extraction_service.py    sow_writer_service.py│   │
│  │  get_registry()           get_registry()           get_registry()       │   │
│  │    .get_vision()            .get_llm()               .get_llm()         │   │
│  │    .vision_complete()       .complete()              .stream()          │   │
│  │                                                                         │   │
│  │  export_service.py        config_loader.py                             │   │
│  │  ReportLab PDF            YAML config reader                           │   │
│  │  python-docx DOCX         Model/prompt settings                        │   │
│  └────────────────┬───────────────────────────────────────────────────────┘   │
│                   │                                                            │
│  ┌────────────────┴───────────────────────────────────────────────────────┐   │
│  │                    PROVIDER ABSTRACTION LAYER                           │   │
│  │                                                                         │   │
│  │  providers/provider_factory.py  →  ProviderRegistry + init_providers() │   │
│  │  providers/base.py              →  5 abstract base classes              │   │
│  │  providers/anthropic_provider.py                                        │   │
│  │  providers/openai_compatible_provider.py  (OpenAI/Azure/Ollama/vLLM)   │   │
│  │  providers/token_manager.py     →  bearer token cache (internal APIs)  │   │
│  │                                                                         │   │
│  │  PROVIDER_MODE (config.yaml): anthropic | internal_vllm | openai |     │   │
│  │    azure_openai | ollama | bedrock | vertex                             │   │
│  └────────────────┬───────────────────────────────────────────────────────┘   │
│                   │                                                            │
│  ┌────────────────┴───────────────────────────────────────────────────────┐   │
│  │                         PROMPTS                                         │   │
│  │  ocr_prompt.py  │  extraction_prompt.py  │  sow_prompt.py              │   │
│  │  (Vision OCR)   │  (Field extraction)    │  (Report writing)           │   │
│  └────────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  ┌──────────────────────────────┐  ┌───────────────────────────────────────┐  │
│  │  database.py + schemas.py    │  │  config/config.yaml                   │  │
│  │  SQLAlchemy 2.0 + PostgreSQL │  │  Master config: PROVIDER_MODE, auth,  │  │
│  └──────────────┬───────────────┘  │  all provider credentials + settings  │  │
└─────────────────┼───────────────── └───────────────────────────────────────┘  │
                  │                                                               │
        ┌─────────┴──────────┐    ┌────────────────────┐   ┌────────────────────┐
        │   PostgreSQL 16    │    │  LLM / Vision API   │   │  Auth Backend      │
        │   (findoc_db)      │    │  (provider-         │   │  LDAP / Azure AD / │
        │   Port: 5432       │    │   dependent)        │   │  OAuth2 / demo     │
        └────────────────────┘    └────────────────────┘   └────────────────────┘

        ┌────────────────────┐
        │  SQLite            │
        │  /tmp/sow_users.db │
        │  User allowlist    │
        └────────────────────┘
```

---

## 3. End-to-End Flow Diagram

```
                              USER JOURNEY
 ═══════════════════════════════════════════════════════════════════

 STEP 1                STEP 2               STEP 3
 ┌──────────┐         ┌──────────┐         ┌──────────────────┐
 │  SELECT   │────────▶│  UPLOAD  │────────▶│ REVIEW EXTRACTION│
 │  PROFILE  │         │   DOCS   │         │                  │
 │           │         │          │         │                  │
 │ ○ Salaried│         │ PDF/JPG  │         │ Processing...    │
 │ ○ Business│         │ PNG files│         │ ┌──────────────┐ │
 │           │         │ (≥1 file)│         │ │ OCR per page │ │
 └──────────┘         └────┬─────┘         │ │ Vision API   │ │
                           │               │ └──────┬───────┘ │
                           │               │        │         │
                    ┌──────▼──────┐        │ ┌──────▼───────┐ │
                    │ POST /upload│        │ │ Field Extract │ │
                    │ multipart   │        │ │ LLM API      │ │
                    │ form data   │        │ └──────┬───────┘ │
                    └──────┬──────┘        │        │         │
                           │               │ ┌──────▼───────┐ │
                    ┌──────▼──────┐        │ │ Category     │ │
                    │ Files saved │        │ │ Accordions   │ │
                    │ /tmp/sow_   │        │ │ Inline Edit  │ │
                    │ sessions/   │        │ │ Confidence   │ │
                    └─────────────┘        │ └──────────────┘ │
                                           └────────┬─────────┘
                                                    │
                    STEP 4                          │              STEP 5
                    ┌───────────────────┐           │    ┌────────────────────┐
                    │  GENERATE SOW     │◀──────────┘    │ SUMMARY & EXPORT   │
                    │                   │                 │                    │
                    │ ┌───────────────┐ │                 │ ┌────────────────┐ │
                    │ │ Section Pills │ │                 │ │ SOW Document   │ │
                    │ │ [✓][✓][●][○] │ │                 │ │ Viewer         │ │
                    │ └───────────────┘ │                 │ │ (formatted)    │ │
                    │                   │                 │ └────────────────┘ │
                    │ ┌───────────────┐ │                 │                    │
                    │ │ Live Streaming│ │────────────────▶│ ┌────────────────┐ │
                    │ │ Text + Cursor │ │                 │ │ Download PDF   │ │
                    │ │ Word Count    │ │                 │ │ Download DOCX  │ │
                    │ └───────────────┘ │                 │ │ Share with RM  │ │
                    │                   │                 │ └────────────────┘ │
                    └───────────────────┘                 └────────────────────┘

 ═══════════════════════════════════════════════════════════════════
                          DATA FLOW (SSE STREAMING)

  Browser                         Backend                    LLM Provider
    │                               │                            │
    │──POST /auth/login────────────▶│                            │
    │◀─{session_token}──────────────│ (SSO validate + allowlist) │
    │                               │                            │
    │──POST /api/v1/upload─────────▶│ (X-Session-Token header)   │
    │◀─{session_id, files}──────────│                            │
    │                               │                            │
    │──POST /api/v1/extract────────▶│                            │
    │◀─SSE: progress(page 1/5)──────│──vision_complete(page)────▶│
    │◀─SSE: progress(page 2/5)──────│◀─OCR text─────────────────│
    │◀─SSE: progress(page 3/5)──────│──vision_complete(page)────▶│
    │◀─SSE: progress(page 4/5)──────│◀─OCR text─────────────────│
    │◀─SSE: progress(page 5/5)──────│──vision_complete(page)────▶│
    │                               │◀─OCR text─────────────────│
    │                               │                            │
    │                               │──llm.complete(all text)───▶│
    │◀─SSE: category_complete───────│◀─structured JSON───────────│
    │◀─SSE: category_complete───────│                            │
    │◀─SSE: complete(extraction_id)─│                            │
    │                               │                            │
    │──GET /extract/{id}/result────▶│                            │
    │◀─{categories, fields}─────────│                            │
    │                               │                            │
    │     [User reviews & edits fields inline]                   │
    │                               │                            │
    │──POST /api/v1/generate───────▶│                            │
    │                               │──llm.stream(fields)───────▶│
    │◀─SSE: section_start───────────│◀─streaming tokens──────────│
    │◀─SSE: token("This Source...")──│◀─streaming tokens──────────│
    │◀─SSE: token("of Wealth...")───│◀─streaming tokens──────────│
    │◀─SSE: section_complete────────│                            │
    │◀─SSE: section_start───────────│◀─streaming tokens──────────│
    │◀─SSE: token(...)──────────────│◀─streaming tokens──────────│
    │◀─SSE: complete(generation_id)─│                            │
    │                               │                            │
    │──POST /api/v1/export/pdf─────▶│                            │
    │◀─binary PDF stream────────────│ (ReportLab generation)     │
    │                               │                            │
    │──POST /api/v1/export/docx────▶│                            │
    │◀─binary DOCX stream───────────│ (python-docx generation)   │
```

---

## 4. Technology Stack

### Backend
| Technology | Version | Purpose |
|---|---|---|
| Python | 3.10+ | Runtime |
| FastAPI | latest | REST API framework |
| Uvicorn | latest | ASGI server |
| SQLAlchemy | 2.0+ | PostgreSQL ORM |
| psycopg2-binary | latest | PostgreSQL driver |
| Pydantic | 2.0+ | Request/response validation |
| python-multipart | latest | File upload parsing |
| PyMuPDF (fitz) | latest | PDF page rendering to images |
| Anthropic SDK | latest | Claude API (Vision + Text) — used via provider abstraction |
| PyYAML | latest | Configuration file parsing |
| ReportLab | latest | PDF document generation |
| python-docx | latest | DOCX document generation |
| aiofiles | latest | Async file I/O |
| httpx | latest | Async HTTP client (OpenAI-compatible providers, token refresh) |
| ldap3 | latest | LDAP/Active Directory SSO integration |
| msal | latest | Microsoft Azure AD SSO (OAuth2/MSAL) |
| watchdog | latest | File system event monitoring |
| websockets | latest | WebSocket support (via uvicorn[standard]) |
| python-dotenv | latest | .env file parsing |

### Frontend
| Technology | Purpose |
|---|---|
| Vanilla HTML5 | Page structure (no framework) |
| Vanilla CSS3 | Styling with CSS custom properties |
| Vanilla JavaScript (ES2020) | Application logic, SSE handling |
| Inter (Google Fonts) | Typography |
| Georgia/serif | SOW document body text |

### Infrastructure
| Technology | Purpose |
|---|---|
| PostgreSQL 16 | Persistent storage for sessions |
| SQLite | User allowlist (`/tmp/sow_users.db`) |
| Docker Compose | Container orchestration |
| Python http.server | Frontend static file serving |

---

## 5. Project Structure & File Reference

```
sowa/
├── .env                              # Environment variables (gitignored)
├── .env.example                      # Environment variable template
├── docker-compose.yml                # Docker orchestration (3 services)
├── CLAUDE.md                         # AI assistant project context
├── RUN_INSTRUCTIONS.md               # Setup and run guide
├── ARCHITECTURE.md                   # This file
│
├── admin-console/                    # Standalone admin web UI
│   └── index.html                    # User allowlist management, provider/system health
│
├── backend/                          # FastAPI backend application
│   ├── Dockerfile                    # Python 3.10-slim container image
│   ├── requirements.txt              # Python dependencies (15 packages)
│   ├── main.py                       # App entry point, router registration, startup
│   ├── app.py                        # Standalone in-memory demo API (no DB)
│   ├── database.py                   # SQLAlchemy engine, session, model definition
│   ├── schemas.py                    # Pydantic models + DOCUMENT_REGISTRY (20 types)
│   ├── seed.py                       # Sample data seeder (3 demo sessions)
│   │
│   ├── config/
│   │   ├── __init__.py
│   │   ├── model_config.yaml         # Legacy LLM config (still active, read by config_loader.py)
│   │   └── config.yaml               # Master config: PROVIDER_MODE, auth provider, all provider settings
│   │
│   ├── providers/                    # LLM/Vision provider abstraction layer
│   │   ├── __init__.py
│   │   ├── base.py                   # 5 abstract base classes (LLMProvider, VisionProvider, etc.)
│   │   ├── anthropic_provider.py     # Anthropic Claude implementation
│   │   ├── openai_compatible_provider.py  # OpenAI / Azure OpenAI / Ollama / internal vLLM
│   │   ├── token_manager.py          # Bearer token cache for internal API endpoints
│   │   └── provider_factory.py       # ProviderRegistry class + init_providers() factory
│   │
│   ├── auth/                         # Authentication system
│   │   ├── __init__.py
│   │   ├── user_store.py             # SQLite allowlist at /tmp/sow_users.db
│   │   ├── sso_handler.py            # LDAP / Azure AD / OAuth2 / demo mode handlers
│   │   └── session_manager.py        # In-memory session store, 8-hour TTL
│   │
│   ├── routers/
│   │   ├── __init__.py
│   │   ├── upload.py                 # POST /upload, GET /status, DELETE /session
│   │   ├── extract.py                # POST /extract (SSE), GET /result
│   │   ├── generate.py               # POST /generate (SSE)
│   │   ├── export.py                 # POST /export/{pdf|docx}
│   │   ├── admin.py                  # /api/admin/* endpoints (X-Admin-Token required)
│   │   ├── auth_router.py            # /auth/* endpoints (login, logout, me)
│   │   ├── admin_config.py      # GET/PUT /admin/api/config/* (YAML + env)
│   │   ├── admin_prompts.py     # GET/PUT/DELETE /admin/api/prompts/*
│   │   └── admin_sync.py        # WS /admin/ws/sync + audit + file editor
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── config_loader.py          # YAML config reader with caching
│   │   ├── ocr_service.py            # PyMuPDF→base64→get_registry().get_vision().vision_complete()
│   │   ├── extraction_service.py     # get_registry().get_llm().complete() — structured JSON
│   │   ├── sow_writer_service.py     # get_registry().get_llm().stream() — streaming SOW narrative
│   │   ├── export_service.py         # ReportLab PDF + python-docx DOCX
│   │   ├── config_manager.py    # Bi-directional config.yaml/.env sync + hot-reload
│   │   ├── prompt_manager.py    # File-backed prompt CRUD, versioning, interpolation
│   │   ├── file_watcher.py      # watchdog file monitor → WebSocket broadcaster
│   │   └── audit_logger.py      # Append-only audit_log.jsonl writer + reader
│   │
│   └── prompts/
│       ├── __init__.py
│       ├── ocr_prompt.py             # OCR system/user prompts
│       ├── extraction_prompt.py      # Field extraction prompts + schema
│       └── sow_prompt.py             # SOW report generation prompts
│
├── backend/prompts_store/           # Prompt file storage
│   ├── prompts_registry.json        # Key → filename + metadata
│   ├── ocr_extraction.txt
│   ├── ocr_user.txt
│   ├── field_extraction.txt
│   ├── sow_report.txt
│   └── history/                     # Auto-versioned backups (last 10)
├── backend/audit_log.jsonl          # Append-only audit trail
└── bos-portal/                       # Frontend (vanilla HTML/CSS/JS)
    ├── index.html                    # 5-step wizard, all page markup
    ├── app.js                        # Application logic, state, SSE, navigation
    ├── styles.css                    # Complete design system (2400+ lines)
    └── logo.svg                      # Custom SOW shield logo
```

### File-by-File Functionality

#### Backend — Core

| File | Lines | Functionality |
|---|---|---|
| `main.py` | ~450 | FastAPI app creation, CORS, startup (DB init + seed + cleanup task + provider init), legacy session/record endpoints, router registration, static file mounts for `/admin/` and portal |
| `app.py` | ~200 | Standalone in-memory demo API (no PostgreSQL needed). Endpoints: `/extract`, `/documents/*`, `/schema`. Uses `_store` dict |
| `database.py` | 69 | SQLAlchemy 2.0 engine setup, `DocumentSession` ORM model (JSONB columns), `get_db()` dependency, `init_db()` table creation |
| `schemas.py` | 97 | Pydantic models: `NOAData`, `PaySlipData`, `SummaryData`, `OtherDocData`. `DOCUMENT_REGISTRY` mapping 20 doc types. API request/response schemas |
| `seed.py` | 152 | Idempotent seeder creating 3 sample sessions (Tan Wei Ming, Priya Nair, Ahmad Fauzi) with realistic financial data |

#### Backend — Providers

| File | Functionality |
|---|---|
| `providers/base.py` | Five abstract base classes: `LLMProvider` (complete, stream), `VisionProvider` (vision_complete), `EmbeddingProvider`, `RerankProvider`, `ProviderBase` (health check) |
| `providers/anthropic_provider.py` | Anthropic Claude implementation of `LLMProvider` + `VisionProvider`. Wraps Anthropic SDK |
| `providers/openai_compatible_provider.py` | Single implementation covering OpenAI, Azure OpenAI, Ollama, and internal vLLM. Uses `httpx` for async calls |
| `providers/token_manager.py` | Manages bearer tokens for internal API endpoints — handles token refresh and caching |
| `providers/provider_factory.py` | `ProviderRegistry` holds the active LLM and Vision provider instances. `init_providers()` reads `PROVIDER_MODE` from `config.yaml` and instantiates the correct classes. Services call `get_registry().get_llm()` or `get_registry().get_vision()` |

#### Backend — Auth

| File | Functionality |
|---|---|
| `auth/user_store.py` | SQLite-backed user allowlist at `/tmp/sow_users.db`. CRUD operations for approved users. Used by both `sso_handler.py` (login check) and `admin.py` (management) |
| `auth/sso_handler.py` | Multi-provider authentication: LDAP (via `ldap3`), Azure AD (via `msal`), generic OAuth2, and a built-in demo mode. Validates credentials then checks the allowlist |
| `auth/session_manager.py` | In-memory session store. Issues opaque tokens returned as `X-Session-Token`. Sessions expire after 8 hours. `get_current_user()` FastAPI dependency reads this header |

#### Backend — Routers

| File | Lines | Functionality |
|---|---|---|
| `routers/upload.py` | 158 | `POST /api/v1/upload` — accepts multipart files, saves to `/tmp/sow_sessions/{session_id}/`, counts PDF pages via PyMuPDF, returns file metadata. `GET /status` — pipeline state for reconnection. `DELETE /session` — cancel and cleanup |
| `routers/extract.py` | 438 | `POST /api/v1/extract` — SSE endpoint. Real mode: calls `ocr_service` then `extraction_service` (both via provider abstraction). Mock mode: smart filename-based OCR + context-aware field extraction. `GET /result` — returns full extraction categories + fields |
| `routers/generate.py` | 306 | `POST /api/v1/generate` — SSE endpoint. Real mode: calls `sow_writer_service` (streaming via provider abstraction). Mock mode: template-based 8-section SOW streamed token-by-token. Stores full text in session state |
| `routers/export.py` | 499 | `POST /api/v1/export/{pdf\|docx}` — generates branded documents. PDF: ReportLab with gold accents, CONFIDENTIAL watermark, section borders, header/footer on every page. DOCX: python-docx with custom styles, gold borders, formatted metadata table |
| `routers/auth_router.py` | — | `POST /auth/login` — delegates to `sso_handler`, issues session token. `POST /auth/logout` — invalidates session. `GET /auth/me` — returns current user from `X-Session-Token` |
| `routers/admin.py` | — | All routes require `X-Admin-Token` header. `GET/POST /api/admin/users` — list/add allowlist users. `DELETE /api/admin/users/{username}` — remove user. `GET /api/admin/users/{username}` — user detail. `GET /api/admin/audit` — audit log. `GET /api/admin/health` — provider + system status |

#### Backend — Services

| File | Lines | Functionality |
|---|---|---|
| `services/config_loader.py` | 54 | Reads `config/model_config.yaml` (legacy) and `config/config.yaml` (master), caches results. Exposes `get_model_config()`, `get_prompt_overrides()`, `get_session_config()` |
| `services/ocr_service.py` | 161 | `process_document()` — async generator yielding progress events per page. Renders PDF pages to base64 PNG via PyMuPDF. Calls `get_registry().get_vision().vision_complete()` with retry (3 attempts, exponential backoff). Skips failed pages gracefully |
| `services/extraction_service.py` | 251 | `extract_fields()` — calls `get_registry().get_llm().complete()` with all OCR text + JSON schema. Parses response, retries once on malformed JSON. Returns partial results on second failure. 8 financial categories with UUID field IDs |
| `services/sow_writer_service.py` | 176 | `generate_sow()` — async generator using `get_registry().get_llm().stream()`. Detects `## N.` section boundaries in streamed text. Yields section_start, token, section_complete, complete events. 8 standard SOW sections |
| `services/export_service.py` | 414 | Standalone PDF/DOCX generators. Custom ReportLab styles, python-docx styles with SOW branding |

#### Backend — Prompts

| File | Lines | Functionality |
|---|---|---|
| `prompts/ocr_prompt.py` | 37 | `get_ocr_system_prompt(override)` — financial document OCR specialist prompt. `get_ocr_user_prompt()` — instruction to preserve all numbers, dates, currencies exactly |
| `prompts/extraction_prompt.py` | 86 | `get_extraction_system_prompt(override)` — senior financial analyst prompt. `get_extraction_user_prompt(corpus, schema)` — formats all OCR text + JSON schema. `FinancialCategory` enum with 8 categories |
| `prompts/sow_prompt.py` | 94 | `get_sow_system_prompt(override)` — RM writing SOW report prompt with MAS regulatory context. `get_sow_user_prompt(fields, profile)` — formats verified fields + 8 section headings |

#### Frontend

| File | Lines | Functionality |
|---|---|---|
| `index.html` | 561 | Login page (split layout, trust indicators), portal with 5-step wizard (step nav, content pages, footer bar), success page, loading overlay, toast container. All 5 step pages defined inline |
| `app.js` | 1103 | State management (global object), auth (sends credentials to `/auth/login`, stores `X-Session-Token`), 5-step navigation, file upload with drag-drop, SSE stream reading (extraction + generation), AbortController for cancel, inline field editing, PDF/DOCX export download, share-with-RM stub |
| `styles.css` | 2424 | Complete design system: CSS variables (colors, fonts, radii, shadows), login layout, portal header, step indicator, profile cards, document accordion cards, upload dropzones, extraction category accordions with confidence borders, generation streaming area with cursor animation, SOW document viewer, download panel, toast notifications, loading spinner |
| `logo.svg` | 30 | Custom SVG logo: shield shape with "S**O**W" text (gold "O"), decorative gold line, small document icon |

#### Admin Console

| File | Functionality |
|---|---|
| `admin-console/index.html` | Standalone single-file admin web UI served at `http://localhost:8000/admin/`. Provides user allowlist management (add/remove/list approved users), audit log viewer, and provider + system health dashboard. Authenticates via `POST /api/admin/login` and sends `X-Admin-Token` on subsequent requests |

#### Configuration & Infrastructure

| File | Functionality |
|---|---|
| `config/config.yaml` | Master configuration: `PROVIDER_MODE`, auth provider selection (ldap/azure_ad/oauth2/demo), all provider credentials and endpoints, admin credentials (`ADMIN_USERNAME`, `admin_password_hash`) |
| `config/model_config.yaml` | Legacy LLM config still read by `config_loader.py`: model name, temperature, max_tokens, OCR DPI, prompt overrides, session cleanup settings |
| `docker-compose.yml` | 3 services: `postgres` (16-alpine, healthcheck), `backend` (FastAPI + volume mounts), `frontend` (python http.server). Reads `.env` for secrets |
| `.env.example` | Template: `DATABASE_URL`, `ANTHROPIC_API_KEY`, `ADMIN_PASSWORD`, ports |
| `Dockerfile` | Python 3.10-slim, installs libpq-dev + gcc, pip installs requirements.txt |

---

## 6. Backend Architecture

### Layered Design

```
Request → Auth Middleware → Router → Service → Provider Abstraction → LLM/Vision API
                                       ↓
                              Config Loader → config.yaml / model_config.yaml

Admin Request → X-Admin-Token check → Admin Router → Auth Layer (user_store)
```

- **Auth layer** gates all portal requests via `X-Session-Token` (8-hour sessions)
- **Routers** orchestrate only — no business logic
- **Services** contain all business logic (OCR, extraction, generation, export). They no longer import any LLM SDK directly; all calls go through the provider registry
- **Provider abstraction** decouples services from specific LLM vendors. Swap providers by changing `PROVIDER_MODE` in `config.yaml` — zero code changes required
- **Prompts** are isolated — all system/user prompts in dedicated files
- **Config** is centralized — master settings in `config.yaml`, legacy model tuning in `model_config.yaml`

### Session State Management

Pipeline sessions are tracked in-memory via a shared `session_states` dict in `upload.py`:

```python
session_states[session_id] = {
    "status": "uploaded" | "extracting" | "extracted" | "generating" | "generated",
    "profile_type": "salaried" | "business",
    "files": [...],
    "extraction_id": str | None,
    "extraction_result": [...] | None,
    "generation_id": str | None,
    "generation_result": str | None,  # Full SOW markdown text
}
```

Files are stored at `/tmp/sow_sessions/{session_id}/` and auto-cleaned after 2 hours.

Auth sessions are managed separately by `auth/session_manager.py` and keyed by opaque tokens with an 8-hour TTL.

### Provider Abstraction

All LLM and Vision calls are routed through the provider registry:

```python
# In any service file
from providers.provider_factory import get_registry

# Text completion
result = await get_registry().get_llm().complete(prompt, system_prompt)

# Streaming
async for chunk in get_registry().get_llm().stream(prompt, system_prompt):
    yield chunk

# Vision / OCR
text = await get_registry().get_vision().vision_complete(image_b64, prompt)
```

`init_providers()` is called once on startup, reads `PROVIDER_MODE` from `config.yaml`, and populates the registry with the appropriate concrete provider class. Supported modes:

| Mode | Provider Class | Notes |
|---|---|---|
| `anthropic` | `AnthropicProvider` | Default. Uses Anthropic SDK |
| `openai` | `OpenAICompatibleProvider` | OpenAI API |
| `azure_openai` | `OpenAICompatibleProvider` | Azure endpoint + API key |
| `internal_vllm` | `OpenAICompatibleProvider` | Internal vLLM with bearer token refresh via `token_manager.py` |
| `ollama` | `OpenAICompatibleProvider` | Local Ollama instance |
| `bedrock` | TBD | AWS Bedrock (configured in config.yaml) |
| `vertex` | TBD | Google Vertex AI (configured in config.yaml) |

### Auth System

```
POST /auth/login
  └── sso_handler.validate(username, password)
        ├── demo mode: check hardcoded credentials
        ├── LDAP mode: ldap3 bind + search
        ├── Azure AD mode: msal PublicClientApplication
        └── OAuth2 mode: token endpoint POST
              └── (all modes) user_store.is_allowed(username)?
                    ├── yes → session_manager.create_session() → X-Session-Token
                    └── no  → 403 Forbidden
```

Users must appear in the SQLite allowlist (`/tmp/sow_users.db`) to receive a session token, regardless of SSO mode. The allowlist is managed via the admin console or `POST /api/admin/users`.

### Real vs Mock Pipeline

The system checks whether `get_registry()` has a configured LLM/Vision provider:

| Condition | OCR | Extraction | Generation |
|---|---|---|---|
| Provider configured | Vision API (page by page) | LLM structured JSON | LLM streaming |
| No provider / key missing | Smart filename-based mock text | Context-aware mock fields | Template-based 8-section SOW |
| API call fails | Falls back to mock pipeline | Returns partial/empty result | Falls back to mock templates |

### Error Resilience

- **OCR page failure**: Log warning, skip page, continue (never blocks)
- **OCR rate limit (429/529)**: Retry 3 times with exponential backoff (2s, 4s, 8s)
- **Extraction bad JSON**: Retry once with correction prompt, return partial on second failure
- **SSE connection drop**: Backend logs `socket.send()` exception, continues processing
- **Frontend cancel**: AbortController aborts fetch, DELETE cleans up session
- **Token refresh failure** (internal vLLM): `token_manager.py` retries token endpoint; if unavailable, request fails fast with a 503

---

## 7. Frontend Architecture

### State Management

Single global state object (no framework):

```javascript
const state = {
    currentUser: null,          // { username, name, role, initials }
    sessionToken: null,         // X-Session-Token from /auth/login
    currentStep: 1,             // 1-5
    selectedProfile: null,      // 'salaried' | 'business'
    uploadedFiles: {},          // docId → File object
    sessionId: null,            // UUID from backend
    extractionId: null,         // UUID from extraction
    extractionResult: null,     // { categories: [...], totalFields: N }
    verifiedFields: [],         // User-edited copy of extracted fields
    sowText: '',                // Generated SOW markdown
    generationId: null,         // UUID from generation
    isExtracting: false,        // Loading state
    isGenerating: false,        // Loading state
    totalWords: 0               // Word count
};
```

### SSE Stream Reading Pattern

```javascript
const response = await fetch(url, {
    headers: { 'X-Session-Token': state.sessionToken },
    signal: abortController.signal
});
const reader = response.body.getReader();
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    // Parse SSE lines: "data: {...}\n\n"
    // Update UI based on event.type
}
```

### Navigation Flow

```
Step 1 → Step 2 → [Upload to backend] → Step 3 → Step 4 → Step 5
                                          ↑ Cancel → Step 2
```

- Step 1→2: Requires profile selection
- Step 2→3: Requires ≥1 file uploaded (soft warning for missing required docs)
- Step 3→4: Requires extraction complete
- Step 4→5: Requires generation complete (no back from Step 4)
- Step 5: "Start New Assessment" resets all state

---

## 8. Configuration

### config.yaml (Master Config — Primary)

`backend/config/config.yaml` is the master configuration file introduced alongside the provider abstraction and auth system. It controls:

```yaml
provider:
  mode: "anthropic"             # anthropic | internal_vllm | openai | azure_openai | ollama | bedrock | vertex

  anthropic:
    api_key: ""                 # or set ANTHROPIC_API_KEY env var
    model: "claude-sonnet-4-20250514"

  openai:
    api_key: ""
    base_url: "https://api.openai.com/v1"
    model: "gpt-4o"

  azure_openai:
    api_key: ""
    endpoint: ""
    deployment: ""
    api_version: "2024-02-01"

  internal_vllm:
    base_url: "http://internal-vllm:8080/v1"
    token_endpoint: "http://auth-service/token"
    model: "meta-llama/Llama-3-8b-instruct"

  ollama:
    base_url: "http://localhost:11434/v1"
    model: "llama3"

auth:
  provider: "demo"              # demo | ldap | azure_ad | oauth2
  allowlist_required: true      # If true, users must be in SQLite allowlist

  ldap:
    server: "ldap://ldap.example.com"
    base_dn: "dc=example,dc=com"
    bind_dn: ""
    bind_password: ""

  azure_ad:
    tenant_id: ""
    client_id: ""

  oauth2:
    token_endpoint: ""
    client_id: ""
    client_secret: ""

admin:
  username: "admin"
  password_hash: ""             # bcrypt hash; or set ADMIN_PASSWORD env var for plain text
```

### model_config.yaml (Legacy — Still Active)

`backend/config/model_config.yaml` is still read by `config_loader.py` for model tuning parameters that have not yet migrated to `config.yaml`:

```yaml
model:
  name: "claude-sonnet-4-20250514"   # Overridden by config.yaml provider.*.model if set
  temperature: 0.2
  max_tokens: 4096
  vision_enabled: true
  ocr_dpi: 200

prompts:
  ocr_system_override: null
  extraction_system_override: null
  sow_system_override: null

session:
  cleanup_after_hours: 2
  upload_dir: "/tmp/sow_sessions"
  max_file_size_mb: 50
```

To customize prompts without changing code, set the override values in `model_config.yaml`:

```yaml
prompts:
  sow_system_override: "You are a compliance officer. Write formal reports..."
```

---

## 9. API Reference

### Portal Auth Endpoints

| Method | Path | Description |
|---|---|---|
| `POST` | `/auth/login` | Authenticate via configured SSO provider. Body: `{username, password}`. Returns `{session_token, user}` |
| `POST` | `/auth/logout` | Invalidate session. Requires `X-Session-Token` header |
| `GET` | `/auth/me` | Return current user details from session token. Requires `X-Session-Token` header |

### SOW Pipeline Endpoints

All pipeline endpoints require `X-Session-Token` header.

| Method | Path | Type | Description |
|---|---|---|---|
| `POST` | `/api/v1/upload` | REST | Upload files, create session. Returns `{session_id, uploaded_files}` |
| `GET` | `/api/v1/session/{id}/status` | REST | Pipeline state for reconnection |
| `DELETE` | `/api/v1/session/{id}` | REST | Cancel session, cleanup files |
| `POST` | `/api/v1/extract` | SSE | OCR + field extraction. Events: `progress`, `category_complete`, `complete` |
| `GET` | `/api/v1/extract/{id}/result` | REST | Full extraction categories + fields |
| `POST` | `/api/v1/generate` | SSE | SOW generation. Events: `section_start`, `token`, `section_complete`, `complete` |
| `POST` | `/api/v1/export/{format}` | Binary | Download PDF or DOCX. Format: `pdf` or `docx` |

### Admin Endpoints

All admin endpoints require `X-Admin-Token` header (obtained from `POST /api/admin/login`).

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/admin/login` | Authenticate as admin. Body: `{username, password}`. Returns `{admin_token}` |
| `GET` | `/api/admin/users` | List all users in the allowlist |
| `POST` | `/api/admin/users` | Add a user to the allowlist. Body: `{username, display_name, email, role}` |
| `DELETE` | `/api/admin/users/{username}` | Remove a user from the allowlist |
| `GET` | `/api/admin/users/{username}` | Get details for a specific allowlist user |
| `GET` | `/api/admin/audit` | Retrieve audit log of login/logout and admin actions |
| `GET` | `/api/admin/health` | Provider connectivity status + system metrics |

### Legacy Endpoints (preserved)

| Method | Path | Description |
|---|---|---|
| `POST` | `/sessions/extract` | Mock extraction + DB persist (multipart form) |
| `GET` | `/sessions` | List all sessions |
| `GET` | `/sessions/{id}` | Session records (latest per doc_type) |
| `GET` | `/sessions/{id}/history` | Full edit history |
| `GET` | `/records/{id}` | Get single record |
| `PUT` | `/records/{id}` | Update record (creates new subsession) |
| `DELETE` | `/records/{id}` | Delete record |
| `POST` | `/records/{id}/summarize` | Mock LLM summary |
| `GET` | `/schema` | JSON Schema for all registered models |

### Admin Console API

See `ADMIN_CONSOLE.md` for the full API reference. Summary:

| Group | Prefix | Endpoints |
|---|---|---|
| Admin Auth + Users | `/api/admin/` | login, users CRUD, audit, health |
| Config Management | `/admin/api/config/` | YAML sections, .env, provider mode, export, reload |
| Prompt Management | `/admin/api/prompts/` | CRUD, versioning, restore, test |
| File Sync + Audit | `/admin/api/sync/` | audit log, raw editors, file import |
| WebSocket | `/admin/ws/sync` | Real-time file change notifications |

### SSE Event Schemas

**Extraction Events:**
```json
{"type": "progress", "page": 3, "total": 12, "filename": "noa_2023.pdf"}
{"type": "category_complete", "category": "Employment Income", "field_count": 6}
{"type": "complete", "extraction_id": "uuid", "total_fields": 18, "categories": ["..."]}
```

**Generation Events:**
```json
{"type": "section_start", "section": "Executive Summary"}
{"type": "token", "text": "This Source of Wealth report..."}
{"type": "section_complete", "section": "Executive Summary", "word_count": 145}
{"type": "complete", "generation_id": "uuid", "total_words": 1250}
```

---

## 10. Database Schema

### Table: `document_sessions`

| Column | Type | Description |
|---|---|---|
| `id` | `SERIAL PK` | Auto-increment primary key |
| `session_id` | `UUID` | Groups all docs for one client case |
| `subsession_id` | `UUID` | One round of edits (audit trail) |
| `doc_type` | `VARCHAR(64)` | Document type key from registry |
| `status` | `VARCHAR(32)` | `extracted` → `reviewing` → `verified` |
| `extracted_data` | `JSONB` | Raw extraction output |
| `verified_data` | `JSONB NULL` | User-curated data |
| `diff_summary` | `JSONB NULL` | Changed fields between extracted/verified |
| `created_at` | `TIMESTAMPTZ` | Record creation time |
| `updated_at` | `TIMESTAMPTZ` | Last update time |

**Index:** `(session_id, doc_type)` for fast session lookups.

**Design:** Append-only — updates create new rows with new `subsession_id` for full audit trail.

### SQLite: `sow_users` (user allowlist)

Managed by `auth/user_store.py` at `/tmp/sow_users.db`. Not part of PostgreSQL. Stores approved usernames, display names, emails, roles, and last-login timestamps. This file is ephemeral (in `/tmp/`) — re-populate via the admin console after a host restart, or configure a persistent path via `config.yaml`.

---

## 11. How to Run — Standalone

### Prerequisites

- Python 3.10+
- PostgreSQL 16+ (running and accessible)

### Step 1: Database Setup

```bash
# macOS
brew install postgresql@16
brew services start postgresql@16
createdb findoc_db
psql findoc_db -c "CREATE USER findoc WITH PASSWORD 'findoc_secret';"
psql findoc_db -c "GRANT ALL PRIVILEGES ON DATABASE findoc_db TO findoc;"
psql findoc_db -c "GRANT ALL ON SCHEMA public TO findoc;"
```

### Step 2: Backend

```bash
cd backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies (15 packages including httpx, ldap3, msal)
pip install -r requirements.txt

# Set environment variables
export DATABASE_URL="postgresql://findoc:findoc_secret@localhost:5432/findoc_db"
export ANTHROPIC_API_KEY="sk-ant-..."   # Optional — set provider.mode in config.yaml instead
export ADMIN_PASSWORD="changeme"        # Plain text admin password (overrides config.yaml hash)

# Start server
uvicorn main:app --reload --port 8000
```

The backend will:
- Create database tables automatically on startup
- Seed sample data (idempotent)
- Initialize the provider registry (`init_providers()`)
- Start session cleanup background task
- Serve API at http://localhost:8000
- Serve Swagger docs at http://localhost:8000/docs
- Serve Admin Console at http://localhost:8000/admin/

### Step 3: Frontend (separate terminal)

```bash
cd bos-portal
python3 -m http.server 3000
```

### Step 4: Access

- **Portal:** http://localhost:3000
- **Portal Login:** `demo` / `gdo2024`
- **Admin Console:** http://localhost:8000/admin/
- **Admin Login:** `admin` / value of `ADMIN_PASSWORD` env var
- **API Docs:** http://localhost:8000/docs

---

## 12. How to Run — Docker

### Prerequisites

- Docker 24+ with Docker Compose

### Step 1: Configure Environment

```bash
cp .env.example .env
# Edit .env:
#   ANTHROPIC_API_KEY  — or configure an alternative provider in config/config.yaml
#   ADMIN_PASSWORD     — plain text admin password
```

### Step 2: Start All Services

```bash
docker compose up --build -d
```

This starts 3 containers:

| Container | Image | Port | Purpose |
|---|---|---|---|
| `findoc_postgres` | postgres:16-alpine | 5432 | PostgreSQL database |
| `findoc_backend` | sowa-backend (custom) | 8000 | FastAPI API server |
| `findoc_frontend` | python:3.10-slim | 3000 | Static file server |

### Step 3: Verify

```bash
docker compose ps          # All 3 containers should be "Up"
docker compose logs backend --tail=5   # Should show "Application startup complete"
```

### Step 4: Access

- **Portal:** http://localhost:3000
- **Portal Login:** `demo` / `gdo2024`
- **Admin Console:** http://localhost:8000/admin/
- **Admin Login:** `admin` / value of `ADMIN_PASSWORD` env var
- **API Docs:** http://localhost:8000/docs

### Management Commands

```bash
# View logs
docker compose logs -f backend

# Restart after code changes (volumes are mounted)
docker compose restart backend

# Stop all services
docker compose down

# Reset database (delete volumes)
docker compose down -v
docker compose up --build -d

# Remove old containers if name conflict
docker rm -f findoc_postgres findoc_backend findoc_frontend
```

---

## 13. Environment Variables

| Variable | Required | Default | Description |
|---|---|---|---|
| `DATABASE_URL` | Yes (standalone) | `postgresql://findoc:findoc_secret@localhost:5432/findoc_db` | PostgreSQL connection string |
| `ANTHROPIC_API_KEY` | No | (none) | Anthropic Claude API key. Only needed when `provider.mode: anthropic` in `config.yaml`. Without it, falls back to mock pipeline |
| `ADMIN_PASSWORD` | Recommended | (none) | Plain text admin password for the admin console. Overrides `admin.password_hash` in `config.yaml`. If neither is set, admin login is disabled |
| `ADMIN_PASSWORD` | No | (none) | Admin console password (plain text). Alternative: set admin_password_hash in config.yaml |

All other provider credentials (OpenAI keys, Azure endpoints, LDAP bind passwords, vLLM token endpoints, etc.) are configured in `backend/config/config.yaml` rather than environment variables, to keep the `.env` file minimal.

---

## 14. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `Connection refused` port 5432 | PostgreSQL not running | `brew services start postgresql@16` or `docker compose up postgres -d` |
| `relation "document_sessions" does not exist` | Tables not created | Restart backend — `init_db()` runs on startup |
| Container name conflict | Old containers exist | `docker rm -f findoc_postgres findoc_backend findoc_frontend` |
| Extraction stuck / slow | Large PDF + real LLM OCR | Use "Stop & Re-upload" button, or upload smaller files |
| `529 Overloaded` in logs | Claude API rate limit | Automatic retry (3x with backoff). Falls back to mock if all retries fail |
| `ANTHROPIC_API_KEY` not loaded in Docker | `.env` file missing or not read | Ensure `.env` exists in project root, run `docker compose down && docker compose up -d` |
| Port 8000/3000 in use | Another process on port | `lsof -ti:8000 \| xargs kill` |
| Frontend can't reach backend | CORS or port mismatch | Backend CORS allows all origins (`*`). Ensure backend on 8000 |
| Blank PDF last page | Footer pushed to new page | Fixed — footer now rendered in canvas footer area on every page |
| `**bold**` showing as text in PDF | Markdown not parsed | Fixed — `_md_to_markup()` converts `**text**` to `<b>text</b>` for ReportLab |
| `403 Forbidden` on portal login | User not in allowlist | Add user via Admin Console at `http://localhost:8000/admin/` or `POST /api/admin/users` |
| Admin Console shows `401 Unauthorized` | Wrong admin password or `ADMIN_PASSWORD` not set | Ensure `ADMIN_PASSWORD` env var is set, or set `admin.password_hash` in `config.yaml` |
| `ProviderRegistry not initialized` on startup | `init_providers()` failed | Check `config/config.yaml` for valid `provider.mode` and correct credentials for that mode |
| SSO login fails with valid credentials | User not in allowlist | `allowlist_required: true` in `config.yaml`. Add user via admin console, or set `allowlist_required: false` to bypass |
| LDAP bind error | Wrong `bind_dn` or password | Check `auth.ldap` section in `config.yaml`; test connectivity with `ldapsearch` |
| Azure AD login fails | Tenant ID or client ID wrong | Verify `auth.azure_ad.tenant_id` and `client_id` in `config.yaml`; ensure the app registration has the correct redirect URIs |
| Bearer token refresh loops (internal vLLM) | Token endpoint unreachable | Check `provider.internal_vllm.token_endpoint` in `config.yaml`; verify network connectivity from the backend container |
| User allowlist lost after restart | SQLite stored in `/tmp/` | Allowlist at `/tmp/sow_users.db` is ephemeral. Re-add users via admin console, or configure a persistent path in `config.yaml` |
| File watcher not detecting changes | watchdog not installed or volume mount issue | Ensure `watchdog` is in requirements.txt and backend is rebuilt |
| WebSocket disconnects immediately | Invalid admin token in first message | Re-login to admin console, get fresh token |
| `audit_log.jsonl` missing | No changes made yet | File is created on first admin action |
| Config changes not persisting | Volume mount issue in Docker | Check `./backend:/app` volume is mounted |
