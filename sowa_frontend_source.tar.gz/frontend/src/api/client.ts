import axios from 'axios';
import { env } from '../config/env';

export const apiClient = axios.create({
  baseURL: env.apiBaseUrl,
  headers: { 'Content-Type': 'application/json' },
});

apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem(env.sessionTokenKey);
  if (token) {
    config.headers['X-Session-Token'] = token;
  }
  return config;
});

apiClient.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem(env.sessionTokenKey);
      window.location.href = '/login';
    }
    return Promise.reject(err);
  },
);
