import { useQuery } from '@tanstack/react-query';
import { apiClient } from './client';
import { apiActions } from '../config/apiActions';

export interface SchemaField {
  type?: string;
  title?: string;
  description?: string;
  default?: unknown;
  enum?: string[];
  format?: string;
  items?: SchemaField;
  properties?: Record<string, SchemaField>;
  required?: string[];
  anyOf?: SchemaField[];
}

export interface SchemaResponse {
  registered_types: string[];
  models: Record<string, SchemaField>;
  statuses?: string[];
}

export interface DriverConfig {
  label: string;
  description: string;
  ce_folder: string;
  ce_schema: SchemaField | null;
  data_schema: SchemaField | null;
}

export interface FormsSchemaResponse {
  client_info_schema: SchemaField;
  drivers: Record<string, DriverConfig>;
}

export function useSchema() {
  return useQuery<SchemaResponse>({
    queryKey: ['schema'],
    queryFn: async () => {
      const res = await apiClient.get(apiActions.schema.path);
      return res.data;
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useFormsSchema() {
  return useQuery<FormsSchemaResponse>({
    queryKey: ['formsSchema'],
    queryFn: async () => {
      const res = await apiClient.get(apiActions.formsSchema.path);
      return res.data;
    },
    staleTime: 5 * 60 * 1000,
  });
}
