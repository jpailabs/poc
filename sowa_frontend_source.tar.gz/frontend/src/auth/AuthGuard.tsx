import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { Header } from '../components/Header';
import { StepNav } from '../components/StepNav';

const STEP_MAP: Record<string, number> = {
  '/intake': 1,
  '/verify': 2,
  '/report': 3,
};

export function AuthGuard() {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-8 w-8 rounded-full"
          style={{
            borderWidth: '4px',
            borderStyle: 'solid',
            borderColor: 'var(--color-primary)',
            borderTopColor: 'transparent',
          }} />
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  const currentStep = STEP_MAP[location.pathname] || 0;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Sticky top bar: Header + StepNav */}
      <div className="sticky top-0 z-50" style={{ backgroundColor: 'var(--color-surface)' }}>
        <Header />
        {currentStep > 0 && <StepNav current={currentStep} />}
      </div>

      {/* Page content fills remaining height */}
      <div className="flex-1">
        <Outlet />
      </div>
    </div>
  );
}
