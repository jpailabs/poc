import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from 'react';
import { apiClient } from '../api/client';
import { apiActions } from '../config/apiActions';
import { env } from '../config/env';

interface User {
  username: string;
  display_name: string;
  email: string;
  role: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem(env.sessionTokenKey),
  );
  const [isLoading, setIsLoading] = useState(!!token);

  useEffect(() => {
    if (!token) return;
    apiClient
      .get(apiActions.me.path)
      .then((res) => setUser(res.data))
      .catch(() => {
        localStorage.removeItem(env.sessionTokenKey);
        setToken(null);
      })
      .finally(() => setIsLoading(false));
  }, [token]);

  const login = useCallback(async (username: string, password: string) => {
    const res = await apiClient.post(apiActions.login.path, { username, password });
    const { token: newToken, ...userData } = res.data;
    localStorage.setItem(env.sessionTokenKey, newToken);
    setToken(newToken);
    setUser(userData);
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiClient.post(apiActions.logout.path);
    } catch {
      // ignore logout failures
    }
    localStorage.removeItem(env.sessionTokenKey);
    setToken(null);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
