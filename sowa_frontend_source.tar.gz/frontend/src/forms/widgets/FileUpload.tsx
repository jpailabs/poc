import { useCallback, useState } from 'react';

interface FileUploadProps {
  name: string;
  label: string;
  description?: string;
  files: File[];
  onFilesChange: (files: File[]) => void;
  accept?: string;
  multiple?: boolean;
  disabled?: boolean;
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileIcon(name: string) {
  const ext = name.split('.').pop()?.toLowerCase() || '';
  if (ext === 'pdf') return { color: '#DA1710', label: 'PDF' };
  if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) return { color: '#2563EB', label: ext.toUpperCase() };
  if (['doc', 'docx'].includes(ext)) return { color: '#1D4ED8', label: 'DOC' };
  if (['xls', 'xlsx'].includes(ext)) return { color: '#059669', label: 'XLS' };
  return { color: '#555555', label: ext.toUpperCase() || 'FILE' };
}

export function FileUpload({
  name,
  label,
  description,
  files,
  onFilesChange,
  accept = '.pdf,.jpg,.jpeg,.png',
  multiple = true,
  disabled,
}: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      if (disabled) return;
      const dropped = Array.from(e.dataTransfer.files);
      onFilesChange([...files, ...dropped]);
    },
    [files, onFilesChange, disabled],
  );

  const handleSelect = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!e.target.files) return;
      const selected = Array.from(e.target.files);
      onFilesChange([...files, ...selected]);
      e.target.value = '';
    },
    [files, onFilesChange],
  );

  const removeFile = useCallback(
    (index: number) => {
      onFilesChange(files.filter((_, i) => i !== index));
    },
    [files, onFilesChange],
  );

  return (
    <div>
      {/* Label with file count badge */}
      <div className="flex items-center gap-2 mb-2">
        <label className="text-sm font-semibold" style={{ color: 'var(--color-text-primary)' }}>
          {label}
        </label>
        {files.length > 0 && (
          <span className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-bold"
            style={{ backgroundColor: 'var(--color-primary)', color: 'white' }}>
            {files.length}
          </span>
        )}
      </div>

      {/* Drop zone */}
      <div
        className="rounded-xl overflow-hidden"
        style={{
          border: isDragOver
            ? '2px solid var(--color-primary)'
            : files.length > 0
              ? '2px solid var(--color-primary-200)'
              : `2px dashed ${disabled ? 'var(--color-border)' : 'var(--color-border-strong)'}`,
          backgroundColor: isDragOver
            ? 'var(--color-primary-light)'
            : 'var(--color-surface)',
          cursor: disabled ? 'default' : 'pointer',
          transition: 'all 0.2s ease',
          boxShadow: isDragOver ? '0 0 0 4px rgba(218, 23, 16, 0.08)' : 'none',
        }}
        onDragOver={(e) => { e.preventDefault(); if (!disabled) setIsDragOver(true); }}
        onDragEnter={() => { if (!disabled) setIsDragOver(true); }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={handleDrop}
        onClick={() => {
          if (!disabled) document.getElementById(`file-${name}`)?.click();
        }}
      >
        <input
          id={`file-${name}`}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleSelect}
          className="hidden"
          disabled={disabled}
        />

        {/* Upload prompt area */}
        <div className="px-6 py-5 flex items-center gap-4">
          {/* Icon circle */}
          <div className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center"
            style={{
              backgroundColor: isDragOver ? 'var(--color-primary)' : 'var(--color-primary-light)',
              transition: 'all 0.2s ease',
            }}>
            <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" strokeWidth="2"
              stroke={isDragOver ? 'white' : 'var(--color-primary)'}
              style={{ transition: 'all 0.2s ease' }}>
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" strokeLinecap="round" strokeLinejoin="round" />
              <polyline points="17 8 12 3 7 8" strokeLinecap="round" strokeLinejoin="round" />
              <line x1="12" y1="3" x2="12" y2="15" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          {/* Text */}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
              {isDragOver ? 'Drop files here' : (
                <>Drop files here or <span style={{ color: 'var(--color-primary)', fontWeight: 600 }}>click to browse</span></>
              )}
            </p>
            <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-tertiary)' }}>
              PDF, JPG, PNG up to 50MB each
            </p>
          </div>

          {/* Browse button visual */}
          {!isDragOver && (
            <div className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-semibold"
              style={{
                border: '1px solid var(--color-primary)',
                color: 'var(--color-primary)',
              }}>
              Browse
            </div>
          )}
        </div>

        {/* File list inside the card */}
        {files.length > 0 && (
          <div style={{ borderTop: '1px solid var(--color-primary-200)' }}>
            {files.map((file, i) => {
              const icon = fileIcon(file.name);
              return (
                <div
                  key={`${file.name}-${i}`}
                  className="flex items-center gap-3 px-6 py-3 file-list-item"
                  style={{
                    borderBottom: i < files.length - 1 ? '1px solid var(--color-border)' : 'none',
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* File type badge */}
                  <div className="flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center text-[10px] font-bold text-white"
                    style={{ backgroundColor: icon.color }}>
                    {icon.label}
                  </div>

                  {/* File info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: 'var(--color-text-primary)' }}>
                      {file.name}
                    </p>
                    <p className="text-xs" style={{ color: 'var(--color-text-tertiary)' }}>
                      {formatFileSize(file.size)}
                    </p>
                  </div>

                  {/* Status + Remove */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-[11px] font-medium px-2 py-0.5 rounded-full"
                      style={{ backgroundColor: 'var(--color-success-light)', color: 'var(--color-success)' }}>
                      Ready
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFile(i);
                      }}
                      className="w-7 h-7 rounded-full flex items-center justify-center file-remove-btn"
                    >
                      <svg viewBox="0 0 16 16" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="12" y1="4" x2="4" y2="12" />
                        <line x1="4" y1="4" x2="12" y2="12" />
                      </svg>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {description && (
        <p className="mt-2 text-xs" style={{ color: 'var(--color-text-tertiary)' }}>{description}</p>
      )}
    </div>
  );
}
