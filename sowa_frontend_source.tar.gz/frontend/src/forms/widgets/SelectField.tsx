interface SelectFieldProps {
  name: string;
  label: string;
  description?: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
  required?: boolean;
  disabled?: boolean;
}

export function SelectField({
  name,
  label,
  description,
  value,
  onChange,
  options,
  required,
  disabled,
}: SelectFieldProps) {
  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium mb-1"
        style={{ color: 'var(--color-text-primary)' }}>
        {label}
        {required && <span style={{ color: 'var(--color-error)' }} className="ml-0.5">*</span>}
      </label>
      <select
        id={name}
        name={name}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 text-sm disabled:opacity-60"
        style={{
          border: '1px solid var(--color-border-strong)',
          borderRadius: 'var(--radius-md)',
          outline: 'none',
          height: '38px',
          backgroundColor: 'var(--color-surface)',
        }}
        required={required}
        disabled={disabled}
      >
        <option value="">Select...</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
      {description && (
        <p className="mt-1 text-xs" style={{ color: 'var(--color-text-tertiary)' }}>{description}</p>
      )}
    </div>
  );
}
