interface DriverOption {
  key: string;
  label: string;
  description?: string;
}

interface DriverSelectProps {
  options: DriverOption[];
  selected: string[];
  onChange: (selected: string[]) => void;
  disabled?: boolean;
}

export function DriverSelect({
  options,
  selected,
  onChange,
  disabled,
}: DriverSelectProps) {
  const toggle = (key: string) => {
    if (disabled) return;
    if (selected.includes(key)) {
      onChange(selected.filter((k) => k !== key));
    } else {
      onChange([...selected, key]);
    }
  };

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {options.map((opt) => {
        const isSelected = selected.includes(opt.key);
        return (
          <button
            key={opt.key}
            type="button"
            onClick={() => toggle(opt.key)}
            disabled={disabled}
            className="flex items-start gap-3 rounded-lg p-4 text-left"
            style={{
              border: isSelected ? '2px solid var(--color-primary)' : '2px solid var(--color-border)',
              backgroundColor: isSelected ? 'var(--color-primary-light)' : 'var(--color-surface)',
              opacity: disabled ? 0.5 : 1,
              cursor: disabled ? 'not-allowed' : 'pointer',
            }}
          >
            <div
              className="mt-0.5 flex h-5 w-5 flex-shrink-0 items-center justify-center rounded"
              style={{
                border: isSelected ? 'none' : '2px solid var(--color-border-strong)',
                backgroundColor: isSelected ? 'var(--color-primary)' : 'transparent',
              }}
            >
              {isSelected && (
                <svg viewBox="0 0 12 12" className="w-3 h-3 text-white" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="2,6 5,9 10,3" />
                </svg>
              )}
            </div>
            <div>
              <div className="text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>{opt.label}</div>
              {opt.description && (
                <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-secondary)' }}>{opt.description}</div>
              )}
            </div>
          </button>
        );
      })}
    </div>
  );
}
