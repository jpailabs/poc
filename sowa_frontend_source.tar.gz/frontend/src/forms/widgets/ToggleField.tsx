interface ToggleFieldProps {
  name?: string;
  label: string;
  description?: string;
  value: boolean | null;
  onChange: (value: boolean) => void;
  disabled?: boolean;
}

export function ToggleField({
  label,
  description,
  value,
  onChange,
  disabled,
}: ToggleFieldProps) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1"
        style={{ color: 'var(--color-text-primary)' }}>
        {label}
      </label>
      <div className="flex gap-0 rounded-lg overflow-hidden" style={{ border: '1px solid var(--color-border-strong)', height: '38px', display: 'inline-flex' }}>
        <button
          type="button"
          onClick={() => !disabled && onChange(true)}
          className="px-6 text-sm font-medium transition-colors"
          style={{
            backgroundColor: value === true ? 'var(--color-primary)' : 'var(--color-surface)',
            color: value === true ? 'var(--color-text-inverse)' : 'var(--color-text-secondary)',
            borderRight: '1px solid var(--color-border-strong)',
            height: '100%',
          }}
          disabled={disabled}
        >
          Yes
        </button>
        <button
          type="button"
          onClick={() => !disabled && onChange(false)}
          className="px-6 text-sm font-medium transition-colors"
          style={{
            backgroundColor: value === false ? 'var(--color-primary)' : 'var(--color-surface)',
            color: value === false ? 'var(--color-text-inverse)' : 'var(--color-text-secondary)',
            height: '100%',
          }}
          disabled={disabled}
        >
          No
        </button>
      </div>
      {description && (
        <p className="mt-1 text-xs" style={{ color: 'var(--color-text-tertiary)' }}>{description}</p>
      )}
    </div>
  );
}
