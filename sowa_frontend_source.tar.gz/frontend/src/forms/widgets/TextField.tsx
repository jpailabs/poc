interface TextFieldProps {
  name: string;
  label: string;
  description?: string;
  value: string;
  onChange: (value: string) => void;
  type?: 'text' | 'number' | 'textarea';
  required?: boolean;
  disabled?: boolean;
}

export function TextField({
  name,
  label,
  description,
  value,
  onChange,
  type = 'text',
  required,
  disabled,
}: TextFieldProps) {
  const inputStyle: React.CSSProperties = {
    border: '1px solid var(--color-border-strong)',
    borderRadius: 'var(--radius-md)',
    outline: 'none',
    backgroundColor: 'var(--color-surface)',
    height: type === 'textarea' ? undefined : '38px',
  };

  return (
    <div>
      <label htmlFor={name} className="block text-sm font-medium mb-1"
        style={{ color: 'var(--color-text-primary)' }}>
        {label}
        {required && <span style={{ color: 'var(--color-error)' }} className="ml-0.5">*</span>}
      </label>
      {type === 'textarea' ? (
        <textarea
          id={name}
          name={name}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-3 py-2 text-sm min-h-[80px] resize-y disabled:opacity-60"
          style={inputStyle}
          required={required}
          disabled={disabled}
        />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full px-3 py-2 text-sm disabled:opacity-60"
          style={inputStyle}
          required={required}
          disabled={disabled}
        />
      )}
      {description && (
        <p className="mt-1 text-xs" style={{ color: 'var(--color-text-tertiary)' }}>{description}</p>
      )}
    </div>
  );
}
