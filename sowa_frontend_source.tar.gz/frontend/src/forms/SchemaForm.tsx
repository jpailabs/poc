/**
 * SchemaForm — renders any JSON Schema into form fields at runtime.
 *
 * This is the core schema-driven form renderer. It reads the JSON Schema
 * returned by GET /schema, resolves each field to a widget type, and
 * renders the appropriate UI component. No field names or labels are
 * hardcoded — everything is derived from the schema.
 */

import { useMemo } from 'react';
import type { SchemaField } from '../api/schema';
import { resolveWidget, fieldLabel } from './mapping';
import { TextField } from './widgets/TextField';
import { SelectField } from './widgets/SelectField';
import { FileUpload } from './widgets/FileUpload';
import { DateField } from './widgets/DateField';
import { ToggleField } from './widgets/ToggleField';

interface SchemaFormProps {
  schema: SchemaField;
  schemaKey: string;
  values: Record<string, unknown>;
  onChange: (fieldPath: string, value: unknown) => void;
  files?: Record<string, File[]>;
  onFilesChange?: (fieldPath: string, files: File[]) => void;
  disabled?: boolean;
}

export function SchemaForm({
  schema,
  schemaKey,
  values,
  onChange,
  files = {},
  onFilesChange,
  disabled,
}: SchemaFormProps) {
  const fields = useMemo(() => {
    if (!schema.properties) return [];
    const required = new Set(schema.required || []);
    return Object.entries(schema.properties).map(([name, fieldSchema]) => {
      // Unwrap anyOf to get enum options
      let enumOptions = fieldSchema.enum || [];
      if (!enumOptions.length && fieldSchema.anyOf) {
        const withEnum = fieldSchema.anyOf.find((s) => s.enum);
        if (withEnum) enumOptions = withEnum.enum!;
      }

      return {
        name,
        schema: fieldSchema,
        widget: resolveWidget(name, fieldSchema, schemaKey),
        required: required.has(name),
        label: fieldSchema.title || fieldLabel(name),
        description: fieldSchema.description,
        enumOptions,
      };
    });
  }, [schema, schemaKey]);

  // Separate file-upload fields from regular fields
  const uploadFields = fields.filter((f) => f.widget === 'file-upload');
  const regularFields = fields.filter((f) => f.widget !== 'file-upload');

  return (
    <div>
      {/* Regular form fields in grid */}
      {regularFields.length > 0 && (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {regularFields.map((field) => {
            const fieldPath = `${schemaKey}.${field.name}`;

        if (field.widget === 'date') {
          return (
            <DateField
              key={field.name}
              name={fieldPath}
              label={field.label}
              description={field.description}
              value={String(values[field.name] ?? '')}
              onChange={(val) => onChange(field.name, val)}
              required={field.required}
              disabled={disabled}
            />
          );
        }

        if (field.widget === 'toggle') {
          return (
            <ToggleField
              key={field.name}
              name={fieldPath}
              label={field.label}
              description={field.description}
              value={values[field.name] as boolean | null ?? null}
              onChange={(val) => onChange(field.name, val)}
              disabled={disabled}
            />
          );
        }

        if (field.widget === 'select') {
          return (
            <SelectField
              key={field.name}
              name={fieldPath}
              label={field.label}
              description={field.description}
              value={String(values[field.name] ?? '')}
              onChange={(val) => onChange(field.name, val)}
              options={field.enumOptions}
              required={field.required}
              disabled={disabled}
            />
          );
        }

        if (field.widget === 'checkbox') {
          return (
            <label key={field.name} className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={!!values[field.name]}
                onChange={(e) => onChange(field.name, e.target.checked)}
                disabled={disabled}
                className="h-4 w-4 rounded"
                style={{ accentColor: 'var(--color-primary)' }}
              />
              <span style={{ color: 'var(--color-text-primary)' }}>{field.label}</span>
            </label>
          );
        }

        return (
          <TextField
            key={field.name}
            name={fieldPath}
            label={field.label}
            description={field.description}
            value={String(values[field.name] ?? '')}
            onChange={(val) => onChange(field.name, field.widget === 'number' ? Number(val) : val)}
            type={field.widget === 'number' ? 'number' : field.widget === 'textarea' ? 'textarea' : 'text'}
            required={field.required}
            disabled={disabled}
          />
        );
          })}
        </div>
      )}

      {/* File upload fields in 2-column layout */}
      {uploadFields.length > 0 && (
        <div className={regularFields.length > 0 ? 'mt-6' : ''}>
          <div className="grid gap-5 sm:grid-cols-1 lg:grid-cols-2">
            {uploadFields.map((field) => {
              const fieldPath = `${schemaKey}.${field.name}`;
              return (
                <FileUpload
                  key={field.name}
                  name={fieldPath}
                  label={field.label}
                  description={field.description}
                  files={files[fieldPath] || []}
                  onFilesChange={(newFiles) => onFilesChange?.(fieldPath, newFiles)}
                  disabled={disabled}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
