/**
 * Schema-driven widget mapping.
 *
 * Determines which UI widget to render for a given schema field.
 * CE_* parent class fields -> file upload widgets.
 * Boolean fields -> toggle (Yes/No).
 * Enum fields -> select dropdowns.
 * Date fields -> date picker.
 * Numeric fields -> number inputs.
 * Everything else -> text input.
 */

import type { SchemaField } from '../api/schema';

export type WidgetType = 'text' | 'number' | 'select' | 'checkbox' | 'toggle' | 'file-upload' | 'textarea' | 'list-text' | 'date';

const DATE_FIELD_PATTERNS = ['birthdate', 'date', 'start_date', 'end_date', 'dob'];

export function resolveWidget(
  fieldName: string,
  fieldSchema: SchemaField,
  parentKey?: string,
): WidgetType {
  // CE_* parent class: all fields are file-upload lists
  if (isCEType(parentKey || '')) {
    return 'file-upload';
  }

  // Handle anyOf (Optional fields from Pydantic) — unwrap to find the real type
  if (fieldSchema.anyOf) {
    const nonNull = fieldSchema.anyOf.find((s) => s.type !== 'null');
    if (nonNull) return resolveWidget(fieldName, nonNull, parentKey);
  }

  // Array of strings outside CE -> list-text input
  if (fieldSchema.type === 'array' && fieldSchema.items?.type === 'string') {
    return 'list-text';
  }

  // Boolean -> toggle (Yes/No)
  if (fieldSchema.type === 'boolean') return 'toggle';

  // Date fields — format hint from schema or field name pattern
  if (fieldSchema.format === 'date' || DATE_FIELD_PATTERNS.some((p) => fieldName.toLowerCase().includes(p))) {
    return 'date';
  }

  if (fieldSchema.enum) return 'select';
  if (fieldSchema.type === 'number' || fieldSchema.type === 'integer') return 'number';
  if (fieldSchema.type === 'string') {
    if (fieldName.includes('description') || fieldName.includes('notes') || fieldName.includes('assessment')) {
      return 'textarea';
    }
    return 'text';
  }

  return 'text';
}

export function fieldLabel(fieldName: string): string {
  return fieldName
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export function isCEType(key: string): boolean {
  return key.startsWith('CE_') || key.startsWith('ce_');
}
