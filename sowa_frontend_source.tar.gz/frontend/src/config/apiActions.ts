export const apiActions = {
  login: {
    method: 'POST' as const,
    path: '/auth/login',
  },
  logout: {
    method: 'POST' as const,
    path: '/auth/logout',
  },
  me: {
    method: 'GET' as const,
    path: '/auth/me',
  },
  schema: {
    method: 'GET' as const,
    path: '/schema',
  },
  formsSchema: {
    method: 'GET' as const,
    path: '/schema/forms',
  },
  upload: {
    method: 'POST' as const,
    path: '/api/v1/upload',
  },
  extract: {
    method: 'POST' as const,
    path: '/api/v1/extract',
  },
  extractionStatus: {
    method: 'GET' as const,
    pathFn: (processId: string) => `/api/v1/extract/${processId}/status`,
  },
  extractionResult: {
    method: 'GET' as const,
    pathFn: (processId: string) => `/api/v1/extract/${processId}/result`,
  },
  validateSource: {
    method: 'POST' as const,
    pathFn: (sessionId: string) => `/api/v1/extract/${sessionId}/validate-source`,
  },
  sessionFiles: {
    method: 'GET' as const,
    pathFn: (sessionId: string) => `/api/v1/session/${sessionId}/files`,
  },
  generate: {
    method: 'POST' as const,
    path: '/api/v1/generate',
  },
  exportReport: {
    method: 'POST' as const,
    pathFn: (format: 'pdf' | 'docx') => `/api/v1/export/${format}`,
  },
  sessionStatus: {
    method: 'GET' as const,
    pathFn: (sessionId: string) => `/api/v1/session/${sessionId}/status`,
  },
  settings: {
    method: 'GET' as const,
    path: '/api/v1/settings',
  },
  updateSettings: {
    method: 'PUT' as const,
    path: '/api/v1/settings',
  },
  currencies: {
    method: 'GET' as const,
    path: '/api/v1/currencies',
  },
} as const;
