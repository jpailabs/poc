export const env = {
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || '',
  sessionTokenKey: 'sow_session_token',
} as const;
