import { createBrowserRouter } from 'react-router-dom';
import { AuthGuard } from './auth/AuthGuard';
import { Login } from './pages/Login';
import { Intake } from './pages/Intake';
import { Verify } from './pages/Verify';
import { Report } from './pages/Report';
import { Settings } from './pages/Settings';

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <Login />,
  },
  {
    element: <AuthGuard />,
    children: [
      { path: '/intake', element: <Intake /> },
      { path: '/verify', element: <Verify /> },
      { path: '/report', element: <Report /> },
      { path: '/settings', element: <Settings /> },
    ],
  },
  {
    path: '*',
    element: <Login />,
  },
]);
