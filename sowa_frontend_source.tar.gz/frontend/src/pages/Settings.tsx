/**
 * Settings page — currency and inflation rate preferences.
 */

import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { apiActions } from '../config/apiActions';
import { Section } from '../components/Section';
import { Button } from '../components/Button';
import { Spinner } from '../components/Spinner';
import { Alert } from '../components/Alert';

const CURRENCIES = [
  'SGD', 'USD', 'EUR', 'GBP', 'JPY', 'CNY', 'HKD', 'AUD', 'CAD',
  'CHF', 'NZD', 'INR', 'MYR', 'IDR', 'THB', 'PHP', 'VND', 'KRW',
  'TWD', 'AED', 'SAR', 'QAR', 'BHD', 'KWD', 'ZAR', 'BRL', 'MXN',
];

export function Settings() {
  const navigate = useNavigate();
  const [inputCurrency, setInputCurrency] = useState('SGD');
  const [outputCurrency, setOutputCurrency] = useState('SGD');
  const [inflationRate, setInflationRate] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [loadingSettings, setLoadingSettings] = useState(true);

  useEffect(() => {
    apiClient.get(apiActions.settings.path)
      .then((res) => {
        setInputCurrency(res.data.input_currency || 'SGD');
        setOutputCurrency(res.data.output_currency || 'SGD');
        setInflationRate(res.data.inflation_rate || '');
      })
      .catch(() => {})
      .finally(() => setLoadingSettings(false));
  }, []);

  const handleSave = useCallback(async () => {
    setSaving(true);
    setSaved(false);
    setError('');
    try {
      await apiClient.put(apiActions.updateSettings.path, {
        input_currency: inputCurrency,
        output_currency: outputCurrency,
        inflation_rate: inflationRate || null,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {
      setError('Failed to save settings.');
    } finally {
      setSaving(false);
    }
  }, [inputCurrency, outputCurrency, inflationRate]);

  return (
    <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
      <div className="max-w-4xl mx-auto py-8 px-8 space-y-6">
        <div>
          <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
            Settings
          </h2>
          <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
            Configure currency preferences and inflation rate for your assessments.
          </p>
        </div>

        {loadingSettings ? (
          <div className="flex items-center justify-center py-16">
            <Spinner />
            <span className="ml-3 text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              Loading settings...
            </span>
          </div>
        ) : (<>

        <Section title="Currency">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium mb-1"
                style={{ color: 'var(--color-text-primary)' }}>
                Input Currency
              </label>
              <p className="text-xs mb-2" style={{ color: 'var(--color-text-tertiary)' }}>
                Currency of uploaded document values
              </p>
              <select
                value={inputCurrency}
                onChange={(e) => setInputCurrency(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg"
                style={{
                  border: '1px solid var(--color-border-strong)',
                  outline: 'none',
                }}
              >
                {CURRENCIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-1"
                style={{ color: 'var(--color-text-primary)' }}>
                Output Currency
              </label>
              <p className="text-xs mb-2" style={{ color: 'var(--color-text-tertiary)' }}>
                Currency shown in extraction results and reports
              </p>
              <select
                value={outputCurrency}
                onChange={(e) => setOutputCurrency(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg"
                style={{
                  border: '1px solid var(--color-border-strong)',
                  outline: 'none',
                }}
              >
                {CURRENCIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>
        </Section>

        <Section title="Inflation Rate">
          <div>
            <label className="block text-sm font-medium mb-1"
              style={{ color: 'var(--color-text-primary)' }}>
              Manual Inflation Rate (%)
            </label>
            <p className="text-xs mb-2" style={{ color: 'var(--color-text-tertiary)' }}>
              Optional. Leave blank to use default CPI-based adjustment. Enter as a percentage (e.g., 3.5).
            </p>
            <input
              type="number"
              step="0.1"
              min="0"
              max="100"
              value={inflationRate}
              onChange={(e) => setInflationRate(e.target.value)}
              placeholder="e.g. 3.5"
              className="w-full max-w-xs px-3 py-2 text-sm rounded-lg"
              style={{
                border: '1px solid var(--color-border-strong)',
                outline: 'none',
              }}
            />
          </div>
        </Section>

        {error && <Alert variant="error">{error}</Alert>}
        {saved && <Alert variant="success">Settings saved successfully.</Alert>}

        <div className="flex justify-between pt-2">
          <Button variant="secondary" onClick={() => navigate('/intake')}>
            Back to Home
          </Button>
          <Button onClick={handleSave} loading={saving}>
            Save Settings
          </Button>
        </div>

        </>)}
      </div>
    </div>
  );
}
