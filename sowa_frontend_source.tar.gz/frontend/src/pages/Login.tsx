import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Button } from '../components/Button';
import { Alert } from '../components/Alert';

export function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(username, password);
      navigate('/intake');
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { detail?: string } } })?.response?.data
          ?.detail || 'Invalid credentials. Please try again.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* Left panel — OCBC-themed */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12"
        style={{ backgroundColor: 'var(--color-primary)' }}>
        <div>
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white">SOWA</h2>
            <p className="text-xs font-semibold uppercase tracking-widest mt-1"
              style={{ color: 'rgba(255,255,255,0.7)' }}>
              Source of Wealth Assistant
            </p>
          </div>
          <h1 className="text-4xl font-bold leading-tight text-white">
            Source of <span style={{ color: 'rgba(255,255,255,0.85)' }}>Wealth</span>
            <br />
            Assistant
          </h1>
          <p className="mt-4 max-w-md" style={{ color: 'rgba(255,255,255,0.7)' }}>
            A secure, confidential portal for private and premium banking
            clients to submit supporting documentation as part of our Know Your
            Customer and Source of Wealth review process.
          </p>
        </div>
        <p className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
          This portal is for authorised users only. Documents uploaded are
          subject to our Privacy Policy and data retention guidelines.
        </p>
      </div>

      {/* Right panel */}
      <div className="flex-1 flex items-center justify-center p-8"
        style={{ backgroundColor: 'var(--color-surface)' }}>
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
            Welcome back
          </h2>
          <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
            Sign in to access the SOWA portal
          </p>

          {error && (
            <Alert variant="error" className="mt-4">{error}</Alert>
          )}

          <form onSubmit={handleSubmit} className="mt-8 space-y-5">
            <div>
              <label htmlFor="username" className="block text-sm font-medium mb-1"
                style={{ color: 'var(--color-text-primary)' }}>
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2.5 text-sm"
                style={{
                  border: '1px solid var(--color-border-strong)',
                  borderRadius: 'var(--radius-md)',
                  outline: 'none',
                }}
                placeholder="Enter your username"
                autoComplete="username"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-1"
                style={{ color: 'var(--color-text-primary)' }}>
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2.5 text-sm"
                style={{
                  border: '1px solid var(--color-border-strong)',
                  borderRadius: 'var(--radius-md)',
                  outline: 'none',
                }}
                placeholder="Enter your password"
                autoComplete="current-password"
                required
              />
            </div>

            <Button type="submit" loading={loading} className="w-full">
              Sign In
            </Button>
          </form>

          <p className="mt-6 text-xs text-center" style={{ color: 'var(--color-text-tertiary)' }}>
            Protected by TLS 1.3 end-to-end encryption.
          </p>
        </div>
      </div>
    </div>
  );
}
