/**
 * Verify page — displays extraction results in pure Excel-like table format.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { apiClient } from '../api/client';
import { apiActions } from '../config/apiActions';
import { Button } from '../components/Button';
import { Spinner } from '../components/Spinner';
import { Alert } from '../components/Alert';

interface ExtractedField {
  id: string;
  key: string;
  value: string;
  confidence: number;
  source_file?: string;
  source_page?: number;
  display_label?: string;
  display_category?: string;
}

interface Category {
  category_name: string;
  fields: ExtractedField[];
  icon_key?: string;
}

interface LocationState {
  sessionId: string;
  clientRef: string;
  selectedDrivers: string[];
  clientInfoValues: Record<string, unknown>;
  driverDataValues: Record<string, Record<string, unknown>>;
  profileType: string;
}

const HIDDEN_FIELDS = ['Full Name', 'full_name', 'fullname', 'Name'];

export function Verify() {
  const navigate = useNavigate();
  const location = useLocation();
  const locState = location.state as LocationState | null;

  const [categories, setCategories] = useState<Category[]>([]);
  const [extractionId, setExtractionId] = useState('');
  const [, setProcessId] = useState('');
  const [extracting, setExtracting] = useState(true);
  const [progress, setProgress] = useState(0);
  const [statusMessage, setStatusMessage] = useState('Starting extraction...');
  const [extractError, setExtractError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [editedValues, setEditedValues] = useState<Record<string, string>>({});
  const [editedSources, setEditedSources] = useState<Record<string, string>>({});
  const [uploadedFiles, setUploadedFiles] = useState<string[]>([]);
  const [outputCurrency, setOutputCurrency] = useState('SGD');
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const sessionId = locState?.sessionId || '';
  const clientRef = locState?.clientRef || '';

  useEffect(() => {
    apiClient.get(apiActions.settings.path)
      .then((res) => setOutputCurrency(res.data.output_currency || 'SGD'))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!sessionId) return;
    apiClient.get(apiActions.sessionFiles.pathFn(sessionId))
      .then((res) => setUploadedFiles(res.data.files || []))
      .catch(() => {});
  }, [sessionId]);

  useEffect(() => {
    if (!sessionId) {
      navigate('/intake', { replace: true });
      return;
    }

    async function startExtraction() {
      try {
        const res = await apiClient.post(apiActions.extract.path, { session_id: sessionId });
        const pid = res.data.process_id;
        setProcessId(pid);

        pollRef.current = setInterval(async () => {
          try {
            const statusRes = await apiClient.get(apiActions.extractionStatus.pathFn(pid));
            const { status, progress: pct, message, error } = statusRes.data;
            setProgress(pct);
            setStatusMessage(message || '');

            if (status === 'completed') {
              clearInterval(pollRef.current!);
              pollRef.current = null;
              const resultRes = await apiClient.get(apiActions.extractionResult.pathFn(pid));
              setCategories(resultRes.data.categories || []);
              setExtractionId(resultRes.data.extraction_id || '');
              setExtracting(false);
            } else if (status === 'failed') {
              clearInterval(pollRef.current!);
              pollRef.current = null;
              setExtractError(error || 'Extraction failed.');
              setExtracting(false);
            }
          } catch { /* continue polling */ }
        }, 1000);
      } catch {
        setExtractError('Extraction failed. Please go back and try again.');
        setExtracting(false);
      }
    }

    startExtraction();
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [sessionId, navigate]);

  const filteredCategories = categories.map((cat) => ({
    ...cat,
    fields: cat.fields.filter(
      (f) => !HIDDEN_FIELDS.some((h) => f.key === h || f.display_label === h),
    ),
  })).filter((cat) => cat.fields.length > 0);

  const handleFieldEdit = useCallback((fieldId: string, value: string) => {
    setEditedValues((prev) => ({ ...prev, [fieldId]: value }));
  }, []);

  const handleSourceEdit = useCallback((fieldId: string, sourceFile: string) => {
    setEditedSources((prev) => ({ ...prev, [fieldId]: sourceFile }));
  }, []);

  const getFieldValue = useCallback(
    (field: ExtractedField) => editedValues[field.id] ?? field.value,
    [editedValues],
  );

  const getFieldSource = useCallback(
    (field: ExtractedField) => editedSources[field.id] ?? field.source_file ?? '',
    [editedSources],
  );

  const handleSubmit = useCallback(async () => {
    setSubmitting(true);
    const verifiedFields = filteredCategories.flatMap((cat) =>
      cat.fields.map((field) => ({
        id: field.id,
        key: field.key,
        value: getFieldValue(field),
        category: cat.category_name,
        source_file: getFieldSource(field),
      })),
    );
    navigate('/report', {
      state: {
        sessionId, extractionId, verifiedFields,
        profileType: locState?.profileType || 'salaried',
        clientRef, categories: filteredCategories,
      },
    });
  }, [filteredCategories, getFieldValue, getFieldSource, sessionId, extractionId, locState, clientRef, navigate]);

  const handleBatchSource = useCallback((sourceFile: string) => {
    const allFields = filteredCategories.flatMap((cat) => cat.fields);
    const updates: Record<string, string> = {};
    for (const f of allFields) updates[f.id] = sourceFile;
    setEditedSources((prev) => ({ ...prev, ...updates }));
  }, [filteredCategories]);

  const totalFields = filteredCategories.reduce((sum, cat) => sum + cat.fields.length, 0);

  const cellStyle: React.CSSProperties = {
    border: '1px solid var(--color-border)',
    padding: '8px 12px',
    verticalAlign: 'middle',
  };

  const headerCellStyle: React.CSSProperties = {
    ...cellStyle,
    backgroundColor: 'var(--color-primary)',
    color: 'var(--color-text-inverse)',
    fontWeight: 600,
    fontSize: '12px',
    textTransform: 'uppercase',
    letterSpacing: '0.05em',
    whiteSpace: 'nowrap',
  };

  return (
    <div style={{ backgroundColor: 'var(--color-surface)' }}>
      <div className="w-full px-8 py-6">
        {/* Title bar */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
              Extracted Data Review
            </h2>
            <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
              Review, edit and confirm the extracted data.
              {clientRef && (
                <span className="ml-3 px-2 py-0.5 rounded text-xs font-semibold"
                  style={{ backgroundColor: 'var(--color-primary-light)', color: 'var(--color-primary)' }}>
                  {clientRef}
                </span>
              )}
            </p>
          </div>
          {!extracting && !extractError && (
            <div className="flex items-center gap-4">
              <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                Currency: <strong style={{ color: 'var(--color-text-primary)' }}>{outputCurrency}</strong>
              </span>
              <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                Fields: <strong style={{ color: 'var(--color-primary)' }}>{totalFields}</strong>
              </span>
            </div>
          )}
        </div>

        {/* Extraction in progress */}
        {extracting && !extractError && (
          <div className="flex flex-col items-center gap-4 py-20">
            <Spinner className="h-12 w-12" />
            <h3 className="text-xl font-semibold" style={{ color: 'var(--color-text-primary)' }}>
              Analysing your documents...
            </h3>
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>{statusMessage}</p>
            <div className="w-80 rounded-full h-2.5 overflow-hidden" style={{ border: '1px solid var(--color-border)' }}>
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${progress}%`, backgroundColor: 'var(--color-primary)' }} />
            </div>
            <span className="text-sm font-medium" style={{ color: 'var(--color-primary)' }}>{progress}%</span>
          </div>
        )}

        {/* Error */}
        {extractError && (
          <Alert variant="error" className="mt-4">
            <div>
              {extractError}
              <div className="mt-3">
                <Button variant="secondary" onClick={() => navigate('/intake')}>Go Back</Button>
              </div>
            </div>
          </Alert>
        )}

        {/* Extraction results — Pure Excel-like tables */}
        {!extracting && !extractError && (
          <div className="space-y-8">
            {/* Batch source selector */}
            {uploadedFiles.length > 1 && (
              <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                <span className="font-medium">Apply source to all rows:</span>
                <select
                  defaultValue=""
                  onChange={(e) => { if (e.target.value) handleBatchSource(e.target.value); }}
                  aria-label="Batch source document"
                  className="px-2 py-1.5 text-sm rounded-lg"
                  style={{ border: '1px solid var(--color-border-strong)', outline: 'none' }}
                >
                  <option value="">Select file...</option>
                  {uploadedFiles.map((f) => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>
            )}

            {filteredCategories.map((cat) => {
              const columnKeys = Array.from(new Set(cat.fields.map((f) => f.display_label || f.key)));

              // Group into rows by source
              const rowGroups = new Map<string, ExtractedField[]>();
              for (const field of cat.fields) {
                const rowKey = `${field.source_file || ''}:${field.source_page || 0}`;
                if (!rowGroups.has(rowKey)) rowGroups.set(rowKey, []);
                rowGroups.get(rowKey)!.push(field);
              }
              const rows = Array.from(rowGroups.values());
              const dataRows = rows.length > 1 ? rows : [cat.fields];

              return (
                <div key={cat.category_name}>
                  <h3 className="text-base font-bold mb-3 pl-3"
                    style={{ color: 'var(--color-text-primary)', borderLeft: '4px solid var(--color-primary)' }}>
                    {cat.category_name}
                  </h3>
                  <div className="overflow-x-auto rounded-lg" style={{ border: '1px solid var(--color-border)' }}>
                    <table className="w-full text-sm" style={{ borderCollapse: 'collapse' }}>
                      <thead>
                        <tr>
                          <th style={{ ...headerCellStyle, width: '40px' }}>#</th>
                          {columnKeys.map((col) => (
                            <th key={col} style={headerCellStyle}>{col}</th>
                          ))}
                          <th style={{ ...headerCellStyle, width: '160px' }}>Source Document</th>
                        </tr>
                      </thead>
                      <tbody>
                        {dataRows.map((rowFields, rowIdx) => {
                          const fieldByCol = new Map<string, ExtractedField>();
                          for (const f of rowFields) fieldByCol.set(f.display_label || f.key, f);
                          const firstField = rowFields[0];

                          return (
                            <tr key={rowIdx}
                              className={rowIdx % 2 === 0 ? 'verify-row-even' : 'verify-row-odd'}
                            >
                              <td style={{ ...cellStyle, textAlign: 'center', fontWeight: 600, color: 'var(--color-text-tertiary)' }}>
                                {rowIdx + 1}
                              </td>
                              {columnKeys.map((col) => {
                                const field = fieldByCol.get(col);
                                if (!field) {
                                  return <td key={col} style={{ ...cellStyle, color: 'var(--color-text-tertiary)' }}>—</td>;
                                }
                                return (
                                  <td key={col} style={cellStyle}>
                                    <input
                                      type="text"
                                      value={getFieldValue(field)}
                                      onChange={(e) => handleFieldEdit(field.id, e.target.value)}
                                      aria-label={col}
                                      className={`w-full px-2 py-1 text-sm verify-cell-input ${field.confidence < 0.8 ? 'verify-cell-low-confidence' : ''}`}
                                    />
                                  </td>
                                );
                              })}
                              <td style={cellStyle}>
                                <select
                                  value={firstField ? getFieldSource(firstField) : ''}
                                  onChange={(e) => { for (const f of rowFields) handleSourceEdit(f.id, e.target.value); }}
                                  aria-label="Source Document"
                                  className="w-full px-1 py-1 text-xs"
                                  style={{
                                    border: '1px solid var(--color-border)',
                                    borderRadius: '4px',
                                    outline: 'none',
                                    backgroundColor: 'transparent',
                                  }}
                                >
                                  <option value="">Select...</option>
                                  {uploadedFiles.map((f) => (
                                    <option key={f} value={f}>{f}</option>
                                  ))}
                                </select>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}

            {/* Actions */}
            <div className="flex justify-between pt-4 pb-8">
              <Button variant="secondary" onClick={() => navigate('/intake')}>Back</Button>
              <Button onClick={handleSubmit} loading={submitting}>Confirm & Generate Report</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
