/**
 * Report page — generates SOW and allows download.
 *
 * 1. On mount, triggers POST /api/v1/generate (SSE stream) with verified fields
 * 2. Streams the generated report content in real-time
 * 3. On completion, enables PDF/DOCX download via POST /api/v1/export/{format}
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { apiClient } from '../api/client';
import { apiActions } from '../config/apiActions';
import { Button } from '../components/Button';
import { Spinner } from '../components/Spinner';
import { Alert } from '../components/Alert';
import { env } from '../config/env';

const ALLOWED_TAGS = new Set(['h2', 'h3', 'h4', 'p', 'div', 'span', 'strong', 'em', 'br', 'ul', 'ol', 'li', 'table', 'thead', 'tbody', 'tr', 'th', 'td']);

function sanitizeHtml(html: string): string {
  return html.replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/g, (match, tag) => {
    if (ALLOWED_TAGS.has(tag.toLowerCase())) return match;
    return '';
  }).replace(/on\w+\s*=\s*["'][^"']*["']/gi, '');
}

interface VerifiedField {
  id: string;
  key: string;
  value: string;
  category: string;
}

interface LocationState {
  sessionId: string;
  extractionId: string;
  verifiedFields: VerifiedField[];
  profileType: string;
  clientRef: string;
  categories: Array<{ category_name: string; fields: unknown[] }>;
}

export function Report() {
  const navigate = useNavigate();
  const location = useLocation();
  const locState = location.state as LocationState | null;

  const [sowText, setSowText] = useState('');
  const [generating, setGenerating] = useState(true);
  const [generationId, setGenerationId] = useState('');
  const [totalWords, setTotalWords] = useState(0);
  const [currentSection, setCurrentSection] = useState('');
  const [genError, setGenError] = useState('');
  const [downloading, setDownloading] = useState<string | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const sessionId = locState?.sessionId || '';
  const extractionId = locState?.extractionId || '';
  const verifiedFields = locState?.verifiedFields || [];

  useEffect(() => {
    if (!sessionId || !extractionId) {
      navigate('/intake', { replace: true });
      return;
    }

    const abort = new AbortController();

    async function startGeneration() {
      try {
        const response = await fetch(
          `${env.apiBaseUrl}${apiActions.generate.path}`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Session-Token': localStorage.getItem('sow_session_token') || '',
            },
            body: JSON.stringify({
              session_id: sessionId,
              extraction_id: extractionId,
              verified_fields: verifiedFields,
            }),
            signal: abort.signal,
          },
        );

        if (!response.ok || !response.body) {
          throw new Error('Generation request failed');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (!line.startsWith('data: ')) continue;
            try {
              const event = JSON.parse(line.slice(6));

              if (event.type === 'token') {
                setSowText((prev) => prev + event.text);
              } else if (event.type === 'html_token') {
                setSowText((prev) => prev + event.text);
              } else if (event.type === 'section_start') {
                setCurrentSection(event.section || '');
              } else if (event.type === 'complete') {
                setGenerationId(event.generation_id || '');
                setTotalWords(event.total_words || 0);
                setGenerating(false);
              } else if (event.type === 'error') {
                setGenError(event.message || 'Generation failed');
                setGenerating(false);
              }
            } catch {
              // skip
            }
          }
        }

        setGenerating(false);
      } catch (err: unknown) {
        if ((err as Error).name !== 'AbortError') {
          setGenError('Generation failed. Please try again.');
          setGenerating(false);
        }
      }
    }

    startGeneration();
    return () => abort.abort();
  }, [sessionId, extractionId, verifiedFields, navigate]);

  // Auto-scroll as content streams
  useEffect(() => {
    if (contentRef.current && generating) {
      contentRef.current.scrollTop = contentRef.current.scrollHeight;
    }
  }, [sowText, generating]);

  const handleDownload = useCallback(
    async (format: 'pdf' | 'docx') => {
      setDownloading(format);
      try {
        const fieldCount = verifiedFields.length;
        const docCount = locState?.categories?.length || 0;

        const response = await apiClient.post(
          apiActions.exportReport.pathFn(format),
          {
            session_id: sessionId,
            generation_id: generationId,
            client_name: locState?.clientRef || 'Client',
            profile_type: locState?.profileType || 'salaried',
            doc_count: docCount,
            field_count: fieldCount,
            word_count: totalWords,
            sow_text: sowText,
            report_ref: locState?.clientRef || undefined,
            client_ref: locState?.clientRef || undefined,
          },
          { responseType: 'blob' },
        );

        const blob = new Blob([response.data]);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const disposition = response.headers['content-disposition'] || '';
        const filenameMatch = disposition.match(/filename="?([^"]+)"?/);
        a.href = url;
        a.download = filenameMatch?.[1] || `SOW_Report.${format}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch {
        setGenError(`Failed to download ${format.toUpperCase()}. Please try again.`);
      } finally {
        setDownloading(null);
      }
    },
    [sessionId, generationId, sowText, totalWords, verifiedFields, locState],
  );

  const displayContent = sanitizeHtml(
    sowText
      .replace(/\[SECTION:\s*(.+?)\]/g, '<h2 class="text-lg font-bold mt-6 mb-2 pl-3" style="color:var(--color-text-primary);border-left:3px solid var(--color-primary)">$1</h2>')
      .replace(/\[\/SECTION\]/g, '')
      .replace(/\[NARRATIVE\]/g, '<div class="text-sm leading-relaxed mb-3" style="color:var(--color-text-secondary)">')
      .replace(/\[\/NARRATIVE\]/g, '</div>')
      .replace(/\[TABLE\][\s\S]*?\[\/TABLE\]/g, '<div class="text-xs italic my-2" style="color:var(--color-text-tertiary)">[Table data — visible in PDF/DOCX export]</div>')
      .replace(/^## (.+)$/gm, '<h2 class="text-lg font-bold mt-6 mb-2 pl-3" style="color:var(--color-text-primary);border-left:3px solid var(--color-primary)">$1</h2>')
      .replace(/^### (.+)$/gm, '<h3 class="text-base font-semibold mt-4 mb-1" style="color:var(--color-text-primary)">$1</h3>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>'),
  );

  return (
    <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
      <div className="w-full px-8 py-6">
        <div className="flex gap-6">
          {/* Main content */}
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
              {generating ? 'Generating Report' : 'Report Ready'}
            </h2>
            <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
              {generating
                ? 'Your report is being drafted from verified data points.'
                : 'Review your report below. Download a copy for your records.'}
            </p>

            {genError && (
              <Alert variant="error" className="mt-4">{genError}</Alert>
            )}

            {/* Report content */}
            <div className="mt-6 rounded-xl overflow-hidden"
              style={{
                border: '1px solid var(--color-border)',
                boxShadow: 'var(--shadow-md)',
              }}>
              {/* Report header */}
              <div className="p-6" style={{ backgroundColor: 'var(--color-primary)' }}>
                <h3 className="text-base font-bold text-white">SOWA</h3>
                <p className="text-xs font-semibold uppercase tracking-wider mt-1"
                  style={{ color: 'rgba(255,255,255,0.7)' }}>
                  SOURCE OF WEALTH REPORT
                </p>
                <p className="text-[10px] font-bold uppercase tracking-wider mt-1"
                  style={{ color: 'rgba(255,255,255,0.5)' }}>
                  PRIVATE & CONFIDENTIAL
                </p>
              </div>

              {/* Streaming content */}
              <div
                ref={contentRef}
                className="p-6 max-h-[60vh] overflow-y-auto prose prose-sm max-w-none"
                style={{ backgroundColor: 'var(--color-surface)' }}
              >
                {sowText ? (
                  <div dangerouslySetInnerHTML={{ __html: displayContent }} />
                ) : generating ? (
                  <div className="flex items-center gap-3 py-8 justify-center">
                    <Spinner />
                    <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
                      {currentSection || 'Starting generation...'}
                    </span>
                  </div>
                ) : null}

                {generating && sowText && (
                  <span className="inline-block w-0.5 h-4 animate-pulse ml-1"
                    style={{ backgroundColor: 'var(--color-primary)' }} />
                )}
              </div>

              {/* Footer */}
              {!generating && (
                <div className="px-6 py-3 flex items-center justify-between"
                  style={{
                    borderTop: '1px solid var(--color-border)',
                    backgroundColor: 'var(--color-surface-secondary)',
                  }}>
                  <span className="text-xs" style={{ color: 'var(--color-text-tertiary)' }}>
                    {totalWords > 0 ? `${totalWords} words` : `${sowText.split(/\s+/).length} words`}
                  </span>
                  <span className="text-xs font-medium" style={{ color: 'var(--color-success)' }}>
                    Generation complete
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <aside className="w-72 flex-shrink-0 space-y-4 hidden lg:block">
            {!generating && (
              <>
                <div className="rounded-xl p-5"
                  style={{
                    border: '1px solid var(--color-border)',
                    backgroundColor: 'var(--color-surface)',
                    boxShadow: 'var(--shadow-sm)',
                  }}>
                  <h4 className="text-sm font-semibold mb-3"
                    style={{ color: 'var(--color-text-primary)' }}>
                    Download Report
                  </h4>
                  <div className="space-y-2">
                    <Button
                      className="w-full"
                      onClick={() => handleDownload('pdf')}
                      loading={downloading === 'pdf'}
                      disabled={!!downloading}
                    >
                      Download as PDF
                    </Button>
                    <Button
                      variant="secondary"
                      className="w-full"
                      onClick={() => handleDownload('docx')}
                      loading={downloading === 'docx'}
                      disabled={!!downloading}
                    >
                      Download as Word
                    </Button>
                  </div>
                  <p className="text-[10px] mt-3"
                    style={{ color: 'var(--color-text-tertiary)' }}>
                    Files are watermarked with your session reference.
                  </p>
                </div>

                <div className="rounded-xl p-5"
                  style={{
                    border: '1px solid var(--color-border)',
                    backgroundColor: 'var(--color-surface)',
                    boxShadow: 'var(--shadow-sm)',
                  }}>
                  <h4 className="text-sm font-semibold mb-3"
                    style={{ color: 'var(--color-text-primary)' }}>
                    Report Details
                  </h4>
                  <dl className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <dt style={{ color: 'var(--color-text-secondary)' }}>Reference</dt>
                      <dd className="font-medium" style={{ color: 'var(--color-text-primary)' }}>
                        {locState?.clientRef || sessionId.slice(0, 8)}
                      </dd>
                    </div>
                    <div className="flex justify-between">
                      <dt style={{ color: 'var(--color-text-secondary)' }}>Profile</dt>
                      <dd className="font-medium capitalize" style={{ color: 'var(--color-text-primary)' }}>
                        {locState?.profileType}
                      </dd>
                    </div>
                    <div className="flex justify-between">
                      <dt style={{ color: 'var(--color-text-secondary)' }}>Data Points</dt>
                      <dd className="font-medium" style={{ color: 'var(--color-text-primary)' }}>
                        {verifiedFields.length}
                      </dd>
                    </div>
                  </dl>
                </div>
              </>
            )}

            <div className="pt-2 space-y-2">
              <Button
                variant="secondary"
                className="w-full"
                onClick={() => navigate(-1)}
              >
                Back to Review
              </Button>
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => navigate('/intake')}
              >
                Start New Assessment
              </Button>
            </div>
          </aside>
        </div>

        {/* Mobile download buttons */}
        {!generating && (
          <div className="lg:hidden mt-6 flex gap-3">
            <Button
              className="flex-1"
              onClick={() => handleDownload('pdf')}
              loading={downloading === 'pdf'}
              disabled={!!downloading}
            >
              Download PDF
            </Button>
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => handleDownload('docx')}
              loading={downloading === 'docx'}
              disabled={!!downloading}
            >
              Download Word
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
