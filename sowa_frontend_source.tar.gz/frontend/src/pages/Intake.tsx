/**
 * Intake page — tabbed workspace for driver-based upload & input.
 *
 * Redesigned as a single-page tabbed layout:
 * - "Client Info" tab is always present
 * - Users toggle driver tabs on/off from a sidebar
 * - Each tab has its own file upload zone + input fields
 * - Tab state persists across switches
 * - Completion badges on each tab
 * - Summary/review panel before extraction
 * - Client Reference is auto-generated server-side (never entered)
 */

import { useState, useCallback, useMemo, useEffect } from 'react';
import { useNavigate, useBlocker } from 'react-router-dom';
import { useFormsSchema } from '../api/schema';
import { apiClient } from '../api/client';
import { apiActions } from '../config/apiActions';
import { SchemaForm } from '../forms/SchemaForm';
import { Section } from '../components/Section';
import { Button } from '../components/Button';
import { Alert } from '../components/Alert';

type TabStatus = 'empty' | 'in-progress' | 'complete';

export function Intake() {
  const navigate = useNavigate();
  const { data: formsSchema, isLoading, error: schemaError } = useFormsSchema();

  const [activeTab, setActiveTab] = useState<string>('client_info');
  const [selectedDrivers, setSelectedDrivers] = useState<string[]>([]);
  const [clientInfoValues, setClientInfoValues] = useState<Record<string, unknown>>({});
  const [driverDataValues, setDriverDataValues] = useState<Record<string, Record<string, unknown>>>({});
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, File[]>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [showReview, setShowReview] = useState(false);
  const [profileType] = useState<'salaried' | 'business'>('salaried');

  // Unsaved changes guard
  const hasUnsavedWork = selectedDrivers.length > 0 || Object.keys(uploadedFiles).length > 0
    || Object.values(clientInfoValues).some((v) => v !== '' && v != null);

  useEffect(() => {
    if (!hasUnsavedWork) return;
    const handler = (e: BeforeUnloadEvent) => { e.preventDefault(); };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [hasUnsavedWork]);

  useBlocker(({ currentLocation, nextLocation }) =>
    hasUnsavedWork && !submitting && currentLocation.pathname !== nextLocation.pathname,
  );

  const driverEntries = useMemo(() => {
    if (!formsSchema?.drivers) return [];
    return Object.entries(formsSchema.drivers);
  }, [formsSchema]);

  // Compute tab completion status
  const getTabStatus = useCallback((driverKey: string): TabStatus => {
    if (driverKey === 'client_info') {
      const filled = Object.values(clientInfoValues).filter((v) => v !== '' && v !== null && v !== undefined).length;
      if (filled === 0) return 'empty';
      const total = formsSchema?.client_info_schema?.properties
        ? Object.keys(formsSchema.client_info_schema.properties).length
        : 1;
      return filled >= total * 0.6 ? 'complete' : 'in-progress';
    }
    const data = driverDataValues[driverKey] || {};
    const fileKeys = Object.keys(uploadedFiles).filter((k) => k.startsWith(ceModelKey(driverKey)));
    const hasData = Object.values(data).some((v) => v !== '' && v !== null && v !== undefined);
    const hasFiles = fileKeys.some((k) => uploadedFiles[k]?.length > 0);
    if (!hasData && !hasFiles) return 'empty';
    if (hasData && hasFiles) return 'complete';
    return 'in-progress';
  }, [clientInfoValues, driverDataValues, uploadedFiles, formsSchema]);

  const toggleDriver = useCallback((key: string) => {
    setSelectedDrivers((prev) => {
      const next = prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key];
      // If deselecting the active tab, switch to client_info
      if (!next.includes(key) && activeTab === key) {
        setActiveTab('client_info');
      }
      // If selecting, switch to it
      if (!prev.includes(key)) {
        setActiveTab(key);
      }
      return next;
    });
  }, [activeTab]);

  const handleClientInfoChange = useCallback((field: string, value: unknown) => {
    setClientInfoValues((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleDriverDataChange = useCallback(
    (driverKey: string, field: string, value: unknown) => {
      setDriverDataValues((prev) => ({
        ...prev,
        [driverKey]: { ...prev[driverKey], [field]: value },
      }));
    },
    [],
  );

  const handleFilesChange = useCallback((fieldPath: string, files: File[]) => {
    setUploadedFiles((prev) => ({ ...prev, [fieldPath]: files }));
  }, []);

  const totalFileCount = useMemo(
    () => Object.values(uploadedFiles).reduce((sum, files) => sum + files.length, 0),
    [uploadedFiles],
  );

  const handleSubmit = useCallback(async () => {
    const allFiles = Object.values(uploadedFiles).flat();
    if (allFiles.length === 0) {
      setSubmitError('Please upload at least one document.');
      return;
    }

    setSubmitting(true);
    setSubmitError('');

    try {
      const formData = new FormData();
      formData.append('profile_type', profileType);

      const fileMeta: Array<Record<string, string>> = [];
      for (const [fieldPath, files] of Object.entries(uploadedFiles)) {
        const parts = fieldPath.split('.');
        const ceClass = parts[0] || 'other';
        const ceField = parts[1] || 'other';
        for (const file of files) {
          fileMeta.push({
            filename: file.name,
            category_id: ceField,
            ce_class: ceClass,
            profile: profileType,
          });
          formData.append('files', file);
        }
      }
      formData.append('file_metadata', JSON.stringify(fileMeta));
      formData.append('selected_drivers', JSON.stringify(selectedDrivers));
      formData.append('client_info_values', JSON.stringify(clientInfoValues));
      formData.append('driver_data_values', JSON.stringify(driverDataValues));

      const uploadRes = await apiClient.post(apiActions.upload.path, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const { session_id, client_ref } = uploadRes.data;

      navigate('/verify', {
        state: {
          sessionId: session_id,
          clientRef: client_ref,
          selectedDrivers,
          clientInfoValues,
          driverDataValues,
          profileType,
        },
      });
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { detail?: string } } })?.response?.data
          ?.detail || 'Upload failed. Please try again.';
      setSubmitError(msg);
    } finally {
      setSubmitting(false);
    }
  }, [uploadedFiles, selectedDrivers, clientInfoValues, driverDataValues, profileType, navigate]);

  if (isLoading) {
    return (
      <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
        <div className="flex" style={{ minHeight: 'calc(100vh - 100px)' }}>
          {/* Skeleton sidebar */}
          <aside className="w-72 flex-shrink-0 border-r p-4 space-y-3"
            style={{ backgroundColor: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
            <div className="skeleton h-3 w-16 rounded" />
            <div className="skeleton h-10 w-full rounded-lg" />
            <div className="skeleton h-3 w-24 rounded mt-4" />
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="skeleton h-9 w-full rounded-lg" />
            ))}
          </aside>
          {/* Skeleton content */}
          <main className="flex-1 px-8 py-6 space-y-6">
            <div className="skeleton h-6 w-48 rounded" />
            <div className="skeleton h-4 w-80 rounded" />
            <div className="rounded-xl p-8 space-y-4" style={{ border: '1px solid var(--color-border)' }}>
              <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-2">
                    <div className="skeleton h-3 w-24 rounded" />
                    <div className="skeleton h-10 w-full rounded-lg" />
                  </div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  if (schemaError || !formsSchema) {
    return (
      <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
        <div className="max-w-2xl mx-auto py-12 px-6">
          <Alert variant="error">
            Failed to load form schema. Please ensure the backend is running.
          </Alert>
        </div>
      </div>
    );
  }

  const activeCfg = activeTab !== 'client_info' ? formsSchema.drivers[activeTab] : null;

  // Review panel
  if (showReview) {
    return (
      <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
        <div className="max-w-4xl mx-auto py-8 px-6 space-y-6">
          <div>
            <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
              Review Before Extraction
            </h2>
            <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
              Verify your selections and uploaded documents before starting extraction.
            </p>
          </div>

          <Section title="Client Information">
            <div className="grid gap-2 sm:grid-cols-2 text-sm">
              {Object.entries(clientInfoValues).filter(([, v]) => v).map(([k, v]) => (
                <div key={k} className="flex justify-between py-1"
                  style={{ borderBottom: '1px solid var(--color-border)' }}>
                  <span style={{ color: 'var(--color-text-secondary)' }}>
                    {k.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
                  </span>
                  <span className="font-medium" style={{ color: 'var(--color-text-primary)' }}>
                    {String(v)}
                  </span>
                </div>
              ))}
            </div>
          </Section>

          <Section title="Active Wealth Sources">
            <div className="space-y-3">
              {selectedDrivers.map((dk) => {
                const cfg = formsSchema.drivers[dk];
                const status = getTabStatus(dk);
                const fileCount = Object.keys(uploadedFiles)
                  .filter((k) => k.startsWith(ceModelKey(dk)))
                  .reduce((s, k) => s + (uploadedFiles[k]?.length || 0), 0);
                return (
                  <div key={dk} className="flex items-center justify-between py-2 px-3 rounded-lg"
                    style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
                    <div>
                      <span className="text-sm font-medium" style={{ color: 'var(--color-text-primary)' }}>
                        {cfg?.label}
                      </span>
                      <span className="ml-2 text-xs" style={{ color: 'var(--color-text-tertiary)' }}>
                        {fileCount} file(s)
                      </span>
                    </div>
                    <StatusBadge status={status} />
                  </div>
                );
              })}
            </div>
          </Section>

          <div className="flex items-center justify-between rounded-lg p-4"
            style={{ backgroundColor: 'var(--color-primary-light)', border: '1px solid var(--color-primary-200)' }}>
            <div className="text-sm">
              <span className="font-semibold" style={{ color: 'var(--color-primary)' }}>
                {totalFileCount}
              </span>
              <span className="ml-1" style={{ color: 'var(--color-primary-700)' }}>file(s) ready</span>
              <span className="mx-2" style={{ color: 'var(--color-primary-200)' }}>|</span>
              <span className="font-semibold" style={{ color: 'var(--color-primary)' }}>
                {selectedDrivers.length}
              </span>
              <span className="ml-1" style={{ color: 'var(--color-primary-700)' }}>wealth source(s)</span>
            </div>
          </div>

          {submitError && (
            <Alert variant="error">{submitError}</Alert>
          )}

          <div className="flex justify-between pt-4">
            <Button variant="secondary" onClick={() => setShowReview(false)}>
              Back to Editor
            </Button>
            <Button onClick={handleSubmit} loading={submitting} disabled={selectedDrivers.length === 0}>
              Submit for Extraction
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ backgroundColor: 'var(--color-surface-secondary)' }}>
      <div className="flex" style={{ minHeight: 'calc(100vh - 100px)' }}>
        {/* ── Left Sidebar: Driver selector ── */}
        <aside className="w-72 flex-shrink-0 border-r overflow-y-auto"
          style={{
            backgroundColor: 'var(--color-surface)',
            borderColor: 'var(--color-border)',
          }}>
          <div className="p-4">
            {/* Client Info tab — always present */}
            <h3 className="text-xs font-semibold uppercase tracking-wider mb-2"
              style={{ color: 'var(--color-text-tertiary)' }}>
              General
            </h3>
            <button
              type="button"
              onClick={() => setActiveTab('client_info')}
              className="w-full flex items-center justify-between rounded-lg px-3 py-2.5 text-sm text-left mb-4 transition-colors"
              style={{
                backgroundColor: activeTab === 'client_info' ? 'var(--color-primary-light)' : 'transparent',
                color: activeTab === 'client_info' ? 'var(--color-primary)' : 'var(--color-text-primary)',
                fontWeight: activeTab === 'client_info' ? 600 : 400,
                borderLeft: activeTab === 'client_info' ? '3px solid var(--color-primary)' : '3px solid transparent',
              }}
            >
              <span>Client Information</span>
              <StatusBadge status={getTabStatus('client_info')} small />
            </button>

            {/* Driver tabs */}
            <h3 className="text-xs font-semibold uppercase tracking-wider mb-2"
              style={{ color: 'var(--color-text-tertiary)' }}>
              Wealth Sources
            </h3>
            <div className="space-y-1">
              {driverEntries.map(([key, cfg]) => {
                const isSelected = selectedDrivers.includes(key);
                const isActive = activeTab === key;
                return (
                  <div key={key} className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => toggleDriver(key)}
                      className="flex-shrink-0 w-5 h-5 rounded flex items-center justify-center transition-colors"
                      style={{
                        border: isSelected ? 'none' : '2px solid var(--color-border-strong)',
                        backgroundColor: isSelected ? 'var(--color-primary)' : 'transparent',
                      }}
                    >
                      {isSelected && (
                        <svg viewBox="0 0 12 12" className="w-3 h-3 text-white" fill="none" stroke="currentColor" strokeWidth="2">
                          <polyline points="2,6 5,9 10,3" />
                        </svg>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!isSelected) toggleDriver(key);
                        setActiveTab(key);
                      }}
                      className="flex-1 flex items-center justify-between rounded-lg px-2 py-2 text-sm text-left transition-colors"
                      style={{
                        backgroundColor: isActive ? 'var(--color-primary-light)' : 'transparent',
                        color: isActive ? 'var(--color-primary)' : isSelected ? 'var(--color-text-primary)' : 'var(--color-text-secondary)',
                        fontWeight: isActive ? 600 : 400,
                      }}
                    >
                      <span className="truncate">{cfg.label}</span>
                      {isSelected && <StatusBadge status={getTabStatus(key)} small />}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom summary — sticky */}
          <div className="p-4 border-t sticky bottom-0" style={{ borderColor: 'var(--color-border)', backgroundColor: 'var(--color-surface)' }}>
            <div className="text-xs space-y-1" style={{ color: 'var(--color-text-secondary)' }}>
              <div className="flex justify-between">
                <span>Sources active</span>
                <span className="font-semibold">{selectedDrivers.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Files uploaded</span>
                <span className="font-semibold">{totalFileCount}</span>
              </div>
            </div>
            <Button
              className="w-full mt-3"
              onClick={() => setShowReview(true)}
              disabled={selectedDrivers.length === 0}
            >
              Review & Submit
            </Button>
          </div>
        </aside>

        {/* ── Main content area ── */}
        <main className="flex-1 overflow-y-auto px-8 py-6">
          {/* Client Info tab */}
          {activeTab === 'client_info' && formsSchema.client_info_schema && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
                  Client Information
                </h2>
                <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
                  Enter the client's personal profile details. Client reference will be auto-generated.
                </p>
              </div>
              <Section title="Personal Details">
                <SchemaForm
                  schema={formsSchema.client_info_schema}
                  schemaKey="ClientInfo"
                  values={clientInfoValues}
                  onChange={(field, val) => handleClientInfoChange(field, val)}
                />
              </Section>
            </div>
          )}

          {/* Driver tabs */}
          {activeTab !== 'client_info' && activeCfg && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
                  {activeCfg.label}
                </h2>
                <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
                  {activeCfg.description}
                </p>
              </div>

              {/* Data entry fields — collapsible */}
              {activeCfg.data_schema && (
                <Section title="Details" collapsible defaultOpen={true}
                  description="Fill in the required information for this wealth source">
                  <SchemaForm
                    schema={activeCfg.data_schema}
                    schemaKey={`data_${activeTab}`}
                    values={driverDataValues[activeTab] || {}}
                    onChange={(field, val) => handleDriverDataChange(activeTab, field, val)}
                  />
                </Section>
              )}

              {/* CE file upload fields — collapsible */}
              {activeCfg.ce_schema && (
                <Section title="Supporting Documents" collapsible defaultOpen={true}
                  description="Upload evidence documents for verification">
                  <SchemaForm
                    schema={activeCfg.ce_schema}
                    schemaKey={ceModelKey(activeTab)}
                    values={{}}
                    onChange={() => {}}
                    files={uploadedFiles}
                    onFilesChange={handleFilesChange}
                  />
                </Section>
              )}
            </div>
          )}

          {/* Empty state when no tab is active */}
          {activeTab !== 'client_info' && !activeCfg && (
            <div className="flex flex-col items-center justify-center py-24"
              style={{ color: 'var(--color-text-tertiary)' }}>
              <svg viewBox="0 0 24 24" className="w-16 h-16 mb-4" fill="none" stroke="currentColor" strokeWidth="1">
                <path d="M9 12h6M12 9v6M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z" />
              </svg>
              <p className="text-lg font-medium">Select a wealth source</p>
              <p className="text-sm mt-1">Choose from the sidebar to begin entering data</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

/** Status badge component */
function StatusBadge({ status, small }: { status: TabStatus; small?: boolean }) {
  const config = {
    empty: { bg: 'var(--color-surface-secondary)', color: 'var(--color-text-tertiary)', label: '' },
    'in-progress': { bg: 'var(--color-warning-light)', color: 'var(--color-warning)', label: '' },
    complete: { bg: 'var(--color-success-light)', color: 'var(--color-success)', label: '' },
  };
  const c = config[status];

  if (status === 'empty') return null;

  const size = small ? 'w-2 h-2' : 'w-2.5 h-2.5';

  return (
    <span
      className={`${size} rounded-full inline-block flex-shrink-0`}
      style={{ backgroundColor: c.color }}
      title={status === 'in-progress' ? 'In Progress' : 'Complete'}
    />
  );
}

/** Map driver key to CE model class name */
function ceModelKey(driverKey: string): string {
  const map: Record<string, string> = {
    client_employment_history: 'CE_SalariedEmployee',
    client_company_history: 'CE_CompanyHoldings',
    property_sale: 'CE_Property',
    dividend: 'CE_Dividend',
    financial_investment: 'CE_Investment',
    client_inheritance: 'CE_Inheritance',
    client_gift: 'CE_Gift',
    sur_case: 'CE_SUR',
  };
  return map[driverKey] || `CE_${driverKey}`;
}
