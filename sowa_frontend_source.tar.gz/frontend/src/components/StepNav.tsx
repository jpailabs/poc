const STEPS = [
  { num: 1, label: 'Upload & Input' },
  { num: 2, label: 'Review Extraction' },
  { num: 3, label: 'Generate SOW' },
  { num: 4, label: 'Download Report' },
];

interface StepNavProps {
  current: number;
}

export function StepNav({ current }: StepNavProps) {
  return (
    <nav className="flex items-center justify-center gap-1 py-3"
      style={{ backgroundColor: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)' }}>
      {STEPS.map((step, i) => {
        const isCompleted = step.num < current;
        const isActive = step.num === current;
        return (
          <div key={step.num} className="flex items-center">
            {i > 0 && (
              <div
                className="w-12 h-0.5 mx-1"
                style={{
                  backgroundColor: isCompleted ? 'var(--color-primary)' : 'var(--color-border)',
                }}
              />
            )}
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium"
                style={{
                  backgroundColor: isCompleted
                    ? 'var(--color-primary)'
                    : isActive
                      ? 'var(--color-primary-700)'
                      : 'var(--color-surface-secondary)',
                  color: isCompleted || isActive
                    ? 'var(--color-text-inverse)'
                    : 'var(--color-text-tertiary)',
                  boxShadow: isActive ? 'var(--ring-primary)' : 'none',
                }}
              >
                {isCompleted ? (
                  <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="2,8 6,12 14,4" />
                  </svg>
                ) : (
                  step.num
                )}
              </div>
              <span
                className="text-xs font-medium hidden sm:inline"
                style={{
                  color: isActive
                    ? 'var(--color-text-primary)'
                    : 'var(--color-text-tertiary)',
                }}
              >
                {step.label}
              </span>
            </div>
          </div>
        );
      })}
    </nav>
  );
}
