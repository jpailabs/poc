import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Button } from './Button';

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="flex items-center justify-between px-8 py-3"
      style={{
        backgroundColor: 'var(--color-surface)',
        borderBottom: '2px solid var(--color-primary)',
      }}>
      <button
        type="button"
        onClick={() => navigate('/intake')}
        className="flex items-center gap-2 hover:opacity-80 transition-opacity"
      >
        <span className="text-lg font-bold" style={{ color: 'var(--color-primary)' }}>
          SOWA
        </span>
        <span className="text-xs font-semibold uppercase tracking-wider"
          style={{ color: 'var(--color-text-secondary)' }}>
          Source of Wealth Assistant
        </span>
      </button>
      {user && (
        <div className="flex items-center gap-3">
          <div className="text-right mr-2">
            <div className="text-sm font-semibold" style={{ color: 'var(--color-text-primary)' }}>{user.display_name}</div>
            <div className="text-xs capitalize" style={{ color: 'var(--color-text-secondary)' }}>{user.role}</div>
          </div>
          <Button variant="ghost" onClick={() => navigate('/settings')}>
            <svg viewBox="0 0 20 20" className="w-4 h-4" fill="currentColor">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
          </Button>
          <Button variant="ghost" onClick={logout}>
            Sign Out
          </Button>
        </div>
      )}
    </header>
  );
}
