import type { ReactNode } from 'react';

interface AlertProps {
  variant: 'error' | 'success' | 'warning' | 'info';
  children: ReactNode;
  className?: string;
}

const VARIANT_STYLES = {
  error: {
    bg: 'var(--color-error-light)',
    border: 'var(--color-error-border)',
    color: 'var(--color-error-dark)',
    icon: 'M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z',
  },
  success: {
    bg: 'var(--color-success-light)',
    border: 'var(--color-success-border)',
    color: 'var(--color-success-dark)',
    icon: 'M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z',
  },
  warning: {
    bg: 'var(--color-warning-light)',
    border: 'var(--color-warning-border)',
    color: 'var(--color-warning-dark)',
    icon: 'M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z',
  },
  info: {
    bg: 'var(--color-info-light)',
    border: 'var(--color-info)',
    color: 'var(--color-info)',
    icon: 'M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-5a1 1 0 10-2 0 1 1 0 002 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z',
  },
} as const;

export function Alert({ variant, children, className = '' }: AlertProps) {
  const s = VARIANT_STYLES[variant];
  return (
    <div
      className={`rounded-lg p-3 text-sm flex items-start gap-2 ${className}`}
      style={{
        backgroundColor: s.bg,
        border: `1px solid ${s.border}`,
        color: s.color,
      }}
      role="alert"
    >
      <svg viewBox="0 0 20 20" className="w-4 h-4 flex-shrink-0 mt-0.5" fill="currentColor">
        <path fillRule="evenodd" d={s.icon} clipRule="evenodd" />
      </svg>
      <div>{children}</div>
    </div>
  );
}
