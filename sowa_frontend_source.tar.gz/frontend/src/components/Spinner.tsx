export function Spinner({ className = '' }: { className?: string }) {
  return (
    <div
      className={`animate-spin h-6 w-6 rounded-full ${className}`}
      style={{
        borderWidth: '3px',
        borderStyle: 'solid',
        borderColor: 'var(--color-primary)',
        borderTopColor: 'transparent',
      }}
    />
  );
}
