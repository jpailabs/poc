import { useState, type ReactNode } from 'react';

interface SectionProps {
  title: string;
  description?: string;
  children: ReactNode;
  collapsible?: boolean;
  defaultOpen?: boolean;
}

export function Section({ title, description, children, collapsible = false, defaultOpen = true }: SectionProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="rounded-xl bg-white overflow-hidden"
      style={{
        border: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-sm)',
      }}>
      {/* Header — clickable when collapsible */}
      <div
        className={`px-8 py-5 flex items-center justify-between ${collapsible ? 'cursor-pointer select-none section-header-collapsible' : ''}`}
        style={{
          borderBottom: open ? '1px solid var(--color-border)' : 'none',
          backgroundColor: 'var(--color-surface)',
        }}
        onClick={() => collapsible && setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <h3 className="text-lg font-bold pl-3"
            style={{
              color: 'var(--color-text-primary)',
              borderLeft: '4px solid var(--color-primary)',
            }}>
            {title}
          </h3>
          {description && (
            <p className="text-sm hidden sm:block" style={{ color: 'var(--color-text-secondary)' }}>
              {description}
            </p>
          )}
        </div>
        {collapsible && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium"
              style={{ color: 'var(--color-primary)' }}>
              {open ? 'Collapse' : 'Expand'}
            </span>
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{
                backgroundColor: 'var(--color-primary-light)',
                transition: 'transform 0.2s ease',
                transform: open ? 'rotate(180deg)' : 'rotate(0deg)',
              }}
            >
              <svg viewBox="0 0 16 16" className="w-4 h-4" fill="none" stroke="var(--color-primary)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="4,6 8,10 12,6" />
              </svg>
            </div>
          </div>
        )}
      </div>

      {/* Content — animated collapse */}
      <div style={{
        maxHeight: open ? '5000px' : '0px',
        opacity: open ? 1 : 0,
        overflow: 'hidden',
        transition: 'max-height 0.35s ease, opacity 0.25s ease',
      }}>
        <div className="px-8 py-6">
          {children}
        </div>
      </div>
    </div>
  );
}
