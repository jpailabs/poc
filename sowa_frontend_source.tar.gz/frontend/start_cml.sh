#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# SOWA Frontend — CML Application Startup Script
#
# No Node.js required. Serves pre-built dist/ and proxies API to backend.
#
# Environment variables:
#   CDSW_APP_PORT  — CML sets this automatically
#   API_BASE_URL   — Backend service URL (default: http://localhost:8000)
# ═══════════════════════════════════════════════════════════════════════════════

set -e

cd "$(dirname "$0")"

# Install Python dependencies (only fastapi, uvicorn, httpx needed)
pip install fastapi uvicorn httpx --quiet 2>/dev/null

if [ ! -d "dist" ]; then
    echo "ERROR: dist/ not found."
    echo "Build on a machine with Node.js, then copy dist/ here."
    exit 1
fi

echo "Starting SOWA Frontend (Python-only, no Node.js required)"
exec python cml_app.py
