"""
SOWA Frontend — Static file server + API reverse proxy for Cloudera CML.

Serves the pre-built React app (dist/) and proxies /api, /auth, /schema
requests to the backend service. No Node.js required on the server.

Usage:
  python cml_app.py

Environment variables:
  CDSW_APP_PORT  — Port to serve on (CML sets this automatically, default 3000)
  API_BASE_URL   — Backend API URL (e.g., https://sowa-backend.ml-xxx.company.com)
"""

import logging
import os
import sys
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from starlette.middleware.cors import CORSMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("sowa-frontend")

# ── Config ───────────────────────────────────────────────────────────────────

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000").rstrip("/")
DIST_DIR = Path(__file__).resolve().parent / "dist"

app = FastAPI(title="SOWA Frontend", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

if not DIST_DIR.is_dir():
    print(
        "ERROR: dist/ directory not found.\n"
        "Build the frontend on a machine with Node.js:\n"
        "  cd frontend && npm install && npm run build\n"
        "Then copy the dist/ folder here.",
        file=sys.stderr,
    )
    sys.exit(1)


# ── Health check ─────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "service": "sowa-frontend", "api_backend": API_BASE_URL}


# ── API reverse proxy ────────────────────────────────────────────────────────

async def _proxy(request: Request) -> Response:
    """Forward request to backend API."""
    target_url = f"{API_BASE_URL}{request.url.path}"
    query = str(request.url.query)
    if query:
        target_url = f"{target_url}?{query}"

    # Only forward safe headers — strip CML-injected headers
    safe_headers = {}
    for key, value in request.headers.items():
        lower = key.lower()
        # Skip hop-by-hop and CML-specific headers
        if lower in (
            "host", "connection", "keep-alive", "transfer-encoding",
            "te", "trailer", "upgrade", "proxy-authorization",
            "proxy-connection",
        ):
            continue
        safe_headers[key] = value

    body = await request.body()

    logger.info("PROXY %s %s → %s (%d bytes)",
                request.method, request.url.path, target_url, len(body))

    try:
        async with httpx.AsyncClient(timeout=300.0, verify=False) as client:
            resp = await client.request(
                method=request.method,
                url=target_url,
                headers=safe_headers,
                content=body,
            )
    except httpx.ConnectError as e:
        logger.error("PROXY ERROR: Cannot reach backend at %s: %s", API_BASE_URL, e)
        return Response(
            content=f'{{"detail":"Backend not reachable at {API_BASE_URL}"}}',
            status_code=502,
            media_type="application/json",
        )
    except Exception as e:
        logger.error("PROXY ERROR: %s", e)
        return Response(
            content=f'{{"detail":"Proxy error: {str(e)}"}}',
            status_code=502,
            media_type="application/json",
        )

    # Forward response — strip hop-by-hop headers
    excluded = {"content-encoding", "content-length", "transfer-encoding", "connection"}
    resp_headers = {
        k: v for k, v in resp.headers.items()
        if k.lower() not in excluded
    }

    logger.info("PROXY RESPONSE %s %s → %d (%d bytes)",
                request.method, request.url.path, resp.status_code, len(resp.content))

    return Response(
        content=resp.content,
        status_code=resp.status_code,
        headers=resp_headers,
        media_type=resp.headers.get("content-type"),
    )


# ── Proxy routes — must be before the SPA catch-all ──────────────────────────

@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
async def proxy_api(request: Request):
    return await _proxy(request)


@app.api_route("/auth/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
async def proxy_auth(request: Request):
    return await _proxy(request)


@app.api_route("/schema/{path:path}", methods=["GET"])
async def proxy_schema_sub(request: Request):
    return await _proxy(request)


@app.api_route("/schema", methods=["GET"])
async def proxy_schema_root(request: Request):
    return await _proxy(request)


# ── Static files ─────────────────────────────────────────────────────────────

_assets_dir = DIST_DIR / "assets"
if _assets_dir.is_dir():
    app.mount("/assets", StaticFiles(directory=str(_assets_dir)), name="assets")


@app.get("/{path:path}")
async def serve_spa(path: str):
    """Serve static files or fall through to index.html for SPA routing."""
    file_path = DIST_DIR / path
    if path and file_path.is_file():
        return FileResponse(file_path)
    return FileResponse(DIST_DIR / "index.html")


# ── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("CDSW_APP_PORT", "3000"))
    logger.info("SOWA Frontend on port %d", port)
    logger.info("  Static files: %s", DIST_DIR)
    logger.info("  API proxy:    %s", API_BASE_URL)
    uvicorn.run(app, host="127.0.0.1", port=port)
