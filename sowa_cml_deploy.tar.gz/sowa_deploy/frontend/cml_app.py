"""
SOWA Frontend — Static file server + API reverse proxy for Cloudera CML.

Serves the pre-built React app (dist/) and proxies /api, /auth, /schema
requests to the backend service. No Node.js required on the server.

Usage:
  python cml_app.py

Environment variables:
  CDSW_APP_PORT  — Port to serve on (CML sets this automatically, default 3000)
  API_BASE_URL   — Backend API URL (e.g., http://localhost:8000 or
                   https://sowa-backend.ml-xxx.company.com)
"""

import os
import sys
from pathlib import Path

import httpx
import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from starlette.middleware.cors import CORSMiddleware

# ── Config ───────────────────────────────────────────────────────────────────

API_BASE_URL = os.environ.get("API_BASE_URL", "http://localhost:8000")
DIST_DIR = Path(__file__).resolve().parent / "dist"

app = FastAPI(title="SOWA Frontend", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if not DIST_DIR.is_dir():
    print(
        "ERROR: dist/ directory not found.\n"
        "Build the frontend on a machine with Node.js:\n"
        "  cd frontend && npm install && npm run build\n"
        "Then copy the dist/ folder here.",
        file=sys.stderr,
    )
    sys.exit(1)


# ── Health check ─────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "service": "sowa-frontend", "api_backend": API_BASE_URL}


# ── API reverse proxy ────────────────────────────────────────────────────────
# Forwards /api/*, /auth/*, /schema* requests to the backend service.
# This removes the need for VITE_API_BASE_URL at build time.

_proxy_client = httpx.AsyncClient(base_url=API_BASE_URL, timeout=300.0)

API_PREFIXES = ("/api/", "/auth/", "/schema")


async def _proxy(request: Request) -> Response:
    """Forward request to backend and stream response back."""
    url = str(request.url).split(request.base_url.hostname or "localhost", 1)[-1]
    # Extract path + query from the original URL
    path = request.url.path
    query = str(request.url.query)
    target = f"{path}?{query}" if query else path

    headers = dict(request.headers)
    headers.pop("host", None)

    body = await request.body()

    resp = await _proxy_client.request(
        method=request.method,
        url=target,
        headers=headers,
        content=body,
    )

    excluded_headers = {"content-encoding", "content-length", "transfer-encoding"}
    resp_headers = {
        k: v for k, v in resp.headers.items()
        if k.lower() not in excluded_headers
    }

    return Response(
        content=resp.content,
        status_code=resp.status_code,
        headers=resp_headers,
    )


@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def proxy_api(request: Request):
    return await _proxy(request)


@app.api_route("/auth/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy_auth(request: Request):
    return await _proxy(request)


@app.api_route("/schema", methods=["GET"])
@app.api_route("/schema/{path:path}", methods=["GET"])
async def proxy_schema(request: Request):
    return await _proxy(request)


# ── Static files ─────────────────────────────────────────────────────────────

app.mount("/assets", StaticFiles(directory=str(DIST_DIR / "assets")), name="assets")


@app.get("/{path:path}")
async def serve_spa(path: str):
    """Serve static files or fall through to index.html for SPA routing."""
    file_path = DIST_DIR / path
    if file_path.is_file():
        return FileResponse(file_path)
    return FileResponse(DIST_DIR / "index.html")


# ── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("CDSW_APP_PORT", "3000"))
    print(f"SOWA Frontend on port {port}")
    print(f"  Static files: {DIST_DIR}")
    print(f"  API proxy:    {API_BASE_URL}")
    uvicorn.run(app, host="127.0.0.1", port=port)
