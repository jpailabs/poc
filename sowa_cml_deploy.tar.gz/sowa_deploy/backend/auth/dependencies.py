"""Auth dependency — extracts current user from X-Session-Token header."""
from __future__ import annotations

from typing import Optional
from fastapi import Header, HTTPException
import auth.session_manager as sm


async def get_current_user(
    x_session_token: Optional[str] = Header(None, alias="X-Session-Token"),
) -> dict:
    """FastAPI dependency: validates session token and returns user dict.
    Raises 401 if missing or invalid."""
    if not x_session_token:
        raise HTTPException(401, "Missing X-Session-Token header")
    session = sm.validate_session(x_session_token)
    if not session:
        raise HTTPException(401, "Invalid or expired session")
    return session
