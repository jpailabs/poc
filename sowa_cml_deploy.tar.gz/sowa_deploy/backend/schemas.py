from __future__ import annotations
from typing import Any, Dict, List, Optional, Type
from pydantic import BaseModel, Field
import uuid
from datetime import datetime
from enum import Enum


# ── Enums for structured fields ───────────────────────────────────────────────

class Gender(str, Enum):
    male = "Male"
    female = "Female"
    other = "Other"
    prefer_not_to_say = "Prefer not to say"

class MaritalStatus(str, Enum):
    single = "Single"
    married = "Married"
    divorced = "Divorced"
    widowed = "Widowed"
    separated = "Separated"

class EducationLevel(str, Enum):
    primary = "Primary"
    secondary = "Secondary"
    diploma = "Diploma / ITE"
    bachelors = "Bachelor's Degree"
    masters = "Master's Degree"
    doctorate = "Doctorate"
    professional = "Professional Qualification"
    other = "Other"

# ISO 3166 common countries (banking-relevant)
COUNTRY_OPTIONS = [
    "Singapore", "Malaysia", "Indonesia", "Thailand", "Philippines",
    "Vietnam", "Myanmar", "Cambodia", "Brunei", "Laos",
    "China", "Hong Kong SAR", "Macau SAR", "Taiwan", "Japan", "South Korea",
    "India", "Bangladesh", "Sri Lanka", "Pakistan",
    "Australia", "New Zealand",
    "United Kingdom", "France", "Germany", "Switzerland", "Netherlands",
    "United States", "Canada",
    "United Arab Emirates", "Saudi Arabia", "Qatar", "Bahrain", "Kuwait",
    "South Africa", "Nigeria",
    "Brazil", "Mexico", "Argentina",
    "Other",
]


# ── Domain models (extraction schemas) ───────────────────────────────────────

class NOADetails(BaseModel):
    year: int = Field(0, description="Year of assessment. Use 0 if not available.")
    employment_income: float = Field(0, description="Employment income for the year.")
    tax_payable: float = Field(0, description="Tax payable for the year.")
    currency: str = Field("SGD", description="ISO 4217 currency code.")

class NOAData(BaseModel):
    noa_data: Optional[List[NOADetails]] = Field(default_factory=list)

class PaySlipDetails(BaseModel):
    payment_year: Optional[int] = Field(None, description="Payment year.")
    payment_month: str = Field("", description="Payment month name.")
    net_pay: Optional[float] = Field(None, description="Net pay received.")
    currency: str = Field("", description="ISO 4217 currency code.")

class PaySlipData(BaseModel):
    payslip: List[PaySlipDetails] = Field(default_factory=list)

class SummaryData(BaseModel):
    total_source_of_wealth_coming_from_all_the_employment: Optional[float] = Field(None)
    total_sow_generated_from_client_business: Optional[float] = Field(None)
    total_gain_of_the_property: Optional[float] = Field(None)

class OtherDocData(BaseModel):
    notes: Optional[str] = Field(None, description="Optional notes for other document types")

DOCUMENT_REGISTRY: Dict[str, type] = {
    "noa":     NOAData,
    "payslip": PaySlipData,
    "summary": SummaryData,
    "income_tax": NOAData,
    "tax_returns_biz": NOAData,
    "payslips": PaySlipData,
    "employment_letter": OtherDocData,
    "bank_statements": OtherDocData,
    "cpf_statement": OtherDocData,
    "bonus_letter": OtherDocData,
    "identification": OtherDocData,
    "biz_reg": OtherDocData,
    "ownership_structure": OtherDocData,
    "biz_financials": OtherDocData,
    "bank_statements_biz": OtherDocData,
    "personal_bank_statements": OtherDocData,
    "dividend_record": OtherDocData,
    "director_fee": OtherDocData,
    "biz_contracts": OtherDocData,
    "asset_documents": OtherDocData,
    "ubo_declaration": OtherDocData,
    "identification_biz": OtherDocData,
}


# ── Driver data-entry models (free-text fields per wealth source) ────────────

class ClientInfo(BaseModel):
    """Client personal profile information."""
    fullname: str = Field("", description="Client full name.")
    marital_status: Optional[MaritalStatus] = Field(None, description="Marital status.")
    gender: Optional[Gender] = Field(None, description="Gender.")
    countryofbirth: Optional[str] = Field(None, description="Country of birth.", json_schema_extra={"enum": COUNTRY_OPTIONS})
    nationality: Optional[List[str]] = Field(default_factory=list, description="Nationality ISO codes.")
    country_of_residence: Optional[str] = Field(None, description="Country of residence.", json_schema_extra={"enum": COUNTRY_OPTIONS})
    birthdate: Optional[str] = Field(None, description="Date of birth.", json_schema_extra={"format": "date"})
    age: Optional[float] = Field(None, description="Age.")
    educational_level: Optional[str] = Field(None, description="Highest education level.")
    is_singapore_pr: Optional[bool] = Field(None, description="Whether client is a Singapore PR.")

class ClientEmployment(BaseModel):
    """Employment history entry."""
    start_date: Optional[str] = Field(None, description="Employment start date.", json_schema_extra={"format": "date"})
    end_date: Optional[str] = Field(None, description="Employment end date.", json_schema_extra={"format": "date"})
    employer_name: Optional[str] = Field("", description="Employer name.")
    employer_country: Optional[List[str]] = Field(default_factory=list, description="Employer country.")
    position_held: Optional[str] = Field("", description="Position held.")
    period_of_employment: Optional[str] = Field("", description="Period of employment.")
    duration_of_employment: Optional[str] = Field("", description="Duration of employment.")
    nature_of_employer_business: Optional[List[str]] = Field(default_factory=list, description="Nature of employer business.")
    income_contribution_percent: Optional[float] = Field(None, description="Total income contribution percentage.")
    salary_per_annum: Optional[float] = Field(None, description="Annual salary.")
    bonus: Optional[float] = Field(None, description="Bonus amount.")
    total_amount_saved: Optional[float] = Field(None, description="Total amount saved.")

class ClientCompany(BaseModel):
    """Company / business ownership entry."""

    company_name: Optional[str] = Field("", description="Company name.")
    company_country: Optional[List[str]] = Field(default_factory=list, description="Country where company is located.")
    position_held: Optional[str] = Field("", description="Position held in company.")
    period_of_company: Optional[str] = Field("", description="Period with the company.")
    duration_of_company: Optional[str] = Field("", description="Duration of association.")
    nature_of_business: Optional[List[str]] = Field(default_factory=list, description="Nature of business.")
    income_contribution_percent: Optional[float] = Field(None, description="Income contribution percentage.")
    profit_per_annum: Optional[float] = Field(None, description="Annual profit.")
    bonus: Optional[float] = Field(None, description="Bonus from company.")
    company_status: Optional[str] = Field("", description="Company status (active/dormant).")
    client_shareholdings: Optional[str] = Field("", description="Client shareholding percentage.")
    position_of_executive_authority: Optional[str] = Field("", description="Executive authority position.")
    salary_from_executive_position: Optional[float] = Field(None, description="Salary from executive position.")
    geographical_markets: Optional[str] = Field("", description="Geographical markets served.")

class DividendData(BaseModel):
    """Dividend income entry."""

    company_name: Optional[str] = Field("", description="Company that paid the dividend.")
    company_country: Optional[List[str]] = Field(default_factory=list, description="Country of company.")
    dividend_receipts_date: Optional[str] = Field(None, description="Date dividend was received.", json_schema_extra={"format": "date"})
    total_amt_received: Optional[float] = Field(None, description="Total dividend amount received.")
    share_held_time_length: Optional[str] = Field("", description="Length of time shares were held.")

class FinancialInvestment(BaseModel):
    """Financial investment / sale entry."""

    financial_instrument_type: Optional[str] = Field("", description="Type of financial instrument (stock, bond, etc.).")
    investment_industry: Optional[str] = Field("", description="Industry of the investment.")
    percent_contribution_sow: Optional[float] = Field(None, description="Percentage of SOW from this investment.")
    funds_received_date: Optional[str] = Field(None, description="Date funds were received.", json_schema_extra={"format": "date"})
    investment_sales_net_gain: Optional[float] = Field(None, description="Net gain from investment sale.")
    sale_amt: Optional[float] = Field(None, description="Sale amount.")
    investment_held_org_name: Optional[str] = Field("", description="Organisation that held the investment.")
    time_period: Optional[str] = Field("", description="Time period investment was held.")
    verification_sold: Optional[str] = Field("", description="Verification that investment was sold.")
    plausibility_assessment: Optional[str] = Field("", description="Plausibility assessment.")

class PropertyData(BaseModel):
    """Property sale / ownership entry."""

    property_name: Optional[str] = Field("", description="Name of the property.")
    property_location: Optional[str] = Field("", description="Location of the property.")
    property_country: Optional[str] = Field("", description="Country of the property.")
    property_type: Optional[str] = Field("", description="Type of property (residential, commercial, etc.).")
    est_purchase_price: Optional[float] = Field(None, description="Estimated purchase price.")
    est_sale_price: Optional[float] = Field(None, description="Estimated sale price.")
    property_sale_net: Optional[float] = Field(None, description="Net sale price of property.")
    owned_period: Optional[str] = Field("", description="Period of time property was owned.")
    year_of_sale: Optional[str] = Field("", description="Year the property was sold.")
    plausibility_assessment: Optional[str] = Field("", description="Plausibility assessment of property sale.")

class InheritanceData(BaseModel):
    """Inheritance entry."""

    donor_name: Optional[str] = Field("", description="Donor name.")
    donor_citizenship: Optional[List[str]] = Field(default_factory=list, description="Citizenship of the donor.")
    donor_country: Optional[str] = Field("", description="Country of the donor.")
    inheritance_date: Optional[str] = Field(None, description="Date when the inheritance happened.", json_schema_extra={"format": "date"})
    donor_relationship: Optional[str] = Field("", description="Relationship of the donor to client.")
    type_of_assets: Optional[str] = Field("", description="Type of assets inherited.")
    amt_inheritance: Optional[float] = Field(None, description="Value of the inheritance.")

class GiftData(BaseModel):
    """Gift entry."""

    donor_name: Optional[str] = Field("", description="Donor name.")
    donor_citizenship: Optional[List[str]] = Field(default_factory=list, description="Citizenship of the donor.")
    donor_country: Optional[str] = Field("", description="Country of the donor.")
    gift_date: Optional[str] = Field(None, description="Date when the gift was given.", json_schema_extra={"format": "date"})
    donor_relationship: Optional[str] = Field("", description="Relationship of the donor to client.")
    type_of_assets: Optional[str] = Field("", description="Type of assets gifted.")
    amt_gift: Optional[float] = Field(None, description="Value of the gift.")


# ── CE (Client Evidence) upload models ───────────────────────────────────────
# Each field is a List[str] representing file-upload slots for that evidence type.

class CE_SalariedEmployee(BaseModel):
    """Supporting documents for salaried employment income."""
    company_registry: Optional[List[str]] = Field(default_factory=list, description="Company registry documents.")
    reliable_media_article: Optional[List[str]] = Field(default_factory=list, description="Reliable media articles.")
    tax_assessment_tax_filing_returns_notice: Optional[List[str]] = Field(default_factory=list, description="Tax assessment / tax filing returns / NOA.")
    payslip: Optional[List[str]] = Field(default_factory=list, description="Payslips.")
    bank_statement: Optional[List[str]] = Field(default_factory=list, description="Bank statements showing salary credits.")
    attestation_by_professional: Optional[List[str]] = Field(default_factory=list, description="Attestation by professionals.")
    visitation_report: Optional[List[str]] = Field(default_factory=list, description="Visitation reports.")
    benchmarking: Optional[List[str]] = Field(default_factory=list, description="Benchmarking documents.")

class CE_CompanyHoldings(BaseModel):
    """Supporting documents for business / company holdings."""
    company_registry: Optional[List[str]] = Field(default_factory=list, description="Company registry documents.")
    reliable_media_article: Optional[List[str]] = Field(default_factory=list, description="Reliable media articles.")
    audited_financial_statements: Optional[List[str]] = Field(default_factory=list, description="Audited financial statements.")
    tax_filing_returns: Optional[List[str]] = Field(default_factory=list, description="Tax filing returns.")
    third_party_due_diligence_reports: Optional[List[str]] = Field(default_factory=list, description="Third-party due diligence reports.")
    qualified_accountant_or_lawyer_letter: Optional[List[str]] = Field(default_factory=list, description="Letters from qualified accountants or lawyers.")
    websites: Optional[List[str]] = Field(default_factory=list, description="Website references.")
    rm_justification: Optional[List[str]] = Field(default_factory=list, description="RM justification documents.")

class CE_Property(BaseModel):
    """Supporting documents for property sale proceeds."""
    title_deed_extract_government_registries: Optional[List[str]] = Field(default_factory=list, description="Title deed extracts from government registries.")
    sale_purchase_agreement: Optional[List[str]] = Field(default_factory=list, description="Sale/purchase agreements.")
    licensed_solicitor_regulated_accountant_letter: Optional[List[str]] = Field(default_factory=list, description="Letters from licensed solicitors or regulated accountants.")
    reliable_media_article: Optional[List[str]] = Field(default_factory=list, description="Reliable media articles.")

class CE_Investment(BaseModel):
    """Supporting documents for financial investment / sale."""
    investment_savings_certificates: Optional[List[str]] = Field(default_factory=list, description="Investment savings certificates.")
    contract_notes: Optional[List[str]] = Field(default_factory=list, description="Contract notes.")
    surrender_statement: Optional[List[str]] = Field(default_factory=list, description="Surrender statements.")
    bank_statement: Optional[List[str]] = Field(default_factory=list, description="Bank statements.")
    signed_letter_solicitor_lawyer: Optional[List[str]] = Field(default_factory=list, description="Signed letters from solicitors or lawyers.")
    sale_document: Optional[List[str]] = Field(default_factory=list, description="Sale documents.")
    portfolio_statement: Optional[List[str]] = Field(default_factory=list, description="Portfolio statements.")
    reputable_appraiser_insurance_report: Optional[List[str]] = Field(default_factory=list, description="Reports from reputable appraisers or insurance companies.")
    visitation_report: Optional[List[str]] = Field(default_factory=list, description="Visitation reports.")
    attestation_by_rm: Optional[List[str]] = Field(default_factory=list, description="Attestation by risk managers.")

class CE_Dividend(BaseModel):
    """Supporting documents for dividend income."""
    dividend_contracts_note: Optional[List[str]] = Field(default_factory=list, description="Dividend contracts / notes.")
    bank_statement: Optional[List[str]] = Field(default_factory=list, description="Bank statements.")
    regulated_accountant_letter: Optional[List[str]] = Field(default_factory=list, description="Letters from regulated accountants.")
    company_accounts: Optional[List[str]] = Field(default_factory=list, description="Company accounts.")

class CE_Inheritance(BaseModel):
    """Supporting documents for inheritance."""
    grant_of_probate: Optional[List[str]] = Field(default_factory=list, description="Grant of probate documents.")
    will: Optional[List[str]] = Field(default_factory=list, description="Will documents.")
    letter_from_solicitor: Optional[List[str]] = Field(default_factory=list, description="Letter from solicitor.")
    relation_proof_death: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — death certificate.")
    relation_proof_obituary: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — obituary.")
    relation_proof_birth_cert: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — birth certificate.")
    relation_proof_marriage_cert: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — marriage certificate.")
    relation_proof_passport_copy: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — passport copy.")
    relation_proof_misc: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — miscellaneous.")
    relation_proof_third_party: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — third party.")
    relation_proof_media_articles: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — media articles.")
    visitation_reports: Optional[List[str]] = Field(default_factory=list, description="Visitation reports.")

class CE_Gift(BaseModel):
    """Supporting documents for gifts."""
    reliable_media_articles: Optional[List[str]] = Field(default_factory=list, description="Reliable media articles.")
    bank_statement: Optional[List[str]] = Field(default_factory=list, description="Bank statements for gift amount transferred.")
    letter_from_solicitor: Optional[List[str]] = Field(default_factory=list, description="Letter from solicitor.")
    relation_proof_death: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — death certificate.")
    relation_proof_obituary: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — obituary.")
    relation_proof_birth_cert: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — birth certificate.")
    relation_proof_marriage_cert: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — marriage certificate.")
    relation_proof_passport_copy: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — passport copy.")
    relation_proof_misc: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — miscellaneous.")
    relation_proof_third_party: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — third party.")
    relation_proof_media_articles: Optional[List[str]] = Field(default_factory=list, description="Proof of relationship — media articles.")
    visitation_report: Optional[List[str]] = Field(default_factory=list, description="Visitation reports.")

class CE_SUR(BaseModel):
    """Past SOW documents written by Relationship Manager."""
    rm_sow: Optional[List[str]] = Field(default_factory=list, description="Past SoW written by RM.")


# ── Driver registry — maps each wealth-source driver to its models ───────────

DRIVER_REGISTRY: Dict[str, Dict[str, Any]] = {
    "client_employment_history": {
        "label": "Salaried Employment Income",
        "description": "Income from employment — salary, bonuses, CPF contributions. For employees, senior executives, and professionals.",
        "data_model": ClientEmployment,
        "ce_model": CE_SalariedEmployee,
        "ce_folder": "salaried_employee",
    },
    "client_company_history": {
        "label": "Business Ownership & Holdings",
        "description": "Income from business ownership — profits, director fees, shareholding. For business owners, directors, and major shareholders.",
        "data_model": ClientCompany,
        "ce_model": CE_CompanyHoldings,
        "ce_folder": "company_holdings",
    },
    "property_sale": {
        "label": "Property Sale Proceeds",
        "description": "Wealth from property transactions — purchase, sale, and capital gains on real estate.",
        "data_model": PropertyData,
        "ce_model": CE_Property,
        "ce_folder": "sale_of_property",
    },
    "dividend": {
        "label": "Dividend Income",
        "description": "Income from dividends declared and paid by companies in which the client holds shares.",
        "data_model": DividendData,
        "ce_model": CE_Dividend,
        "ce_folder": "dividend_payment",
    },
    "financial_investment": {
        "label": "Financial Investment / Sale",
        "description": "Wealth from sale of financial instruments — stocks, bonds, unit trusts, and other securities.",
        "data_model": FinancialInvestment,
        "ce_model": CE_Investment,
        "ce_folder": "sale_of_investment",
    },
    "client_inheritance": {
        "label": "Inheritance",
        "description": "Wealth inherited from a deceased person — estate distributions, bequests, and probate proceeds.",
        "data_model": InheritanceData,
        "ce_model": CE_Inheritance,
        "ce_folder": "inheritance",
    },
    "client_gift": {
        "label": "Gift",
        "description": "Wealth received as a gift — monetary or asset transfers from donors.",
        "data_model": GiftData,
        "ce_model": CE_Gift,
        "ce_folder": "gift",
    },
    "sur_case": {
        "label": "RM SoW (SUR Reference)",
        "description": "Past Source of Wealth documents previously written by the Relationship Manager.",
        "data_model": None,
        "ce_model": CE_SUR,
        "ce_folder": "sur/rm_sow",
    },
}

# ── API request/response schemas ─────────────────────────────────────────────

class CreateSessionRequest(BaseModel):
    session_id: Optional[uuid.UUID] = Field(None, description="Provide to add to existing session, or omit to create new.")
    doc_types: List[str] = Field(..., description="Document types to extract.")

class UpdateDocRequest(BaseModel):
    verified_data: Dict[str, Any] = Field(..., description="User-curated data payload.")
    status: str = Field("reviewing", description="New status: reviewing | verified")

class DocumentSessionOut(BaseModel):
    id: int
    session_id: uuid.UUID
    subsession_id: uuid.UUID
    doc_type: str
    status: str
    extracted_data: Dict[str, Any]
    verified_data: Optional[Dict[str, Any]]
    diff_summary: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class SessionSummaryOut(BaseModel):
    session_id: uuid.UUID
    doc_types: List[str]
    total_records: int
    verified_count: int
    latest_updated: Optional[datetime]

class SummarizeResponse(BaseModel):
    record_id: int
    doc_type: str
    summary: str
    key_figures: Dict[str, Any]
