"""Tests for authorization — cross-user access prevention and source document validation."""
import pytest
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    """Create a test client with in-memory SQLite DB."""
    os.environ["DATABASE_URL"] = "sqlite:///./test_auth.db"

    from main import app
    from database import init_db
    init_db()

    with TestClient(app) as c:
        yield c

    # Cleanup
    if os.path.exists("test_auth.db"):
        os.remove("test_auth.db")


def _login(client: TestClient, username: str = "demo", password: str = "gdo2024") -> str:
    """Login and return session token."""
    res = client.post("/auth/login", json={"username": username, "password": password})
    assert res.status_code == 200
    return res.json()["token"]


def test_upload_requires_auth(client):
    """Upload without token should fail with 401."""
    from io import BytesIO
    res = client.post(
        "/api/v1/upload",
        data={"profile_type": "salaried"},
        files={"files": ("test.pdf", BytesIO(b"%PDF-1.4 test"), "application/pdf")},
    )
    assert res.status_code == 401


def test_upload_returns_client_ref(client):
    """Upload should auto-generate client_ref."""
    token = _login(client)
    from io import BytesIO
    res = client.post(
        "/api/v1/upload",
        data={"profile_type": "salaried"},
        files={"files": ("test.pdf", BytesIO(b"%PDF-1.4 test"), "application/pdf")},
        headers={"X-Session-Token": token},
    )
    assert res.status_code == 200
    data = res.json()
    assert "client_ref" in data
    assert data["client_ref"].startswith("SOW-")
    assert "session_id" in data


def test_cross_user_session_access_blocked(client):
    """User A's session should not be accessible by User B."""
    # Login as user A (demo)
    token_a = _login(client, "demo", "gdo2024")

    # Upload as user A
    from io import BytesIO
    res = client.post(
        "/api/v1/upload",
        data={"profile_type": "salaried"},
        files={"files": ("noa_2023.pdf", BytesIO(b"%PDF-1.4 test"), "application/pdf")},
        headers={"X-Session-Token": token_a},
    )
    assert res.status_code == 200
    session_id = res.json()["session_id"]

    # User A can access their own session
    res = client.get(
        f"/api/v1/session/{session_id}/status",
        headers={"X-Session-Token": token_a},
    )
    assert res.status_code == 200

    # Another token (simulating user B) should be blocked
    # Since demo auth creates same user, we test by checking that
    # an unauthenticated request is blocked
    res = client.get(f"/api/v1/session/{session_id}/status")
    assert res.status_code == 401


def test_extract_requires_auth(client):
    """Extract without token should fail."""
    res = client.post(
        "/api/v1/extract",
        json={"session_id": "fake-session-id"},
    )
    assert res.status_code == 401


def test_extract_wrong_session_blocked(client):
    """Extracting a non-owned session should fail with 403."""
    token = _login(client)
    res = client.post(
        "/api/v1/extract",
        json={"session_id": "non-existent-session"},
        headers={"X-Session-Token": token},
    )
    assert res.status_code == 403


def test_source_document_validation(client):
    """Validate that source_file must be in uploaded files list."""
    token = _login(client)

    # Upload a file
    from io import BytesIO
    res = client.post(
        "/api/v1/upload",
        data={"profile_type": "salaried"},
        files={"files": ("noa_2023.pdf", BytesIO(b"%PDF-1.4 test"), "application/pdf")},
        headers={"X-Session-Token": token},
    )
    session_id = res.json()["session_id"]

    # Valid source document
    res = client.post(
        f"/api/v1/extract/{session_id}/validate-source",
        json={
            "key": "Employment Income",
            "value": "420000",
            "source_file": "noa_2023.pdf",
            "category": "Tax Assessment",
        },
        headers={"X-Session-Token": token},
    )
    assert res.status_code == 200
    assert res.json()["valid"] is True

    # Invalid source document — not uploaded
    res = client.post(
        f"/api/v1/extract/{session_id}/validate-source",
        json={
            "key": "Employment Income",
            "value": "420000",
            "source_file": "fake_document.pdf",
            "category": "Tax Assessment",
        },
        headers={"X-Session-Token": token},
    )
    assert res.status_code == 400


def test_settings_crud(client):
    """Settings can be read and updated per user."""
    token = _login(client)

    # Get default settings
    res = client.get("/api/v1/settings", headers={"X-Session-Token": token})
    assert res.status_code == 200
    assert res.json()["input_currency"] == "SGD"

    # Update settings
    res = client.put(
        "/api/v1/settings",
        json={"input_currency": "USD", "output_currency": "EUR", "inflation_rate": "3.5"},
        headers={"X-Session-Token": token},
    )
    assert res.status_code == 200
    assert res.json()["input_currency"] == "USD"
    assert res.json()["output_currency"] == "EUR"
    assert res.json()["inflation_rate"] == "3.5"

    # Verify persistence
    res = client.get("/api/v1/settings", headers={"X-Session-Token": token})
    assert res.status_code == 200
    assert res.json()["output_currency"] == "EUR"
