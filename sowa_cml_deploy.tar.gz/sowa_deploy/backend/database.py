"""
Database layer — SQLAlchemy 2.0

Supports both PostgreSQL (production/Docker) and SQLite (CML/local dev).
Set DATABASE_URL env var:
  PostgreSQL: postgresql://user:pass@host:5432/dbname
  SQLite:     sqlite:///./sow.db           (relative to backend dir)
              sqlite:////home/cdsw/sow.db  (absolute path on CML)

SQLite is the default when DATABASE_URL is not set.
"""

import os
import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column, DateTime, Index, Integer,
    JSON, String, create_engine, text
)
from sqlalchemy.orm import DeclarativeBase, sessionmaker

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"sqlite:///{os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sow.db')}"
)

_IS_SQLITE = DATABASE_URL.startswith("sqlite")

if _IS_SQLITE:
    engine = create_engine(
        DATABASE_URL, echo=False,
        connect_args={"check_same_thread": False},
    )
else:
    engine = create_engine(DATABASE_URL, echo=False, pool_pre_ping=True)

SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


class Base(DeclarativeBase):
    pass


class DocumentSession(Base):
    __tablename__ = "document_sessions"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    session_id     = Column(String(36), nullable=False, default=lambda: str(uuid.uuid4()), index=True)
    subsession_id  = Column(String(36), nullable=False, default=lambda: str(uuid.uuid4()), index=True)
    doc_type       = Column(String(64), nullable=False)
    status         = Column(String(32), nullable=False, default="extracted")
    extracted_data = Column(JSON, nullable=False)
    verified_data  = Column(JSON, nullable=True)
    diff_summary   = Column(JSON, nullable=True)
    created_at     = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime(timezone=True),
                            default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_session_doctype", "session_id", "doc_type"),
    )


class UserProcess(Base):
    """Maps user_id to process_id for authorization checks."""
    __tablename__ = "user_processes"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    user_id    = Column(String(128), nullable=False, index=True)
    process_id = Column(String(36), nullable=False, unique=True, index=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class UserSettings(Base):
    """Per-user settings (currency, inflation rate)."""
    __tablename__ = "user_settings"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    user_id         = Column(String(128), nullable=False, unique=True, index=True)
    input_currency  = Column(String(8), nullable=False, default="SGD")
    output_currency = Column(String(8), nullable=False, default="SGD")
    inflation_rate  = Column(String(16), nullable=True)
    updated_at      = Column(DateTime(timezone=True),
                             default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    Base.metadata.create_all(bind=engine)


def init_pipeline_jobs_table():
    """Create the pipeline_jobs table for status event history."""
    try:
        with engine.connect() as conn:
            if _IS_SQLITE:
                conn.execute(text("""
                    CREATE TABLE IF NOT EXISTS pipeline_jobs (
                        id          INTEGER PRIMARY KEY AUTOINCREMENT,
                        session_id  TEXT NOT NULL,
                        job_id      TEXT NOT NULL,
                        stage       TEXT NOT NULL,
                        message     TEXT NOT NULL,
                        progress    INTEGER DEFAULT 0,
                        service     TEXT DEFAULT \'\',
                        model       TEXT DEFAULT \'\',
                        page_num    INTEGER,
                        is_error    INTEGER DEFAULT 0,
                        is_warning  INTEGER DEFAULT 0,
                        timestamp   TEXT NOT NULL
                    )
                """))
            else:
                conn.execute(text("""
                    CREATE TABLE IF NOT EXISTS pipeline_jobs (
                        id          SERIAL PRIMARY KEY,
                        session_id  TEXT NOT NULL,
                        job_id      TEXT NOT NULL,
                        stage       TEXT NOT NULL,
                        message     TEXT NOT NULL,
                        progress    INTEGER DEFAULT 0,
                        service     TEXT DEFAULT \'\',
                        model       TEXT DEFAULT \'\',
                        page_num    INTEGER,
                        is_error    BOOLEAN DEFAULT FALSE,
                        is_warning  BOOLEAN DEFAULT FALSE,
                        timestamp   TEXT NOT NULL
                    )
                """))
            conn.execute(text(
                "CREATE INDEX IF NOT EXISTS ix_pipeline_jobs_session "
                "ON pipeline_jobs (session_id)"
            ))
            conn.commit()
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning("Could not create pipeline_jobs table: %s", e)
