"""Settings router — per-user currency and inflation rate preferences."""
from __future__ import annotations

from typing import Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from auth.dependencies import get_current_user
from database import get_db, UserSettings

router = APIRouter(prefix="/api/v1", tags=["Settings"])


class SettingsPayload(BaseModel):
    input_currency: str = "SGD"
    output_currency: str = "SGD"
    inflation_rate: Optional[str] = None


class SettingsResponse(BaseModel):
    input_currency: str
    output_currency: str
    inflation_rate: Optional[str]


VALID_CURRENCIES = [
    "SGD", "USD", "EUR", "GBP", "JPY", "CNY", "HKD", "AUD", "CAD",
    "CHF", "NZD", "INR", "MYR", "IDR", "THB", "PHP", "VND", "KRW",
    "TWD", "AED", "SAR", "QAR", "BHD", "KWD", "ZAR", "BRL", "MXN",
]


@router.get("/settings", response_model=SettingsResponse)
async def get_settings(
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    row = db.query(UserSettings).filter(
        UserSettings.user_id == user["username"]
    ).first()
    if not row:
        return SettingsResponse(input_currency="SGD", output_currency="SGD", inflation_rate=None)
    return SettingsResponse(
        input_currency=row.input_currency,
        output_currency=row.output_currency,
        inflation_rate=row.inflation_rate,
    )


@router.put("/settings", response_model=SettingsResponse)
async def update_settings(
    body: SettingsPayload,
    user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    row = db.query(UserSettings).filter(
        UserSettings.user_id == user["username"]
    ).first()
    if not row:
        row = UserSettings(user_id=user["username"])
        db.add(row)
    row.input_currency = body.input_currency
    row.output_currency = body.output_currency
    row.inflation_rate = body.inflation_rate
    db.commit()
    db.refresh(row)
    return SettingsResponse(
        input_currency=row.input_currency,
        output_currency=row.output_currency,
        inflation_rate=row.inflation_rate,
    )


@router.get("/currencies")
async def list_currencies():
    return {"currencies": VALID_CURRENCIES}
