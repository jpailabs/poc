"""
Extract router — OCR + field extraction with async process ID workflow.

POST /api/v1/extract returns a process_id immediately.
GET  /api/v1/extract/{process_id}/status polls for status.
GET  /api/v1/extract/{process_id}/result returns the full result when done.

Source-document validation: rows referencing non-uploaded docs are rejected.
Authorization: all endpoints verify user owns the process.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from utils.paths import get_sessions_root, get_session_dir
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session as DBSession
from services.config_loader import get_provider_mode

from auth.dependencies import get_current_user
from database import get_db, UserProcess

router = APIRouter(prefix="/api/v1", tags=["Extract"])
logger = logging.getLogger(__name__)

# ── JSON bypass — path to pre-extracted JSON file ─────────────────────────────
_JSON_BYPASS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "sample_extraction.json"
)

# In-memory extraction job tracking
extraction_jobs: Dict[str, Dict[str, Any]] = {}


class ExtractRequest(BaseModel):
    session_id: str


class ExtractRowUpdate(BaseModel):
    """For editing/adding extraction rows with source document validation."""
    field_id: Optional[str] = None
    key: str
    value: str
    source_file: str
    source_page: Optional[int] = None
    category: str


def _has_api_key() -> bool:
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


# ── ENDPOINT: Start extraction (async — returns process_id) ─────────────────

@router.post("/extract")
async def extract(
    body: ExtractRequest,
    user: dict = Depends(get_current_user),
    db: DBSession = Depends(get_db),
):
    """
    Start async extraction. Returns process_id immediately.
    Client polls GET /api/v1/extract/{process_id}/status for progress.
    """
    from routers.upload import session_states, verify_process_owner

    session_id = body.session_id

    # Authorization check
    if not verify_process_owner(db, user["username"], session_id):
        raise HTTPException(403, "You do not have access to this session.")

    session_dir = get_session_dir(session_id)
    if not os.path.isdir(session_dir):
        raise HTTPException(404, f"Session {session_id} not found or no files uploaded.")

    if session_id in session_states:
        session_states[session_id]["status"] = "extracting"

    process_id = str(uuid.uuid4())

    # Bind process_id to user for authorization
    from routers.upload import bind_process_to_user
    bind_process_to_user(db, user["username"], process_id)

    # Initialize job tracking
    extraction_jobs[process_id] = {
        "session_id": session_id,
        "status": "processing",
        "progress": 0,
        "message": "Starting extraction...",
        "result": None,
        "error": None,
    }

    # Launch extraction in background
    asyncio.create_task(_run_extraction(process_id, session_id, session_dir))

    return {
        "process_id": process_id,
        "session_id": session_id,
        "status": "processing",
    }


async def _run_extraction(process_id: str, session_id: str, session_dir: str):
    """Background task that runs the extraction pipeline."""
    from routers.upload import session_states

    try:
        files = [
            f for f in os.listdir(session_dir)
            if os.path.isfile(os.path.join(session_dir, f))
        ]

        if not files:
            extraction_jobs[process_id]["status"] = "failed"
            extraction_jobs[process_id]["error"] = "No files found in session"
            return

        # ── External extraction service (when configured) ────────────────
        from services.extraction_client import is_external_extraction_enabled
        if is_external_extraction_enabled():
            await _run_external_extraction(process_id, session_id, session_dir, files)
            return

        # JSON bypass
        if os.path.isfile(_JSON_BYPASS_PATH):
            logger.warning("JSON bypass active — loading fields from %s", _JSON_BYPASS_PATH)
            await _load_json_bypass_async(process_id, session_id)
            return

        # Determine pipeline
        use_real = _has_api_key()
        provider_mode = get_provider_mode()
        has_real = use_real or provider_mode == "private"

        if has_real:
            try:
                from services.pipeline_router import process_document

                file_paths = [os.path.join(session_dir, f) for f in files]
                _state = session_states.get(session_id, {})

                async for event in process_document(
                    session_id=session_id,
                    files=file_paths,
                    profile_type=_state.get("profile_type", "salaried"),
                ):
                    event_type = event.get("type", "")

                    if event_type == "status":
                        extraction_jobs[process_id]["progress"] = event.get("progress", 0)
                        extraction_jobs[process_id]["message"] = event.get("message", "")

                    elif event_type == "complete":
                        extraction_id = event.get("extraction_id", "")
                        doc_type = event.get("doc_type", "other")
                        categories_full = event.get("_categories_full", [])
                        extraction_metadata = event.get("extraction_metadata", [])
                        total_fields = event.get("total_fields", 0)

                        if session_id in session_states:
                            session_states[session_id]["status"] = "extracted"
                            session_states[session_id]["extraction_id"] = extraction_id
                            session_states[session_id]["extraction_result"] = categories_full
                            session_states[session_id]["doc_type"] = doc_type
                            session_states[session_id]["extraction_metadata"] = extraction_metadata

                        extraction_jobs[process_id]["status"] = "completed"
                        extraction_jobs[process_id]["progress"] = 100
                        extraction_jobs[process_id]["message"] = "Extraction complete."
                        extraction_jobs[process_id]["result"] = {
                            "extraction_id": extraction_id,
                            "session_id": session_id,
                            "total_fields": total_fields,
                            "categories": categories_full,
                            "doc_type": doc_type,
                        }

                return

            except Exception as e:
                logger.error("Pipeline router failed for session %s: %s", session_id, str(e))
                # Fall through to mock

        # Mock pipeline
        await _run_mock_pipeline_async(process_id, session_id, session_dir, files)

    except Exception as e:
        logger.error("Extraction failed for process %s: %s", process_id, str(e))
        extraction_jobs[process_id]["status"] = "failed"
        extraction_jobs[process_id]["error"] = str(e)


async def _run_external_extraction(
    process_id: str, session_id: str, session_dir: str, files: List[str]
):
    """
    Run extraction via the external CE extraction service.
    Builds the SoWCoPilotRequest payload from session state and submits it.
    """
    from routers.upload import session_states
    from services.extraction_payload_builder import build_extraction_payload
    from services.extraction_client import submit_extraction, poll_extraction_status, fetch_extraction_result

    state = session_states.get(session_id, {})

    extraction_jobs[process_id]["message"] = "Building extraction payload..."
    extraction_jobs[process_id]["progress"] = 5

    # Build CE file mapping: fieldPath → list of actual file paths on disk
    ce_file_mapping: Dict[str, List[str]] = {}
    doc_cats = state.get("doc_categories", {})
    for filename, cat_info in doc_cats.items():
        if isinstance(cat_info, str):
            # Simple category_id mapping
            key = cat_info
            file_path = os.path.join(session_dir, filename)
            ce_file_mapping.setdefault(key, []).append(file_path)

    # Build the payload
    payload = build_extraction_payload(
        customer_id=state.get("client_ref", ""),
        client_info=state.get("client_info_values", {}),
        selected_drivers=state.get("selected_drivers", []),
        driver_data=state.get("driver_data_values", {}),
        ce_file_mapping=ce_file_mapping,
        client_name=state.get("owner", ""),
        process_id=process_id,
    )

    extraction_jobs[process_id]["message"] = "Submitting to extraction service..."
    extraction_jobs[process_id]["progress"] = 10

    try:
        # Submit to external service
        response = await submit_extraction(payload)
        job_id = response.get("process_id") or response.get("job_id") or process_id

        # Poll for completion
        async for status_event in poll_extraction_status(job_id):
            ext_status = status_event.get("status", "unknown")
            ext_progress = status_event.get("progress", 0)
            ext_message = status_event.get("message", "")

            extraction_jobs[process_id]["progress"] = min(10 + int(ext_progress * 0.85), 95)
            extraction_jobs[process_id]["message"] = ext_message or f"Extraction in progress ({ext_status})..."

            if ext_status in ("completed", "complete", "done"):
                break
            elif ext_status in ("failed", "error"):
                extraction_jobs[process_id]["status"] = "failed"
                extraction_jobs[process_id]["error"] = status_event.get("error", "External extraction failed")
                return

        # Fetch final result
        extraction_jobs[process_id]["message"] = "Fetching extraction results..."
        extraction_jobs[process_id]["progress"] = 95

        result = await fetch_extraction_result(job_id)

        # Transform external result into our internal category format
        categories = result.get("categories", [])
        if not categories:
            # If the service returns flat fields, wrap them
            categories = _transform_external_result(result)

        # Assign IDs to fields if missing
        for cat in categories:
            for field in cat.get("fields", []):
                if not field.get("id"):
                    field["id"] = str(uuid.uuid4())

        total_fields = sum(len(cat.get("fields", [])) for cat in categories)
        extraction_id = str(uuid.uuid4())

        if session_id in session_states:
            session_states[session_id]["status"] = "extracted"
            session_states[session_id]["extraction_id"] = extraction_id
            session_states[session_id]["extraction_result"] = categories

        extraction_jobs[process_id]["status"] = "completed"
        extraction_jobs[process_id]["progress"] = 100
        extraction_jobs[process_id]["message"] = "Extraction complete."
        extraction_jobs[process_id]["result"] = {
            "extraction_id": extraction_id,
            "session_id": session_id,
            "total_fields": total_fields,
            "categories": categories,
            "doc_type": "external",
        }

    except Exception as e:
        logger.error("External extraction failed: %s", str(e))
        extraction_jobs[process_id]["status"] = "failed"
        extraction_jobs[process_id]["error"] = f"External extraction error: {str(e)}"


def _transform_external_result(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Transform a flat external extraction result into categorized fields."""
    categories = []

    # Common pattern: result has driver keys with extracted data
    category_map = {
        "client_info": "Client Information",
        "client_employment_history": "Employment Income",
        "client_company_history": "Business Holdings",
        "dividend": "Dividends",
        "financial_investment": "Financial Investments",
        "property_sale": "Property",
        "client_inheritance": "Inheritance",
        "client_gift": "Gifts",
    }

    for key, label in category_map.items():
        data = result.get(key)
        if not data:
            continue

        fields = []
        items = data if isinstance(data, list) else [data]
        for item in items:
            if not isinstance(item, dict):
                continue
            for field_key, field_val in item.items():
                if field_key in ("bos_cidnumber", "sow_ref_no", "Emp_Order"):
                    continue  # Skip internal keys
                if field_val is None or field_val == "" or field_val == []:
                    continue
                display_val = ", ".join(field_val) if isinstance(field_val, list) else str(field_val)
                display_label = field_key.replace("_", " ").replace("bos ", "").title()
                fields.append({
                    "id": str(uuid.uuid4()),
                    "key": field_key,
                    "value": display_val,
                    "display_label": display_label,
                    "display_category": label,
                    "confidence": 0.90,
                    "source_file": "",
                    "source_page": None,
                })

        if fields:
            categories.append({
                "category_name": label,
                "fields": fields,
            })

    return categories


async def _load_json_bypass_async(process_id: str, session_id: str):
    """Load pre-extracted fields from sample_extraction.json."""
    from routers.upload import session_states

    try:
        with open(_JSON_BYPASS_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        extraction_jobs[process_id]["status"] = "failed"
        extraction_jobs[process_id]["error"] = f"Failed to load sample_extraction.json: {e}"
        return

    categories = data.get("categories", [])
    doc_type = data.get("doc_type", "IRAS_NOA")

    for cat in categories:
        for f in cat.get("fields", []):
            if not f.get("id"):
                f["id"] = str(uuid.uuid4())

    total_fields = sum(len(cat.get("fields", [])) for cat in categories)
    extraction_id = str(uuid.uuid4())

    # Simulate processing delay
    stages = [
        ("Analysing document structure...", 10),
        ("Classifying pages...", 30),
        ("Extracting fields...", 60),
        ("Validating results...", 85),
    ]
    for msg, pct in stages:
        extraction_jobs[process_id]["message"] = msg
        extraction_jobs[process_id]["progress"] = pct
        await asyncio.sleep(0.3)

    if session_id in session_states:
        session_states[session_id]["status"] = "extracted"
        session_states[session_id]["extraction_id"] = extraction_id
        session_states[session_id]["extraction_result"] = categories
        session_states[session_id]["doc_type"] = doc_type

    extraction_jobs[process_id]["status"] = "completed"
    extraction_jobs[process_id]["progress"] = 100
    extraction_jobs[process_id]["message"] = "Extraction complete."
    extraction_jobs[process_id]["result"] = {
        "extraction_id": extraction_id,
        "session_id": session_id,
        "total_fields": total_fields,
        "categories": categories,
        "doc_type": doc_type,
    }


# ── MOCK PIPELINE ────────────────────────────────────────────────────────────

def _mock_ocr_process(file_path: str) -> str:
    filename = os.path.basename(file_path).lower()
    if "noa" in filename or "tax" in filename:
        return (
            "INLAND REVENUE AUTHORITY OF SINGAPORE\n"
            "NOTICE OF ASSESSMENT — Year of Assessment 2023\n\n"
            "Name: John Tan Wei Ming\n"
            "NRIC: S****567A\n"
            "Employer: TechCorp Pte Ltd\n"
            "Employment Income: SGD 420,000.00\n"
            "Tax Payable: SGD 42,350.00\n"
            "Assessment Year: 2023\n"
        )
    elif "payslip" in filename or "pay" in filename or "salary" in filename:
        return (
            "PAYSLIP — January 2024\n"
            "Employee: John Tan Wei Ming\n"
            "Employer: TechCorp Pte Ltd\n"
            "Designation: Senior Vice President\n"
            "Gross Salary: SGD 35,000.00\n"
            "CPF Deduction: SGD 6,500.00\n"
            "Net Pay: SGD 28,500.00\n"
            "Employment Start Date: 15 March 2018\n"
        )
    elif "bank" in filename or "statement" in filename:
        return (
            "DBS BANK STATEMENT — Q1 2024\n"
            "Account Holder: John Tan Wei Ming\n"
            "Account: ***4892\n"
            "Opening Balance: SGD 245,000.00\n"
            "Total Credits: SGD 85,500.00\n"
            "Total Debits: SGD 62,300.00\n"
            "Closing Balance: SGD 268,200.00\n"
        )
    elif "biz" in filename or "business" in filename or "acra" in filename:
        return (
            "ACRA BIZFILE — Certificate of Incorporation\n"
            "Company Name: Global Ventures Pte Ltd\n"
            "UEN: 201912345A\n"
            "Date of Incorporation: 12 June 2019\n"
            "Paid-up Capital: SGD 5,000,000\n"
            "Director: John Tan Wei Ming (65% shareholding)\n"
        )
    elif "dividend" in filename:
        return (
            "BOARD RESOLUTION — Dividend Declaration FY2023\n"
            "Company: Global Ventures Pte Ltd\n"
            "Dividend per share: SGD 0.30\n"
            "Total dividend to John Tan: SGD 195,000.00\n"
            "Payment date: 15 March 2024\n"
        )
    elif "ownership" in filename or "share" in filename:
        return (
            "SHAREHOLDER REGISTER\n"
            "Company: Global Ventures Pte Ltd\n"
            "John Tan Wei Ming: 650,000 shares (65%)\n"
            "Sarah Lim: 200,000 shares (20%)\n"
            "Investment Holdings Pte Ltd: 150,000 shares (15%)\n"
        )
    elif "cpf" in filename:
        return (
            "CPF CONTRIBUTION HISTORY — 2023\n"
            "Employee: John Tan Wei Ming\n"
            "Employer: TechCorp Pte Ltd\n"
            "Total Employee Contribution: SGD 78,000\n"
            "Total Employer Contribution: SGD 78,000\n"
        )
    elif "employment" in filename or "letter" in filename:
        return (
            "EMPLOYMENT CONFIRMATION LETTER\n"
            "TechCorp Pte Ltd\n\n"
            "To Whom It May Concern\n"
            "This is to certify that John Tan Wei Ming (S****567A) has been employed "
            "as Senior Vice President since 15 March 2018.\n"
            "Current gross monthly salary: SGD 35,000.00\n"
            "Annual package including bonus: SGD 420,000.00\n"
        )
    elif "passport" in filename or "nric" in filename or "id" in filename or "identification" in filename:
        return (
            "REPUBLIC OF SINGAPORE — NATIONAL REGISTRATION IDENTITY CARD\n"
            "Name: TAN WEI MING, JOHN\n"
            "NRIC: S****567A\n"
            "Date of Birth: 14 August 1985\n"
            "Nationality: Singaporean\n"
        )
    else:
        return f"Document content extracted from {os.path.basename(file_path)}\n"


def _mock_extract_fields(
    ocr_corpus: Dict[str, str], uploaded_filenames: List[str]
) -> List[Dict[str, Any]]:
    """Mock field extraction — parses mock OCR text into structured categories."""
    categories = []
    all_text = "\n".join(ocr_corpus.values())

    # Personal Information — always present
    categories.append({
        "category_name": "Personal Information",
        "icon_key": "user",
        "fields": [
            {"id": str(uuid.uuid4()), "key": "NRIC / Passport", "value": "S****567A", "confidence": 0.95, "source_file": uploaded_filenames[0] if uploaded_filenames else "document.pdf", "source_page": 1},
            {"id": str(uuid.uuid4()), "key": "Date of Birth", "value": "14 August 1985", "confidence": 0.93, "source_file": uploaded_filenames[0] if uploaded_filenames else "document.pdf", "source_page": 1},
            {"id": str(uuid.uuid4()), "key": "Nationality", "value": "Singaporean", "confidence": 0.98, "source_file": uploaded_filenames[0] if uploaded_filenames else "document.pdf", "source_page": 1},
        ]
    })

    # Employment Income
    if any(kw in all_text.lower() for kw in ["employer", "salary", "payslip", "employment", "net pay"]):
        emp_file = next((f for f in uploaded_filenames if any(k in f.lower() for k in ["payslip", "pay", "employment", "letter"])), uploaded_filenames[0] if uploaded_filenames else "payslip.pdf")
        categories.append({
            "category_name": "Employment Income",
            "icon_key": "briefcase",
            "fields": [
                {"id": str(uuid.uuid4()), "key": "Employer Name", "value": "TechCorp Pte Ltd", "confidence": 0.94, "source_file": emp_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Designation", "value": "Senior Vice President", "confidence": 0.89, "source_file": emp_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Annual Base Salary", "value": "420,000.00", "confidence": 0.97, "source_file": emp_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Monthly Net Pay", "value": "28,500.00", "confidence": 0.96, "source_file": emp_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Employment Start Date", "value": "15 March 2018", "confidence": 0.91, "source_file": emp_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "CPF Contribution (Annual)", "value": "78,000.00", "confidence": 0.88, "source_file": emp_file, "source_page": 1},
            ]
        })

    # Tax Assessment
    if any(kw in all_text.lower() for kw in ["assessment", "tax payable", "iras", "notice of assessment"]):
        tax_file = next((f for f in uploaded_filenames if any(k in f.lower() for k in ["noa", "tax", "income"])), uploaded_filenames[0] if uploaded_filenames else "noa.pdf")
        categories.append({
            "category_name": "Tax Assessment",
            "icon_key": "file-text",
            "fields": [
                {"id": str(uuid.uuid4()), "key": "Assessment Year", "value": "2023", "confidence": 0.99, "source_file": tax_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Total Assessable Income", "value": "420,000.00", "confidence": 0.96, "source_file": tax_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Tax Payable", "value": "42,350.00", "confidence": 0.95, "source_file": tax_file, "source_page": 1},
            ]
        })

    # Bank Statements
    if any(kw in all_text.lower() for kw in ["bank statement", "opening balance", "closing balance", "account"]):
        bank_file = next((f for f in uploaded_filenames if any(k in f.lower() for k in ["bank", "statement"])), uploaded_filenames[0] if uploaded_filenames else "statement.pdf")
        categories.append({
            "category_name": "Bank Statements",
            "icon_key": "credit-card",
            "fields": [
                {"id": str(uuid.uuid4()), "key": "Bank Name", "value": "DBS Bank", "confidence": 0.93, "source_file": bank_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Account (Last 4)", "value": "***4892", "confidence": 0.90, "source_file": bank_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Opening Balance (Q1 2024)", "value": "245,000.00", "confidence": 0.94, "source_file": bank_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Closing Balance (Q1 2024)", "value": "268,200.00", "confidence": 0.94, "source_file": bank_file, "source_page": 1},
            ]
        })

    # Shareholding
    if any(kw in all_text.lower() for kw in ["shareholding", "shareholder", "incorporation", "uen", "paid-up capital"]):
        biz_file = next((f for f in uploaded_filenames if any(k in f.lower() for k in ["biz", "business", "acra", "ownership", "share"])), uploaded_filenames[0] if uploaded_filenames else "biz_reg.pdf")
        categories.append({
            "category_name": "Shareholding",
            "icon_key": "building",
            "fields": [
                {"id": str(uuid.uuid4()), "key": "Company Name", "value": "Global Ventures Pte Ltd", "confidence": 0.96, "source_file": biz_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "UEN", "value": "201912345A", "confidence": 0.94, "source_file": biz_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Shareholding %", "value": "65%", "confidence": 0.93, "source_file": biz_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Paid-up Capital", "value": "5,000,000", "confidence": 0.91, "source_file": biz_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Date of Incorporation", "value": "12 June 2019", "confidence": 0.97, "source_file": biz_file, "source_page": 1},
            ]
        })

    # Dividends
    if any(kw in all_text.lower() for kw in ["dividend", "board resolution"]):
        div_file = next((f for f in uploaded_filenames if "dividend" in f.lower()), uploaded_filenames[0] if uploaded_filenames else "dividend.pdf")
        categories.append({
            "category_name": "Dividends",
            "icon_key": "trending-up",
            "fields": [
                {"id": str(uuid.uuid4()), "key": "Dividend FY2023", "value": "195,000.00", "confidence": 0.92, "source_file": div_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Dividend per Share", "value": "0.30", "confidence": 0.88, "source_file": div_file, "source_page": 1},
                {"id": str(uuid.uuid4()), "key": "Payment Date", "value": "15 March 2024", "confidence": 0.90, "source_file": div_file, "source_page": 1},
            ]
        })

    return categories


async def _run_mock_pipeline_async(
    process_id: str, session_id: str, session_dir: str, files: List[str]
):
    """Run the mock OCR + extraction pipeline asynchronously."""
    from routers.upload import session_states

    total_pages = 0
    for filename in files:
        file_path = os.path.join(session_dir, filename)
        pages = 1
        if filename.lower().endswith(".pdf"):
            try:
                import fitz
                doc = fitz.open(file_path)
                pages = len(doc)
                doc.close()
            except Exception:
                pages = 1
        total_pages += pages

    ocr_corpus: Dict[str, str] = {}
    current_page = 0

    for filename in files:
        file_path = os.path.join(session_dir, filename)
        pages = 1
        if filename.lower().endswith(".pdf"):
            try:
                import fitz
                doc = fitz.open(file_path)
                pages = len(doc)
                doc.close()
            except Exception:
                pages = 1

        for p in range(pages):
            current_page += 1
            pct = int((current_page / max(total_pages, 1)) * 80)
            extraction_jobs[process_id]["progress"] = pct
            extraction_jobs[process_id]["message"] = f"Processing page {current_page}/{total_pages}..."
            await asyncio.sleep(0.15)

        ocr_text = _mock_ocr_process(file_path)
        ocr_corpus[filename] = ocr_text

    extraction_jobs[process_id]["message"] = "Extracting fields..."
    extraction_jobs[process_id]["progress"] = 85
    await asyncio.sleep(0.2)

    categories = _mock_extract_fields(ocr_corpus, files)
    total_fields = sum(len(cat["fields"]) for cat in categories)

    extraction_id = str(uuid.uuid4())
    if session_id in session_states:
        session_states[session_id]["status"] = "extracted"
        session_states[session_id]["extraction_id"] = extraction_id
        session_states[session_id]["extraction_result"] = categories

    extraction_jobs[process_id]["status"] = "completed"
    extraction_jobs[process_id]["progress"] = 100
    extraction_jobs[process_id]["message"] = "Extraction complete."
    extraction_jobs[process_id]["result"] = {
        "extraction_id": extraction_id,
        "session_id": session_id,
        "total_fields": total_fields,
        "categories": categories,
        "doc_type": "auto",
    }


# ── ENDPOINT: Poll extraction status ─────────────────────────────────────────

@router.get("/extract/{process_id}/status")
async def get_extraction_status(
    process_id: str,
    user: dict = Depends(get_current_user),
    db: DBSession = Depends(get_db),
):
    """Poll extraction progress by process_id."""
    from routers.upload import verify_process_owner

    if not verify_process_owner(db, user["username"], process_id):
        raise HTTPException(403, "You do not have access to this process.")

    job = extraction_jobs.get(process_id)
    if job is None:
        raise HTTPException(404, f"Process {process_id} not found.")

    return {
        "process_id": process_id,
        "session_id": job["session_id"],
        "status": job["status"],
        "progress": job["progress"],
        "message": job["message"],
        "error": job.get("error"),
    }


# ── ENDPOINT: Get full extraction result ─────────────────────────────────────

@router.get("/extract/{process_id}/result")
async def get_extraction_result(
    process_id: str,
    user: dict = Depends(get_current_user),
    db: DBSession = Depends(get_db),
):
    """Return the full extraction result when completed."""
    from routers.upload import verify_process_owner

    if not verify_process_owner(db, user["username"], process_id):
        raise HTTPException(403, "You do not have access to this process.")

    job = extraction_jobs.get(process_id)
    if job is None:
        raise HTTPException(404, f"Process {process_id} not found.")

    if job["status"] == "processing":
        raise HTTPException(202, "Extraction still in progress.")

    if job["status"] == "failed":
        raise HTTPException(500, job.get("error", "Extraction failed."))

    return job["result"]


# ── ENDPOINT: Validate source document for row edit/add (Section 8) ──────────

@router.post("/extract/{session_id}/validate-source")
async def validate_source_document(
    session_id: str,
    body: ExtractRowUpdate,
    user: dict = Depends(get_current_user),
    db: DBSession = Depends(get_db),
):
    """Validate that a source_file is in the uploaded files for this session."""
    from routers.upload import session_states, verify_process_owner

    if not verify_process_owner(db, user["username"], session_id):
        raise HTTPException(403, "You do not have access to this session.")

    state = session_states.get(session_id)
    if state is None:
        raise HTTPException(404, f"Session {session_id} not found.")

    uploaded_filenames = state.get("uploaded_filenames", [])
    if body.source_file not in uploaded_filenames:
        raise HTTPException(
            400,
            f"Source document '{body.source_file}' was not uploaded in this session. "
            f"Uploaded files: {uploaded_filenames}"
        )

    return {"valid": True, "source_file": body.source_file}
