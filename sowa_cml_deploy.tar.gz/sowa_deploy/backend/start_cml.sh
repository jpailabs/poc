#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════════
# SOWA Backend — CML Application Startup Script
# Deploy as: CML Application → Script: backend/start_cml.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -e

cd "$(dirname "$0")"

# Install dependencies if needed
if [ ! -f ".deps_installed" ]; then
    echo "Installing Python dependencies..."
    pip install -r requirements.txt --quiet
    touch .deps_installed
fi

# Set port (CML provides CDSW_APP_PORT)
PORT="${CDSW_APP_PORT:-8000}"

echo "Starting SOWA Backend on port $PORT"
exec python -m uvicorn main:app --host 127.0.0.1 --port "$PORT"
