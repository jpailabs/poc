"""
Builds the exact JSON payload required by the external CE extraction service.

The payload shape matches the production SoWCoPilotRequest format:
  - customer_id, client_info (with bos_* prefixed field names)
  - driver data arrays (client_employment_history, client_company_history, etc.)
  - ce_mapping (file paths grouped by CE folder / field)
  - selected_drivers (boolean map)
  - client, process_id
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional


# ── Field mapping: frontend model fields → extraction service field names ─────

_CLIENT_INFO_MAP = {
    "fullname": "fullname",
    "marital_status": "marital_status",
    "gender": "gender",
    "countryofbirth": "countryofbirth",
    "nationality": "bos_nationalityisocode",
    "country_of_residence": "bos_countryofresidence",
    "birthdate": "birthdate",
    "age": "age",
    "educational_level": "educational_level",
    "is_singapore_pr": "bos_issingaporeanpr",
}

_EMPLOYMENT_MAP = {
    "start_date": "Start_Emp",
    "end_date": "End_Emp",
    "employer_name": "employer_name",
    "employer_country": "employer_country",
    "position_held": "position_held",
    "period_of_employment": "period_of_employment",
    "duration_of_employment": "duration_of_employment",
    "nature_of_employer_business": "nature_of_employer_business",
    "income_contribution_percent": "totalincomecontributionpercent",
    "salary_per_annum": "salary_per_annum",
    "bonus": "bonus",
    "total_amount_saved": "total_amount_saved",
}

_COMPANY_MAP = {
    "company_name": "company_name",
    "company_country": "company_country",
    "position_held": "position_held",
    "period_of_company": "period_of_company",
    "duration_of_company": "duration_of_company",
    "nature_of_business": "nature_of_business",
    "income_contribution_percent": "totalincomecontributionpercent",
    "profit_per_annum": "profit_per_annum",
    "bonus": "bonus",
    "company_status": "company_status",
    "client_shareholdings": "client_shareholdings",
    "position_of_executive_authority": "position_of_executive_authority",
    "salary_from_executive_position": "salary_from_executive_position",
    "geographical_markets": "geographical_markets",
}

# ── CE folder → driver key mapping ───────────────────────────────────────────

_DRIVER_TO_CE_FOLDER = {
    "client_employment_history": "salaried_employee",
    "client_company_history": "company_holdings",
    "property_sale": "sale_of_property",
    "dividend": "dividend_payment",
    "financial_investment": "sale_of_investment",
    "client_inheritance": "inheritance",
    "client_gift": "gift",
    "sur_case": "sur",
}

# All driver keys for selected_drivers boolean map
ALL_DRIVER_KEYS = [
    "client_employment_history",
    "client_company_history",
    "dividend",
    "financial_investment",
    "property_sale",
    "client_inheritance",
    "client_gift",
    "sur_case",
]


def _remap_fields(data: Dict[str, Any], field_map: Dict[str, str]) -> Dict[str, Any]:
    """Rename fields using a mapping dict."""
    result: Dict[str, Any] = {}
    for src_key, dest_key in field_map.items():
        if src_key in data and data[src_key] is not None:
            val = data[src_key]
            # Convert bool to Yes/No string for bos_issingaporeanpr
            if dest_key == "bos_issingaporeanpr" and isinstance(val, bool):
                val = "Yes" if val else "No"
            result[dest_key] = val
        else:
            result[dest_key] = None
    return result


def build_extraction_payload(
    customer_id: str,
    client_info: Dict[str, Any],
    selected_drivers: List[str],
    driver_data: Dict[str, Dict[str, Any]],
    ce_file_mapping: Dict[str, List[str]],
    client_name: str = "",
    process_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Build the complete extraction service payload.

    Args:
        customer_id: Client ID / CID number
        client_info: Dict of client profile fields from frontend
        selected_drivers: List of selected driver keys
        driver_data: Dict of driver_key → field values
        ce_file_mapping: Dict of "CE_Class.field" → list of file paths
        client_name: Client/bank code
        process_id: Optional pre-generated process ID

    Returns:
        Dict matching the extraction service SoWCoPilotRequest schema
    """
    if not process_id:
        process_id = str(uuid.uuid4())

    cid = customer_id or client_info.get("fullname", "").replace(" ", "").upper()[:20] or "UNKNOWN"

    # ── client_info section ──────────────────────────────────────────────
    ci = _remap_fields(client_info, _CLIENT_INFO_MAP)
    ci["bos_cidnumber"] = cid
    # Ensure list fields are lists
    if not isinstance(ci.get("bos_nationalityisocode"), list):
        val = ci.get("bos_nationalityisocode")
        ci["bos_nationalityisocode"] = [val] if val else []

    # ── Driver data arrays ───────────────────────────────────────────────
    employment_data = []
    company_data = []
    dividend_data = []
    investment_data = []
    property_data = []
    inheritance_data = []
    gift_data = []

    for idx, driver_key in enumerate(selected_drivers, 1):
        raw = driver_data.get(driver_key, {})
        ref_no = f"DR-{idx}"
        base = {"bos_cidnumber": cid, "sow_ref_no": ref_no}

        if driver_key == "client_employment_history":
            entry = {**base, "Emp_Order": float(idx), **_remap_fields(raw, _EMPLOYMENT_MAP)}
            employment_data.append(entry)

        elif driver_key == "client_company_history":
            entry = {**base, **_remap_fields(raw, _COMPANY_MAP)}
            company_data.append(entry)

        elif driver_key == "dividend":
            entry = {**base, **raw}
            dividend_data.append(entry)

        elif driver_key == "financial_investment":
            entry = {**base, **raw}
            investment_data.append(entry)

        elif driver_key == "property_sale":
            entry = {**base, **raw}
            property_data.append(entry)

        elif driver_key == "client_inheritance":
            entry = {**base, **raw}
            inheritance_data.append(entry)

        elif driver_key == "client_gift":
            entry = {**base, **raw}
            gift_data.append(entry)

    # ── CE mapping ───────────────────────────────────────────────────────
    ce_mapping = _build_ce_mapping(ce_file_mapping)

    # ── selected_drivers boolean map ─────────────────────────────────────
    sel_drivers = {k: (k in selected_drivers) for k in ALL_DRIVER_KEYS}

    return {
        "customer_id": cid,
        "client_info": ci,
        "client_employment_history": employment_data,
        "client_company_history": company_data,
        "dividend": dividend_data,
        "financial_investment": investment_data,
        "property_sale": property_data,
        "client_inheritance": inheritance_data,
        "client_gift": gift_data,
        "ce_mapping": ce_mapping,
        "selected_drivers": sel_drivers,
        "client": client_name,
        "process_id": process_id,
    }


def _build_ce_mapping(ce_file_mapping: Dict[str, List[str]]) -> Dict[str, Any]:
    """
    Transform frontend file mapping (CE_Class.field → [filepaths])
    into the extraction service ce_mapping format (folder → {field: [paths]}).
    """
    from schemas import DRIVER_REGISTRY

    # Build empty structure from DRIVER_REGISTRY
    ce_map: Dict[str, Any] = {
        "client_employment_company_journey": [],
    }

    for driver_key, cfg in DRIVER_REGISTRY.items():
        ce_model = cfg.get("ce_model")
        ce_folder = cfg.get("ce_folder", "")
        if ce_model is None:
            continue

        # Get all field names from the CE model
        folder_fields: Dict[str, List[str]] = {}
        for field_name in ce_model.model_fields:
            folder_fields[field_name] = []

        ce_map[ce_folder] = folder_fields

    # Fill in actual file paths from the frontend mapping
    # Frontend uses keys like "CE_SalariedEmployee.payslip" → [file paths]
    _CE_CLASS_TO_FOLDER = {
        "CE_SalariedEmployee": "salaried_employee",
        "CE_CompanyHoldings": "company_holdings",
        "CE_Property": "sale_of_property",
        "CE_Investment": "sale_of_investment",
        "CE_Dividend": "dividend_payment",
        "CE_Inheritance": "inheritance",
        "CE_Gift": "gift",
        "CE_SUR": "sur",
    }

    for field_path, file_paths in ce_file_mapping.items():
        parts = field_path.split(".", 1)
        if len(parts) != 2:
            continue
        ce_class, field_name = parts
        folder = _CE_CLASS_TO_FOLDER.get(ce_class, "")
        if folder and folder in ce_map and isinstance(ce_map[folder], dict):
            ce_map[folder][field_name] = file_paths

    return ce_map
