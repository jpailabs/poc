"""
HTTP client for the external CE extraction service.

Sends the built SoWCoPilotRequest payload to the configured extraction
endpoint and polls/streams the result. Configurable via config.yaml.
"""

from __future__ import annotations

import logging
import asyncio
from typing import Any, AsyncGenerator, Dict, Optional

import httpx

from services.config_loader import load_config

logger = logging.getLogger(__name__)


def _get_extraction_config() -> Dict[str, Any]:
    """Load extraction service config from config.yaml."""
    config = load_config()
    return config.get("EXTRACTION_SERVICE", {})


def is_external_extraction_enabled() -> bool:
    """Check if external extraction service is configured and enabled."""
    cfg = _get_extraction_config()
    return bool(cfg.get("enabled", False) and cfg.get("endpoint"))


async def submit_extraction(
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Submit payload to the external extraction service.

    Returns the initial response (may contain a job_id for polling).
    """
    cfg = _get_extraction_config()
    endpoint = cfg["endpoint"]
    timeout = cfg.get("timeout_seconds", 300)
    auth_token = cfg.get("auth_token", "")
    auth_header = cfg.get("auth_header", "Authorization")
    verify_ssl = cfg.get("verify_ssl", True)

    headers: Dict[str, str] = {"Content-Type": "application/json"}
    if auth_token:
        headers[auth_header] = auth_token

    logger.info("Submitting extraction to %s (timeout=%ds)", endpoint, timeout)

    async with httpx.AsyncClient(timeout=timeout, verify=verify_ssl) as client:
        resp = await client.post(endpoint, json=payload, headers=headers)
        resp.raise_for_status()
        return resp.json()


async def poll_extraction_status(
    job_id: str,
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Poll the extraction service for job status updates.

    Yields status events until completion or failure.
    """
    cfg = _get_extraction_config()
    status_endpoint = cfg.get("status_endpoint", "")
    poll_interval = cfg.get("poll_interval_seconds", 3)
    max_polls = cfg.get("max_poll_attempts", 200)
    auth_token = cfg.get("auth_token", "")
    auth_header = cfg.get("auth_header", "Authorization")
    verify_ssl = cfg.get("verify_ssl", True)

    if not status_endpoint:
        logger.warning("No status_endpoint configured, skipping polling")
        return

    headers: Dict[str, str] = {}
    if auth_token:
        headers[auth_header] = auth_token

    url = status_endpoint.replace("{job_id}", job_id)

    async with httpx.AsyncClient(timeout=30, verify=verify_ssl) as client:
        for attempt in range(max_polls):
            try:
                resp = await client.get(url, headers=headers)
                resp.raise_for_status()
                data = resp.json()

                status = data.get("status", "unknown")
                yield data

                if status in ("completed", "complete", "done", "failed", "error"):
                    return

            except Exception as e:
                logger.warning("Poll attempt %d failed: %s", attempt + 1, str(e))

            await asyncio.sleep(poll_interval)

    yield {"status": "failed", "error": "Max poll attempts exceeded"}


async def fetch_extraction_result(
    job_id: str,
) -> Dict[str, Any]:
    """
    Fetch the final extraction result from the service.
    """
    cfg = _get_extraction_config()
    result_endpoint = cfg.get("result_endpoint", "")
    auth_token = cfg.get("auth_token", "")
    auth_header = cfg.get("auth_header", "Authorization")
    verify_ssl = cfg.get("verify_ssl", True)

    if not result_endpoint:
        raise ValueError("No result_endpoint configured")

    url = result_endpoint.replace("{job_id}", job_id)

    headers: Dict[str, str] = {}
    if auth_token:
        headers[auth_header] = auth_token

    async with httpx.AsyncClient(timeout=60, verify=verify_ssl) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
        return resp.json()
