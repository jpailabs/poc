# SOWA — Source of Wealth Assistant

Enterprise document extraction and SOW report generation platform for private banking compliance.

## Project Structure

```
sowa/
├── backend/                 ← FastAPI backend (Python)
│   ├── main.py              Entry point
│   ├── auth/                Authentication (LDAP, Azure AD, OAuth2, demo)
│   ├── config/config.yaml   All configuration
│   ├── routers/             API route handlers
│   ├── services/            Business logic
│   ├── providers/           AI provider integrations
│   ├── prompts/             LLM prompt templates
│   ├── schemas.py           Pydantic models + DRIVER_REGISTRY
│   ├── database.py          SQLAlchemy models
│   ├── requirements.txt     Python dependencies
│   └── start_cml.sh         Cloudera CML startup script
│
├── frontend/                ← React frontend (TypeScript)
│   ├── src/                 Source code
│   ├── public/              Static assets
│   ├── dist/                Built output (after npm run build)
│   ├── package.json         Node dependencies
│   ├── vite.config.ts       Dev server + proxy config
│   ├── cml_app.py           Python static server for CML
│   └── start_cml.sh         Cloudera CML startup script
│
└── backup_20260711/         ← Backup of previous codebase
```

## Authentication

The backend supports multiple auth providers configured in `backend/config/config.yaml`:

| Provider | Config Value | Description |
|----------|-------------|-------------|
| Demo | `demo` | Built-in user `demo`/`gdo2024` (dev/testing) |
| LDAP | `ldap` | Active Directory / LDAP authentication |
| Azure AD | `azure_ad` | Microsoft Azure Active Directory (MSAL) |
| OAuth2 | `oauth2` | Generic OAuth2 ROPC flow |

To switch providers, edit `AUTH.provider` in `config.yaml` and fill in the corresponding credentials.

## Local Development

```bash
# Terminal 1: Backend
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Terminal 2: Frontend
cd frontend
npm install
npm run dev
# Open http://localhost:3000
# Login: demo / gdo2024
```

## Application Flow

1. **Login** → Authenticate via configured provider
2. **Intake** → Select wealth sources, upload documents, fill schema-driven forms
3. **Extract** → Click "Submit for Extraction" → triggers `POST /api/v1/extract`
4. **Verify** → Review extracted fields in editable table, correct if needed
5. **Generate** → Click "Confirm & Generate Report" → triggers `POST /api/v1/generate`
6. **Download** → Download PDF or DOCX report

## Cloudera CML Deployment

Deploy as **two separate CML Applications**:

### Service 1: Backend API
- **Script:** `backend/start_cml.sh`
- **Port:** Set by CML (`CDSW_APP_PORT`)
- **Requirements:** Python 3.10+

### Service 2: Frontend UI
- **Script:** `frontend/start_cml.sh`
- **Port:** Set by CML (`CDSW_APP_PORT`)
- **Requirements:** Python 3.10+ (serves static files via FastAPI)
- **Build step:** Run `cd frontend && npm run build` before deploying (or on CML if Node.js available)

### Environment Variables (Frontend)
Set `VITE_API_BASE_URL` to the backend service URL before building:
```bash
VITE_API_BASE_URL=https://sowa-backend.cml.company.com npm run build
```

### Environment Variables (Backend)
- `DATABASE_URL` — PostgreSQL connection string (optional, defaults to SQLite)
- Config is read from `backend/config/config.yaml`
